# OSMANX Retail Intelligence R2.0 — Journey Intelligence

**Five implemented workflows**, adding privacy-conscious in-store customer-journey observations. Source: manually recorded by authorized store operators. No cameras, faces, identity matching, automatic POS entries, payments, coupons, location trails or promises of financial return. No public deployment.

## Five working modules

1. **Anonymous visit cards and controlled stages.** `GET/POST /api/admin/r20/journeys`, `GET /journeys/{id}`, `POST /journeys/{id}/steps`. The owner/manager records `entered → browsing → inquired → assisting → assisted → purchased → exited`, with only allowed transitions. Direct `entered → purchased/exited` or `inquired → exited` remain permitted when stages are genuinely not observed. No names, phone numbers, photos, individual identifiers or camera feeds. Unique organization-scoped request keys return the original row or HTTP 409 on changed payload, and each transition is logged.

2. **Documented assistance time.** The back end timestamps assistance start/end and calculates seconds using server time. Unsupported or overly long sessions (over four hours) are rejected. The UI does not equate consultation time with wasted work and does not rank or punish staff. Unfinished assistance is reported separately, not counted as a completed journey.

3. **Existing POS evidence only.** `POST /api/admin/r20/journeys/{id}/verify-sale` checks the already stored `sales` record belongs to the same store, is within ±6 hours of the visit, is not marked demo and is not already used by another journey. The record is linked atomically under SQLite's writer lock. The API does **not** create any receipt or execute checkout. Linking a sale is an operator-provided documentary match; it is not proof the purchaser was the specific observed person.

4. **Hourly operational funnel.** `GET /api/admin/r20/funnel?slug=central&days=14`, `/funnel.csv` group only finished, manually recorded journeys by store-local hour: browsing/no purchase; asked/no purchase; assisted/no purchase; self-reported purchase not POS-confirmed; purchase linked to an existing POS record. Shows open records, assistance time, exit reasons, sample-size and coverage caveats. The denominator is *recorded visits*, not all footfall and never unique persons. Authenticated CSV prevents spreadsheet formula injection.

5. **Evidence-backed corrective decisions.** `GET/POST /api/admin/r20/actions`, `PATCH /actions/{id}`, `GET /actions/{id}/history`. A task can only be opened when at least three completed journeys support the same cohort in the chosen time window. It retains an aggregate evidence snapshot and SHA-256 integrity digest. Explicit roles, due dates and audited `open → investigating → completed` or dismissal transitions. A stored task status does not prove profit or causation.

## Interfaces

- `/static/journey.html` — native Russian responsive app with five live tabs: Визиты, Консультации, Чеки, Воронка, Решения. Actual FastAPI/SQLite read/write operations. Existing dark-navy and muted red brand system, no fake numbers.
- `frontend/r20_nav.js` adds the shortcut without replacing existing sidebar event handlers.

## Security and known limits

- All endpoints use existing authenticated admin sessions. Writes require `owner` or `manager`, and every resource is checked against the user's organization and assigned branch.
- Customer journeys may be incomplete or recorded more than once. Do not estimate store-wide conversion or lost revenue from this data alone.
- POS links require an authorized operator. They do not identify the actual paying individual. Later physical integrations would require separate privacy and hardware validation.
- Event timestamps and durations come from the server. Data use SQLite foreign keys and bounded periods; retention and deletion policies for this new anonymous dataset must be configured before production.
- The module adds new tables and does not replace R1.9 terminal scheduling, anonymous Voice Studio or existing surveys.

## Verification

```bash
python -m pytest tests/test_r20.py -q
python -m compileall -q backend scripts
node --check frontend/journey.js
node --check frontend/r20_nav.js
python scripts/r20_browser_smoke.py
```

The Chromium test uses a real FastAPI TestClient connected to an isolated SQLite file; it verifies complete UI flows, CSV, persistence and desktop/mobile widths (1440/390 px). It does not publish a public site or test physical hardware.

## Anonymous-visit retention

`python -m scripts.purge_journeys_r20` runs a dry-run showing records older than the store-specific retention policy (7–365 days, default 90). Add `--apply` for one atomic deletion of old visit cards, their event history and POS cross-links. Aggregate management actions and audit events are retained separately for accountability. The cleanup is not automatically scheduled; operators must configure and execute it according to their privacy requirements before production use.
