"""OSMANX R2.0 Journey Intelligence.

Human-entered, short-lived visit observations; no faces, identities, cameras,
marketing profiles, contacts or inference of individual intentions.
Five flows: visits, assisted-time, POS evidence, aggregated funnels and actions.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import sqlite3
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from typing import Literal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field

from backend.database import now_iso
from backend.retail import safe_spreadsheet_cell
from backend.security import Principal, audit, check_store_access, require_role, visible_store

DDL = """
CREATE TABLE IF NOT EXISTS journey_sessions_r20 (
 id INTEGER PRIMARY KEY,
 organization_id INTEGER NOT NULL REFERENCES organizations(id),
 store_id INTEGER NOT NULL REFERENCES stores(id),
 request_id TEXT NOT NULL,
 stage TEXT NOT NULL DEFAULT 'entered' CHECK(stage IN ('entered','browsing','inquired','assisting','assisted','purchased','exited')),
 started_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 finished_at TEXT,
 assistance_started_at TEXT,
 assistance_seconds INTEGER NOT NULL DEFAULT 0 CHECK(assistance_seconds BETWEEN 0 AND 14400),
 asked INTEGER NOT NULL DEFAULT 0 CHECK(asked IN (0,1)),
 helped INTEGER NOT NULL DEFAULT 0 CHECK(helped IN (0,1)),
 purchase_reported INTEGER NOT NULL DEFAULT 0 CHECK(purchase_reported IN (0,1)),
 verified_sale_id INTEGER UNIQUE REFERENCES sales(id),
 exit_reason TEXT CHECK(exit_reason IS NULL OR exit_reason IN ('browsing','missing_size','price','service','other','unknown')),
 UNIQUE(organization_id, request_id)
);
CREATE INDEX IF NOT EXISTS journey_session_store_time_r20 ON journey_sessions_r20(store_id,started_at);
CREATE TABLE IF NOT EXISTS journey_steps_r20 (
 id INTEGER PRIMARY KEY,
 session_id INTEGER NOT NULL REFERENCES journey_sessions_r20(id),
 request_id TEXT NOT NULL,
 payload_sha TEXT NOT NULL,
 event TEXT NOT NULL CHECK(event IN ('browse','inquire','assist_start','assist_end','purchase','exit')),
 previous_stage TEXT NOT NULL, next_stage TEXT NOT NULL,
 created_at TEXT NOT NULL,
 UNIQUE(session_id,request_id)
);
CREATE INDEX IF NOT EXISTS journey_steps_session_r20 ON journey_steps_r20(session_id,created_at);
CREATE TABLE IF NOT EXISTS journey_sale_evidence_r20 (
 id INTEGER PRIMARY KEY,
 session_id INTEGER NOT NULL UNIQUE REFERENCES journey_sessions_r20(id),
 sale_id INTEGER NOT NULL UNIQUE REFERENCES sales(id),
 checked_at TEXT NOT NULL, checked_by INTEGER
);
CREATE TABLE IF NOT EXISTS journey_actions_r20 (
 id INTEGER PRIMARY KEY,
 organization_id INTEGER NOT NULL REFERENCES organizations(id),
 store_id INTEGER NOT NULL REFERENCES stores(id),
 request_id TEXT NOT NULL,
 payload_sha TEXT NOT NULL,
 title TEXT NOT NULL,
 owner TEXT NOT NULL,
 category TEXT NOT NULL CHECK(category IN ('browsing','asked_no_purchase','helped_no_purchase','purchase_unverified','other')),
 due_date TEXT NOT NULL,
 evidence_json TEXT NOT NULL, evidence_sha TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','investigating','completed','dismissed')),
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 UNIQUE(organization_id,request_id)
);
CREATE INDEX IF NOT EXISTS journey_actions_store_r20 ON journey_actions_r20(store_id,status,due_date);
CREATE TABLE IF NOT EXISTS journey_action_history_r20 (
 id INTEGER PRIMARY KEY,
 action_id INTEGER NOT NULL REFERENCES journey_actions_r20(id),
 previous_status TEXT NOT NULL, next_status TEXT NOT NULL,
 note TEXT NOT NULL, changed_at TEXT NOT NULL, actor_id INTEGER
);
"""

REASONS = ('browsing','missing_size','price','service','other','unknown')
EVIDENCE_CATEGORIES = ('browsing','asked_no_purchase','helped_no_purchase','purchase_unverified','other')


def ensure_schema(db: sqlite3.Connection) -> None:
    db.executescript(DDL)


def canonical(value: object) -> str:
    return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'))


def digest(value: object) -> str:
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


def dt(value: str) -> datetime:
    try:
        date=datetime.fromisoformat(value)
        if date.tzinfo is None:raise ValueError('Timezone is required')
        return date.astimezone(timezone.utc)
    except (ValueError,TypeError,OverflowError):
        raise HTTPException(409,'Некорректная дата зарегистрированного события') from None


def store_tz(store:sqlite3.Row):
    try:return ZoneInfo(store['timezone'] or 'UTC')
    except (ZoneInfoNotFoundError,KeyError):return timezone.utc


def _session(db,sid:int,principal:Principal):
    row=db.execute('SELECT * FROM journey_sessions_r20 WHERE id=? AND organization_id=?',(sid,principal.organization_id)).fetchone()
    if row is None:raise HTTPException(404,'Визит не найден')
    check_store_access(db,row['store_id'],principal)
    return row


def _action(db,aid:int,principal:Principal):
    row=db.execute('SELECT * FROM journey_actions_r20 WHERE id=? AND organization_id=?',(aid,principal.organization_id)).fetchone()
    if row is None:raise HTTPException(404,'Решение не найдено')
    check_store_access(db,row['store_id'],principal)
    return row


def _one(db,principal,event,subject):
    audit(db,principal,'r20.'+event,str(subject))


class StartIn(BaseModel):
    slug: str = Field(default='central',min_length=1,max_length=60)
    request_id: str = Field(min_length=16,max_length=100)


class StepIn(BaseModel):
    request_id: str = Field(min_length=16,max_length=100)
    event: Literal['browse','inquire','assist_start','assist_end','purchase','exit']
    reason: Literal['browsing','missing_size','price','service','other','unknown']|None = None


class VerifyIn(BaseModel):
    sale_id: int = Field(gt=0)


class ActionIn(BaseModel):
    slug: str = 'central'
    request_id: str = Field(min_length=16,max_length=100)
    title: str = Field(min_length=12,max_length=180)
    owner: str = Field(min_length=3,max_length=100)
    category: Literal['browsing','asked_no_purchase','helped_no_purchase','purchase_unverified','other']
    due_date: str = Field(min_length=10,max_length=10,pattern=r'^\d{4}-\d{2}-\d{2}$')
    days: int = Field(default=14,ge=1,le=90)


class ActionStatusIn(BaseModel):
    status: Literal['investigating','completed','dismissed']
    note: str = Field(min_length=12,max_length=600)


def _step(row,kind,reason,at):
    """Server-owned state machine: people and outcomes cannot be inferred from sensors."""
    old=row['stage'];next_stage=old
    if kind=='exit':
        if old=='exited':raise HTTPException(409,'Визит уже завершён')
        if old=='assisting':raise HTTPException(409,'Сначала завершите консультацию')
        if reason is None:raise HTTPException(422,'Нужно указать причину завершения')
        if row['purchase_reported'] and reason not in ('other','unknown'):
            raise HTTPException(422,'Причина отказа не подходит для отмеченной покупки')
        next_stage='exited'
    else:
        if reason is not None:raise HTTPException(422,'Причина нужна только для выхода')
        if old=='exited':raise HTTPException(409,'Визит уже завершён')
        if kind=='browse' and old=='entered':next_stage='browsing'
        elif kind=='inquire' and old in ('entered','browsing'):next_stage='inquired'
        elif kind=='assist_start' and old=='inquired':next_stage='assisting'
        elif kind=='assist_end' and old=='assisting':next_stage='assisted'
        elif kind=='purchase' and old in ('entered','browsing','inquired','assisted'):next_stage='purchased'
        else:raise HTTPException(409,'Недопустимый порядок действий: '+kind)
    seconds=row['assistance_seconds'];start=row['assistance_started_at'];asked=row['asked'];helped=row['helped'];purchased=row['purchase_reported']
    if kind=='inquire':asked=1
    if kind=='assist_start':start=at
    if kind=='assist_end':
        elapsed=int((dt(at)-dt(start)).total_seconds()) if start else -1
        if not 0<=elapsed<=4*3600 or seconds+elapsed>4*3600:
            raise HTTPException(409,'Время консультации превышает 4 часа — нужна проверка записи')
        seconds+=elapsed;start=None;helped=1
    if kind=='purchase':purchased=1
    return {'stage':next_stage,'reason':reason if kind=='exit' else row['exit_reason'],
            'start':start,'seconds':seconds,'asked':asked,'helped':helped,'purchased':purchased,
            'finished_at':at if kind=='exit' else row['finished_at']}


def _cohort(row):
    if row['purchase_reported']:
        return 'purchased_verified' if row['verified_sale_id'] else 'purchase_unverified'
    if row['helped']:return 'helped_no_purchase'
    if row['asked']:return 'asked_no_purchase'
    if row['stage']=='exited':return 'browsing'
    return 'other'


def funnel(db,store,days:int):
    if not 1<=days<=90:raise HTTPException(422,'Период должен быть от 1 до 90 дней')
    cutoff=(datetime.now(timezone.utc)-timedelta(days=days)).isoformat(timespec='seconds')
    # Only finalized visits count as outcomes. Open sessions are a separate metric.
    rows=db.execute('SELECT * FROM journey_sessions_r20 WHERE store_id=? AND started_at>=? ORDER BY id LIMIT 20001',
                    (store['id'],cutoff)).fetchall()
    if len(rows)>20000:raise HTTPException(413,'Слишком много записей: сократите период')
    groups=Counter();hours=defaultdict(Counter);reason=Counter();total_seconds=0;assisted=0
    complete=0;open_sessions=0;reported=0;verified=0
    for r in rows:
        if r['stage']!='exited':open_sessions+=1;continue
        complete+=1;cohort=_cohort(r);groups[cohort]+=1
        local=dt(r['started_at']).astimezone(store_tz(store))
        bucket=f'{local.hour:02d}:00';hours[bucket][cohort]+=1;hours[bucket]['total']+=1
        if r['exit_reason'] and not r['purchase_reported']:reason[r['exit_reason']]+=1
        if r['asked']:assisted+=1
        total_seconds+=r['assistance_seconds']
        if r['purchase_reported']:reported+=1
        if r['verified_sale_id']:verified+=1
    result={k:groups[k] for k in ('browsing','asked_no_purchase','helped_no_purchase','purchase_unverified','purchased_verified')}
    result['other']=groups['other']
    warnings=['Воронка охватывает только вручную зафиксированные визиты, не всех посетителей магазина.',
              'Один человек может быть учтён более одного раза. Нельзя отслеживать личность или делать выводы по камере.',
              'Подтверждение продажи означает соответствие существующему чеку, а не независимое установление личности покупателя.']
    if complete<30:warnings.append('Менее 30 завершённых визитов; доли неустойчивы.')
    if open_sessions:warnings.append('Есть незавершённые карточки; они не включены в результаты.')
    if reported>verified:warnings.append('Часть отмеченных покупок пока не подтверждена чеками.')
    total=sum(groups.values())
    by_hour=[{'hour':h,'count':cnt['total'],**{k:cnt[k] for k in result}} for h,cnt in sorted(hours.items())]
    return {'store':store['slug'],'days':days,'completed':complete,'open':open_sessions,
            'cohorts':result,'by_hour':by_hour,'exit_reasons':[{'code':k,'count':v} for k,v in reason.most_common()],
            'assisted_seconds':total_seconds,'assisted_visit_count':assisted,'reported_purchases':reported,
            'pos_evidenced_purchases':verified,'sample_completion_pct':round(100*complete/len(rows),1) if rows else None,
            'warnings':warnings,'methodology':'Простая ручная регистрация действий, без идентификации посетителей и без оценки потерянной выручки.'}


def action_evidence(report,cat):
    value=report['cohorts'].get(cat,0)
    if cat=='other':value=report['cohorts']['other']
    return {'store':report['store'],'days':report['days'],'cohort':cat,'support':value,
            'completed':report['completed'],'recorded_at':now_iso(),'source':'journey_sessions_r20'}


def csv_safe(items,keys):
    out=io.StringIO(newline='');writer=csv.writer(out)
    writer.writerow(keys)
    for item in items:writer.writerow([safe_spreadsheet_cell(item.get(k,'')) for k in keys])
    return '\ufeff'+out.getvalue()


def build_router(admin,db_conn):
    router=APIRouter(prefix='/api/admin/r20',tags=['R2.0 Journey Intelligence'])

    @router.get('/journeys')
    def list_journeys(slug:str='central',principal:Principal=Depends(admin),db:sqlite3.Connection=Depends(db_conn)):
        store=visible_store(db,slug,principal)
        rows=db.execute('SELECT * FROM journey_sessions_r20 WHERE store_id=? ORDER BY id DESC LIMIT 100',(store['id'],)).fetchall()
        return {'items':[{**dict(x),'cohort':_cohort(x)} for x in rows]}

    @router.post('/journeys',status_code=201)
    def start(body:StartIn,principal:Principal=Depends(admin),db:sqlite3.Connection=Depends(db_conn)):
        require_role(principal,'owner','manager')
        try:
            db.execute('BEGIN IMMEDIATE')
            store=visible_store(db,body.slug,principal)
            prev=db.execute('SELECT * FROM journey_sessions_r20 WHERE organization_id=? AND request_id=?',
                            (principal.organization_id,body.request_id)).fetchone()
            if prev:
                if prev['store_id']!=store['id']:raise HTTPException(409,'Ключ уже использован в другом филиале')
                db.commit();return {'id':prev['id'],'duplicate':True,'stage':prev['stage']}
            stamp=now_iso()
            row=db.execute('INSERT INTO journey_sessions_r20(organization_id,store_id,request_id,started_at,updated_at) VALUES(?,?,?,?,?)',
                           (principal.organization_id,store['id'],body.request_id,stamp,stamp))
            _one(db,principal,'journey.start',row.lastrowid);db.commit()
            return {'id':row.lastrowid,'stage':'entered','duplicate':False}
        except Exception:db.rollback();raise

    @router.get('/journeys/{sid}')
    def journey(sid:int,principal:Principal=Depends(admin),db:sqlite3.Connection=Depends(db_conn)):
        row=_session(db,sid,principal)
        history=[dict(x) for x in db.execute('SELECT event,previous_stage,next_stage,created_at FROM journey_steps_r20 WHERE session_id=? ORDER BY id',(sid,))]
        return {'journey':{**dict(row),'cohort':_cohort(row)},'history':history}

    @router.post('/journeys/{sid}/steps',status_code=201)
    def step(sid:int,body:StepIn,principal:Principal=Depends(admin),db:sqlite3.Connection=Depends(db_conn)):
        require_role(principal,'owner','manager');spec=body.model_dump(mode='json');signature=digest(spec)
        try:
            db.execute('BEGIN IMMEDIATE');row=_session(db,sid,principal)
            old=db.execute('SELECT * FROM journey_steps_r20 WHERE session_id=? AND request_id=?',(sid,body.request_id)).fetchone()
            if old:
                if old['payload_sha']!=signature:raise HTTPException(409,'Ключ операции повторён с другими данными')
                db.commit();return {'id':old['id'],'stage':old['next_stage'],'duplicate':True}
            stamp=now_iso();new=_step(row,body.event,body.reason,stamp)
            op=db.execute('INSERT INTO journey_steps_r20(session_id,request_id,payload_sha,event,previous_stage,next_stage,created_at) VALUES(?,?,?,?,?,?,?)',
                           (sid,body.request_id,signature,body.event,row['stage'],new['stage'],stamp))
            db.execute('''UPDATE journey_sessions_r20 SET stage=?,updated_at=?,assistance_started_at=?,assistance_seconds=?,
                        asked=?,helped=?,purchase_reported=?,finished_at=?,exit_reason=? WHERE id=?''',
                       (new['stage'],stamp,new['start'],new['seconds'],new['asked'],new['helped'],new['purchased'],new['finished_at'],new['reason'],sid))
            _one(db,principal,'journey.step',f'{sid}:{body.event}');db.commit()
            return {'id':op.lastrowid,'stage':new['stage'],'duplicate':False,'assistance_seconds':new['seconds']}
        except Exception:db.rollback();raise

    @router.post('/journeys/{sid}/verify-sale')
    def verify(sid:int,body:VerifyIn,principal:Principal=Depends(admin),db:sqlite3.Connection=Depends(db_conn)):
        require_role(principal,'owner','manager')
        try:
            db.execute('BEGIN IMMEDIATE');row=_session(db,sid,principal)
            if not row['purchase_reported']:raise HTTPException(409,'Визит не отмечен как покупка')
            if row['verified_sale_id']:
                if row['verified_sale_id']!=body.sale_id:raise HTTPException(409,'К этому визиту уже привязан другой чек')
                db.commit();return {'verified':True,'duplicate':True,'sale_id':body.sale_id}
            sale=db.execute('SELECT * FROM sales WHERE id=? AND store_id=?',(body.sale_id,row['store_id'])).fetchone()
            if sale is None:raise HTTPException(404,'Чек не найден в этом филиале')
            if sale['source'].casefold().startswith('demo'):raise HTTPException(409,'Демонстрационный чек нельзя считать подтверждением')
            if abs((dt(sale['occurred_at'])-dt(row['started_at'])).total_seconds())>6*3600:
                raise HTTPException(409,'Чек вне шестичасового интервала визита')
            used=db.execute('SELECT 1 FROM journey_sale_evidence_r20 WHERE sale_id=?',(body.sale_id,)).fetchone()
            if used:raise HTTPException(409,'Этот чек уже связан с другим визитом')
            db.execute('INSERT INTO journey_sale_evidence_r20(session_id,sale_id,checked_at,checked_by) VALUES(?,?,?,?)',
                       (sid,body.sale_id,now_iso(),principal.user_id if not principal.demo else None))
            db.execute('UPDATE journey_sessions_r20 SET verified_sale_id=?,updated_at=? WHERE id=?',
                       (body.sale_id,now_iso(),sid))
            _one(db,principal,'journey.sale_evidence',sid);db.commit()
            return {'verified':True,'duplicate':False,'sale_id':body.sale_id,'note':'Это сверка с существующим чеком, не идентификация покупателя.'}
        except sqlite3.IntegrityError:
            db.rollback();raise HTTPException(409,'Чек уже связан с другим визитом') from None
        except Exception:db.rollback();raise

    @router.get('/funnel')
    def funnel_get(slug:str='central',days:int=14,principal:Principal=Depends(admin),db:sqlite3.Connection=Depends(db_conn)):
        store=visible_store(db,slug,principal);return funnel(db,store,days)

    @router.get('/funnel.csv')
    def funnel_csv(slug:str='central',days:int=14,principal:Principal=Depends(admin),db:sqlite3.Connection=Depends(db_conn)):
        report=funnel(db,visible_store(db,slug,principal),days)
        records=[{'type':'cohort','label':k,'count':v,'hour':''} for k,v in report['cohorts'].items()]
        records += [{'type':'hour','label':'registered_journeys','count':x['count'],'hour':x['hour']} for x in report['by_hour']]
        return Response(csv_safe(records,['type','label','count','hour']),media_type='text/csv; charset=utf-8',
                        headers={'Cache-Control':'no-store','Content-Disposition':'attachment; filename="osmanx-journey-funnel.csv"'})

    @router.get('/actions')
    def list_actions(slug:str='central',principal:Principal=Depends(admin),db:sqlite3.Connection=Depends(db_conn)):
        store=visible_store(db,slug,principal)
        return {'items':[{**dict(x),'evidence_valid':digest(json.loads(x['evidence_json']))==x['evidence_sha']} for x in
                  db.execute('SELECT * FROM journey_actions_r20 WHERE store_id=? ORDER BY id DESC LIMIT 100',(store['id'],))]}

    @router.post('/actions',status_code=201)
    def create_action(body:ActionIn,principal:Principal=Depends(admin),db:sqlite3.Connection=Depends(db_conn)):
        require_role(principal,'owner','manager')
        try:due=datetime.strptime(body.due_date,'%Y-%m-%d').date()
        except ValueError:raise HTTPException(422,'Дата должна существовать') from None
        if due<datetime.now(timezone.utc).date() or due>datetime.now(timezone.utc).date()+timedelta(days=366):
            raise HTTPException(422,'Срок задачи должен быть в пределах года')
        spec=body.model_dump(mode='json')
        if not body.title.strip() or not body.owner.strip():raise HTTPException(422,'Нужно заполнить действие и ответственного')
        try:
            db.execute('BEGIN IMMEDIATE');store=visible_store(db,body.slug,principal)
            old=db.execute('SELECT * FROM journey_actions_r20 WHERE organization_id=? AND request_id=?',
                           (principal.organization_id,body.request_id)).fetchone()
            signature=digest({**spec,'store_id':store['id']})
            if old:
                if old['payload_sha']!=signature:raise HTTPException(409,'Ключ решения уже занят другой записью')
                db.commit();return {'id':old['id'],'duplicate':True}
            report=funnel(db,store,body.days);proof=action_evidence(report,body.category)
            if proof['support']<3:raise HTTPException(409,'Для решения нужно минимум три завершённых визита соответствующего типа')
            stamp=now_iso();row=db.execute('''INSERT INTO journey_actions_r20(organization_id,store_id,request_id,payload_sha,
               title,owner,category,due_date,evidence_json,evidence_sha,created_at,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
                (principal.organization_id,store['id'],body.request_id,signature,body.title.strip(),body.owner.strip(),body.category,
                 body.due_date,canonical(proof),digest(proof),stamp,stamp))
            _one(db,principal,'action.create',row.lastrowid);db.commit()
            return {'id':row.lastrowid,'duplicate':False,'evidence':proof}
        except Exception:db.rollback();raise

    @router.patch('/actions/{aid}')
    def update_action(aid:int,body:ActionStatusIn,principal:Principal=Depends(admin),db:sqlite3.Connection=Depends(db_conn)):
        require_role(principal,'owner','manager')
        if len(body.note.strip())<12:raise HTTPException(422,'Нужно описать подтверждение')
        try:
            db.execute('BEGIN IMMEDIATE');row=_action(db,aid,principal)
            valid={'open':('investigating','dismissed'),'investigating':('completed','dismissed')}
            if body.status not in valid.get(row['status'],()):raise HTTPException(409,'Переход статуса запрещён')
            if digest(json.loads(row['evidence_json']))!=row['evidence_sha']:
                raise HTTPException(409,'Контрольная сумма доказательства нарушена')
            stamp=now_iso()
            db.execute('UPDATE journey_actions_r20 SET status=?,updated_at=? WHERE id=?',(body.status,stamp,aid))
            db.execute('INSERT INTO journey_action_history_r20(action_id,previous_status,next_status,note,changed_at,actor_id) VALUES(?,?,?,?,?,?)',
                       (aid,row['status'],body.status,body.note.strip(),stamp,principal.user_id if not principal.demo else None))
            _one(db,principal,'action.status',aid);db.commit()
            return {'id':aid,'status':body.status,'note':'Отметка выполнения не подтверждает экономический эффект.'}
        except Exception:db.rollback();raise

    @router.get('/actions/{aid}/history')
    def action_history(aid:int,principal:Principal=Depends(admin),db:sqlite3.Connection=Depends(db_conn)):
        _action(db,aid,principal)
        return {'items':[dict(x) for x in db.execute('SELECT previous_status,next_status,note,changed_at FROM journey_action_history_r20 WHERE action_id=? ORDER BY id',(aid,))]}

    return router
