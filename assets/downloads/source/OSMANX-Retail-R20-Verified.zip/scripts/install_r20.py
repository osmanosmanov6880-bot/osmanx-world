"""Repeatable, additive integration into an actual R1.9 OSMANX source checkout.

Refuses unexpected anchors; does not migrate real data or deploy a server.
"""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def patch(path: str,old: str,new: str):
    item=ROOT/path
    text=item.read_text(encoding='utf-8')
    if new in text:return False
    if old not in text:raise RuntimeError(f'Unexpected {path} structure: {old[:80]!r}')
    item.write_text(text.replace(old,new,1),encoding='utf-8')
    return True

def main():
    path='backend/app.py'
    patch(path,'from backend.r19 import ensure_schema as ensure_r19_schema, build_router as r19_router',
          'from backend.r19 import ensure_schema as ensure_r19_schema, build_router as r19_router\nfrom backend.r20 import ensure_schema as ensure_r20_schema, build_router as r20_router')
    patch(path,'        ensure_r19_schema(db)\n','        ensure_r19_schema(db)\n        ensure_r20_schema(db)\n')
    patch(path,'app.include_router(r19_router(admin, db_conn))',
          'app.include_router(r19_router(admin, db_conn))\napp.include_router(r20_router(admin, db_conn))')
    patch(path,'version="1.9.0"','version="2.0.0"')
    patch('frontend/index.html','</body>','  <script src="/static/r20_nav.js" defer></script>\n</body>')
    print('R2.0 registered. Run API, browser and regression tests before deployment.')

if __name__=='__main__':main()
