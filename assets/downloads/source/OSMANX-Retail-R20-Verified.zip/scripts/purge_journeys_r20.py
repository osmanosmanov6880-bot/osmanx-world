"""Conservative, opt-in retention cleanup for anonymous Journey Intelligence.

Dry-run by default. Uses the store survey_retention_days when available, else
90 days. Removes event details and POS link checks before removing visit cards;
keeps aggregate management action evidence and audit records separately.
"""
from __future__ import annotations

import argparse
import sqlite3
from datetime import datetime,timedelta,timezone

from backend.database import connect


def purge(db:sqlite3.Connection,apply:bool=False,now:datetime|None=None):
    moment=now or datetime.now(timezone.utc)
    if moment.tzinfo is None:raise ValueError('now must be timezone aware')
    results=[]
    for store in db.execute('SELECT * FROM stores ORDER BY id').fetchall():
        try:retention=int(store['survey_retention_days'])
        except (IndexError,KeyError,TypeError):retention=90
        retention=max(7,min(365,retention))
        cutoff=(moment.astimezone(timezone.utc)-timedelta(days=retention)).isoformat(timespec='seconds')
        count=db.execute('SELECT COUNT(*) FROM journey_sessions_r20 WHERE store_id=? AND updated_at<?',
                         (store['id'],cutoff)).fetchone()[0]
        results.append({'store_id':store['id'],'store':store['slug'],'retention_days':retention,
                        'cutoff':cutoff,'sessions':count})
    if apply:
        try:
            db.execute('BEGIN IMMEDIATE')
            for row in results:
                params=(row['store_id'],row['cutoff'])
                selector='SELECT id FROM journey_sessions_r20 WHERE store_id=? AND updated_at<?'
                db.execute('DELETE FROM journey_steps_r20 WHERE session_id IN ('+selector+')',params)
                db.execute('DELETE FROM journey_sale_evidence_r20 WHERE session_id IN ('+selector+')',params)
                db.execute('DELETE FROM journey_sessions_r20 WHERE store_id=? AND updated_at<?',params)
            db.commit()
        except Exception:db.rollback();raise
    return results


def main():
    parser=argparse.ArgumentParser(description='R2.0 anonymous journey cleanup; dry-run by default')
    parser.add_argument('--apply',action='store_true',help='Permanently delete eligible observations')
    args=parser.parse_args()
    with connect() as db:
        data=purge(db,apply=args.apply)
    print('Applied' if args.apply else 'Dry-run')
    for row in data:print(row['store'],row['sessions'],'old observations',row['retention_days'],'day retention')

if __name__=='__main__':main()
