"""R2.0 Chromium end-to-end test using live FastAPI TestClient + isolated SQLite.

No public internet or hardware is used. Captures 1440px and 390px UI screens.
"""
from __future__ import annotations

import os
import shutil
import sys
import tempfile
from pathlib import Path

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.testclient import TestClient
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
QA=ROOT/'qa';QA.mkdir(exist_ok=True)


def main():
    with tempfile.TemporaryDirectory(prefix='osmanx-r20-browser-') as tmp:
        os.environ['OSMANX_DATA_DIR']=tmp
        os.environ['OSMANX_DEMO_MODE']='0'
        os.environ['OSMANX_ADMIN_PASSWORD']='bootstrap-super-secret-2026'
        os.environ['OSMANX_BOOTSTRAP_EMAIL']='owner@osmanx.local'
        from backend.database import connect,initialize_db,now_iso
        from backend.security import Principal
        from backend.r20 import ensure_schema,build_router
        initialize_db(demo=False)
        with connect() as db:ensure_schema(db);db.commit()
        def db_conn():
            with connect() as db:yield db
        def principal(authorization:str|None=Header(default=None)):
            if authorization and authorization!='Bearer demo-owner':raise HTTPException(401,'Invalid session')
            return Principal(1,1,'owner@osmanx.local','owner')
        app=FastAPI();app.include_router(build_router(principal,db_conn))
        with TestClient(app) as client,sync_playwright() as playwright:
            browser=playwright.chromium.launch(headless=True,executable_path=shutil.which('chromium') or None,args=['--no-sandbox','--disable-dev-shm-usage'])
            try:
                def screen(width,height):
                    page=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1,accept_downloads=True)
                    errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
                    def call_api(method,url,body,headers):
                        res=client.request(method,url,json=body,headers=headers or {}) if body is not None else client.request(method,url,headers=headers or {})
                        return {'status':res.status_code,'text':res.text,'type':res.headers.get('content-type','application/json')}
                    page.expose_function('__api_call',call_api)
                    html=(ROOT/'frontend/journey.html').read_text()
                    html=html.replace('<link rel="stylesheet" href="/static/journey.css">','').replace('<script src="/static/journey.js" defer></script>','')
                    html=html.replace('</head>','<style>'+(ROOT/'frontend/journey.css').read_text()+'</style></head>')
                    page.set_content(html,wait_until='domcontentloaded')
                    page.evaluate('''() => {window.__OSMANX_SESSION__={getItem(){return null}};
                      window.fetch=async(path,opts={})=>{const response=await window.__api_call(opts.method||'GET',path,opts.body?JSON.parse(opts.body):null,opts.headers||{});
                      return new Response(response.text,{status:response.status,headers:{'Content-Type':response.type}});}
                    }''')
                    javascript=(ROOT/'frontend/journey.js').read_text().replace('sessionStorage','window.__OSMANX_SESSION__')
                    page.add_script_tag(content=javascript)
                    page.locator('.hero h1').wait_for(timeout=15000)
                    return page,errors

                desktop,errors=screen(1440,900)
                desktop.screenshot(path=str(QA/'r20-capture-desktop.png'),full_page=True)
                desktop.locator('#new-journey').click()
                desktop.locator('[data-step=inquire]').wait_for(timeout=12000)
                desktop.locator('[data-step=inquire]').click()
                desktop.get_by_role('tab',name='02 / Консультации').click()
                desktop.locator('[data-step=assist_start]').click()
                desktop.screenshot(path=str(QA/'r20-assistance-desktop.png'),full_page=True)
                desktop.locator('[data-step=assist_end]').click()
                desktop.get_by_role('tab',name='01 / Визиты').click()
                desktop.locator('[data-step=purchase]').click()
                desktop.locator('#exit-form [name=reason]').select_option('unknown')
                desktop.locator('#exit-form button[type=submit]').click()
                with connect() as db:
                    sale=db.execute('INSERT INTO sales(store_id,amount_kopeks,source,occurred_at,external_id) VALUES(?,?,?,?,?)',
                      (1,345000,'pos',now_iso(),'r20-browser-sale')).lastrowid
                    db.commit()
                desktop.get_by_role('tab',name='03 / Чеки').click()
                desktop.locator('#verify-form [name=sale_id]').fill(str(sale))
                desktop.locator('#verify-form button[type=submit]').click()
                desktop.get_by_text('Чек найден в кассе').first.wait_for()
                desktop.screenshot(path=str(QA/'r20-sales-desktop.png'),full_page=True)

                # Three anonymous walk-ins who browsed without buying.
                desktop.get_by_role('tab',name='01 / Визиты').click()
                for i in range(3):
                    desktop.locator('#new-journey').click()
                    desktop.locator('#exit-form').wait_for()
                    desktop.locator('#exit-form button[type=submit]').click()
                    desktop.get_by_text('Визит завершён',exact=False).first.wait_for()
                desktop.get_by_role('tab',name='04 / Воронка').click()
                desktop.get_by_text('Смотрел и ушёл').first.wait_for()
                desktop.screenshot(path=str(QA/'r20-funnel-desktop.png'),full_page=True)
                with desktop.expect_download(timeout=15000) as download:
                    desktop.locator('#csv').click()
                assert download.value.suggested_filename=='osmanx-journey-funnel.csv'
                desktop.get_by_role('tab',name='05 / Решения').click()
                desktop.locator('#new-action input[name=title]').fill('Проверить потребности посетителей после осмотра')
                desktop.locator('#new-action input[name=owner]').fill('Управляющий')
                # Use browser local date + 7 days.
                desktop.locator('#new-action input[name=due_date]').fill((__import__('datetime').date.today()+__import__('datetime').timedelta(days=7)).isoformat())
                desktop.locator('#new-action button[type=submit]').click()
                desktop.get_by_text('Управленческая задача создана').wait_for(timeout=15000)
                desktop.locator('[data-action][data-status=investigating]').click()
                desktop.locator('#action-status textarea').fill('Проверили выкладку и наличие размеров по складу')
                desktop.locator('#action-status button[type=submit]').click()
                desktop.get_by_text('Статус сохранён в истории').wait_for(timeout=15000)
                desktop.screenshot(path=str(QA/'r20-actions-desktop.png'),full_page=True)
                assert errors==[],errors
                desktop.close()

                phone,errors=screen(390,844)
                phone.screenshot(path=str(QA/'r20-capture-mobile.png'),full_page=True)
                phone.get_by_role('tab',name='04 / Воронка').click()
                phone.screenshot(path=str(QA/'r20-funnel-mobile.png'),full_page=True)
                phone.get_by_role('tab',name='05 / Решения').click()
                phone.screenshot(path=str(QA/'r20-actions-mobile.png'),full_page=True)
                size=phone.evaluate('({page:document.documentElement.scrollWidth,screen:innerWidth})')
                assert size['page']<=size['screen']+2,size
                assert errors==[],errors
                phone.close()
                with connect() as db:
                    assert db.execute('SELECT COUNT(*) FROM journey_sessions_r20 WHERE stage="exited"').fetchone()[0]==4
                    assert db.execute('SELECT COUNT(*) FROM journey_sale_evidence_r20').fetchone()[0]==1
                    assert db.execute('SELECT COUNT(*) FROM journey_actions_r20 WHERE status="investigating"').fetchone()[0]==1
                print('R2.0 Chromium: five tabs, real SQLite journeys/assistance/sale/funnel/action, CSV and mobile 390px PASS')
            finally:browser.close()

if __name__=='__main__':main()
