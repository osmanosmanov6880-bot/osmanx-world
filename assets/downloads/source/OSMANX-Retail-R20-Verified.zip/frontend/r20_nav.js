/* Appends a conservative R2.0 shortcut, without changing earlier menus. */
(()=>{
 if(location.pathname.includes('/kiosk/')||location.pathname.includes('voice_kiosk'))return;
 const attach=()=>{
  const nav=document.querySelector('.sidebar .nav');
  if(!nav||nav.querySelector('[data-r20-shortcut]'))return;
  const link=document.createElement('a');link.className='nav-btn';link.href='/static/journey.html';link.dataset.r20Shortcut='1';
  const emblem=document.createElement('span');emblem.textContent='◉';emblem.style.cssText='color:#ef5e7d;font-size:18px;font-weight:900';
  const label=document.createElement('span');label.textContent='Journey Intelligence · Визиты';
  link.append(emblem,label);nav.append(link);
 };
 new MutationObserver(attach).observe(document.body,{childList:true,subtree:true});attach();
})();
