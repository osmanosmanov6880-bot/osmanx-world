"""Journey Intelligence R2.0 API acceptance against an isolated SQLite database."""
from __future__ import annotations
from datetime import date,datetime,timedelta,timezone
import pytest
from fastapi import Depends,FastAPI,Header,HTTPException
from fastapi.testclient import TestClient
from backend.security import Principal

@pytest.fixture
def site(tmp_path,monkeypatch):
    monkeypatch.setenv('OSMANX_DATA_DIR',str(tmp_path))
    monkeypatch.setenv('OSMANX_DEMO_MODE','0')
    monkeypatch.setenv('OSMANX_ADMIN_PASSWORD','bootstrap-super-secret-2026')
    monkeypatch.setenv('OSMANX_BOOTSTRAP_EMAIL','owner@osmanx.local')
    import backend.database as dbapi
    import backend.r20 as r20
    dbapi.initialize_db(demo=False)
    with dbapi.connect() as db:
        r20.ensure_schema(db);db.commit()
    def connect():
        with dbapi.connect() as db:yield db
    def auth(authorization:str|None=Header(default=None)):
        identities={
            'Bearer owner':Principal(1,1,'owner@osmanx.local','owner'),
            'Bearer manager':Principal(2,1,'manager@osmanx.local','manager'),
            'Bearer analyst':Principal(3,1,'analyst@osmanx.local','analyst'),
            'Bearer other':Principal(4,2,'other@osmanx.local','owner')}
        if authorization not in identities:raise HTTPException(401,'Необходимо войти')
        return identities[authorization]
    app=FastAPI();app.include_router(r20.build_router(auth,connect))
    with TestClient(app) as c:yield c,dbapi,{'Authorization':'Bearer owner'}

def create(site,req='journey-session-00001',slug='central'):
    c,_,h=site
    return c.post('/api/admin/r20/journeys',headers=h,json={'request_id':req,'slug':slug})

def start(site,req='journey-session-00001'):
    r=create(site,req);assert r.status_code==201,r.text
    return r.json()['id']

def step(site,jid,event,req=None,reason=None):
    c,_,h=site
    body={'request_id':req or f'journey-step-{jid}-{event}-0001','event':event}
    if reason is not None:body['reason']=reason
    return c.post(f'/api/admin/r20/journeys/{jid}/steps',headers=h,json=body)

def finish(site,jid,reason='browsing'):
    return step(site,jid,'exit',reason=reason)

def sale(site,source='pos',store=1,when=None):
    _,dbapi,_=site
    with dbapi.connect() as db:
        cur=db.execute('INSERT INTO sales(store_id,amount_kopeks,source,occurred_at,external_id) VALUES(?,?,?,?,?)',
                       (store,250000,source,when or dbapi.now_iso(),f'sale-{source}-{datetime.now().timestamp()}'))
        db.commit();return cur.lastrowid

def test_start_idempotency_and_store_visibility(site):
    c,_,h=site;first=create(site)
    assert first.status_code==201,first.text
    assert create(site).json()=={'id':first.json()['id'],'duplicate':True,'stage':'entered'}
    assert c.get('/api/admin/r20/journeys',headers=h).json()['items'][0]['id']==first.json()['id']
    assert c.get(f"/api/admin/r20/journeys/{first.json()['id']}",headers=h).status_code==200
    assert c.post('/api/admin/r20/journeys',json={'request_id':'other-request-0001','slug':'central'}).status_code==401
    assert c.get('/api/admin/r20/journeys',headers={'Authorization':'Bearer other'}).status_code==404

def test_steps_out_of_order_and_frozen_exit(site):
    jid=start(site)
    assert step(site,jid,'assist_start').status_code==409
    assert step(site,jid,'browse').json()['stage']=='browsing'
    assert step(site,jid,'inquire').json()['stage']=='inquired'
    assert step(site,jid,'assist_start').json()['stage']=='assisting'
    assert finish(site,jid).status_code==409
    assert step(site,jid,'assist_end').json()['stage']=='assisted'
    assert finish(site,jid,'missing_size').json()['stage']=='exited'
    assert step(site,jid,'purchase').status_code==409
    assert step(site,jid,'exit',req='alternative-exit-event-01',reason='unknown').status_code==409
    detail=site[0].get(f'/api/admin/r20/journeys/{jid}',headers=site[2]).json()
    assert len(detail['history'])==5 and detail['journey']['cohort']=='helped_no_purchase'

def test_step_idempotency_conflict_exact_payload(site):
    jid=start(site)
    assert step(site,jid,'browse',req='same-request-step-00001').status_code==201
    assert step(site,jid,'browse',req='same-request-step-00001').json()['duplicate']
    assert step(site,jid,'inquire',req='same-request-step-00001').status_code==409
    assert step(site,jid,'purchase',reason='unknown').status_code==422

def test_assistance_timer_server_owns_duration(site):
    jid=start(site)
    step(site,jid,'inquire');step(site,jid,'assist_start')
    with site[1].connect() as db:
        db.execute('UPDATE journey_sessions_r20 SET assistance_started_at=? WHERE id=?',
                   ((datetime.now(timezone.utc)-timedelta(minutes=3)).isoformat(timespec='seconds'),jid))
        db.commit()
    done=step(site,jid,'assist_end')
    assert done.status_code==201 and 175<=done.json()['assistance_seconds']<=190
    assert finish(site,jid).status_code==201
    report=site[0].get('/api/admin/r20/funnel',headers=site[2]).json()
    assert report['assisted_seconds']>=175 and report['cohorts']['helped_no_purchase']==1

def test_purchase_reporting_is_not_a_verified_sale(site):
    jid=start(site);step(site,jid,'purchase');finish(site,jid,'unknown')
    report=site[0].get('/api/admin/r20/funnel',headers=site[2]).json()
    assert report['cohorts']['purchase_unverified']==1
    assert report['pos_evidenced_purchases']==0
    assert any('не подтверждена' in w for w in report['warnings'])

def test_sale_verification_same_store_and_once_only(site):
    c,_,h=site
    jid=start(site);step(site,jid,'purchase');finish(site,jid,'unknown')
    sid=sale(site)
    matched=c.post(f'/api/admin/r20/journeys/{jid}/verify-sale',json={'sale_id':sid},headers=h)
    assert matched.status_code==200,matched.text
    assert matched.json()['verified']
    assert c.post(f'/api/admin/r20/journeys/{jid}/verify-sale',json={'sale_id':sid},headers=h).json()['duplicate']
    report=c.get('/api/admin/r20/funnel',headers=h).json()
    assert report['cohorts']['purchased_verified']==1
    other=start(site,'second-journey-session-00002');step(site,other,'purchase');finish(site,other,'unknown')
    assert c.post(f'/api/admin/r20/journeys/{other}/verify-sale',json={'sale_id':sid},headers=h).status_code==409
    demo=sale(site,'demo_pos')
    assert c.post(f'/api/admin/r20/journeys/{other}/verify-sale',json={'sale_id':demo},headers=h).status_code==409


def test_receipt_proximity_missing_and_no_reported_sale(site):
    c,_,h=site;jid=start(site);step(site,jid,'purchase')
    old=sale(site,'pos_old',when=(datetime.now(timezone.utc)-timedelta(days=2)).isoformat())
    assert c.post(f'/api/admin/r20/journeys/{jid}/verify-sale',json={'sale_id':old},headers=h).status_code==409
    assert c.post(f'/api/admin/r20/journeys/{jid}/verify-sale',json={'sale_id':929292},headers=h).status_code==404
    notbuyer=start(site,'third-journey-session-00003')
    assert c.post(f'/api/admin/r20/journeys/{notbuyer}/verify-sale',json={'sale_id':old},headers=h).status_code==409


def test_funnel_counts_only_completed(site):
    c,_,h=site
    a=start(site);finish(site,a)
    b=start(site,'funnel-inquiry-session-02');step(site,b,'inquire');finish(site,b,'missing_size')
    d=start(site,'funnel-purchase-session-03');step(site,d,'purchase');finish(site,d,'unknown')
    start(site,'funnel-incomplete-0004')
    r=c.get('/api/admin/r20/funnel',headers=h).json()
    assert r['completed']==3 and r['open']==1
    assert r['cohorts']['browsing']==1 and r['cohorts']['asked_no_purchase']==1
    assert r['cohorts']['purchase_unverified']==1
    assert sum(x['count'] for x in r['by_hour'])==3
    assert 'вручную' in r['warnings'][0]
    assert c.get('/api/admin/r20/funnel?days=95',headers=h).status_code==422
    csv=c.get('/api/admin/r20/funnel.csv',headers=h)
    assert csv.status_code==200 and 'text/csv' in csv.headers['content-type']


def test_action_evidence_min_three_lifecycle(site):
    c,_,h=site
    for i in range(3):finish(site,start(site,f'window-detect-visitor-{i:05}'))
    body={'slug':'central','request_id':'decision-evidence-00001',
          'title':'Проверить удобство ассортимента после наблюдений',
          'owner':'Управляющий','category':'browsing',
          'due_date':str(date.today()+timedelta(days=7)),'days':14}
    created=c.post('/api/admin/r20/actions',json=body,headers=h)
    assert created.status_code==201,created.text
    aid=created.json()['id'];assert created.json()['evidence']['support']==3
    assert c.post('/api/admin/r20/actions',json=body,headers=h).json()['duplicate']
    assert c.post('/api/admin/r20/actions',json={**body,'title':'Другая версия задачи'},headers=h).status_code==409
    assert c.patch(f'/api/admin/r20/actions/{aid}',headers=h,json={'status':'completed','note':'Сразу закрываем без проверки'}).status_code==409
    assert c.patch(f'/api/admin/r20/actions/{aid}',headers=h,json={'status':'investigating','note':'Проверили выкладку и размеры вещей'}).status_code==200
    assert c.patch(f'/api/admin/r20/actions/{aid}',headers=h,json={'status':'completed','note':'Внедрили исправление с подтверждением акта'}).status_code==200
    assert c.patch(f'/api/admin/r20/actions/{aid}',headers=h,json={'status':'investigating','note':'Нельзя повторно открыть событие'}).status_code==409
    assert len(c.get(f'/api/admin/r20/actions/{aid}/history',headers=h).json()['items'])==2


def test_action_requires_multiple_observations(site):
    c,_,h=site;finish(site,start(site))
    r=c.post('/api/admin/r20/actions',headers=h,json={
       'request_id':'decision-single-visitor-01','title':'Проверить спрос после одного наблюдения',
       'owner':'Директор','category':'browsing','due_date':str(date.today()+timedelta(days=10)),'days':14})
    assert r.status_code==409


def test_viewer_and_tenant_isolation(site):
    c,dbapi,h=site;jid=start(site)
    with dbapi.connect() as db:
        db.execute('INSERT INTO organizations(id,slug,name,created_at) VALUES(2,?,?,?)',('other','Other',dbapi.now_iso()))
        db.execute('INSERT INTO stores(id,slug,name,created_at,organization_id) VALUES(2,?,?,?,2)',('abroad','Another',dbapi.now_iso()))
        db.execute('INSERT INTO users(id,organization_id,email,password_hash,role,created_at) VALUES(?,?,?,?,?,?)',
                   (3,1,'analyst-r20@osmanx.local','disabled-local-test','analyst',dbapi.now_iso()))
        db.execute('INSERT INTO user_store_access(user_id,store_id) VALUES(3,1)')
        db.commit()
    other={'Authorization':'Bearer other'}
    analyst={'Authorization':'Bearer analyst'}
    assert c.get('/api/admin/r20/journeys',headers=other).status_code==404
    assert c.get(f'/api/admin/r20/journeys/{jid}',headers=other).status_code==404
    assert c.get('/api/admin/r20/funnel',headers=analyst).status_code==200
    assert create((c,dbapi,analyst),'read-only-create-0001').status_code==403
    assert c.post(f'/api/admin/r20/journeys/{jid}/steps',headers=analyst,
        json={'request_id':'new-step-from-viewer-01','event':'browse'}).status_code==403


def test_schema_idempotent(site):
    _,dbapi,h=site;jid=start(site)
    from backend.r20 import ensure_schema
    with dbapi.connect() as db:
        ensure_schema(db);ensure_schema(db)
        assert db.execute('PRAGMA foreign_key_check').fetchall()==[]
        assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert db.execute('SELECT COUNT(*) FROM journey_sessions_r20 WHERE id=?',(jid,)).fetchone()[0]==1


def test_malformed_and_expired_requests(site):
    c,_,h=site
    assert c.post('/api/admin/r20/journeys',headers=h,json={'slug':'central','request_id':'short'}).status_code==422
    jid=start(site)
    assert step(site,jid,'exit',reason='something_else').status_code==422
    assert c.post('/api/admin/r20/actions',headers=h,json={'slug':'central',
       'request_id':'invalid-date-task-0001','title':'Проверить выброс посещений и причины',
       'owner':'Директор','category':'browsing','due_date':'2026-02-31','days':14}).status_code==422


def test_retention_cleanup_dryrun_and_stored_action_is_separate(site):
    c,dbapi,h=site
    sid=start(site);step(site,sid,'browse');finish(site,sid,'browsing')
    from scripts.purge_journeys_r20 import purge
    old=(datetime.now(timezone.utc)-timedelta(days=190)).isoformat(timespec='seconds')
    with dbapi.connect() as db:
        db.execute('UPDATE journey_sessions_r20 SET updated_at=? WHERE id=?',(old,sid));db.commit()
        before=purge(db,apply=False)
        assert before[0]['sessions']==1
        assert db.execute('SELECT COUNT(*) FROM journey_sessions_r20').fetchone()[0]==1
        after=purge(db,apply=True)
        assert after[0]['sessions']==1
        assert db.execute('SELECT COUNT(*) FROM journey_sessions_r20').fetchone()[0]==0
        assert db.execute('SELECT COUNT(*) FROM journey_steps_r20').fetchone()[0]==0
        assert db.execute('PRAGMA foreign_key_check').fetchall()==[]
