# OSMANX SERVICE PLATFORM — Interactive Prototype R1

A responsive, Russian-language, dependency-free interactive demo for six recurring-service verticals.

## Open

Open `index.html` in a modern browser. No installation or server is required. For a local development server, run:

```bash
python3 -m http.server 8080
```

Then visit `http://localhost:8080`.

## Implemented

1. Responsive executive dashboard with per-industry branding and calculated sample metrics.
2. Six industry modes: laboratory, dental clinic, auto service, beauty & SPA, fitness studio, coffee shop.
3. Booking CRM: create booking, filter/search, change booking status, calculated revenue, CSV export.
4. Customer database: create/search customer, inspect customer visit history and open booking form.
5. Editable per-industry service catalog: name, duration, price, and appointment creation.
6. Interactive mobile app prototype: home, bookings, profile, brand identity and industry-specific services.
7. Company settings, feature toggles, local persistence and seed-data reset.

## Quality and limitations

- All data is **synthetic demo data** and stored in browser `localStorage`.
- All marketing growth percentages from design references were deliberately omitted. Only sample-data counts are calculated; trend chart is explicitly labeled illustrative.
- No backend, authentication, multi-tenancy security, real payments, SMS, health-record storage, external integration, mobile binary, app-store publication or production-grade authorization is included.
- **Never input real personal, patient or payment data in this prototype.** Production medical deployment requires secure API, encryption, access control, audit logs, legal basis/consent and regulatory review.
- Offline use works with system fonts. Google Font loading is optional and requires internet.
- `localStorage` is per-browser, not shared between employees or devices.

## Next engineering phases

R2: real API with PostgreSQL, protected auth, tenant isolation and server validation. R3: role permissions, integrations and auditable event tracking. R4: cross-platform native clients and store distributions. R5: production testing, deployment, observability, backups, security and compliance.
