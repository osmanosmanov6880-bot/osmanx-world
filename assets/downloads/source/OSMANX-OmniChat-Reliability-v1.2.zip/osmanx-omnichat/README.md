# OSMANX OMNICHAT — v1.2 Reliability & Clarity

**Что нового:** атомарная защита от повторных webhook-событий при одновременной обработке, дополнительные проверки границ компаний перед отправкой, SQL-аналитика без загрузки всей истории, приоритетная очередь проблем и простой русскоязычный раздел «Что сделать сейчас». Тёмный дизайн и единый Inbox сохранены. Текущая версия — локальный MVP; публикация и платежи отложены.

**Запуск:** Windows `start_windows.bat`; Linux/macOS `./start_linux.sh`; открыть `http://127.0.0.1:8000`. При первом запуске нужен Python 3.12+ и доступ к установке зависимостей.

**Документация v1.2:** [релиз и проверки](docs/RELEASE_V1_2_RU.md) · [как разбирать проблемы с отправкой](docs/OPERATIONS_RUNBOOK_V12.md) · [реальный скриншот экрана доставки](docs/preview-v12-operations-desktop.png).

**Остаётся сделать до production:** подтвердить реальные официальные подключения, обновить React 16 (npm из данной среды недоступен), испытать PostgreSQL/Docker под нагрузкой, провести security-аудит, настроить HTTPS. Ни одна соцсеть не объявляется подключённой на основании тестового ответа API.

---

# OSMANX OMNICHAT v1.1 — Secure Operations

**Что нового:** защита входа на уровне общей базы, завершение сеансов других устройств в русскоязычных настройках, безопасный повтор сообщений и серверный лимит Web Chat, ускоренная обработка подтверждений WhatsApp. Утверждённый тёмный интерфейс сохранён.

**Запуск:** Windows — `start_windows.bat`, Linux/macOS — `./start_linux.sh`; после запуска откройте `http://127.0.0.1:8000`. Потребуется Python 3.12+ и установка зависимостей. В деморежиме реальные соцсети не задействуются.

**Важно:** реальные аккаунты соцсетей не подключались; приём платежей и публичная публикация не выполнялись. React 16 остаётся техническим долгом до получения зависимостей и сборки React 19. Обязательны HTTPS, права официальных API и проверка работы каждого канала.

- [Что изменено, что проверено и что остаётся](docs/RELEASE_V1_1_RU.md)
- [Как управлять сеансами — инструкция владельцу](docs/SESSIONS_FOR_OWNER_RU.md)
- [Реальный скриншот раздела безопасности](docs/preview-v11-security-desktop.png)
- [Мобильная версия](docs/preview-v11-security-mobile.png)

---

# OSMANX OMNICHAT v1.0 -- CONNECTOR ASSURANCE

**Current status:** locally executable platform with Russian UI, verified multi-tenant roles, official-channel adapters, in-app setup, evidence-based channel probes, and truthful outgoing delivery statuses. No paid subscriptions, public deployment, or unapproved accounts are activated.

**Start:** Windows `start_windows.bat`, Linux/macOS `./start_linux.sh`; open `http://127.0.0.1:8000`. For the first run: Python 3.12+, install dependencies. To connect your own social accounts, register a real workspace rather than opening Demo Mode.

**New in v1.0:** one-click read-only provider connection check; provider-side Telegram/MAX webhook comparison; 30-second server cooldown and tenant-bound authorization; monotonic WhatsApp delivery receipts; distinct queued/API-accepted/delivered/read/uncertain message labels; quick-start only counts externally accepted replies. No social platform is claimed operational without live credentials and permission.

**Verification:** 71/71 backend tests, successful TypeScript build, Alembic migrations with old data retained, Chromium checks at desktop/390px/320px through a local FastAPI bridge. Third-party responses in automated tests are mocked, and do not prove a real channel connection.

- [Release report / tested and missing](docs/RELEASE_V1_0.md)
- [Steps for connection owners](docs/CONNECT_V1_0_RU.md)
- [Desktop screenshot of real React + FastAPI](docs/preview-v10-connector-desktop.png)
- [Mobile screenshot of real React + FastAPI](docs/preview-v10-connector-mobile.png)
- [Original user guide in Russian](docs/EASY_START_RU.md)

---

# OSMANX OMNICHAT v0.9 — Clarity First

**Запускаемый локальный MVP**, ориентированный на максимально простой путь: зарегистрировать компанию, выбрать канал, получить сообщение и ответить. Важные изменения в v0.9 — реальный быстрый старт из трёх шагов, настройка одной соцсети за раз, черновики при переключении диалогов и идемпотентная отправка после потерянного ответа сети. Утверждённый тёмный Obsidian Silence сохранён.

**Запуск:** распакуйте архив → Windows: `start_windows.bat`, Linux/macOS: `./start_linux.sh` → `http://127.0.0.1:8000`. Python 3.12+ и доступ к установке зависимостей нужны при первом запуске. Нажмите «Демоверсия» или зарегистрируйте отдельную компанию.

**Проверки:** 64 API/security-теста, TypeScript, реальный React в Chromium на ПК и телефонах, браузерная регистрация и сценарий повторной отправки после потери HTTP-подтверждения. Боевые соцсети, публикация и платежи **не** подключались.

- [Инструкция обычному пользователю](docs/EASY_START_RU.md)
- [Что именно реализовано](docs/RELEASE_V0_9.md)
- [Быстрый старт — скриншот Chromium](docs/preview-v09-start-desktop.png)
- [Подключение одного канала — скриншот Chromium](docs/preview-v09-choose-channel.png)

---

# OSMANX OMNICHAT v0.8 — Real Connect Readiness

**Новая версия: реальные механизмы подключения с доказуемыми статусами, без фиктивной синхронизации.** Проект остаётся локальным self-hosted MVP; платежи и публикация отложены.

**Что нового:** четыре проверяемых шага подключения в русском интерфейсе, серверная проверка регистраций Telegram `getWebhookInfo` и MAX `GET /subscriptions`, сохранение подтверждений внешнего API, безопасный сброс доказательств после смены токена, локальная проверка готовности сервера и новая миграция базы. Темный Obsidian Silence и единый Inbox сохранены.

**Быстро попробовать на Windows:** распакуйте архив → запустите `start_windows.bat` (Python 3.12+ и доступ к pip) → откройте `http://127.0.0.1:8000` → нажмите **«Открыть демоверсию»**. Для настройки собственных аккаунтов зарегистрируйте отдельную компанию и откройте **«Интеграции»**. Доступ к настоящим соцсетям требует официальных разрешений и доступного HTTPS сервера, которых в этом релизе не предоставлялось.

**Проверка:** 59 Python API/security тестов, TypeScript, миграции v0.7 → v0.8, Chromium desktop/mobile и настоящий React + FastAPI при тестовом транспорте. Этот результат **не является сертификацией production**.

- [Как подключить соцсети: обычному владельцу компании и администратору OSMANX](docs/CONNECT_REAL_CHANNELS_V08.md)
- [Инженерный отчёт v0.8](docs/RELEASE_V0_8.md)
- [Скриншот настоящего мастера подключения](docs/preview-v08-onboarding.png)

---

# OSMANX OMNICHAT v0.7 — OBSIDIAN SILENCE

**Полноценный исходный код приложения с новым тёмным интерфейсом, точно по утверждённому направлению.** Обновление касается настоящего React + TypeScript, CSS и встроенного JS, а не изображения-макета. Основа — предыдущий релиз v0.6 с backend и интеграционной архитектурой.

## Запуск за один шаг

**Windows:** распакуйте архив, запустите `start_windows.bat`, после установки зависимостей откройте `http://127.0.0.1:8000` и нажмите «Открыть демоверсию». Нужны Python 3.12+ и доступ к установке пакетов.

**Linux/macOS:** `./start_linux.sh`, затем тот же локальный адрес. Node.js для обычного запуска не нужен — JS уже собран в `frontend/public/app.js`.

## Что изменилось в v0.7

- Реализован утверждённый **тёмный четырёхзонный интерфейс**: навигация → диалоги → переписка → карточка клиента.
- Переписаны входящие, карточка клиента, компактное меню действий, экран входа; добавлена рабочая доска сделок.
- Добавление и удаление тегов, редактирование стадии, ответственного, напоминания, заметки, отправка сообщения и фильтрация каналов остаются действиями на настоящем серверном API.
- Проверены 45 backend-тестов, Chromium E2E с настоящим FastAPI TestClient на ПК и телефонах 390/320 px, TypeScript-компиляция.
- Публикация, платежи и реальные подключения к соцсетям не выполнялись. Адаптеры требуют официальных разрешений и отдельного тестирования.

**Снимок реально отрисованного интерфейса:** ![Рабочий Inbox](docs/preview-v07-desktop.png)

[Подробный релиз](docs/RELEASE_V0_7.md) · [Дизайн-система](docs/DESIGN_V0_7.md) · [Мобильный экран](docs/preview-v07-mobile.png) · [Экран входа](docs/preview-v07-auth.png)

---

## Архивная документация предыдущей версии v0.6

# OSMANX OMNICHAT

**Единый центр общения с клиентами** · Self-hosted SaaS MVP · версия **0.6.0** · 4 ноября 2026 года

> **Реальное приложение, не макет.** Исходники React/TypeScript, серверные API, база данных, миграции, Docker Compose, проверки, документация. Авито, Instagram и WhatsApp подключаются только официальными способами. Без выданных разрешений и действительных токенов никакое реальное подключение не считается рабочим.

![Демо рабочего интерфейса](docs/preview-desktop.png)

[Проверенный мобильный вид](docs/preview-mobile.png)

## v0.6 CUSTOMER-OWNED CHANNELS — свои аккаунты у каждой компании

**Самообслуживание компаний:** пользователь регистрирует собственную организацию, создаёт дополнительные рабочие области в «Настройки и тариф → Ваши компании», выбирает собственные разрешённые каналы в «Ещё разделы → Интеграции» и отвечает на сообщения в одном Inbox. Данные и токены двух компаний не смешиваются: серверная проверка членства, ограничения прав и частичный SQL-индекс по внешнему аккаунту.

**Каналы:** Авито, Instagram, WhatsApp Business, Telegram-бот, сообщество ВКонтакте, MAX-бот, Facebook Messenger Page, собственный чат сайта. Для Facebook Pages и WhatsApp добавлены официальные сценарии привязки через Meta, но реальная авторизация требует одобренного Meta-приложения. Подготовлены проверки webhook/HMAC, права доступа, контроль статуса и обработка исходящих через прежний outbox. Нельзя читать личные переписки произвольных пользователей.

**Проверено локально:** 45 backend-тестов, TypeScript, Alembic, настоящий Chromium desktop/mobile и отдельный путь регистрации компании. **Внешние API смоделированы контрактными ответами:** живые бизнес-аккаунты, одобрение Meta, публичный HTTPS, production Docker/PostgreSQL и реальные платежи не выполнялись. Веб-чат сайта по-прежнему полноценно проверяется локально.

[Подключение для клиентов](docs/CUSTOMER_ONBOARDING_V06.md) · [Администратору платформы](docs/PLATFORM_OWNER_SETUP_V06.md) · [Отчёт v0.6](docs/RELEASE_V0_6.md) · [Скриншот процесса подключения](docs/preview-v06-onboarding.png)

## v0.5 FOCUS INBOX — проще и сильнее

**Новый спокойный интерфейс:** только Inbox, Клиенты, Аналитика на виду; «Ещё разделы» открывает CRM-связанные настройки; фильтры и настройки диалога скрываются до запроса; карточка клиента открывается отдельной кнопкой. Сохранены все функции v0.4, мобильная версия от 320 px.

**Единый Inbox в деморежиме:** 9 диалогов из 7 каналов — Авито, Instagram, WhatsApp, Telegram, ВКонтакте и MAX. Собственный чат сайта остаётся рабочим каналом в локальной среде.

**Добавлены официальные серверные адаптеры для Telegram-ботов, сообществ VK и ботов MAX**. Проверка токенов, защищённые входящие webhooks, маршрутизация в Inbox, отправка ответа через прежнюю очередь, дедупликация, разграничение организаций. Настоящие аккаунты не предоставлены: это проверенный через контрактные тесты код, **не** живая проверка провайдеров. Токен не равен успешной интеграции; подключение ожидает подписанного webhook-события.

**Проверено:** 39 backend-тестов, TypeScript, in-process FastAPI + Chromium E2E на ПК и мобильном экране, отсутствие JS-ошибок и переполнения при 320 px. Публичный деплой, реальные аккаунты и платежи не запускались.

[Инструкция по каналам](docs/CHANNELS_V05.md) · [Релиз и тесты](docs/RELEASE_V0_5.md) · [Принципы дизайна](docs/DESIGN_FOCUS_V05.md) · [Скриншот Inbox](docs/preview-v05-inbox.png)

## v0.4 Obsidian Atelier — новый центр управления и полностью русскоязычный интерфейс

![Реальный экран центра управления](docs/preview-v04-command.png)

Релиз v0.4 — развитие настоящего приложения, а не создание декоративных изображений. Новые функции: **Центр управления** с объяснимой приоритетной очередью обращений, временем ожидания и SLA; изменяемые **четыре приоритета** с серверной блокировкой конфликтов; **сохранённые подборки** по фильтрам; **журнал действий по диалогу**; русскоязычные меню, кнопки и сообщения; светлая/тёмная темы; новое премиальное оформление на CSS; оптимизированные SQL-запросы и составные индексы. Чат сайта, CRM, роли, автоматизация и очередь доставки из v0.3 сохранены.

**Проверка релиза:** 34 backend-теста успешно, TypeScript без ошибок, чистая миграция и проверка соответствия модели, переход с v0.3 с сохранением данных, Chromium desktop/mobile и цикл сайт-виджета с реальным backend через TestClient. Без реальных подключений к платформам, без платежей и без публичного развёртывания.

[Что изменено](docs/RELEASE_V0_4.md) · [Приоритеты и SLA](docs/COMMAND_CENTER.md) · [Дизайн-система](docs/DESIGN_SYSTEM_RU.md) · [Актуальный инженерный статус](docs/STATUS.md)

Предпросмотры: [Inbox](docs/preview-v04-inbox.png) · [Мобильная версия](docs/preview-v04-mobile.png) · [Виджет клиента](docs/preview-v04-widget.png) · [Светлая тема](docs/preview-v04-light.png).

**Приоритеты пользователя:** реальные клиенты, публикация и платежи — позднее. В v0.4 эти действия не запускались.

## v0.3 World Edition - verified engineering additions

**New: First-Party Website Messenger**. Configure a widget in the **Sites / Web Chat** page, copy the one-line `<script>` snippet, and embed it on an allowed website. Visitor messages now enter the same Inbox as external-channel messages; staff replies are returned to the visitor widget. Demo-mode traffic remains visibly labeled. Unlike third-party connectors, this channel does not need Avito or Meta credentials. See [installation and security guide](docs/WEBSITE_CHAT.md).

- **Team collaboration:** timed server-side conversation claims/release; conflicting employee replies receive HTTP 409; no silent overwrites.
- **Operational visibility:** scoped outbox dashboard, explicit unknown-delivery reconciliation with audit evidence, and dedicated Docker worker service.
- **International foundation:** per-company IANA timezone and ISO currency; daily analytics uses company timezone; changes that would reinterpret existing deal amounts are blocked.
- **Embed security:** whitelist iframe origins, visitor bearer token hashes at rest, 30-day session expiry, per-visitor rate limits, nonce deduplication, no visitor access to internal notes or other contacts. Launcher CSS is an external stylesheet to accommodate strict CSPs.
- **Verification:** 34 Python tests; TypeScript compilation; Alembic upgrade + drift check; Chromium renders the actual React UI and widget and exercises a real FastAPI **in-process** message roundtrip with no JavaScript errors. Due to execution-environment network policy, Chromium did not navigate to a publicly hosted endpoint. This is not a production network test.

Preview of the new management and visitor UI: [desktop](docs/preview-world-websites.png) | [mobile](docs/preview-world-mobile.png) | [visitor widget](docs/preview-world-widget.png).

[Release notes](docs/RELEASE_V0_3.md) | [Detailed status A-G](docs/STATUS.md) | [World roadmap and release gates](docs/WORLD_ROADMAP.md)

> **Scope completion at v0.3: approximately 67%**, not commercial readiness. Every external provider still requires permission from the business account owner and end-to-end verification. React 16 remains unsupported and must be upgraded before customer production deployment. No payment gateway or paid SaaS billing has been activated.

## Быстрый запуск

**Windows:** распакуйте архив и запустите `start_windows.bat` двойным щелчком (нужен установленный Python 3.12+ и доступ к pip).
**Linux/macOS:** выполните `./start_linux.sh`. Оба скрипта создают виртуальное окружение, устанавливают зависимости, применяют миграцию и запускают приложение локально на `http://127.0.0.1:8000`. При первом запуске нужно выбрать **«Открыть демоверсию»**.

## Начало работы за 3 минуты — локально

Необходимо: **Python 3.12+**, доступ к `pip`. Node.js для обычного запуска **не нужен** — приложение уже содержит скомпилированный React. Для редактирования TSX потребуется TypeScript.

```bash
# В корневой папке проекта
python -m venv .venv
source .venv/bin/activate           # Windows: .venv\Scripts\activate
pip install -r backend/requirements.txt
cp .env.example .env               # Windows PowerShell: Copy-Item .env.example .env
# Для простого локального демо не требуется редактировать .env
PYTHONPATH=backend alembic -c backend/alembic.ini upgrade head
PYTHONPATH=backend uvicorn app.main:app --host 127.0.0.1 --port 8000
```

**Откройте:** `http://127.0.0.1:8000` и нажмите **«Открыть демоверсию»**. Появятся 9 тестовых диалогов, 7 помеченных демоканалов, CRM, аналитика, заметки, команда и правила.

На Windows PowerShell без присваивания `PYTHONPATH=...`:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r backend/requirements.txt
Copy-Item .env.example .env
$env:PYTHONPATH = "backend"
python -m alembic -c backend/alembic.ini upgrade head
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

`.env` загружается при локальном запуске автоматически (существующие переменные окружения имеют приоритет). `PUBLIC_BASE_URL` должен совпадать с адресом, открытым в браузере, особенно для WebSocket.

`DATABASE_URL` по умолчанию — `sqlite:///./omnichat.db`. Демо создаёт **новую изолированную организацию** и не обращается к внешним API.

## Альтернативный запуск — Docker Compose + PostgreSQL

```bash
cp .env.example .env
# Обязательно замените POSTGRES_PASSWORD на собственный URL-safe пароль
# Для локального демо оставьте APP_ENV=development, COOKIE_SECURE=false
# Если DATABASE_URL в .env указывает на SQLite, Docker всё равно использует PostgreSQL.
docker compose up --build -d
curl -f http://127.0.0.1:8000/api/health/ready
```

При первом запуске контейнер автоматически выполняет миграцию Alembic и запускает Uvicorn. Docker не установлен в среде, в которой собирался архив: **конфигурация подготовлена, но `docker compose up` здесь не проверялся**.

Для интернет-публикации необходимо настроить HTTPS, настоящий домен, DNS, `PUBLIC_BASE_URL=https://...`, `COOKIE_SECURE=true`, `APP_ENV=production`, `INTEGRATION_ENCRYPTION_KEY`, пароль БД, резервные копии и Webhook callback адреса. См. [production-runbook](docs/PRODUCTION.md).

## Что реально работает

- Регистрация компании, вход и выход, защищённые cookie-сессии, CSRF, переключение между организациями по членству.
- Отдельные организации с tenant-scoped SQL-запросами, роли владельца, администратора, руководителя, менеджера, оператора.
- Трёхколоночный Inbox: списки чатов, поиск по сообщениям и контактам, фильтры по каналу, статусу и ответственному, архив, pin, счётчик непрочитанного, карточка клиента.
- История сообщений, отправка тестовых ответов, optimistic lock по `version`, idempotency `client_nonce`, внутренние заметки, быстрые ответы, тестовые новые обращения.
- Карточки CRM, воронка, теги, суммы сделки, **разделение подтверждённой и потенциальной выручки**, ручное объединение идентичностей, дата напоминания.
- Команда, приглашения токеном (с проверкой пароля существующего пользователя), статус доступности, назначение оператора.
- Автоматизация по событиям: содержит фразу/всегда, назначение наименее загруженного оператора, тег, статус или закрепление.
- Аналитика, SLA-оповещения, выбор политики хранения, экспорт и удаление данных компании.
- WebSocket обновлений (+ запасное обновление раз в 7 секунд), адаптивная светлая/тёмная тема.
- Табличная SQL-очередь отправки, идемпотентное получение входящих сообщений, HMAC подписи Meta webhooks, повторные попытки только там, где это безопасно.
- Реальные **реализации адаптеров официальных API** Авито, Instagram и WhatsApp — не равнозначно пройденной внешней проверке. Реальные токены и разрешения не предоставлялись.
- Миграция Alembic, CI, Docker-файлы, 45 автоматических тестов и Chromium smoke-test интерфейса на ПК/телефоне.

## Не готово — перед платным запуском

1. **Проверить каждый внешний канал с разрешённым реальным аккаунтом**: OAuth/App Review, webhooks, реальная отправка и входящие; установить нужные бизнес-тарифы/разрешения. Текущая среда не имела этих доступов.
2. **Обновить vendored React 16.0 до поддерживаемой современной версии** (в данной среде загрузка npm из интернета недоступна). Текущая сборка работает, но устаревшая библиотека — блокер промышленного security review. Не скрывать это от покупателей.
3. Реализовать официальные медиа-ответы/шаблоны WhatsApp, полную синхронизацию истории Instagram, восстановление токенов и обработку всех видов вложений.
4. Перевести фоновую очередь на выделенный масштабируемый worker, добавить Redis/внешнюю rate-limit систему, расширить мониторинг и нагрузочные тесты.
5. Проверить Docker в целевой инфраструктуре, выполнить внешний security audit, сценарии восстановления из бэкапа, правовой аудит персональных данных и договоров с платформами.
6. Реальные платежи и подписки **не подключены**: серверные лимиты тарифов работают, но оплата и автоматическая смена тарифов отсутствуют.

## Использованный стек

| Слой | Фактически в проекте |
| --- | --- |
| UI | React + TypeScript, CSS с темизацией; локальный prebuilt JS без внешнего CDN |
| API | Python FastAPI, Pydantic |
| Данные | SQLAlchemy, SQLite (локально) / PostgreSQL (Docker) |
| Миграции | Alembic |
| Каналы | Асинхронные HTTP-клиенты с official API, HMAC Meta webhooks, Avito polling |
| Обновление | WebSocket-инвалидация ~2 с + fallback polling |
| Отправка | Транзакционная SQL-очередь OutgoingJob и worker внутри одного API процесса |
| Деплой | Docker Compose, Caddy HTTPS (опционально), GitHub Actions |

**Почему не Next.js/NestJS/Prisma/Redis из рекомендаций?** В текущем offline runtime нельзя установить npm-зависимости. Вместо неподтверждённого псевдопроекта собран проверенный локальный MVP на FastAPI/SQLAlchemy с реальным React UI. Это честное отклонение от рекомендуемого стека; последующая миграция на Next/Nest возможна через документированный API и адаптерный контракт.

## Проверка

```bash
PYTHONPATH=backend pytest -q backend/tests
# должно быть: 45 passed

tsc --project frontend/tsconfig.json
# компиляция React UI (при наличии TypeScript)

DATABASE_URL=sqlite:///./schema-qa.db alembic -c backend/alembic.ini upgrade head
DATABASE_URL=sqlite:///./schema-qa.db alembic -c backend/alembic.ini check

python scripts/visual_smoke.py
# offline Chromium UI smoke test (требуются playwright и установленный Chromium)
```

**Фактическое покрытие первоначального ТЗ (оценка из v0.4): около 70% (не production-готовность).** Подробный поэтапный отчёт: [Статус A–G](docs/STATUS.md). Полный перечень API: [docs/API.md](docs/API.md). Неопределённая отправка через API безопасно переводится в ручную сверку.

API docs: `http://localhost:8000/api/docs` (только если `ENABLE_API_DOCS=true`). Health: `/api/health`, Ready: `/api/health/ready`.

## Структура репозитория

```text
backend/
  app/             модели, API, авторизация, очередь, webhooks, media и адаптеры
  alembic/         реальная миграция схемы
  tests/           автоматические проверки backend/API/security
  Dockerfile
  requirements.txt
frontend/
  src/app.tsx      все React-компоненты и состояния
  public/          HTML, CSS, compiled JS и vendored React
.github/workflows  автоматические тесты, миграция, сборка Docker
infra/             Caddy и скрипт PostgreSQL backup
scripts/           Chromium визуальная проверка
docs/              архитектура, интеграции, безопасность, статус, эксплуатация
```

**Ограничение ответственности:** решение является проверяемым **MVP**, но **не сертифицированной production-системой**. Реальные подключения не могут быть признаны исправными без разрешённых аккаунтов, а юридические обязанности владельца клиентских данных требуют отдельной проверки.
