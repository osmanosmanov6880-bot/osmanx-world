#!/bin/sh
# Run on the Docker host: env vars loaded from the project's .env file.
set -eu
cd "$(dirname "$0")/.."
mkdir -p ./backups
umask 077
stamp="$(date -u +%Y%m%dT%H%M%SZ)"
out="./backups/omnichat-${stamp}.sql.gz"
docker compose exec -T postgres sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" --no-owner --no-acl' | gzip -9 > "$out"
[ -s "$out" ] || { rm -f "$out"; echo "Backup failed" >&2; exit 1; }
echo "Backup created: $out. Store an encrypted offsite copy."
