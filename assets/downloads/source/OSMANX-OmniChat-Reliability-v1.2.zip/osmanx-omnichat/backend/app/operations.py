"""Bounded, tenant-scoped operational health and delivery diagnostics.

Return aggregates from SQL, not all conversations or messages in application memory.
Provider tokens and message text are deliberately excluded from this endpoint.
"""
from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session
from .db import get_db, ChannelConnection, Conversation, OutgoingJob, Message, now
from .auth import auth, require_role

router=APIRouter(prefix='/api/operations', tags=['operations'])

@router.get('/overview')
def operations_overview(p=Depends(auth), db: Session=Depends(get_db)):
    require_role(p, 'owner', 'admin', 'lead')
    org_id = p.org.id
    clock = now()
    statuses = dict(db.query(OutgoingJob.status, func.count(OutgoingJob.id)).filter(
        OutgoingJob.organization_id == org_id).group_by(OutgoingJob.status).all())
    delayed = db.query(func.count(OutgoingJob.id)).filter(
        OutgoingJob.organization_id == org_id,
        OutgoingJob.status.in_(['queued', 'processing']),
        OutgoingJob.created_at < clock - 300).scalar() or 0
    channel_total = db.query(func.count(ChannelConnection.id)).filter_by(organization_id=org_id).scalar() or 0
    live_connected = db.query(func.count(ChannelConnection.id)).filter_by(
        organization_id=org_id, status='connected', mode='live').scalar() or 0
    messages_total = db.query(func.count(Message.id)).filter_by(organization_id=org_id).scalar() or 0
    conversations_total = db.query(func.count(Conversation.id)).filter_by(organization_id=org_id).scalar() or 0
    # A bounded result prevents a very large tenant from overwhelming its browser.
    channel_rows = (db.query(ChannelConnection).filter_by(organization_id=org_id)
                    .order_by(ChannelConnection.created_at.desc(), ChannelConnection.id)
                    .limit(201).all())
    channels = channel_rows[:200]
    return {
        'as_of': clock, 'organization_id': org_id,
        'channel_total': channel_total, 'live_connected_count': live_connected,
        'channels_truncated': len(channel_rows)>200,
        'outbox': {name:statuses.get(name,0) for name in ('queued','processing','uncertain','failed','done')},
        'outbox_delayed_over_5_min': delayed,
        'messages_total': messages_total, 'conversations_total': conversations_total,
        'channels': [
            {'id':c.id, 'provider':c.provider, 'name':c.name, 'mode':c.mode,
             'status':c.status, 'last_sync_at':c.last_sync_at,
             'last_error':(c.last_error or '')[:180]}
            for c in channels],
        'reconciliation_required':statuses.get('uncertain',0),
        'live_external_channels_verified':False,
        'note':'A connected credential is not evidence of live end-to-end send and receive validation.'}
