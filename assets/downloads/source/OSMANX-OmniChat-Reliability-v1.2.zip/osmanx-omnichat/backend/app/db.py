"""SQLAlchemy persistence. SQLite for zero-setup local development; PostgreSQL in production."""
import os
import time
import uuid
from sqlalchemy import create_engine, Column, String, Float, ForeignKey, Integer, Boolean, Text, UniqueConstraint, Index, text
from sqlalchemy.orm import DeclarativeBase, sessionmaker


def uid():
    return str(uuid.uuid4())

def now():
    return time.time()


def engine_for(url=None):
    url = url or os.getenv('DATABASE_URL', 'sqlite:///./omnichat.db')
    options = {'connect_args': {'check_same_thread': False}} if url.startswith('sqlite') else {'pool_pre_ping': True}
    return create_engine(url, **options)

class Base(DeclarativeBase):
    pass

class Organization(Base):
    __tablename__ = 'organizations'
    id = Column(String(36), primary_key=True, default=uid)
    name = Column(String(160), nullable=False)
    plan = Column(String(32), nullable=False, default='starter')
    is_demo = Column(Boolean, default=False, nullable=False)
    retention_days = Column(Integer, nullable=False, default=365)
    sla_minutes = Column(Integer, nullable=False, default=5)
    currency = Column(String(3), nullable=False, default='RUB')
    timezone = Column(String(64), nullable=False, default='UTC')
    created_at = Column(Float, default=now, nullable=False)

class User(Base):
    __tablename__ = 'users'
    id = Column(String(36), primary_key=True, default=uid)
    email = Column(String(250), unique=True, nullable=False, index=True)
    password_hash = Column(String(300), nullable=False)
    name = Column(String(120), nullable=False)
    created_at = Column(Float, default=now, nullable=False)

class Membership(Base):
    __tablename__ = 'memberships'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), ForeignKey('organizations.id'), nullable=False, index=True)
    user_id = Column(String(36), ForeignKey('users.id'), nullable=False, index=True)
    role = Column(String(24), nullable=False, default='operator')
    active = Column(Boolean, default=True, nullable=False)
    available = Column(Boolean, default=True, nullable=False)
    __table_args__ = (UniqueConstraint('organization_id', 'user_id'),)

class AuthSession(Base):
    __tablename__ = 'auth_sessions'
    id_hash = Column(String(64), primary_key=True)
    user_id = Column(String(36), ForeignKey('users.id'), nullable=False)
    organization_id = Column(String(36), ForeignKey('organizations.id'), nullable=False)
    csrf_hash = Column(String(64), nullable=False)
    expires_at = Column(Float, nullable=False)
    created_at = Column(Float, default=now)

class LoginFailure(Base):
    """Password-attempt receipt for shared-database login abuse protection.

    No plaintext email or password is stored. Attempts expire automatically.
    """
    __tablename__ = 'login_failures'
    id = Column(String(36), primary_key=True, default=uid)
    email_digest = Column(String(64), nullable=False)
    attempted_at = Column(Float, nullable=False, default=now)
    __table_args__ = (Index('ix_login_failure_identity_time', 'email_digest', 'attempted_at'),)

class OAuthState(Base):
    __tablename__ = 'oauth_states'
    state_hash = Column(String(64), primary_key=True)
    user_id = Column(String(36), nullable=False)
    organization_id = Column(String(36), nullable=False)
    provider = Column(String(24), nullable=False)
    expires_at = Column(Float, nullable=False)

class PendingChannelSelection(Base):
    """Encrypted, time-limited OAuth assets available for an explicit user selection."""
    __tablename__ = 'pending_channel_selections'
    id = Column(String(36), primary_key=True, default=uid)
    user_id = Column(String(36), ForeignKey('users.id'), nullable=False)
    organization_id = Column(String(36), ForeignKey('organizations.id'), nullable=False)
    provider = Column(String(32), nullable=False)
    encrypted_payload = Column(Text, nullable=False)
    expires_at = Column(Float, nullable=False)
    created_at = Column(Float, default=now, nullable=False)
    __table_args__ = (Index('ix_pending_channel_selection_owner','organization_id','user_id'),)

class ChannelConnection(Base):
    __tablename__ = 'channel_connections'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), ForeignKey('organizations.id'), nullable=False, index=True)
    provider = Column(String(32), nullable=False)
    name = Column(String(100), nullable=False)
    external_account_id = Column(String(150))
    mode = Column(String(20), nullable=False, default='live')
    status = Column(String(24), nullable=False, default='disconnected')
    encrypted_credentials = Column(Text)
    last_sync_at = Column(Float)
    last_verified_at = Column(Float)
    webhook_verified_at = Column(Float)
    webhook_registered_at = Column(Float)
    webhook_provider_verified_at = Column(Float)
    outbound_api_accepted_at = Column(Float)
    last_probe_at = Column(Float)
    token_expires_at = Column(Float)
    last_error = Column(Text)
    created_at = Column(Float, default=now, nullable=False)
    __table_args__ = (
        Index('channel_provider_ext_idx', 'provider', 'external_account_id'),
        # Prevent routing one live external identity to two tenants, even under concurrent requests.
        # Demo accounts and disconnected historical connections are intentionally excluded.
        Index('uq_live_channel_identity', 'provider', 'external_account_id', unique=True,
            sqlite_where=text("mode = 'live' AND status != 'disconnected' AND external_account_id IS NOT NULL"),
            postgresql_where=text("mode = 'live' AND status != 'disconnected' AND external_account_id IS NOT NULL")),
    )

class Contact(Base):
    __tablename__ = 'contacts'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), ForeignKey('organizations.id'), nullable=False, index=True)
    name = Column(String(160), nullable=False)
    phone = Column(String(80))
    email = Column(String(250))
    tags = Column(Text, default='[]', nullable=False)
    stage = Column(String(40), default='new', nullable=False)
    deal_amount = Column(Float)
    deal_confirmed = Column(Boolean, default=False, nullable=False)
    next_followup_at = Column(Float)
    created_at = Column(Float, default=now)

class Conversation(Base):
    __tablename__ = 'conversations'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), ForeignKey('organizations.id'), nullable=False, index=True)
    channel_id = Column(String(36), ForeignKey('channel_connections.id'), nullable=False)
    contact_id = Column(String(36), ForeignKey('contacts.id'), nullable=False)
    external_chat_id = Column(String(250), nullable=False)
    external_recipient_id = Column(String(250))
    status = Column(String(30), nullable=False, default='new')
    priority = Column(String(12), nullable=False, default='normal')
    assigned_user_id = Column(String(36), ForeignKey('users.id'))
    pinned = Column(Boolean, default=False, nullable=False)
    archived = Column(Boolean, default=False, nullable=False)
    unread_count = Column(Integer, default=0, nullable=False)
    reply_lock_owner_id = Column(String(36))
    reply_lock_expires_at = Column(Float)
    version = Column(Integer, default=0, nullable=False)
    last_message_at = Column(Float, default=now, nullable=False)
    last_inbound_at = Column(Float)
    first_reply_at = Column(Float)
    sla_warned_at = Column(Float)
    created_at = Column(Float, default=now, nullable=False)
    __table_args__ = (UniqueConstraint('channel_id', 'external_chat_id'),
        Index('ix_conversation_tenant_priority','organization_id','priority','last_message_at'),
        Index('ix_conversation_tenant_queue','organization_id','archived','status','last_message_at'))

class SavedInboxView(Base):
    __tablename__ = 'saved_inbox_views'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), ForeignKey('organizations.id'), nullable=False, index=True)
    creator_user_id = Column(String(36), ForeignKey('users.id'), nullable=False, index=True)
    name = Column(String(64), nullable=False)
    filters_json = Column(Text, nullable=False, default='{}')
    shared = Column(Boolean, nullable=False, default=False)
    created_at = Column(Float, nullable=False, default=now)
    __table_args__ = (UniqueConstraint('organization_id','creator_user_id','name'),)

class Message(Base):
    __tablename__ = 'messages'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), ForeignKey('organizations.id'), nullable=False, index=True)
    conversation_id = Column(String(36), ForeignKey('conversations.id'), nullable=False, index=True)
    external_id = Column(String(250))
    client_nonce = Column(String(100))
    direction = Column(String(12), nullable=False)
    kind = Column(String(32), default='text', nullable=False)
    body = Column(Text, nullable=False, default='')
    attachment = Column(Text)
    delivery_status = Column(String(24), nullable=False, default='delivered')
    author_user_id = Column(String(36))
    is_demo = Column(Boolean, default=False, nullable=False)
    created_at = Column(Float, default=now, nullable=False)
    __table_args__ = (UniqueConstraint('conversation_id', 'external_id'), UniqueConstraint('conversation_id', 'client_nonce'),
        Index('ix_message_tenant_conversation_direction_date','organization_id','conversation_id','direction','created_at'))

class Note(Base):
    __tablename__ = 'notes'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), ForeignKey('organizations.id'), nullable=False, index=True)
    conversation_id = Column(String(36), ForeignKey('conversations.id'), nullable=False, index=True)
    author_user_id = Column(String(36), ForeignKey('users.id'), nullable=False)
    body = Column(Text, nullable=False)
    created_at = Column(Float, default=now)

class AutomationRule(Base):
    __tablename__ = 'automation_rules'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), ForeignKey('organizations.id'), nullable=False, index=True)
    name = Column(String(120), nullable=False)
    event = Column(String(40), nullable=False)
    condition_type = Column(String(40), nullable=False)
    condition_value = Column(String(200), default='')
    action_type = Column(String(40), nullable=False)
    action_value = Column(String(200), default='')
    enabled = Column(Boolean, default=True, nullable=False)
    created_at = Column(Float, default=now)

class QuickReply(Base):
    __tablename__ = 'quick_replies'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), ForeignKey('organizations.id'), nullable=False, index=True)
    title = Column(String(90), nullable=False)
    body = Column(Text, nullable=False)
    created_at = Column(Float, default=now)

class ContactIdentity(Base):
    __tablename__ = 'contact_identities'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), ForeignKey('organizations.id'), nullable=False, index=True)
    contact_id = Column(String(36), ForeignKey('contacts.id'), nullable=False, index=True)
    channel_id = Column(String(36), ForeignKey('channel_connections.id'), nullable=False)
    external_user_id = Column(String(250), nullable=False)
    __table_args__ = (UniqueConstraint('channel_id', 'external_user_id'),)

class WebhookEvent(Base):
    __tablename__ = 'webhook_events'
    id = Column(String(36), primary_key=True, default=uid)
    provider = Column(String(32), nullable=False)
    fingerprint = Column(String(64), nullable=False)
    created_at = Column(Float, default=now)
    __table_args__ = (UniqueConstraint('provider', 'fingerprint'),)

class AuditLog(Base):
    __tablename__ = 'audit_logs'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), nullable=False, index=True)
    user_id = Column(String(36))
    action = Column(String(90), nullable=False)
    entity_id = Column(String(36))
    detail = Column(Text)
    created_at = Column(Float, default=now)

class Invite(Base):
    __tablename__ = 'invites'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), nullable=False)
    email = Column(String(250), nullable=False)
    role = Column(String(24), nullable=False)
    token_hash = Column(String(64), nullable=False, unique=True)
    expires_at = Column(Float, nullable=False)
    accepted_at = Column(Float)

class BillingEvent(Base):
    __tablename__ = 'billing_events'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), nullable=False)
    type = Column(String(30), nullable=False)
    detail = Column(Text, nullable=False, default='{}')
    created_at = Column(Float, default=now)


_engine = None
SessionLocal = None

def initialize(url=None):
    global _engine, SessionLocal
    _engine = engine_for(url)
    Base.metadata.create_all(bind=_engine)
    SessionLocal = sessionmaker(bind=_engine, autoflush=False, expire_on_commit=False)
    return _engine

def get_db():
    if SessionLocal is None:
        initialize()
    with SessionLocal() as db:
        yield db

class OutgoingJob(Base):
    __tablename__ = 'outgoing_jobs'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), nullable=False, index=True)
    message_id = Column(String(36), ForeignKey('messages.id'), nullable=False, unique=True)
    channel_id = Column(String(36), ForeignKey('channel_connections.id'), nullable=False)
    status = Column(String(25), nullable=False, default='queued')
    attempts = Column(Integer, default=0, nullable=False)
    next_attempt_at = Column(Float, default=now, nullable=False)
    claimed_at = Column(Float)
    last_error = Column(Text)
    created_at = Column(Float, default=now, nullable=False)

class WebsiteWidget(Base):
    __tablename__ = 'website_widgets'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), ForeignKey('organizations.id'), nullable=False, index=True)
    channel_id = Column(String(36), ForeignKey('channel_connections.id'), nullable=False, unique=True)
    public_key = Column(String(64), nullable=False, unique=True, index=True)
    allowed_origins = Column(Text, nullable=False, default='[]')
    greeting = Column(String(240), nullable=False, default='Здравствуйте! Чем можем вам помочь?')
    accent = Column(String(7), nullable=False, default='#6489F5')
    enabled = Column(Boolean, nullable=False, default=True)
    created_at = Column(Float, default=now, nullable=False)

class WebsiteVisitor(Base):
    __tablename__ = 'website_visitors'
    id = Column(String(36), primary_key=True, default=uid)
    organization_id = Column(String(36), ForeignKey('organizations.id'), nullable=False, index=True)
    widget_id = Column(String(36), ForeignKey('website_widgets.id'), nullable=False, index=True)
    token_hash = Column(String(64), nullable=False, unique=True)
    conversation_id = Column(String(36), ForeignKey('conversations.id'))
    nickname = Column(String(80), nullable=False)
    expires_at = Column(Float, nullable=False)
    last_activity_at = Column(Float, nullable=False)
    created_at = Column(Float, default=now, nullable=False)
