"""OSMANX OMNICHAT backend package."""
