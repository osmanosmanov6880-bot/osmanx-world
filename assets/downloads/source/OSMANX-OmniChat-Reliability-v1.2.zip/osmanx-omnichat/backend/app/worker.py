"""Dedicated durable background worker for production deployments.

Run one worker instance initially; the SQL outbox claims each message atomically.
Uncertain POST outcomes are quarantined rather than silently retried.
"""
import asyncio
import logging
import os
import signal
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[2]/'.env',override=False)
from . import db
from .services import process_outbox
from .synchronizers import sync_all_avito
from .extras import purge_expired

logging.basicConfig(level=os.environ.get('LOG_LEVEL','INFO'))
log=logging.getLogger('omnichat.worker')

async def cycle(index:int):
    if not db.SessionLocal:
        raise RuntimeError('Database not initialized')
    sent=await process_outbox(db.SessionLocal)
    if index%12==0 and os.getenv('ENABLE_AVITO_POLLING','true').lower()=='true':
        await sync_all_avito(db.SessionLocal)
    if index%20==0:
        with db.SessionLocal() as session:
            purge_expired(session)
    return sent

async def main():
    if os.getenv('APP_ENV')=='production' and not os.getenv('DATABASE_URL','').startswith(('postgresql://','postgresql+psycopg://')):
        raise RuntimeError('Production worker requires PostgreSQL')
    engine=db.initialize()
    stop=asyncio.Event()
    loop=asyncio.get_running_loop()
    for s in (signal.SIGTERM,signal.SIGINT):
        try:loop.add_signal_handler(s,stop.set)
        except NotImplementedError:pass
    log.info('OMNICHAT worker started')
    index=0
    while not stop.is_set():
        index+=1
        try:
            sent=await cycle(index)
            if sent:log.info('Outbox processed %s jobs',sent)
        except Exception:
            log.exception('Worker cycle failed')
        try:await asyncio.wait_for(stop.wait(),timeout=3)
        except asyncio.TimeoutError:pass
    log.info('OMNICHAT worker stopped cleanly')
    engine.dispose()

if __name__=='__main__':
    asyncio.run(main())
