"""Message normalization, deterministic rules, analytics and durable outgoing queue."""
import asyncio
import json
import math
import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from sqlalchemy.orm import Session
from sqlalchemy import update, or_
from .db import (Contact, Conversation, ChannelConnection, Message, Note,
                 AutomationRule, OutgoingJob, AuditLog, Membership, ContactIdentity, now, uid)
from .auth import audit
from .integrations.adapters import adapter_for, unseal
from .integrations.base import AdapterError

VALID_STATUSES = {'new','in_progress','waiting','closed'}
VALID_STAGES = {'new','interested','negotiation','payment','success','lost'}

def as_message(m):
    return dict(id=m.id, direction=m.direction, body=m.body, kind=m.kind, created_at=m.created_at, delivery_status=m.delivery_status, is_demo=m.is_demo, attachment=json.loads(m.attachment) if m.attachment else None)

def as_conversation(db, c):
    contact = db.get(Contact, c.contact_id)
    ch = db.get(ChannelConnection, c.channel_id)
    last = db.query(Message).filter_by(organization_id=c.organization_id,conversation_id=c.id).order_by(Message.created_at.desc()).first()
    return dict(id=c.id, contact_id=c.contact_id, contact_name=contact.name, channel_id=ch.id, channel=ch.provider, channel_name=ch.name, channel_mode=ch.mode, status=c.status, priority=c.priority, assigned_user_id=c.assigned_user_id, reply_lock_owner_id=c.reply_lock_owner_id if c.reply_lock_expires_at and c.reply_lock_expires_at>now() else None, reply_lock_expires_at=c.reply_lock_expires_at if c.reply_lock_expires_at and c.reply_lock_expires_at>now() else None, pinned=c.pinned, archived=c.archived, unread_count=c.unread_count, version=c.version, last_message_at=c.last_message_at, last_message=last.body[:140] if last else '', stage=contact.stage, tags=json.loads(contact.tags or '[]'), created_at=c.created_at)

def as_contact(c):
    return dict(id=c.id,name=c.name,phone=c.phone,email=c.email,tags=json.loads(c.tags or '[]'),stage=c.stage,deal_amount=c.deal_amount,deal_confirmed=c.deal_confirmed,next_followup_at=c.next_followup_at)

def run_rules(db, org_id, conv, message):
    if message.direction != 'in': return
    rules = db.query(AutomationRule).filter_by(organization_id=org_id,event='message_received',enabled=True).all()
    contact = db.get(Contact, conv.contact_id)
    for rule in rules:
        match = rule.condition_type == 'always' or (rule.condition_type == 'contains' and bool(rule.condition_value) and rule.condition_value.lower() in message.body.lower())
        if not match: continue
        if rule.action_type == 'tag' and rule.action_value:
            tags = json.loads(contact.tags or '[]')
            if rule.action_value not in tags:
                tags.append(rule.action_value)
                contact.tags = json.dumps(tags, ensure_ascii=False)
        elif rule.action_type == 'priority':
            conv.pinned = True
        elif rule.action_type == 'status' and rule.action_value in VALID_STATUSES:
            conv.status = rule.action_value
            if rule.action_value == 'closed': conv.archived = True
        elif rule.action_type == 'assign_least_busy' and not conv.assigned_user_id:
            choices = db.query(Membership).filter_by(organization_id=org_id,active=True,available=True).filter(Membership.role.in_(['operator','manager'])).all()
            if choices:
                workloads = {m.user_id: db.query(Conversation).filter_by(organization_id=org_id,assigned_user_id=m.user_id).filter(Conversation.status!='closed').count() for m in choices}
                conv.assigned_user_id = min(workloads, key=lambda u: (workloads[u],u))

def ingest_inbound(db, *, channel, external_chat_id, external_message_id, sender_id, sender_name, text, timestamp=None, kind='text', history=False, attachment=None):
    """Idempotent normalization, tenant scoped from verified channel, never auto-link by name."""
    if not external_message_id or not external_chat_id or not sender_id:
        return None
    existing = db.query(Conversation).filter_by(channel_id=channel.id,external_chat_id=str(external_chat_id),organization_id=channel.organization_id).first()
    if existing:
        conv = existing
    else:
        identity = db.query(ContactIdentity).filter_by(organization_id=channel.organization_id,channel_id=channel.id,external_user_id=str(sender_id)).first()
        if identity:
            contact = db.query(Contact).filter_by(id=identity.contact_id,organization_id=channel.organization_id).first()
        else:
            contact = None
        if contact is None:
            contact = Contact(organization_id=channel.organization_id,name=(sender_name or f'Клиент {str(sender_id)[-6:]}')[:160])
            db.add(contact); db.flush()
            db.add(ContactIdentity(organization_id=channel.organization_id,contact_id=contact.id,channel_id=channel.id,external_user_id=str(sender_id)))
        conv = Conversation(organization_id=channel.organization_id,channel_id=channel.id,contact_id=contact.id,external_chat_id=str(external_chat_id),external_recipient_id=str(sender_id),status='new',assigned_user_id=None)
        db.add(conv); db.flush()
    duplicate = db.query(Message).filter_by(organization_id=channel.organization_id,conversation_id=conv.id,external_id=str(external_message_id)).first()
    if duplicate: return duplicate
    event_time = float(timestamp or now())
    msg = Message(organization_id=channel.organization_id,conversation_id=conv.id,external_id=str(external_message_id),body=text or '[Медиа]',kind=kind,direction='in',attachment=json.dumps(attachment,ensure_ascii=False) if attachment else None,created_at=event_time,delivery_status='delivered',is_demo=(channel.mode=='demo'))
    db.add(msg)
    conv.last_message_at = max(conv.last_message_at or 0, event_time)
    conv.last_inbound_at = max(conv.last_inbound_at or 0, event_time)
    if not history:conv.unread_count += 1
    conv.archived = False
    if conv.status == 'closed': conv.status = 'new'
    conv.version += 1
    if not history:run_rules(db, channel.organization_id,conv,msg)
    db.flush()
    return msg

def analytics(db, org_id):
    """Tenant-scoped KPIs without loading entire historical message tables.

    Only the last seven days' inbound timestamps are loaded for chart bucketing.
    Counts and revenue are aggregated in the database. 'First response' uses
    the first reply timestamp recorded for each conversation, not a guess from
    the message text. All time buckets use the organization's IANA timezone.
    """
    from sqlalchemy import and_, case, exists, func, select
    from datetime import time as date_time
    from .db import Organization

    org = db.get(Organization,org_id)
    sla_seconds = 60*(org.sla_minutes if org else 5)
    clock=now()
    n_conv = db.query(func.count(Conversation.id)).filter(
        Conversation.organization_id==org_id).scalar() or 0
    n_closed = db.query(func.count(Conversation.id)).filter(
        Conversation.organization_id==org_id,Conversation.status=='closed').scalar() or 0
    n_inbound = db.query(func.count(Message.id)).filter(
        Message.organization_id==org_id,Message.direction=='in').scalar() or 0
    first_inbound=(db.query(Message.conversation_id.label('conversation_id'),
                func.min(Message.created_at).label('first_at'))
              .filter(Message.organization_id==org_id,Message.direction=='in')
              .group_by(Message.conversation_id).subquery())
    avg_reply = (db.query(func.avg((Conversation.first_reply_at-first_inbound.c.first_at)/60))
                 .join(first_inbound,first_inbound.c.conversation_id==Conversation.id)
                 .filter(Conversation.organization_id==org_id,
                         Conversation.first_reply_at.is_not(None),
                         Conversation.first_reply_at>=first_inbound.c.first_at).scalar())
    last_dir=(select(Message.direction)
              .where(Message.organization_id==org_id,
                     Message.conversation_id==Conversation.id)
              .order_by(Message.created_at.desc(),Message.id.desc())
              .limit(1).scalar_subquery())
    unanswered=db.query(func.count(Conversation.id)).filter(
        Conversation.organization_id==org_id,last_dir=='in').scalar() or 0
    responded_after_last=exists(select(Message.id).where(
        Message.organization_id==org_id,
        Message.conversation_id==Conversation.id,
        Message.direction=='out',Message.created_at>=Conversation.last_inbound_at))
    sla_overdue=db.query(func.count(Conversation.id)).filter(
        Conversation.organization_id==org_id,Conversation.status!='closed',
        Conversation.last_inbound_at.is_not(None),
        Conversation.last_inbound_at<clock-sla_seconds,
        ~responded_after_last).scalar() or 0

    by_channel=dict(db.query(ChannelConnection.provider,func.count(Conversation.id))
                    .join(Conversation,Conversation.channel_id==ChannelConnection.id)
                    .filter(Conversation.organization_id==org_id,
                            ChannelConnection.organization_id==org_id)
                    .group_by(ChannelConnection.provider).all())
    raw_workload=db.query(Conversation.assigned_user_id,func.count(Conversation.id)).filter(
        Conversation.organization_id==org_id).group_by(Conversation.assigned_user_id).all()
    workload={identity or 'unassigned':count for identity,count in raw_workload}

    # Avoid scanning old rows for the chart, including on very large tenants.
    zone=ZoneInfo((org.timezone if org else None) or 'UTC')
    today=datetime.fromtimestamp(clock,zone).date()
    earliest=today-timedelta(days=6)
    lower=datetime.combine(earliest,date_time.min,zone).timestamp()
    upper=datetime.combine(today+timedelta(days=1),date_time.min,zone).timestamp()
    recent=db.query(Message.created_at).filter(
        Message.organization_id==org_id,Message.direction=='in',
        Message.created_at>=lower,Message.created_at<upper).all()
    buckets=Counter(datetime.fromtimestamp(ts,zone).date() for (ts,) in recent)
    timeline=[{'day':(today-timedelta(days=i)).strftime('%d.%m'),
               'count':buckets[today-timedelta(days=i)]} for i in range(6,-1,-1)]

    is_confirmed=and_(Contact.stage=='success',Contact.deal_confirmed.is_(True),
                       Contact.deal_amount.is_not(None))
    is_potential=and_(Contact.deal_confirmed.is_(False),
                      Contact.stage.notin_(['lost','success']))
    r=db.query(func.coalesce(func.sum(case((is_confirmed,Contact.deal_amount),else_=0)),0),
               func.sum(case((is_confirmed,1),else_=0)),
               func.coalesce(func.sum(case((is_potential,Contact.deal_amount),else_=0)),0))        .filter(Contact.organization_id==org_id).one()
    confirmed_revenue,confirmed_deals,potential_revenue=r
    has_demo=db.query(Message.id).filter(Message.organization_id==org_id,
                                         Message.is_demo.is_(True)).limit(1).first() is not None
    return dict(
        sla_overdue=sla_overdue,conversations=n_conv,inbound=n_inbound,
        no_response=unanswered,closed=n_closed,
        avg_first_reply_min=round(float(avg_reply),1) if avg_reply is not None else None,
        by_channel=by_channel,days=timeline,workload=workload,
        confirmed_revenue=float(confirmed_revenue),confirmed_deals=int(confirmed_deals or 0),
        potential_revenue=float(potential_revenue),
        conversion_pct=round(100*int(confirmed_deals or 0)/n_conv,1) if n_conv else 0,
        currency=(org.currency if org else 'RUB'),
        timezone=(org.timezone if org else 'UTC'),
        data_source='demo' if has_demo else 'recorded')

async def process_outbox(db_factory, limit=20):
    """Single-worker retryable outbox. In production, deploy one dedicated worker instance."""
    processed=0
    with db_factory() as db:
        # Crash recovery: never blindly retry a claimed POST. The provider may have
        # received it before this process died. Quarantine it for human reconciliation.
        stale=db.query(OutgoingJob).filter(OutgoingJob.status=='processing', OutgoingJob.claimed_at < now()-120).all()
        for job in stale:
            job.status='uncertain'
            job.last_error='Worker stopped during send; verify delivery with provider before resolving'
            stale_message=db.get(Message,job.message_id)
            if stale_message:stale_message.delivery_status='uncertain'
        db.commit()
        due = db.query(OutgoingJob).filter(OutgoingJob.status=='queued',OutgoingJob.next_attempt_at<=now()).order_by(OutgoingJob.created_at.asc()).limit(limit).all()
        for job in due:
            # Optimistic claim; concurrent workers cannot both transition the same queued job.
            result = db.execute(update(OutgoingJob).where(OutgoingJob.id==job.id,OutgoingJob.status=='queued').values(status='processing',claimed_at=now(),attempts=OutgoingJob.attempts+1))
            db.commit()
            if result.rowcount != 1: continue
            message = db.get(Message, job.message_id)
            channel = db.get(ChannelConnection,job.channel_id)
            conv = db.get(Conversation,message.conversation_id) if message else None
            # A corrupt job or a programming mistake must never read/send another
            # company's message or silently switch to another provider account.
            if (not message or not channel or not conv or
                message.organization_id != job.organization_id or
                channel.organization_id != job.organization_id or
                conv.organization_id != job.organization_id or
                message.conversation_id != conv.id or conv.channel_id != channel.id or
                channel.id != job.channel_id or channel.mode != 'live' or
                channel.status != 'connected'):
                job.status='failed'; job.last_error='Несовпадение организации, диалога или канала'; db.commit(); continue
            try:
                if channel.provider in ('whatsapp','instagram','messenger') and (not conv.last_inbound_at or now()-conv.last_inbound_at > 24*3600):
                    raise AdapterError('24-часовое окно ответа закрыто; требуется разрешённый шаблон или новый ответ клиента')
                credentials=unseal(channel.encrypted_credentials)
                if credentials.get('expires_at') and credentials['expires_at'] < now()+300:
                    if channel.provider not in ('instagram','avito'):
                        raise AdapterError('Срок действия токена истёк; необходимо обновить подключение')
                    refreshed=await adapter_for(channel.provider).refresh_credentials(credentials)
                    if refreshed.get('expires_in'):
                        refreshed['expires_at']=now()+int(refreshed['expires_in'])
                    elif refreshed.get('expires_at') and refreshed['expires_at']<=now():
                        raise AdapterError('Сервис не вернул новый срок действия токена')
                    credentials=refreshed
                    from .integrations.adapters import seal
                    channel.encrypted_credentials=seal(credentials)
                    channel.token_expires_at=credentials.get('expires_at')
                    channel.last_verified_at=now()
                    db.commit()
                credentials['_outgoing_message_id']=message.id
                external_id = await adapter_for(channel.provider).send_message(credentials,channel,conv,message.body)
                message.external_id = external_id or f'local-out-{message.id}'
                message.delivery_status='accepted'
                # Provider accepted the API request. This is NOT customer delivery/read receipt.
                channel.outbound_api_accepted_at=now()
                job.status='done'
                job.last_error=None
                channel.last_error=None
            except AdapterError as exc:
                job.last_error=str(exc)[:320]
                channel.last_error=str(exc)[:320]
                if exc.uncertain:
                    job.status='uncertain'; message.delivery_status='uncertain'
                elif exc.retriable and job.attempts < 4:
                    job.status='queued'; job.next_attempt_at = now() + min(300, 5 * 2 ** job.attempts)
                    message.delivery_status='queued'
                else:
                    job.status='failed'; message.delivery_status='failed'
            except Exception:
                # Unknown post-send exceptions must not cause silent duplicate delivery.
                job.last_error='Неожиданная ошибка отправки. Проверить у провайдера'
                job.status='uncertain';message.delivery_status='uncertain'
            db.commit(); processed+=1
    return processed
