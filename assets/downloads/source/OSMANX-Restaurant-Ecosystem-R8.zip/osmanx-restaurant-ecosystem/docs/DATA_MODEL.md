# Модель данных R1–R4

| Таблица | Назначение | Ограничения |
|---|---|---|
| `users` | Пользователь и hash пароля | email lower-case unique |
| `organizations` | Юридическая/операционная группа | Валюта по ISO-коду, RUB по умолчанию |
| `memberships` | Роль человека в организации | PK(org,user), роль CHECK |
| `branches` | Заведение сети | FK на организацию, IANA timezone |
| `branch_grants` | Разрешённые филиалы для сотрудника | Композитные FK на membership и branch |
| `sessions` | Серверные сессии | SHA-256 токена, TTL 7 дней |
| `invitations` | Разовое приглашение | SHA-256 токена, 48 часов, redeemed_at |
| `menu_items` | Каталог и цена | Цена в integer cents, optimistic revision |
| `dining_tables` | Столы зала | Уникальная метка в филиале, capacity 1–40 |
| `orders` | Заголовок заказа | Revision, статус, snapshot total; один активный заказ на стол |
| `order_lines` | Позиции заказа | Замороженная цена, generated line total |
| `idempotency_records` | Результат повторной операции | PK(org,actor,operation_key), fingerprint |
| `audit_events` | История значимых действий | actor, org, branch, action, entity, timestamp |

БД работает со статусами `OPEN`, `SENT`, `PREPARING`, `READY`, `COMPLETED`, `CANCELLED`. Переход назад из `COMPLETED`/`CANCELLED` запрещён. Строки заказа редактируются только в `OPEN`. Записи в чужом филиале не проходят одновременно проверку API и составные внешние ключи PostgreSQL.

Точность: все деньги в минимальных единицах (для RUB в копейках). В HTTP API они передаются как **safe JSON integer** с бизнес-лимитами. Для будущих валют с тремя или нулём десятичных знаков будет введён справочник currency_exponents в R9. Сейчас default RUB, точность 2 знака, мультивалютное начисление не реализовано.

## R2 / миграция 002_operations.sql

- `reservations` — запись гостя, вместимость, временное окно `[starts_at, ends_at)`, статус и optimistic revision. Обязательные FK `(org,branch,table)`. **Exclusion GiST** с расширением `btree_gist` не допускает пересечения временных интервалов на одном столе для двух `CONFIRMED` броней даже при конкурирующих транзакциях. Имя гостя является персональными данными и требует политики хранения/удаления до production.
- `orders.reservation_id` — опциональный FK на бронь; unique индекс запрещает больше одного заказа на бронь. После закрытия заказа связанная бронь становится `COMPLETED` в той же транзакции.
- `orders.sent_at`, `preparing_at`, `ready_at` — серверные времена отправки, начала приготовления и выдачи. Для заказов, возникших до R2, эти поля остаются `NULL`: история задним числом **не выдумывается**.
- `staff_shifts` — организация/филиал/сотрудник, фактические времена открытия/закрытия, инициаторы, примечания, revision. Частичный UNIQUE `(organization_id,user_id) WHERE status='OPEN'` запрещает двойную активную смену в сети.
- `floor` и `kitchen` — вычисляемые представления API из бронирований, заказов и блюд; **отдельные дублирующие таблицы статусов не создаются**.

Для R2 сохранён audit trail на создание брони, посадку, отмену/неявку, открытие/закрытие смены и переходы заказа. Ограничения внешних ключей защищают от связей между филиалами.

## R3 / миграция 003_inventory_tasks.sql

| Таблица / поле | Назначение | Ключевой инвариант |
|---|---|---|
| `ingredients` | Справочник сырья, g/ml/pcs, минимум | `UNIQUE (org,branch,name)`, composite FK |
| `stock_balances` | Доступное количество, учётная стоимость, revision | Суммы неотрицательны, блокировка строк и optimistic version |
| `menu_recipes` | Заголовок текущей рецептуры блюда | PK `(org,branch,menu_item_id)`, revision |
| `recipe_components` | Норма ингредиента на одну порцию | FK на scoped menu+ingredient, уникальные компоненты |
| `suppliers` | Поставщик конкретного ресторана | FK на филиал |
| `purchase_receipts` | Приходная накладная и общая фактическая стоимость | Idempotency-Key и unique для непустого номера по поставщику |
| `purchase_receipt_lines` | Позиции накладной | Scoped ingredient/receipt FK |
| `stock_movements` | Складские движения приход/заказ/инвентаризация | Журнал событий, unique расход одного ingredient на order |
| `stock_counts` | Фактическое количество и отклонение | Фиксация before/after, стоимость отклонения |
| `orders.recipe_missing_lines` | Число строк заказа без рецептуры | NULL для исторического или ещё не отправленного заказа |
| `orders.actual_food_cost_cents` | Достоверно учтённая часть food cost | NULL при отсутствии информации, не P&L |
| `orders.costed_at` | Время фактического списания | NULL для исторического или незавершённого заказа |
| `order_recipe_snapshots` | Замороженный расход по каждой строке заказа | Scoped FK к order_line и ingredient, не переписывается правками рецепта |
| `restaurant_tasks` | Назначенная задача и её история изменений | Scoped FK, revision, допустимые статусы |

**Единицы:** `quantity_milli=18000` означает 18,000 г/мл/шт. Денежные суммы не умножаются на float. Все складские расчёты ведутся по отдельному филиалу в его валюте; для полного P&L нужна следующая финансовая модель. У недостающей рецептуры `foodCostComplete=false`, стоимость, если есть, считается **частичной**. Исторические заказы до R3 не переоцениваются.


## R4 / миграция 004_finance.sql

| Таблица | Назначение | Инварианты |
|---|---|---|
| `finance_expenses` | Ручные фактические операционные расходы филиала | `amount_cents` положительный `bigint`, обязательная дата, ограниченные категории; сумма никогда не переписывается; аннулирование требует `voided_at`, автора и причину; scoped FK |
| `finance_budgets` | План по категории для `YYYY-MM` и филиала | Составной PK `(org,branch,period,category)`, `amount_cents >= 0`, `revision` для конкурентных изменений, FK организации/филиала |
| `audit_events` (имеющаяся) | Audit trail создания/аннулирования расходов, изменения бюджетов | Инициатор, филиал, действие, документ, дополнительная метаинформация |
| `orders.completed_at` (имеющаяся) | Месяц признания фактической выручки | Считаются только `COMPLETED` с датой, переведённой в IANA timezone филиала |
| `stock_counts.delta_value_cents` (имеющаяся) | Недостача по инвентаризации | Только отрицательные разницы учитываются как отдельные потери; положительные не становятся выручкой |

**Расчётный P&L:**

- `revenueCents = SUM(total_cents)` завершённых заказов месяца филиала, без утверждения о реальном получении платежа.
- `foodCostCents = SUM(actual_food_cost_cents)` только при `costed_at IS NOT NULL` и `recipe_missing_lines=0` у каждого завершённого заказа. Иначе `foodCostCents=NULL`, `knownFoodCostCents` содержит только известную часть.
- `grossProfitCents = revenueCents - foodCostCents` при полной себестоимости; иначе `NULL`.
- `expensesCents = SUM(amount_cents)` только `finance_expenses.status='POSTED'` за период. `laborCostCents` — часть этой суммы с категорией `PAYROLL`.
- `stockLossCents = SUM(-delta_value_cents)` только для отрицательных инвентаризационных отклонений; увеличения остатка не признаются продажей.
- `operatingResultCents = grossProfitCents - expensesCents - stockLossCents`, либо `NULL`, если `grossProfitCents=NULL`. Этот показатель расчётный и может не включать неразмеченные статьи расходов, налоги, возвраты и амортизацию.
- `varianceCents = actualCents - plannedCents`; при отсутствующем плане или неполном факте — `NULL`. `foodCostRateBps = round(foodCost/revenue*10000)`, `laborCostRateBps = round(payroll/revenue*10000)` при положительной выручке, иначе `NULL`.

**Нельзя менять прошлую выручку под текущую цену** — суммы заказа и рецептуры уже зафиксированы. В R4 запрещено путать нулевой расход и недостающие сведения. Все ручные расходы — самостоятельные данные владельца; сверка с банковскими платежами или учётными регистрами ещё не реализована.

## R5 / миграция 005_guests.sql

| Сущность | Данные | Ограничения |
|---|---|---|
| `crm_guests` | Филиальная карточка: имя, необязательный email/phone, revision | Вся PII внутри `(organization_id,branch_id)`, нет авто-склейки по совпадению контактов |
| `guest_consents` | EMAIL/SMS, GRANTED/REVOKED, evidence, оператор, recorded_at, revision | Не создаётся без действия сотрудника; GRANTED требует основание, FK на гостя, ON DELETE CASCADE |
| `orders.guest_id` | Связь заказа с гостем | NULL для неидентифицированных, составной FK org/branch/guest, при удалении гостя значение становится NULL; сумма заказа неизменна |
| `guest_feedback` | Вид обращения, рейтинг 1..5 или свободный текст, решение, revision | Составные FK на гостя/заказ; для удаления гостя связанные отзывы удаляются, чтобы PII не осталась в комментариях |
| `audit_events` | События гостя/согласия/обращения | Без email/телефона в метаданных; UUID записи может сохраняться для служебного расследования |

Аналитика RFM использует только `orders.status='COMPLETED'` и `completed_at` в окне 365 суток. Для `guestId=NULL` заказ влияет на покрытие, но не формирует выдуманного пользователя. Суммы в `GuestInsights` вычисляются через BigInt/целочисленную арифметику и сериализуются как safe integers.

## R6 — данные диагностики и решений

`intelligence_decisions`: scoped FK `(organization_id,branch_id)` -> `branches`; `actor_id` -> `users`; `signal_id`, `baseline_period`, `title`, `hypothesis`, `action`, `implementation_cost_cents` (BIGINT minor units), `status`, `revision`, `baseline_revenue_cents`, nullable `baseline_profit_cents`, nullable `review_period`, nullable observed financial measures и текст `observation`. Любой nullable итог означает «не определён», никогда не заменяется 0. История переходов фиксируется в общем `audit_events`.

`intelligence_commands`: `(organization_id,branch_id,actor_id,idempotency_key)` как составной PK, `fingerprint` запроса, JSONB неизменяемого ответа. Транзакционная advisory-lock сериализует совпадающие ключи. Размер таблицы и срок хранения требуют дальнейшей эксплуатации/retention policy.

## R7 — `007_network.sql`

| Таблица | Назначение | Целостность и авторизация |
|---|---|---|
| `network_standards` | Название, активность, `revision`, JSONB-массив взвешенных критериев | FK организации, уникальная пара `(organization_id,id)`, аудит управления редакциями |
| `network_audits` | Неизменяемый snapshot стандарта и ответов, баллы `score_bps`, нарушения, серверная дата и проверяющий | Композитные FK `(organization_id,branch_id)` и `(organization_id,standard_id)`, индекс последних проверок |
| `network_corrective_actions` | Отдельное действие по каждому несоблюдённому пункту, версия, статус, результат, редакция стандарта | Композитный FK аудит/филиал/организация, FK на стандарт, транзакционная дедупликация нерешённых замечаний |
| `network_commands` | Область `(organization_id,actor_id,idempotency_key)`, отпечаток и сохранённый результат | Повтор операции не меняет данные; тот же ключ с другим телом — `409` |
| `audit_events` (существует с R1) | Следы создания/изменения стандарта, аудита и действия | Сохраняет актор, scope, тип события и время |

`score_bps` хранится целым числом от 0 до 10000. Старые аудиты не пересчитываются при обновлении стандарта. `openActions` рассчитывается SQL COUNT по всем незакрытым действиям филиала. `null` в сетевом отчёте означает отсутствие актуального сопоставимого аудита, а не нулевое качество.

## R8 — PostgreSQL `008_integrations.sql`

- `integration_connections`: связь с `(organization_id,branch_id)`, provider `IIKO`, внешний UUID ресторана, `sealed_credentials` (AES-256-GCM), состояние `UNVERIFIED/VERIFIED/ERROR/DISABLED`, оптимистическая `revision`, timestamps проверки и синхронизации. Уникальный тройной составной ключ для межтабличных FK.
- `integration_commands`: `(organization_id,actor_id,idempotency_key)` и хеш отпечатка операции, возвращаемый результат; plaintext credentials не попадают в отпечаток или ответ.
- `integration_sync_jobs`: `connection_id`, menuId, состояние `QUEUED/RUNNING/RETRY/SUCCEEDED/FAILED/CANCELLED`, попытки, время следующей попытки, lease token/deadline, безопасный код ошибки. Partial unique index разрешает только одну активную задачу на подключение. Составные FK защищают от чужого филиала.
- `integration_catalog`: текущий изолированный снимок блюд (внешний ID, название, категория, `price_cents NULL` при неопределённости, идентификатор успешной синхронизации). Снимок заменяется атомарно. Нет автоматического изменения `menu_items`.
- `integration_menu_links`: таблица соответствия `(connection_id, external_id) -> (organization_id,branch_id,menu_item_id)` для повторного явного импорта без создания дублей; FK на уже существующее `menu_items`.

Использование локальной валюты: iiko-цены R8 — RUB, конвертации не выполняются; разрешён явный импорт только в организацию `currency='RUB'`. Денежные значения в БД — `BIGINT` копейки. Никаких плавающих округлений при признании цены.
