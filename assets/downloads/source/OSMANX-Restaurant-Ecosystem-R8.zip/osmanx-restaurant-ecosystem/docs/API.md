# HTTP API R4 — v1

Base path: `/api/v1`; через веб-приложение запросы идут same-origin и проксируются на API. Формат JSON. Ошибка: `{"error":{"code":"STALE_VERSION","message":"..."}}` и корректный HTTP-статус.

## Аутентификация

- `POST /auth/register` — `email,password,displayName,organizationName,branchName`. Создаёт владельца и первую организацию атомарно, HttpOnly cookie.
- `POST /auth/login` — `email,password`, cookie.
- `GET /me` — `user,memberships,csrfToken`.
- `POST /auth/logout` — инвалидация сессии + очистка cookie.
- `POST /auth/accept-invite` — `token,email,displayName,password`. Одноразовое приглашение создаёт новую учётную запись. Присоединение **существующего** аккаунта — будущая функция.

Все POST/PATCH после входа требуют `x-osmanx-csrf` из `/me`. В браузере проверяется `Origin`. Запросы с заказами, бронями и сменами также требуют `Idempotency-Key` (уникальная строка 8–100 символов).

## Организация и филиалы

- `GET /organizations` — собственные организации и доступные филиалы.
- `GET /organizations/:organizationId/branches` — доступные филиалы.
- `POST /organizations/:organizationId/branches` — `name,timezone`. Роли: владелец/операционный директор.
- `POST /organizations/:organizationId/invitations` — `email,role,branchIds`, только владелец. Возвращает одноразовую `invitation.url` для ручной передачи. Срок 48 часов.

## Операционный префикс

Дальнейшие маршруты: `/organizations/:organizationId/branches/:branchId`.

- `GET /dashboard` → `dashboard` с реальной выручкой завершённых заказов, средним чеком, открытыми заказами и семидневной серией.
- `GET /menu` → `items`.
- `POST /menu` `{name,priceCents}` → `item`.
- `PATCH /menu/:itemId` `{revision,name?,priceCents?,active?}` → `item`.
- `GET /tables` → `tables`.
- `POST /tables` `{label,capacity}` → `table`.
- `GET /orders` → `orders`.
- `POST /orders` `{tableId:null | UUID}` → `order`, заголовок `Idempotency-Key`.
- `POST /orders/:orderId/items` `{menuItemId,quantity,expectedRevision}` → `order`, заголовок `Idempotency-Key`.
- `POST /orders/:orderId/status` `{status,expectedRevision}` → `order`, заголовок `Idempotency-Key`.

`priceCents`, `totalCents`, `averageCheckCents` — целые неотрицательные числа минимальных денежных единиц. Роль и филиал проверяются **на сервере**, а не только в интерфейсе. Код `409 STALE_VERSION` означает, что клиенту необходимо перечитать запись перед новой операцией.

## Операции R2

Маршруты ниже используют тот же `/organizations/:organizationId/branches/:branchId` и проверяют роль **на сервере**. Создание и изменение требуют CSRF + заголовка `Idempotency-Key` длиной 8–100 символов. У операций изменения обязательна `expectedRevision`.

- `GET /floor` → `{tables: FloorTable[]}`. `state` рассчитывается из активного заказа и ближайшей подтверждённой брони. Доступна следующая бронь `nextReservationAt` и `activeOrderId`.
- `GET /reservations` → `{reservations: Reservation[]}` за последние 7 дней и будущее (до 200 записей).
- `POST /reservations` → `{reservation}`; тело `{tableId,guestName,partySize,startsAt,durationMinutes}`. Время `startsAt` — строгий UTC ISO 8601 (`...Z`), длительность 30–240 минут, доступно до 90 дней вперёд. Несовместимая вместимость `409 CAPACITY`, пересечение с другой бронью `409 RESERVATION_CONFLICT`, занятый стол для близкой брони `409 TABLE_BUSY`.
- `POST /reservations/:reservationId/status` → `{reservation}`; `{status:"CANCELLED"|"NO_SHOW",expectedRevision}`. Неявку можно отметить не раньше 15 минут после начала брони.
- `POST /reservations/:reservationId/seat` → `{reservation,order}`; `{expectedRevision}`. Допускается от 30 минут до начала и до 30 минут после окончания брони. Заказ с новым `reservationId` создаётся транзакционно, только один раз.
- `GET /kitchen` → `{tickets: KitchenTicket[]}` для `SENT/PREPARING/READY`. Содержит snapshot блюд, статус, версию, `sentAt/preparingAt/readyAt`; дальнейшее продвижение идёт через уже существующий `POST /orders/:id/status` с правами кухни.
- `GET /staff` → `{staff: Employee[]}`. Для менеджера — сотрудники с доступом к филиалу, для остальных — только свой профиль.
- `GET /shifts` → `{shifts: Shift[]}`. Менеджер видит сотрудников филиала, исполнитель — только свои смены.
- `POST /shifts` → `{shift}`; `{userId?,openingNote?}`. Менеджер может открыть смену сотруднику своей организации/филиала; сотрудник — только себе. Одна открытая смена на сотрудника в организации.
- `POST /shifts/:shiftId/close` → `{shift}`; `{expectedRevision,closingNote?}`. Нельзя закрыть чужую смену без управленческой роли.

Ограничения: список бронирований не имеет серверной пагинации и редактирования слота; KDS использует **опрос**, а не WebSocket. Ни одна из этих функций не считается production-ready без запуска интеграционных и браузерных тестов.

## Инфраструктура

- `GET /health/live` — процесс API работает.
- `GET /health/ready` — ответ `200`, если доступна БД, или `503`.

Уже есть компактная машиночитаемая спецификация [openapi.yaml](openapi.yaml); при росте API схемы будут расширяться в рамках версионирования.

## Ресурсы и себестоимость R3

Префикс: `/organizations/:organizationId/branches/:branchId`. Все изменения требуют действующую cookie-сессию, корректный Origin, `x-osmanx-csrf` и `Idempotency-Key`. Данные неизменно проверяются по организации и филиалу в SQL. Количество задаётся **в тысячных долях единицы**: `quantityMilli=18000` = 18 грамм (если `unit=g`). Все суммы `*Cents` — целые минимальные единицы валюты.

- `GET /ingredients` → `{ingredients: Ingredient[]}` с `quantityMilli,valueCents,minQuantityMilli,lowStock,revision`.
- `POST /ingredients` → `{ingredient}`; `{name,unit:"g"|"ml"|"pcs",minQuantityMilli}`.
- `POST /ingredients/:ingredientId/minimum` → `{ingredient}`; `{minQuantityMilli,expectedRevision}`.
- `POST /ingredients/:ingredientId/count` → `{count}`; `{countedQuantityMilli,expectedRevision,foundValueCents?}`. Излишек без явной стоимости отклоняется `COUNT_GAIN_VALUE`, устаревшая версия `STALE_VERSION`.
- `GET /stock-movements` → `{movements}` — последние записи прихода, расхода и инвентаризации.
- `GET /recipes/:menuItemId` → `{recipe:Recipe|null}`. Если нет рецепта, `recipe=null`.
- `PUT /recipes/:menuItemId` → `{recipe}`; `{expectedRevision,components:[{ingredientId,quantityMilli}]}`. При первом создании `expectedRevision=0`; требуется минимум один компонент. Параллельные изменения защищены блокировкой блюда и optimistic revision.
- `GET /suppliers` → `{suppliers}`.
- `POST /suppliers` → `{supplier}`; `{name}`.
- `GET /receipts` → `{receipts}`.
- `POST /receipts` → `{receipt}`; `{supplierId:null|UUID,reference,lines:[{ingredientId,quantityMilli,totalCostCents}]}`. Одна накладная с тем же номером и поставщиком не проводится повторно. Строки списания/прихода атомарны.
- `GET /tasks` → `{tasks}`. Для руководителя — все задачи филиала, для исполнителя — только назначенные ему.
- `POST /tasks` → `{task}`; `{title,description?,assignedTo?:UUID|null,dueAt?:UTC_ISO|null}`. Роли: владелец, операционный директор, управляющий.
- `POST /tasks/:taskId/status` → `{task}`; `{status:"IN_PROGRESS"|"DONE"|"CANCELLED",expectedRevision}`. Исполнитель может начать/завершить; отменяет только управляющий.

**Расширения существующих ответов:** `GET /dashboard` добавил `lowStockCount` (не подменяет финансовый показатель). Объект `Order` содержит `actualFoodCostCents`, `missingRecipeLines`, `foodCostComplete`. Для ролей без доступа к данным склада поля себестоимости редактируются на сервере до возврата. При историческом заказе `actualFoodCostCents=null`, а при отсутствующей рецептуре `foodCostComplete=false` (частичная известная оценка).

Частые ошибки: `403 FORBIDDEN`, `404 INGREDIENT_NOT_FOUND`, `409 DUPLICATE`, `409 STOCK_SHORTAGE`, `409 STALE_VERSION`, `409 IDEMPOTENCY_CONFLICT`. Полная бухгалтерская себестоимость, налоги, закупочные заказы с согласованием и возвраты/сторнирование склада остаются задачами последующих релизов.


## Финансы и P&L R4

Для филиальных путей ниже действует тот же префикс `/organizations/:organizationId/branches/:branchId`. Все запросы требуют cookie-сессию, права `finance:read` и доступ к филиалу. Изменения также требуют CSRF, Origin и `Idempotency-Key` (8–100 символов). Нельзя использовать один ключ с разными телами операций. Суммы `*Cents` — точные целые неотрицательные значения, максимум 9 999 999 999 999; дата расхода — существующая календарная дата `YYYY-MM-DD`, период — `YYYY-MM` с годами 2000–2100.

- `GET /finance/report?period=YYYY-MM` → `{report:FinanceReport}`. Завершённые продажи, известный и полный Food Cost (`null`, если есть незакрытые данные), прямые недостачи, расходы по категориям, Labour/Food проценты в bps, валовая прибыль, расчётный результат, план-факт и `expenseCoverage:'UNVERIFIED'`.
- `GET /finance/ledger?period=YYYY-MM` → `{entries:LedgerEntry[]}`. Источники `ORDER`, `FOOD_COST`, `EXPENSE`, `STOCK_LOSS`, `sourceId` заказа/операции и `signedAmountCents`. Это ограниченная выборка (до 400 завершённых заказов и до 400 недостач, плюс расходы), **не полный экспорт бухгалтерского регистра**.
- `GET /finance/expenses?period=YYYY-MM` → `{expenses:Expense[]}` с историей, включая `VOIDED`.
- `POST /finance/expenses` → `{expense}` (201), `{category,description,amountCents,occurredOn}`. Категории: `PAYROLL`, `RENT`, `UTILITIES`, `MARKETING`, `SERVICES`, `OTHER`. `finance:write`: владелец/финансовый директор/операционный директор/управляющий. Это *расход*, а не новая накладная по продуктам.
- `POST /finance/expenses/:expenseId/void` → `{expense}` (200), `{expectedRevision,reason}`. `finance:void`: владелец, финансовый или операционный директор. Нельзя удалять исходную сумму; в исходной записи сохраняются причина и ответственный.
- `GET /finance/budgets?period=YYYY-MM` → `{budgets:Budget[]}`.
- `PUT /finance/budgets/:category` → `{budget}` (200), `{period,amountCents,expectedRevision}`. Категории бюджета: `REVENUE`, `FOOD_COST` и шесть категорий расходов. Для нового бюджета `expectedRevision=0`, для изменения — текущая `revision`. `finance:budget` доступно владельцу и директорам.
- `GET /organizations/:organizationId/finance/overview?period=YYYY-MM` → `{overview:FinanceNetwork}`. Отчёты только доступных филиалов; сеть учитывает неполноту Food Cost и не возвращает фиктивную консолидированную прибыль. Здесь путь **относительно `/api/v1`**, без филиального префикса.

Денежная семантика: `operatingResultCents` — **не подтверждённая чистая прибыль**; продажи признаются при завершении заказа по месяцу локальной зоны филиала, а расходы — по заданной дате. Покупка запасов в накладных не учитывается повторно в `finance_expenses`. Ошибки: `400 FINANCE_DATE/FINANCE_PERIOD/FINANCE_CATEGORY`, `403 FORBIDDEN`, `404 EXPENSE_NOT_FOUND`, `409 STALE_VERSION/IDEMPOTENCY_CONFLICT/EXPENSE_VOIDED`.

## Гости, история, RFM и обратная связь R5

Все филиальные пути ниже относительны к `/organizations/:organizationId/branches/:branchId` после `/api/v1`. Сессия проверяется на сервере; запись/изменение дополнительно требуют `Origin`, `x-osmanx-csrf` и `Idempotency-Key` (8–100 символов). Идентификация гостя вручную — по конкретной карточке, без автосопоставления имени, телефона или email. Эти данные считаются персональными.

- `GET /guests?after=UUID` → `{guests:Guest[],nextCursor:string|null}`. До 100 карточек по `id` на запрос, `after` необязателен. **guests:read:** owner, operations_director, manager, marketer, waiter, cashier. Аудитор и аналитик не получают PII-список.
- `POST /guests` → `{guest}`, `{displayName,email?,phone?}`. По умолчанию оба маркетинговых канала без согласия. **guests:write:** те же роли.
- `PATCH /guests/:guestId` → `{guest}`, `{displayName,email?,phone?,expectedRevision}`. При конфликте версии — 409; запись другого филиала — 404.
- `DELETE /guests/:guestId` → `{result:{guestId,erased:true}}`, `{expectedRevision}`. Только owner/operations_director. Транзакционно удаляет карточку и согласия, удаляет отзывы с возможной персональной информацией, отвязывает гостя от заказов, **сохраняя сумму и финансовые события**. Не удаляет персональные данные из резервных копий и независимых записей бронирований; необходима отдельная политика retention.
- `GET /guests/:guestId/visits` → `{visits:GuestVisit[]}` (до 200 последних привязанных завершённых заказов, **не** полная выгрузка).
- `GET /guests/:guestId/consents` → `{consents:Consent[]}`. **Отсутствие записи — НЕ разрешение на коммуникацию**.
- `PUT /guests/:guestId/consents/:channel` → `{consent}`, где `channel=EMAIL|SMS`, тело `{state:'GRANTED'|'REVOKED',evidence?,expectedRevision}`. Запись с `GRANTED` требует источник длиной минимум 8 символов; `expectedRevision=0` только при первом создании. Документ не подтверждает юридическую действительность источника. **guests:consent:** owner/operations_director/manager/marketer; официант и кассир не могут выдавать согласие. Отзывают тем же методом (`REVOKED`), мгновенно меняя состояние; отправка сообщений в R5 отсутствует.
- `POST /orders/:orderId/guest` → `{order}`, `{guestId:UUID|null,expectedRevision}`. Разрешено только для `OPEN` заказа и гостя того же филиала; ревизия заказа увеличивается. После отправки на кухню и закрытия заказа связь меняется только через будущие согласованные процессы, чтобы не дописывать историю задним числом.
- `GET /guest-insights` → `{insights:GuestInsights}`. Роль **guests:analytics:** owner/operations_director/manager/marketer/analyst/auditor. Присутствуют общее количество завершённых заказов, число идентифицированных, покрытие идентификацией, наблюдаемая доля повторных среди идентифицированных и RFM-баллы. Аналитик/аудитор получает только агрегаты (`guests:[]`), без персональных UUID и контактов.
- `GET /feedback` → `{feedback:GuestFeedback[]}`. Последние 200 обращений филиала (без пагинации). **feedback:read:** owner/operations_director/manager/marketer/analyst/auditor.
- `POST /feedback` → `{feedback}`, `{guestId?:UUID|null,orderId?:UUID|null,kind:'COMPLAINT'|'COMPLIMENT'|'SUGGESTION',rating?:1..5|null,comment?:string|null}`. Необходима оценка или текст. Если есть guest+order, их соответствие проверяется; нельзя прикрепить отзыв к чужому филиалу. **feedback:write:** owner/operations_director/manager/marketer/waiter/cashier. Источник считается ручным вводом, а не подтверждённой личностью автора отзыва.
- `POST /feedback/:feedbackId/resolve` → `{feedback}`, `{expectedRevision,resolution}`. Закрытие с зафиксированным действием от пяти символов, без повторного разрешения, **feedback:resolve:** owner/operations_director/manager/marketer.

**Формулы R5:** аналитика использует только завершённые заказы, срок 365 скользящих суток по UTC. Число *наблюдаемых визитов* = число завершённых заказов, явно связанных с гостем. Это **не обязательно число физических приходов**. `identificationCoveragePercent=100*identifiedOrders/completedOrders` или `null`, если заказов нет. `repeatShareOfIdentifiedPercent=100*guestsWithTwoPlusLinkedOrders/guestsWithOnePlusLinkedOrders` или `null`, если идентифицированных гостей с заказами нет. Это не retention всей клиентской базы.

- R recency в целых днях: 0–7 → 5, 8–30 → 4, 31–90 → 3, 91–180 → 2, более 180 → 1.
- F frequency: 1 → 1; 2 → 2; 3–5 → 3; 6–11 → 4; от 12 → 5.
- M monetary: квинтили по сумме связанных завершённых заказов среди гостей с посещениями, только когда их 5 или больше; иначе `null`. Одинаковые суммы получают одинаковый балл.
- `AT_RISK`: 2+ заказов за год, отсутствует новый заказ более 90 дней. Это **описательная группа, не прогноз оттока** и не доказательство причины. Другие сегменты: NEW, LOYAL (3+ заказов, последний не старше 30 дней), OTHER, NO_VISITS.

В R5 нет SMS/email-рассылок, интеграции с источниками отзывов, автоматического NPS/CSAT, привязки брони к CRM, импорта POS-гостей, гарантированного соответствия GDPR/152-ФЗ или правовых автоматизированных процедур. Всё это — отдельные обязательные проверки и реализации следующих релизов.

## R6 — OSMANX Intelligence

Все пути начинаются с `/api/v1/organizations/{organizationId}/branches/{branchId}`. Сервер удостоверяет активную cookie-сессию, CSRF для изменений и право доступа к конкретному филиалу. **intelligence:read** имеют owner, finance_director, operations_director, manager, analyst, auditor; **intelligence:write** — owner, finance_director, operations_director, manager.

- `GET /intelligence/diagnosis?period=2026-11`: сравнение с предшествующим месяцем, список сигналов и ограничения данных. Сервер вычисляет сигналы заново, без сохранённых «AI-выводов».
- `GET /intelligence/decisions`: последние 200 решений конкретного филиала с версиями, датами и результатами наблюдений.
- `POST /intelligence/decisions`: обязательные `Idempotency-Key`, `x-osmanx-csrf`; тело `{period,signalId,title,hypothesis,action,implementationCostCents}`. Сигнал обязан существовать в заново вычисленной диагностике. Финансовая база записывается при создании.
- `POST /intelligence/decisions/{decisionId}/status`: `{status,expectedRevision,reviewPeriod?,observation?}` плюс CSRF и уникальный Idempotency-Key. Состояния: `PROPOSED → IN_PROGRESS → IMPLEMENTED → REVIEWED`; отмена возможна из первых двух. Для REVIEWED нужно указать наблюдение и доступный календарный месяц **строго позднее** базового и не в будущем.

Расчёт `observedProfitDeltaCents = observedProfitCents − baselineProfitCents` делается только когда известны оба операционных результата. Значение — **описательное сравнение**: оно не является доказанным эффектом решения или ROI. В системе нет автоматических внешних AI-вызовов, рекламы, отправки сообщений или обещаний роста прибыли. Код ошибок: `403` право, `404` чужой филиал или чужое решение, `409` версия, переход состояния, повторный ключ с изменёнными данными.

## R7 — Network Quality / стандарты, аудиты и корректирующие действия

Все маршруты требуют действующей сессии. `POST/PATCH` требуют `x-osmanx-csrf`, Origin и `Idempotency-Key` (8–100 символов). Отсутствующий или недоступный филиал / стандарт / действие возвращает 404. Версии защищают от перезаписи конкурентных изменений (409).

**Организация:** `/organizations/:organizationId`

| Метод | Маршрут | Назначение и право |
|---|---|---|
| GET | `/standards` | Список стандартов; `network:standards:read` |
| POST | `/standards` | `{title,description,criteria:[{title,weight,critical}]}`; владелец или операционный директор |
| PATCH | `/standards/:standardId` | `{title,description,criteria,active,expectedRevision}`; новая редакция, старые аудиты не переписываются |
| GET | `/network/quality?standardId=UUID` | Доступные филиалы, итоговый балл актуальной редакции и точный счётчик открытых корректировок; `network:audits:read` и `network:standards:read` |
| GET | `/network/actions` | Централизованный журнал действий только по разрешённым филиалам, до 300 на филиал |

**Филиал:** `/organizations/:organizationId/branches/:branchId`

| Метод | Маршрут | Назначение и право |
|---|---|---|
| GET | `/audits?standardId=UUID` | Неизменяемая история аудитов (до 200 записей) |
| POST | `/audits` | `{standardId,expectedStandardRevision,answers:[{criterionId,passed,note}]}` — заполнить *все* пункты, описание нарушения не короче 8 символов |
| GET | `/corrective-actions` | Открытые, выполняемые и закрытые нарушения филиала (до 300 записей) |
| POST | `/corrective-actions/:actionId/status` | `{expectedRevision,status,resolution?}` — переход OPEN → IN_PROGRESS → RESOLVED, повторное открытие из RESOLVED в OPEN; при RESOLVED описание ≥8 символов |

Баллы аудита (0–10 000 basis points): `round(10000 × sum(weight_i if passed_i else 0) / sum(weight_i))`. `criticalFailures` — число неуспешных критических пунктов, независимо от общего балла. Чек-лист хранит собственный снимок критериев, редакции и оценок. Повторный независимый аудит создаёт новую историю, но по одному неустранённому пункту *в той же редакции стандарта* не создаёт дубль корректирующего действия.

**Важно:** `comparable=true` только для как минимум двух доступных филиалов с текущей редакцией выбранного активного стандарта и аудитами за один месяц по UTC. Если данных нет, `scoreBps=null`, а не 0. Баллы — самоотчётная проверка чек-листа, не независимая сертификация. Не реализованы франчайзи/регионы, контроль независимости аудитора, ежедневные контрольные листы, фото-доказательства и автоматические уведомления.

Полная спецификация: [`openapi.yaml`](openapi.yaml), версия 0.7.0.

## R8 — POS-интеграции iikoCloud (частичная готовность; без живых ключей)

Префикс: `/organizations/:organizationId/branches/:branchId/integrations`. Только API-сессия и проверенный доступ к `branchId`; для POST нужны CSRF и `Idempotency-Key` (8–100 ASCII символов). GET с метаданными не возвращает токены, Client Secret, API Key или зашифрованные значения.

| Метод | Адрес | Назначение | Разрешённые роли |
|---|---|---|---|
| GET | `/` | Список метаданных подключений филиала | owner, finance_director, operations_director, manager, analyst, auditor |
| POST | `/` | Создать **UNVERIFIED** подключение; `{alias,remoteOrganizationId,appId,clientSecret,apiKey}` | owner, operations_director |
| POST | `/:connectionId/verify` | `{expectedRevision}` — реальная проверка iiko через доступ к организации; затем `VERIFIED` | owner, operations_director |
| GET | `/:connectionId/menus` | Получить опубликованные внешние меню из официального API | Роли чтения |
| POST | `/:connectionId/sync` | `{menuId}` — поставить чтение каталога в устойчивую PostgreSQL-очередь | owner, operations_director |
| GET | `/:connectionId/jobs` | 40 последних попыток, статусы и безопасные коды ошибок | Роли чтения |
| GET | `/:connectionId/catalog` | Последний полученный снимок блюд (до 5000) | Роли чтения |
| POST | `/:connectionId/import` | `{sourceRunId,externalIds:[...]}` — перенести только явно отмеченные блюда с однозначной ценой в меню филиала | owner, operations_director, manager |
| POST | `/:connectionId/rotate` | `{expectedRevision,appId,clientSecret,apiKey}` — сменить ключи, отменить задачи, очистить снимок и вернуть статус `UNVERIFIED` | owner, operations_director |
| POST | `/:connectionId/disable` | `{expectedRevision}` — отключить коннектор, отменить очередь | owner, operations_director |

- Официальные маршруты iiko: `POST /api/v2/access_token`, `POST /api/1/organizations`, `POST /api/2/menu`, `POST /api/menu/v3/by_id`. Хост закреплён в серверном коде: `https://api-ru.iiko.services`. Указать произвольный URL нельзя.
- Запросы с ограничением времени 12 секунд, отключёнными HTTP-редиректами и ограничением ответа 8 MiB. Ошибки iiko возвращаются как безопасные коды без raw response и ключей.
- Воркеры забирают задачу через `FOR UPDATE SKIP LOCKED`; активна максимум одна синхронизация на коннектор. Истёкшая lease переотдаётся воркеру. Повторы только для временных ошибок (`429`, `5xx`, timeout), максимум четыре попытки с экспоненциальной задержкой.
- Полученный каталог заменяется **атомарно только при успешной загрузке**. При 401/ошибке старый снимок не перезаписывается. Перенос в локальное меню — только отдельной командой, транзакционно, с идентификаторами внешних блюд, чтобы не дублировать местные записи. Заказы не перезаписываются, исторические цены заказов остаются snapshot.
- **Неоднозначная или неизвестная цена — `priceCents: null`; это не нулевая цена.** Такие строки запрещены к переносу. Для iiko R8 поддерживает только организации с валютой `RUB`; трансформация валют не допускается.
- `ERROR` означает неудачную попытку проверки, а `VERIFIED` подтверждает доступ **на момент последней проверки**, не гарантирует будущую доступность. `DISABLED` нельзя использовать для синхронизации. Отсутствующий `INTEGRATION_ENCRYPTION_KEY` блокирует операции с ключами (`503`), но не ломает остальные модули.
- Не поддерживается: запись заказов или чеков в POS, двусторонняя синхронизация цен/склада, эквайринг, вебхуки и iiko-регион за пределами `api-ru.iiko.services`. Для r_keeper и Quick Resto адаптеры не заявлены работающими без договорённостей и подтверждённых API.
