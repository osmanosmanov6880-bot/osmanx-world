import test from 'node:test';
import assert from 'node:assert/strict';
import {calculateGuestInsights,consentEvidence,consentChannel,guestInput,feedbackInput} from '../src/domain/guests.ts';
import {isUuid} from '../src/domain/rules.ts';
const asOf=new Date('2026-11-07T00:00:00Z');
const visit=(guestId:string|null,day:string,totalCents:number)=>({guestId,orderId:`order-${day}-${guestId||'unknown'}`,completedAt:`${day}T12:00:00Z`,totalCents});

test('R5: guest details validated without implicit opt-in',()=>{
  assert.deepEqual(guestInput({displayName:'  Мария ',phone:'',email:''}),{displayName:'Мария',phone:null,email:null});
  assert.equal(guestInput({displayName:'Мария',phone:'+7 999 111-22-33',email:'M@EXAMPLE.COM'}).email,'m@example.com');
  assert.throws(()=>guestInput({displayName:'a',phone:null,email:null}),{code:'VALIDATION'});
  assert.throws(()=>guestInput({displayName:'Maria',phone:'abcdefg',email:null}),{code:'PHONE'});
});
test('R5: consent requires documented basis for granting and supports revocation',()=>{
  assert.equal(consentChannel('SMS'),'SMS');
  assert.throws(()=>consentChannel('PUSH'),{code:'CONSENT_CHANNEL'});
  assert.throws(()=>consentEvidence('GRANTED',''),{code:'VALIDATION'});
  assert.equal(consentEvidence('GRANTED','Бумажная анкета №91'),'Бумажная анкета №91');
  assert.equal(consentEvidence('REVOKED',undefined),null);
});
test('R5: feedback validates ratings and textual evidence',()=>{
  const input=feedbackInput({kind:'COMPLAINT',rating:1,comment:null,guestId:null,orderId:null},isUuid);
  assert.equal(input.rating,1);
  assert.throws(()=>feedbackInput({kind:'COMPLAINT',rating:6,guestId:null,orderId:null},isUuid),{code:'VALIDATION'});
  assert.throws(()=>feedbackInput({kind:'COMPLAINT',guestId:null,orderId:null},isUuid),{code:'FEEDBACK_EMPTY'});
});
test('R5: empty cohort has null coverage and no invented retention',()=>{
  const result=calculateGuestInsights(['one'],[],asOf);
  assert.equal(result.totalCompletedOrders,0);assert.equal(result.identificationCoveragePercent,null);
  assert.equal(result.repeatShareOfIdentifiedPercent,null);assert.equal(result.guests[0].segment,'NO_VISITS');
  assert.equal(result.guests[0].monetaryScore,null);
});
test('R5: no identity for orders means no evidence of repeat guests',()=>{
  const result=calculateGuestInsights(['g1'],[visit(null,'2026-11-06',5000),visit(null,'2026-11-05',3000)],asOf);
  assert.equal(result.totalCompletedOrders,2);assert.equal(result.identifiedCompletedOrders,0);
  assert.equal(result.identificationCoveragePercent,0);assert.equal(result.repeatGuests,0);
});
test('R5: completed linked orders give observational recency/frequency/money without causal claims',()=>{
  const result=calculateGuestInsights(['g1','g2'],[
    visit('g1','2026-11-06',5000),visit('g1','2026-10-30',7000),visit(null,'2026-11-05',1000),
    visit('g2','2026-10-01',6000),visit('g1','2025-01-01',90000)
  ],asOf);
  assert.equal(result.totalCompletedOrders,4);assert.equal(result.identifiedCompletedOrders,3);
  assert.equal(result.identificationCoveragePercent,75);assert.equal(result.repeatShareOfIdentifiedPercent,50);
  assert.equal(result.guests[0].visits365,2);assert.equal(result.guests[0].spend365Cents,12000);
  assert.equal(result.guests[0].frequencyScore,2);assert.equal(result.guests[0].monetaryScore,null);
  assert.equal(result.guests[0].recencyDays,0);
  assert.equal(result.guests[1].visits365,1);
});
test('R5: monetary quintiles rank documented cohort, equal spends receive equal rank',()=>{
  const ids=['a','b','c','d','e'];
  const result=calculateGuestInsights(ids,ids.map((id,i)=>visit(id,'2026-11-06',(i+1)*1000)),asOf);
  assert.equal(result.monetaryScoringAvailable,true);
  assert.deepEqual(result.guests.map(g=>g.monetaryScore),[1,2,3,4,5]);
  const tie=calculateGuestInsights(ids,ids.map(id=>visit(id,'2026-11-06',1000)),asOf);
  assert.deepEqual(tie.guests.map(g=>g.monetaryScore),[1,1,1,1,1]);
});
test('R5: future and old tickets excluded from 365-day observation window',()=>{
  const result=calculateGuestInsights(['a'],[visit('a','2026-11-08',50),visit('a','2023-01-01',30)],asOf);
  assert.equal(result.totalCompletedOrders,0);
});
