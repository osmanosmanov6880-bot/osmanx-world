import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID,randomBytes} from 'node:crypto';
import {runMigrations} from '../src/migrate.ts';
import {createPostgresStore} from '../src/infra/postgres.ts';
import {IntegrationRuntime} from '../src/integrations/runtime.ts';
const skip=!process.env.DATABASE_URL?'DATABASE_URL not configured':false;
test('R8 PostgreSQL: encrypted credentials, true menu import, revisions, tenant isolation and concurrent queue',{skip},async()=>{
  await runMigrations();const store=await createPostgresStore(process.env.DATABASE_URL!);
  try{
    const suffix=randomUUID();
    const a=await store.bootstrap({email:`r8a-${suffix}@test.example`,displayName:'A',passwordHash:'test-only',organizationName:'Group A',branchName:'A1'});
    const b=await store.bootstrap({email:`r8b-${suffix}@test.example`,displayName:'B',passwordHash:'test-only',organizationName:'Group B',branchName:'B1'});
    const first={userId:a.user.id,organizationId:a.organizationId,branchId:a.branchId,role:'owner' as const};
    const foreign={userId:b.user.id,organizationId:b.organizationId,branchId:b.branchId,role:'owner' as const};
    const second=await store.createBranch(a.organizationId,a.user.id,'A2','Europe/Moscow');
    const otherBranch={...first,branchId:second.id};
    const repo=store.integrationRepository();const remoteId=randomUUID();
    const worker=new IntegrationRuntime(repo,{verify:async()=>({id:remoteId,name:'iiko A1'}),menus:async()=>[{id:'menu',name:'Menu'}],
      catalog:async()=>[{externalId:'x',name:'Americano',category:'Coffee',priceCents:15000},
        {externalId:'unknown',name:'Mystery',category:'Coffee',priceCents:null}]},randomBytes(32).toString('base64'));
    const input={alias:'A1 iiko',remoteOrganizationId:remoteId,appId:'app-r8',clientSecret:'safe-secret-123456',apiKey:'api-key-123456'};
    const c=await worker.create(first,input,`create-${suffix}`);
    assert.equal((await worker.create(first,input,`create-${suffix}`)).id,c.id);
    await assert.rejects(repo.read(foreign,c.id),(e:any)=>e.status===404);
    await assert.rejects(repo.read(otherBranch,c.id),(e:any)=>e.status===404);
    const secret=(await repo.read(first,c.id)).sealedCredentials;assert(!secret.includes(input.apiKey));
    const v=await worker.verify(first,c.id,1,`verify-${suffix}`);assert.equal(v.state,'VERIFIED');
    const settled=await Promise.allSettled([
      repo.enqueue(first,c.id,'menu',`queuea-${suffix}`),repo.enqueue(first,c.id,'menu',`queueb-${suffix}`)
    ]);
    assert.equal(settled.filter(x=>x.status==='fulfilled').length,1);
    assert.equal(settled.filter(x=>x.status==='rejected').length,1);
    const job=(await repo.jobs(first,c.id))[0];
    assert.equal(await worker.runOnce(),'SUCCEEDED');
    assert.equal((await repo.catalog(first,c.id)).length,2);
    await assert.rejects(repo.importCatalog(first,c.id,job.id,['unknown'],`unknown-${suffix}`),(e:any)=>e.code==='MISSING_PRICE');
    const imported=await repo.importCatalog(first,c.id,job.id,['x'],`import-${suffix}`);
    assert.deepEqual(imported,{imported:1,created:1,updated:0});
    assert.equal((await store.menu(first)).filter(m=>m.name==='Americano'&&m.priceCents===15000).length,1);
    const retry=await repo.importCatalog(first,c.id,job.id,['x'],`import-${suffix}`);assert.deepEqual(retry,imported);
    const again=await repo.importCatalog(first,c.id,job.id,['x'],`import-b-${suffix}`);
    assert.equal(again.updated,1);assert.equal((await store.menu(first)).filter(m=>m.name==='Americano').length,1);
    await assert.rejects(repo.importCatalog(foreign,c.id,job.id,['x'],`foreign-${suffix}`),(e:any)=>e.status===404);
    // A stale worker token cannot replace a finished catalog.
    const another=await repo.enqueue(first,c.id,'menu',`another-${suffix}`);
    const claim=await repo.claim();assert(claim&&claim.id===another.id);
    assert.equal(await repo.succeed({...claim,leaseToken:randomUUID()},[]),false);
    assert.equal(await repo.succeed(claim,[]),true);
    assert.equal((await repo.catalog(first,c.id)).length,0);
    await assert.rejects(repo.importCatalog(first,c.id,job.id,['x'],`stale-${suffix}`),(e:any)=>e.code==='STALE_CATALOG');
    const disabled=await repo.transition(first,c.id,v.revision,'DISABLE',{},`disable-${suffix}`);assert.equal(disabled.state,'DISABLED');
    await assert.rejects(repo.enqueue(first,c.id,'menu',`disabled-queue-${suffix}`),(e:any)=>e.code==='NOT_VERIFIED');
  }finally{await store.close();}
});
