import test from 'node:test';
import assert from 'node:assert/strict';
import {hashPassword,verifyPassword,csrfToken,verifyCsrf,sessionCookie,cookieValue,RateLimiter,sha256,validateRequestOrigin} from '../src/infra/security.ts';

test('Пароли: scrypt с уникальной солью, проверка и отказ неверного',async()=>{
  const first=await hashPassword('Very-Strong-Test-Password-19');
  const second=await hashPassword('Very-Strong-Test-Password-19');
  assert.notEqual(first,second);assert.equal(await verifyPassword('Very-Strong-Test-Password-19',first),true);
  assert.equal(await verifyPassword('Wrong-Password',first),false);
  assert.equal(await verifyPassword('X','invalid'),false);
});
test('CSRF: HMAC привязан к сессии и секрету',()=>{
  const hash=sha256('token');const token=csrfToken(hash,'a'.repeat(32));
  assert.doesNotThrow(()=>verifyCsrf(token,token));
  assert.throws(()=>verifyCsrf(token,csrfToken(hash,'b'.repeat(32))),{code:'CSRF'});
  assert.throws(()=>verifyCsrf(token,undefined),{code:'CSRF'});
});
test('Cookie HttpOnly, SameSite и Secure в production',()=>{
  const c=sessionCookie('abc',true);
  assert.match(c,/HttpOnly/);assert.match(c,/SameSite=Lax/);assert.match(c,/Secure/);
  assert.equal(cookieValue('theme=dark; osmanx_session=abc; other=1','osmanx_session'),'abc');
});
test('Запрещены запросы из чужого Origin и исчерпание лимита',()=>{
  assert.doesNotThrow(()=>validateRequestOrigin('http://localhost:3000','http://localhost:3000'));
  assert.throws(()=>validateRequestOrigin('https://evil.example','http://localhost:3000'),{code:'ORIGIN'});
  const limiter=new RateLimiter(2,10000);limiter.check('ip',1000);limiter.check('ip',1001);
  assert.throws(()=>limiter.check('ip',1002),{status:429});
  assert.doesNotThrow(()=>limiter.check('ip',11002));
});
