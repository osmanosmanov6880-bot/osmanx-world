import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {runMigrations} from '../src/migrate.ts';
import {createPostgresStore} from '../src/infra/postgres.ts';
const skip=!process.env.DATABASE_URL?'DATABASE_URL not configured':false;

test('R5 PostgreSQL: migrations, scoped guests, consents, linked orders and irreversible erasure',{skip},async()=>{
  await runMigrations();const store=await createPostgresStore(process.env.DATABASE_URL!);
  try{
    const suffix=randomUUID();
    const a=await store.bootstrap({email:`r5-a-${suffix}@example.test`,displayName:'A',passwordHash:'test',organizationName:'R5 A',branchName:'A1'});
    const b=await store.bootstrap({email:`r5-b-${suffix}@example.test`,displayName:'B',passwordHash:'test',organizationName:'R5 B',branchName:'B1'});
    const aa={userId:a.user.id,organizationId:a.organizationId,branchId:a.branchId,role:'owner' as const};
    const bb={userId:b.user.id,organizationId:b.organizationId,branchId:b.branchId,role:'owner' as const};
    const input={displayName:'Test guest',phone:'+7 999 111-22-33',email:'guest@example.test'};
    const guest=await store.createGuest(aa,input,`guest-${suffix}`);
    assert.equal((await store.createGuest(aa,input,`guest-${suffix}`)).id,guest.id);
    await assert.rejects(store.guestVisits(bb,guest.id),(e:any)=>e.status===404);
    await assert.rejects(store.saveGuestConsent(bb,guest.id,'EMAIL','GRANTED','Consent Form 1',0,`foreign-consent-${suffix}`),(e:any)=>e.status===404);
    const consent=await store.saveGuestConsent(aa,guest.id,'EMAIL','GRANTED','Signed paper form 114',0,`consent-${suffix}`);
    assert.equal(consent.revision,1);assert.equal((await store.guestConsents(aa,guest.id))[0].state,'GRANTED');
    await assert.rejects(store.saveGuestConsent(aa,guest.id,'EMAIL','REVOKED',null,0,`stale-${suffix}`),(e:any)=>e.code==='STALE_VERSION');
    assert.equal((await store.saveGuestConsent(aa,guest.id,'EMAIL','REVOKED',null,1,`revoke-${suffix}`)).state,'REVOKED');
    const dish=await store.addMenuItem(aa,'R5 tea',23000);
    const order=await store.createOrder(aa,null,`order-${suffix}`);
    await assert.rejects(store.linkOrderGuest(bb,order.id,guest.id,1,`foreign-link-${suffix}`),(e:any)=>e.status===404);
    await store.linkOrderGuest(aa,order.id,guest.id,1,`link-${suffix}`);
    await store.addOrderItem(aa,order.id,dish.id,1,2,`item-${suffix}`);
    for(const [status,version] of [['SENT',3],['PREPARING',4],['READY',5],['COMPLETED',6]] as const)
      await store.changeOrderStatus(aa,order.id,status,version,`state-${status}-${suffix}`);
    assert.equal((await store.guestVisits(aa,guest.id))[0].totalCents,23000);
    assert.equal((await store.guestInsights(aa)).identifiedCompletedOrders,1);
    assert.equal((await store.guestInsights(bb)).identifiedCompletedOrders,0);
    const feedback=await store.createGuestFeedback(aa,{guestId:guest.id,orderId:order.id,kind:'COMPLAINT',rating:1,comment:'Cold soup'},`feedback-${suffix}`);
    assert.equal((await store.resolveGuestFeedback(aa,feedback.id,1,'Chef has been notified',`resolve-${suffix}`)).status,'RESOLVED');
    const erased=await store.eraseGuest(aa,guest.id,1,`erase-${suffix}`);
    assert.equal(erased.erased,true);assert.equal((await store.guestFeedback(aa)).length,0);
    assert.equal((await store.orders(aa)).find(o=>o.id===order.id)?.guestId,null);
    assert.equal((await store.guestInsights(aa)).identifiedCompletedOrders,0);
    const summary=(await store.dashboard(aa));assert.equal(summary.revenueCents,23000);
    assert.equal((await store.guests(aa,null)).guests.length,0);
    await assert.rejects(store.guestConsents(aa,guest.id),(e:any)=>e.status===404);
  }finally{await store.close();}
});

test('R5 PostgreSQL: concurrent updates cannot overwrite guest and consent revisions',{skip},async()=>{
  await runMigrations();const store=await createPostgresStore(process.env.DATABASE_URL!);
  try{
    const suffix=randomUUID();const a=await store.bootstrap({email:`r5-race-${suffix}@example.test`,displayName:'A',passwordHash:'test',organizationName:'Race',branchName:'A1'});
    const ctx={userId:a.user.id,organizationId:a.organizationId,branchId:a.branchId,role:'owner' as const};
    const input={displayName:'Guest',email:null,phone:null};const guest=await store.createGuest(ctx,input,`guest-${suffix}`);
    const result=await Promise.allSettled([
      store.updateGuest(ctx,guest.id,1,{...input,displayName:'First'},`first-${suffix}`),
      store.updateGuest(ctx,guest.id,1,{...input,displayName:'Second'},`second-${suffix}`)
    ]);
    assert.equal(result.filter(x=>x.status==='fulfilled').length,1);
    assert.equal((result.find(x=>x.status==='rejected') as PromiseRejectedResult).reason.code,'STALE_VERSION');
    const versions=await Promise.allSettled([
      store.saveGuestConsent(ctx,guest.id,'SMS','REVOKED',null,0,`sms-a-${suffix}`),
      store.saveGuestConsent(ctx,guest.id,'SMS','GRANTED','Signed SMS consent form',0,`sms-b-${suffix}`)
    ]);
    assert.equal(versions.filter(x=>x.status==='fulfilled').length,1);
    assert.equal((versions.find(x=>x.status==='rejected') as PromiseRejectedResult).reason.code,'STALE_VERSION');
  }finally{await store.close();}
});
