import test,{before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import type {Server} from 'node:http';
import type {AddressInfo} from 'node:net';
import {createApiServer} from '../src/http.ts';
import {FakeStore} from './fake-store.ts';
const store=new FakeStore(),config={origin:'http://localhost:3000',sessionSecret:'g'.repeat(64),secureCookies:false};
let server:Server,base='',cookie='',csrf='',org='',branch='',otherBranch='',guestId='',revision=1,orderId='',otherGuest='';
const root=(b=branch)=>`/api/v1/organizations/${org}/branches/${b}`;
async function req(path:string,method='GET',body?:unknown,auth:{cookie?:string;csrf?:string;key?:string}={}){
  const headers:Record<string,string>={};
  if(body!==undefined)headers['content-type']='application/json';
  if(auth.cookie||cookie)headers.cookie=auth.cookie||cookie;
  if(method!=='GET'){headers.origin=config.origin;headers['x-osmanx-csrf']=auth.csrf??csrf;}
  if(auth.key)headers['idempotency-key']=auth.key;
  const res=await fetch(`${base}${path}`,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});
  return {status:res.status,data:await res.json(),cookie:res.headers.get('set-cookie')?.split(';')[0]||''};
}
const key=()=>`r5-${randomUUID()}`;
before(async()=>{
  server=createApiServer(store,config);await new Promise<void>(done=>server.listen(0,'127.0.0.1',done));
  base=`http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  const owner=await req('/api/v1/auth/register','POST',{email:`r5-${randomUUID()}@example.test`,displayName:'Owner',password:'Guests-SecretPass-123',organizationName:'R5',branchName:'A'});
  assert.equal(owner.status,201);cookie=owner.cookie;org=owner.data.organizationId;branch=owner.data.branchId;
  csrf=(await req('/api/v1/me')).data.csrfToken;
  const b=await req(`/api/v1/organizations/${org}/branches`,'POST',{name:'B',timezone:'Europe/Moscow'});
  assert.equal(b.status,201);otherBranch=b.data.branch.id;
});
after(async()=>{await new Promise<void>(resolve=>server.close(()=>resolve()));});

test('R5 HTTP: guest creation, safe page, optimistic edits, idempotency and branch isolation',async()=>{
  const input={displayName:'Елена Смирнова',email:'elena@example.test',phone:'+7 999 111-22-33'};
  const k=key();let result=await req(`${root()}/guests`,'POST',input,{key:k});
  assert.equal(result.status,201);guestId=result.data.guest.id;
  assert.equal((await req(`${root()}/guests`,'POST',input,{key:k})).data.guest.id,guestId);
  assert.equal((await req(`${root()}/guests`,'POST',{...input,displayName:'Другая'},{key:k})).data.error.code,'IDEMPOTENCY_CONFLICT');
  assert.equal((await req(`${root()}/guests`)).data.guests.length,1);
  assert.equal((await req(`${root(otherBranch)}/guests`)).data.guests.length,0);
  assert.equal((await req(`${root(otherBranch)}/guests/${guestId}/visits`)).status,404);
  result=await req(`${root()}/guests/${guestId}`,'PATCH',{...input,displayName:'Елена С.',expectedRevision:2},{key:key()});
  assert.equal(result.status,409);
  result=await req(`${root()}/guests/${guestId}`,'PATCH',{...input,displayName:'Елена С.',expectedRevision:1},{key:key()});
  assert.equal(result.status,200);revision=result.data.guest.revision;assert.equal(revision,2);
  const second=await req(`${root()}/guests`,'POST',{displayName:'Другой гость',email:null,phone:null},{key:key()});
  otherGuest=second.data.guest.id;
});

test('R5 HTTP: consent record defaults absent, requires evidence, has versions and rejects unauthorized writers',async()=>{
  assert.deepEqual((await req(`${root()}/guests/${guestId}/consents`)).data.consents,[]);
  const path=`${root()}/guests/${guestId}/consents/EMAIL`;
  const noProof=await req(path,'PUT',{state:'GRANTED',evidence:'',expectedRevision:0},{key:key()});
  assert.equal(noProof.status,400);
  const k=key();let result=await req(path,'PUT',{state:'GRANTED',evidence:'Согласие на бумаге №11',expectedRevision:0},{key:k});
  assert.equal(result.status,200);assert.equal(result.data.consent.revision,1);
  assert.equal((await req(path,'PUT',{state:'GRANTED',evidence:'Согласие на бумаге №11',expectedRevision:0},{key:k})).data.consent.revision,1);
  const wrong=await req(path,'PUT',{state:'REVOKED',expectedRevision:0},{key:key()});assert.equal(wrong.status,409);
  result=await req(path,'PUT',{state:'REVOKED',expectedRevision:1},{key:key()});
  assert.equal(result.status,200);assert.equal(result.data.consent.state,'REVOKED');
  assert.equal((await req(`${root()}/guests/${guestId}/consents`)).data.consents[0].state,'REVOKED');
  assert.equal((await req(`${root(otherBranch)}/guests/${guestId}/consents`)).status,404);
});

test('R5 HTTP: order–guest linkage and real completed-visit analytics',async()=>{
  const item=await req(`${root()}/menu`,'POST',{name:'Чай',priceCents:30000});
  const start=await req(`${root()}/orders`,'POST',{tableId:null},{key:key()});orderId=start.data.order.id;
  assert.equal(start.data.order.guestId,null);
  const cross=await req(`${root(otherBranch)}/orders/${orderId}/guest`,'POST',{guestId,expectedRevision:1},{key:key()});
  assert.equal(cross.status,404);
  let link=await req(`${root()}/orders/${orderId}/guest`,'POST',{guestId,expectedRevision:1},{key:key()});
  assert.equal(link.status,200);assert.equal(link.data.order.guestId,guestId);
  const stale=await req(`${root()}/orders/${orderId}/guest`,'POST',{guestId:otherGuest,expectedRevision:1},{key:key()});
  assert.equal(stale.status,409);
  const line=await req(`${root()}/orders/${orderId}/items`,'POST',{menuItemId:item.data.item.id,quantity:1,expectedRevision:2},{key:key()});
  assert.equal(line.status,200);
  for(const [status,version] of [['SENT',3],['PREPARING',4],['READY',5],['COMPLETED',6]] as const){
    const done=await req(`${root()}/orders/${orderId}/status`,'POST',{status,expectedRevision:version},{key:key()});
    assert.equal(done.status,200);
  }
  const late=await req(`${root()}/orders/${orderId}/guest`,'POST',{guestId:otherGuest,expectedRevision:7},{key:key()});
  assert.equal(late.status,409);assert.equal(late.data.error.code,'ORDER_LOCKED');
  const visits=(await req(`${root()}/guests/${guestId}/visits`)).data.visits;
  assert.equal(visits.length,1);assert.equal(visits[0].totalCents,30000);
  const insight=(await req(`${root()}/guest-insights`)).data.insights;
  assert.equal(insight.totalCompletedOrders,1);assert.equal(insight.identifiedCompletedOrders,1);
  assert.equal(insight.identifiedGuestsWithVisits,1);assert.equal(insight.repeatShareOfIdentifiedPercent,0);
  assert.equal(insight.monetaryScoringAvailable,false);
});

test('R5 HTTP: complaint is verified by IDs, resolution tracked, no foreign records',async()=>{
  const invalid=await req(`${root()}/feedback`,'POST',{guestId:otherGuest,orderId,kind:'COMPLAINT',rating:1,comment:'Плохое обслуживание'},{key:key()});
  assert.equal(invalid.status,409);assert.equal(invalid.data.error.code,'FEEDBACK_IDENTITY');
  const created=await req(`${root()}/feedback`,'POST',{guestId,orderId,kind:'COMPLAINT',rating:2,comment:'Долго ожидали'},{key:key()});
  assert.equal(created.status,201);const id=created.data.feedback.id;
  assert.equal((await req(`${root()}/feedback`)).data.feedback.length,1);
  assert.equal((await req(`${root(otherBranch)}/feedback`)).data.feedback.length,0);
  const stale=await req(`${root()}/feedback/${id}/resolve`,'POST',{expectedRevision:2,resolution:'Обсудили с управляющим'},{key:key()});
  assert.equal(stale.status,409);
  const resolved=await req(`${root()}/feedback/${id}/resolve`,'POST',{expectedRevision:1,resolution:'Связались с гостем и обучили смену'},{key:key()});
  assert.equal(resolved.status,200);assert.equal(resolved.data.feedback.status,'RESOLVED');
});

test('R5 HTTP: PII erasure preserves orders and money but clears identity and linked feedback',async()=>{
  const wrong=await req(`${root()}/guests/${guestId}`,'DELETE',{expectedRevision:1},{key:key()});assert.equal(wrong.status,409);
  const k=key();const erased=await req(`${root()}/guests/${guestId}`,'DELETE',{expectedRevision:revision},{key:k});
  assert.equal(erased.status,200);assert.equal(erased.data.result.erased,true);
  assert.equal((await req(`${root()}/guests/${guestId}`,'DELETE',{expectedRevision:revision},{key:k})).status,200);
  assert.equal((await req(`${root()}/guests/${guestId}/visits`)).status,404);
  assert.equal((await req(`${root()}/feedback`)).data.feedback.length,0);
  const order=(await req(`${root()}/orders`)).data.orders.find((x:any)=>x.id===orderId);
  assert.equal(order.guestId,null);assert.equal(order.totalCents,30000);
  const overview=(await req(`${root()}/guest-insights`)).data.insights;
  assert.equal(overview.totalCompletedOrders,1);assert.equal(overview.identifiedCompletedOrders,0);
});

test('R5 HTTP: auditor can see aggregate analytics but not personal guest list or mutations',async()=>{
  const email=`r5-auditor-${randomUUID()}@example.test`;
  const invite=await req(`/api/v1/organizations/${org}/invitations`,'POST',{email,role:'auditor',branchIds:[branch]});
  const token=new URL(invite.data.invitation.url).searchParams.get('token');
  const accepted=await req('/api/v1/auth/accept-invite','POST',{token,email,displayName:'Auditor',password:'R5-SecretPass123'});
  assert.equal(accepted.status,201);const auditorCookie=accepted.cookie;
  const auditorCsrf=(await req('/api/v1/me','GET',undefined,{cookie:auditorCookie})).data.csrfToken;
  const auth={cookie:auditorCookie,csrf:auditorCsrf};
  const aggregated=await req(`${root()}/guest-insights`,'GET',undefined,auth);assert.equal(aggregated.status,200);
  assert.deepEqual(aggregated.data.insights.guests,[]);
  assert.equal((await req(`${root()}/guests`,'GET',undefined,auth)).status,403);
  assert.equal((await req(`${root()}/guests`,'POST',{displayName:'No access'},{...auth,key:key()})).status,403);
  assert.equal((await req(`${root()}/feedback`,'POST',{kind:'COMPLAINT',rating:1},{...auth,key:key()})).status,403);
  assert.equal((await req(`${root(otherBranch)}/guest-insights`,'GET',undefined,auth)).status,404);
});
