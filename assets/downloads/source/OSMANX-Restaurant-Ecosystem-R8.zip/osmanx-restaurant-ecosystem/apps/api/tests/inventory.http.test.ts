import {before,after,test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import type {AddressInfo} from 'node:net';
import type {Server} from 'node:http';
import {createApiServer} from '../src/http.ts';
import {FakeStore} from './fake-store.ts';

const store=new FakeStore(),config={origin:'http://localhost:3000',sessionSecret:'y'.repeat(64),secureCookies:false};
let server:Server,base:string,cookie='',csrf='',org='',branch='',ingredient='',item='',waiterCookie='',waiterCsrf='',waiterId='';
async function request(path:string,method='GET',body?:unknown,options:{cookie?:string;csrf?:string;key?:string}={}){
  const headers:Record<string,string>={};
  if(body!==undefined)headers['content-type']='application/json';
  if(options.cookie||cookie)headers['cookie']=options.cookie||cookie;
  if(method!=='GET'){headers.origin='http://localhost:3000';if(options.csrf||csrf)headers['x-osmanx-csrf']=options.csrf||csrf;}
  if(options.key)headers['idempotency-key']=options.key;
  const res=await fetch(`${base}${path}`,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});
  return {status:res.status,data:await res.json(),cookie:res.headers.get('set-cookie')?.split(';')[0]||''};
}
const root=()=>`/api/v1/organizations/${org}/branches/${branch}`;
before(async()=>{server=createApiServer(store,config);await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));base=`http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  const u=await request('/api/v1/auth/register','POST',{email:'r3-owner@integration.test',password:'SecureR3Password-001',displayName:'Владелец',organizationName:'R3 Restaurant',branchName:'Центр'});
  assert.equal(u.status,201);cookie=u.cookie;org=u.data.organizationId;branch=u.data.branchId;csrf=(await request('/api/v1/me')).data.csrfToken;});
after(async()=>{await new Promise<void>(resolve=>server.close(()=>resolve()));});

test('R3 HTTP ingredient, supplier, receipt, stock count + idempotency',async()=>{
  const absent=await request(`${root()}/ingredients`,'POST',{name:'Кофе',unit:'kg',minQuantityMilli:100},{key:'ing-r3bad'});
  assert.equal(absent.status,400);
  const i=await request(`${root()}/ingredients`,'POST',{name:'Кофейное зерно',unit:'g',minQuantityMilli:5000},{key:'ing-r3001'});
  assert.equal(i.status,201);ingredient=i.data.ingredient.id;
  assert.equal(i.data.ingredient.lowStock,true);
  assert.equal((await request(`${root()}/ingredients`,'POST',{name:'Кофейное зерно',unit:'g',minQuantityMilli:5000},{key:'ing-r3001'})).data.ingredient.id,ingredient);
  const s=await request(`${root()}/suppliers`,'POST',{name:'Поставщик Один'},{key:'sup-r3001'});
  assert.equal(s.status,201);
  const lines=[{ingredientId:ingredient,quantityMilli:100000,totalCostCents:75000}];
  const r=await request(`${root()}/receipts`,'POST',{supplierId:s.data.supplier.id,reference:'Поставка #1',lines},{key:'recv-r3001'});
  assert.equal(r.status,201);assert.equal(r.data.receipt.totalCostCents,75000);
  assert.equal((await request(`${root()}/receipts`,'POST',{supplierId:s.data.supplier.id,reference:'Поставка #1',lines},{key:'recv-r3001'})).data.receipt.id,r.data.receipt.id);
  const duplicateInvoice=await request(`${root()}/receipts`,'POST',{supplierId:s.data.supplier.id,reference:'Поставка #1',lines},{key:'recv-r3002'});
  assert.equal(duplicateInvoice.status,409);assert.equal(duplicateInvoice.data.error.code,'DUPLICATE');
  const updated=(await request(`${root()}/ingredients`)).data.ingredients[0];
  assert.equal(updated.quantityMilli,100000);assert.equal(updated.valueCents,75000);
  const stale=await request(`${root()}/ingredients/${ingredient}/count`,'POST',{countedQuantityMilli:90000,expectedRevision:1},{key:'count-stale-r3'});
  assert.equal(stale.status,409);
  const withoutValue=await request(`${root()}/ingredients/${ingredient}/count`,'POST',{countedQuantityMilli:120000,expectedRevision:updated.revision},{key:'count-no-value-r3'});
  assert.equal(withoutValue.status,400);
  const count=await request(`${root()}/ingredients/${ingredient}/count`,'POST',{countedQuantityMilli:90000,expectedRevision:updated.revision},{key:'count-r3001'});
  assert.equal(count.status,200);assert.equal(count.data.count.deltaQuantityMilli,-10000);
  assert.equal((await request(`${root()}/stock-movements`)).data.movements.length,2);
});

test('R3 HTTP recipe revision, invoice cost and consumption on completed order',async()=>{
  const m=await request(`${root()}/menu`,'POST',{name:'Эспрессо R3',priceCents:25000});assert.equal(m.status,201);item=m.data.item.id;
  const components=[{ingredientId:ingredient,quantityMilli:18000}];
  const first=await request(`${root()}/recipes/${item}`,'PUT',{expectedRevision:0,components},{key:'recipe-r3001'});
  assert.equal(first.status,200);assert.equal(first.data.recipe.revision,1);
  const stale=await request(`${root()}/recipes/${item}`,'PUT',{expectedRevision:0,components},{key:'recipe-r3002'});
  assert.equal(stale.status,409);
  const o=await request(`${root()}/orders`,'POST',{tableId:null},{key:'order-r3001'});assert.equal(o.status,201);
  const id=o.data.order.id;
  await request(`${root()}/orders/${id}/items`,'POST',{menuItemId:item,quantity:2,expectedRevision:1},{key:'add-r3001'});
  const sent=await request(`${root()}/orders/${id}/status`,'POST',{status:'SENT',expectedRevision:2},{key:'sent-r3001'});
  assert.equal(sent.status,200);assert.equal(sent.data.order.missingRecipeLines,0);
  const changed=await request(`${root()}/recipes/${item}`,'PUT',{expectedRevision:1,components:[{ingredientId:ingredient,quantityMilli:30000}]},{key:'recipe-r3003'});
  assert.equal(changed.status,200);
  for(const [status,expectedRevision,key] of [['PREPARING',3,'prep-r3001'],['READY',4,'ready-r3001'],['COMPLETED',5,'done-r3001']] as const){
    const v=await request(`${root()}/orders/${id}/status`,'POST',{status,expectedRevision},{key});assert.equal(v.status,200);
    if(status==='COMPLETED'){assert.equal(v.data.order.foodCostComplete,true);assert.equal(v.data.order.actualFoodCostCents,27000);}
  }
  assert.equal((await request(`${root()}/ingredients`)).data.ingredients[0].quantityMilli,54000);
  assert.equal((await request(`${root()}/dashboard`)).data.dashboard.revenueCents,50000);
});

test('R3 HTTP tasks: invitations, protected cost and employee-only task updates',async()=>{
  const invite=await request(`/api/v1/organizations/${org}/invitations`,'POST',{email:'r3-worker@integration.test',role:'waiter',branchIds:[branch]});
  assert.equal(invite.status,201);
  const token=new URL(invite.data.invitation.url).searchParams.get('token');
  const w=await request('/api/v1/auth/accept-invite','POST',{token,email:'r3-worker@integration.test',displayName:'Официант',password:'SecureR3Password-002'});
  assert.equal(w.status,201);waiterCookie=w.cookie;waiterId=w.data.user.id;
  waiterCsrf=(await request('/api/v1/me','GET',undefined,{cookie:waiterCookie})).data.csrfToken;
  const task=await request(`${root()}/tasks`,'POST',{title:'Инвентаризация по закрытию',description:'Пересчитать зерно',assignedTo:waiterId,dueAt:null},{key:'task-r3001'});
  assert.equal(task.status,201);
  const forbidden=await request(`${root()}/ingredients`,'GET',undefined,{cookie:waiterCookie});assert.equal(forbidden.status,403);
  const stockModify=await request(`${root()}/receipts`,'POST',{lines:[]},{cookie:waiterCookie,csrf:waiterCsrf,key:'waiter-stock-r3'});
  assert.equal(stockModify.status,403);
  const noAssign=await request(`${root()}/tasks`,'POST',{title:'Нельзя',description:'',assignedTo:waiterId},{cookie:waiterCookie,csrf:waiterCsrf,key:'waiter-task-r3'});
  assert.equal(noAssign.status,403);
  const own=await request(`${root()}/tasks`,'GET',undefined,{cookie:waiterCookie});assert.equal(own.status,200);
  assert.equal(own.data.tasks.length,1);
  const active=await request(`${root()}/tasks/${task.data.task.id}/status`,'POST',{status:'IN_PROGRESS',expectedRevision:1},{cookie:waiterCookie,csrf:waiterCsrf,key:'waiter-start-r3'});
  assert.equal(active.status,200);
  const done=await request(`${root()}/tasks/${task.data.task.id}/status`,'POST',{status:'DONE',expectedRevision:2},{cookie:waiterCookie,csrf:waiterCsrf,key:'waiter-done-r3'});
  assert.equal(done.status,200);assert.equal(done.data.task.status,'DONE');
  const orderView=await request(`${root()}/orders`,'GET',undefined,{cookie:waiterCookie});
  assert.equal(orderView.status,200);
  assert.equal(orderView.data.orders[0].actualFoodCostCents,null);
  assert.equal(orderView.data.orders[0].foodCostComplete,false);
});

test('R3 HTTP: insufficient stock rolls back completed order and preserves revenue',async()=>{
  // Previous case left 54 grams of coffee; current recipe needs 30 grams per serving.
  const before=(await request(`${root()}/ingredients`)).data.ingredients.find((x:any)=>x.id===ingredient);
  assert.equal(before.quantityMilli,54000);
  const priorRevenue=(await request(`${root()}/dashboard`)).data.dashboard.revenueCents;
  const created=await request(`${root()}/orders`,'POST',{tableId:null},{key:'order-r3-short-01'});
  assert.equal(created.status,201);const id=created.data.order.id;
  const add=await request(`${root()}/orders/${id}/items`,'POST',{menuItemId:item,quantity:2,expectedRevision:1},{key:'order-r3-short-02'});
  assert.equal(add.status,200);
  for(const [status,expectedRevision,key] of [['SENT',2,'order-r3-short-03'],['PREPARING',3,'order-r3-short-04'],['READY',4,'order-r3-short-05']] as const){
    const result=await request(`${root()}/orders/${id}/status`,'POST',{status,expectedRevision},{key});
    assert.equal(result.status,200);
  }
  const refused=await request(`${root()}/orders/${id}/status`,'POST',{status:'COMPLETED',expectedRevision:5},{key:'order-r3-short-06'});
  assert.equal(refused.status,409);assert.equal(refused.data.error.code,'STOCK_SHORTAGE');
  const after=(await request(`${root()}/ingredients`)).data.ingredients.find((x:any)=>x.id===ingredient);
  assert.equal(after.quantityMilli,before.quantityMilli);assert.equal(after.valueCents,before.valueCents);
  assert.equal((await request(`${root()}/dashboard`)).data.dashboard.revenueCents,priorRevenue);
  const unchanged=(await request(`${root()}/orders`)).data.orders.find((x:any)=>x.id===id);
  assert.equal(unchanged.status,'READY');assert.equal(unchanged.actualFoodCostCents,null);
});
