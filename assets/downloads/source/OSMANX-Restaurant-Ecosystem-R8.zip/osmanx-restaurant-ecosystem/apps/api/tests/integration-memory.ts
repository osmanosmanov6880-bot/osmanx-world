// R8 test-only store. Production always uses PostgreSQL implementation.
import {randomUUID} from 'node:crypto';
import {createHash} from 'node:crypto';
import {assert} from '../src/domain/rules.ts';
import type {Ctx} from '../src/store.ts';
import type {IntegrationRepository} from '../src/integrations/repository.ts';
import type {CatalogItem,CatalogProduct,ClaimedSync,IntegrationConnection,StoredIntegration,SyncJob} from '../src/domain/integrations.ts';
const now=()=>new Date().toISOString();
export class MemoryIntegrationRepository implements IntegrationRepository {
  private entries=new Map<string,StoredIntegration & {org:string;branch:string}>();
  private rows=new Map<string,CatalogItem[]>();
  private jobMap=new Map<string,SyncJob & {org:string;branch:string;lease:string|null}>();
  private links=new Map<string,string>();
  private commands=new Map<string,{fingerprint:string;value:unknown}>();
  private command<T>(ctx:Ctx,key:string,request:unknown,fn:()=>T):T{
    const k=`${ctx.organizationId}:${ctx.userId}:${key}`;
    const fingerprint=createHash('sha256').update(JSON.stringify(request)).digest('hex');
    const prior=this.commands.get(k);
    if(prior){assert(prior.fingerprint===fingerprint,409,'IDEMPOTENCY_CONFLICT','Ключ уже использован');return structuredClone(prior.value) as T;}
    const result=fn();this.commands.set(k,{fingerprint,value:structuredClone(result)});return structuredClone(result);
  }
  private get(ctx:Ctx,id:string){
    const v=this.entries.get(id);
    assert(v&&v.org===ctx.organizationId&&v.branch===ctx.branchId,404,'NOT_FOUND','Подключение не найдено');
    return v;
  }
  private public(v:StoredIntegration&{org:string;branch:string}):IntegrationConnection{
    const {org,branch,sealedCredentials,...rest}=v;return structuredClone(rest);
  }
  async list(ctx:Ctx){return [...this.entries.values()].filter(e=>e.org===ctx.organizationId&&e.branch===ctx.branchId).map(e=>this.public(e));}
  async read(ctx:Ctx,id:string){const {org,branch,...v}=this.get(ctx,id);return structuredClone(v);}
  async create(ctx:Ctx,input:{id:string;alias:string;remoteOrganizationId:string;sealedCredentials:string;fingerprint:string},key:string){
    return this.command(ctx,key,{action:'create',alias:input.alias,remote:input.remoteOrganizationId,fingerprint:input.fingerprint},()=>{
      const c:StoredIntegration&{org:string;branch:string}={id:input.id,branchId:ctx.branchId,provider:'IIKO',alias:input.alias,
        remoteOrganizationId:input.remoteOrganizationId,sealedCredentials:input.sealedCredentials,org:ctx.organizationId,branch:ctx.branchId,
        state:'UNVERIFIED',revision:1,remoteOrganizationName:null,verifiedAt:null,lastErrorCode:null,lastSyncAt:null,
        createdAt:now(),updatedAt:now()};
      this.entries.set(c.id,c);return this.public(c);
    });
  }
  async transition(ctx:Ctx,id:string,revision:number,action:'VERIFY'|'ERROR'|'DISABLE'|'ROTATE',
    value:{remoteOrganizationName?:string;errorCode?:string;sealedCredentials?:string;fingerprint?:string},key:string){
    return this.command(ctx,key,{action,id,revision,remoteName:value.remoteOrganizationName,errorCode:value.errorCode,fingerprint:value.fingerprint},()=>{
      const c=this.get(ctx,id);assert(c.revision===revision,409,'VERSION_CONFLICT','Подключение изменено');
      if(action==='VERIFY')assert(c.state!=='DISABLED',409,'DISABLED','Отключено');
      if(action==='VERIFY'){c.state='VERIFIED';c.remoteOrganizationName=value.remoteOrganizationName||null;c.verifiedAt=now();}
      if(action==='ERROR')c.state='ERROR';
      if(action==='DISABLE')c.state='DISABLED';
      if(action==='ROTATE'){
        assert(value.sealedCredentials,400,'VALIDATION','Нужен новый секрет');c.state='UNVERIFIED';
        c.sealedCredentials=value.sealedCredentials;c.remoteOrganizationName=null;c.verifiedAt=null;this.rows.delete(id);
      }
      if(action==='ROTATE'||action==='DISABLE')for(const j of this.jobMap.values())if(j.connectionId===id&&['QUEUED','RETRY','RUNNING'].includes(j.status)){
        j.status='CANCELLED';j.lease=null;j.completedAt=now();
      }
      c.lastErrorCode=value.errorCode||null;c.updatedAt=now();c.revision++;return this.public(c);
    });
  }
  async enqueue(ctx:Ctx,id:string,menuId:string,key:string):Promise<SyncJob>{
    return this.command(ctx,key,{type:'enqueue',id,menuId},()=>{
      const c=this.get(ctx,id);assert(c.state==='VERIFIED',409,'NOT_VERIFIED','Не подтверждено');
      assert(![...this.jobMap.values()].some(j=>j.connectionId===id&&['QUEUED','RETRY','RUNNING'].includes(j.status)),409,'SYNC_BUSY','Задача уже есть');
      const job:SyncJob&{org:string;branch:string;lease:string|null}={id:randomUUID(),connectionId:id,menuId,status:'QUEUED',attemptCount:0,
        nextAttemptAt:now(),lastErrorCode:null,createdAt:now(),completedAt:null,itemsCount:null,org:ctx.organizationId,branch:ctx.branchId,lease:null};
      this.jobMap.set(job.id,job);return this.cleanJob(job);
    });
  }
  private cleanJob(j:SyncJob&{org:string;branch:string;lease:string|null}):SyncJob{
    const {org,branch,lease,...rest}=j;return structuredClone(rest);
  }
  async jobs(ctx:Ctx,id:string){this.get(ctx,id);return [...this.jobMap.values()].filter(j=>j.org===ctx.organizationId&&j.branch===ctx.branchId&&j.connectionId===id).map(j=>this.cleanJob(j));}
  async catalog(ctx:Ctx,id:string){this.get(ctx,id);return structuredClone(this.rows.get(id)||[]);}
  async importCatalog(ctx:Ctx,id:string,jobId:string,ids:string[],key:string){
    return this.command(ctx,key,{type:'import',id,jobId,ids},()=>{
      const c=this.get(ctx,id);assert(c.state==='VERIFIED',409,'NOT_VERIFIED','Не подтверждено');
      assert(this.jobMap.get(jobId)?.status==='SUCCEEDED',409,'STALE_CATALOG','Нет завершённого импорта');
      const selected=(this.rows.get(id)||[]).filter(r=>ids.includes(r.externalId));
      assert(selected.length===ids.length&&selected.every(r=>r.sourceRunId===jobId),409,'STALE_CATALOG','Каталог изменился');
      assert(selected.every(r=>r.priceCents!==null),409,'MISSING_PRICE','Нет цены');
      let created=0,updated=0;
      for(const item of selected){const link=`${id}:${item.externalId}`;
        if(this.links.has(link))updated++;else{this.links.set(link,randomUUID());created++;}
        item.importedMenuItemId=this.links.get(link)!;
      }
      return {imported:created+updated,created,updated};
    });
  }
  async claim(){
    const row=[...this.jobMap.values()].find(j=>['QUEUED','RETRY'].includes(j.status)&&this.entries.get(j.connectionId)?.state==='VERIFIED');
    if(!row)return null;
    row.status='RUNNING';row.lease=randomUUID();row.attemptCount++;
    const c=this.entries.get(row.connectionId)!;
    return {id:row.id,connectionId:row.connectionId,organizationId:row.org,branchId:row.branch,menuId:row.menuId,
      leaseToken:row.lease,attemptCount:row.attemptCount,sealedCredentials:c.sealedCredentials,
      remoteOrganizationId:c.remoteOrganizationId};
  }
  async succeed(job:ClaimedSync,items:CatalogProduct[]){
    const row=this.jobMap.get(job.id);if(!row||row.status!=='RUNNING'||row.lease!==job.leaseToken)return false;
    this.rows.set(job.connectionId,items.map(i=>({...i,sourceRunId:job.id,importedMenuItemId:this.links.get(`${job.connectionId}:${i.externalId}`)||null})));
    row.status='SUCCEEDED';row.lease=null;row.completedAt=now();row.itemsCount=items.length;
    this.entries.get(job.connectionId)!.lastSyncAt=now();return true;
  }
  async fail(job:ClaimedSync,code:string){
    const row=this.jobMap.get(job.id);if(!row||row.status!=='RUNNING'||row.lease!==job.leaseToken)return false;
    row.status=job.attemptCount<4&&['RATE_LIMIT','UNAVAILABLE','TIMEOUT'].includes(code)?'RETRY':'FAILED';
    row.lease=null;row.lastErrorCode=code;if(row.status==='FAILED')row.completedAt=now();
    this.entries.get(job.connectionId)!.lastErrorCode=code;return true;
  }
}
