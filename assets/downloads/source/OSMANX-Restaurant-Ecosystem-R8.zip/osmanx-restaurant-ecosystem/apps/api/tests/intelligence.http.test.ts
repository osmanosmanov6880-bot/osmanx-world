import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import type {AddressInfo} from 'node:net';
import {createApiServer} from '../src/http.ts';
import {FakeStore} from './fake-store.ts';
const cfg={origin:'http://localhost:3000',sessionSecret:'i'.repeat(64),secureCookies:false};
test('R6 HTTP: scope, diagnosis, decision lifecycle, idempotency and version checks',async()=>{
  const store=new FakeStore();const server=createApiServer(store,cfg);
  await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));
  const host=`http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  let cookie='',csrf='';
  async function call(path:string,method='GET',data?:unknown,key?:string){const headers:Record<string,string>={};
    if(cookie)headers.cookie=cookie;
    if(data!==undefined)headers['content-type']='application/json';
    if(method!=='GET'){headers.origin=cfg.origin;if(csrf)headers['x-osmanx-csrf']=csrf;}
    if(key)headers['idempotency-key']=key;
    const r=await fetch(host+path,{method,headers,body:data===undefined?undefined:JSON.stringify(data)});
    return {status:r.status,body:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};
  }
  try{
    const reg=await call('/api/v1/auth/register','POST',{email:`r6-${randomUUID()}@example.test`,password:'R6safePassword123456',displayName:'Owner',organizationName:'Network',branchName:'A'});
    assert.equal(reg.status,201);cookie=reg.cookie!;csrf=(await call('/api/v1/me')).body.csrfToken;
    const base=`/api/v1/organizations/${reg.body.organizationId}/branches/${reg.body.branchId}`;
    const period=new Date().toISOString().slice(0,7);
    const dish=await call(`${base}/menu`,'POST',{name:'Without recipe',priceCents:1999});
    assert.equal(dish.status,201);
    const order=await call(`${base}/orders`,'POST',{tableId:null},'r6-order-new');assert.equal(order.status,201);
    const withItem=await call(`${base}/orders/${order.body.order.id}/items`,'POST',{menuItemId:dish.body.item.id,quantity:1,expectedRevision:1},'r6-order-item');
    assert.equal(withItem.status,200);
    for(const [status,revision] of [['SENT',2],['PREPARING',3],['READY',4],['COMPLETED',5]] as const){
      const r=await call(`${base}/orders/${order.body.order.id}/status`,'POST',{status,expectedRevision:revision},`r6-order-${status.toLowerCase()}`);
      assert.equal(r.status,200);
    }
    const diagnosis=await call(`${base}/intelligence/diagnosis?period=${period}`);assert.equal(diagnosis.status,200);
    assert(diagnosis.body.diagnosis.signals.some((s:any)=>s.id==='MISSING_FOOD_COST'));
    const body={period,signalId:'MISSING_FOOD_COST',title:'Проверить себестоимость',hypothesis:'Для части блюд отсутствует рецептура',action:'Проверить нормы расхода ингредиентов',implementationCostCents:12000};
    const first=await call(`${base}/intelligence/decisions`,'POST',body,'r6-decision-one');assert.equal(first.status,201);
    const same=await call(`${base}/intelligence/decisions`,'POST',body,'r6-decision-one');assert.equal(same.body.decision.id,first.body.decision.id);
    const conflict=await call(`${base}/intelligence/decisions`,'POST',{...body,title:'Другой заголовок'},'r6-decision-one');assert.equal(conflict.status,409);
    const id=first.body.decision.id;
    const premature=await call(`${base}/intelligence/decisions/${id}/status`,'POST',{status:'REVIEWED',expectedRevision:1,reviewPeriod:'2099-12',observation:'Проверка без реализации'},'r6-premature');assert.equal(premature.status,409);
    const changed=await call(`${base}/intelligence/decisions/${id}/status`,'POST',{status:'IN_PROGRESS',expectedRevision:1},'r6-progress');assert.equal(changed.status,200);
    assert.equal(changed.body.decision.revision,2);
    const stale=await call(`${base}/intelligence/decisions/${id}/status`,'POST',{status:'IMPLEMENTED',expectedRevision:1},'r6-stale');assert.equal(stale.status,409);
    assert.equal((await call(`${base}/intelligence/decisions`)).body.decisions.length,1);
    const other=await call(`${base.replace(reg.body.branchId,randomUUID())}/intelligence/decisions`);assert.equal(other.status,404);
  }finally{await new Promise<void>(resolve=>server.close(()=>resolve()));}
});
