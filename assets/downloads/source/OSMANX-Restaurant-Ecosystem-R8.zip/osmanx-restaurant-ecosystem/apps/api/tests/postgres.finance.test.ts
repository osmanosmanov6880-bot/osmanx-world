import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {runMigrations} from '../src/migrate.ts';
import {createPostgresStore} from '../src/infra/postgres.ts';

const available=!!process.env.DATABASE_URL;

test('R4 PostgreSQL: monthly P&L, journal sources, purchase inventory and financial void',{skip:!available?'DATABASE_URL not configured':false},async()=>{
  await runMigrations();const store=await createPostgresStore(process.env.DATABASE_URL!);
  try{
    const id=randomUUID(),who=await store.bootstrap({email:`r4-fin-${id}@example.test`,displayName:'Financial owner',passwordHash:'tests only',organizationName:'Financial R4',branchName:'Central'});
    const ctx={userId:who.user.id,organizationId:who.organizationId,branchId:who.branchId,role:'owner' as const};
    const now=new Date();
    // Independent construction avoids ICU variations of locale date formatting.
    const today=new Intl.DateTimeFormat('en-US',{year:'numeric',month:'2-digit',day:'2-digit',timeZone:'Europe/Moscow'}).formatToParts(now);
    const part=(type:string)=>today.find(p=>p.type===type)?.value;
    const date=`${part('year')}-${part('month')}-${part('day')}`;const period=date.slice(0,7);
    const ingredient=await store.createIngredient(ctx,'Espresso beans','g',0,`ing-${id}`);
    await store.receiveStock(ctx,null,'INVOICE-451',[{ingredientId:ingredient.id,quantityMilli:100000,totalCostCents:50000}],`receipt-${id}`);
    assert.equal((await store.financeReport(ctx,period)).expensesCents,0); // Purchase asset, not an operating expense.
    const dish=await store.addMenuItem(ctx,'Espresso',36000);
    await store.saveRecipe(ctx,dish.id,0,[{ingredientId:ingredient.id,quantityMilli:20000}],`recipe-${id}`);
    const order=await store.createOrder(ctx,null,`create-order-${id}`);
    await store.addOrderItem(ctx,order.id,dish.id,1,1,`add-order-${id}`);
    for(const [status,revision] of [['SENT',2],['PREPARING',3],['READY',4],['COMPLETED',5]] as const)
      await store.changeOrderStatus(ctx,order.id,status,revision,`order-${status}-${id}`);
    let report=await store.financeReport(ctx,period);
    assert.equal(report.revenueCents,36000);assert.equal(report.foodCostCents,10000);
    const stock=(await store.ingredients(ctx))[0];
    await store.countStock(ctx,ingredient.id,70000,stock.revision,null,`count-${id}`);
    const payroll=await store.createFinanceExpense(ctx,{category:'PAYROLL',amountCents:8000,description:'Monthly payroll',occurredOn:date},`expense-a-${id}`);
    assert.equal((await store.createFinanceExpense(ctx,{category:'PAYROLL',amountCents:8000,description:'Monthly payroll',occurredOn:date},`expense-a-${id}`)).id,payroll.id);
    const rent=await store.createFinanceExpense(ctx,{category:'RENT',amountCents:2000,description:'Rent',occurredOn:date},`expense-b-${id}`);
    report=await store.financeReport(ctx,period);
    assert.equal(report.revenueCents,36000);assert.equal(report.foodCostCents,10000);
    assert.equal(report.laborCostCents,8000);assert.equal(report.stockLossCents,5000);
    assert.equal(report.operatingResultCents,11000);
    const ledger=await store.financeLedger(ctx,period);
    assert.ok(ledger.some(x=>x.source==='ORDER'&&x.signedAmountCents===36000));
    assert.ok(ledger.some(x=>x.source==='FOOD_COST'&&x.signedAmountCents===-10000));
    assert.ok(ledger.some(x=>x.source==='STOCK_LOSS'&&x.signedAmountCents===-5000));
    assert.ok(ledger.some(x=>x.source==='EXPENSE'&&x.sourceId===rent.id&&x.signedAmountCents===-2000));
    const voided=await store.voidFinanceExpense(ctx,rent.id,1,'Double invoice',`void-${id}`);
    assert.equal(voided.revision,2);assert.equal(voided.status,'VOIDED');
    assert.equal((await store.financeReport(ctx,period)).operatingResultCents,13000);
    assert.equal((await store.financeExpenses(ctx,period)).find(x=>x.id===rent.id)?.voidReason,'Double invoice');
    // A missing recipe is unknown cost, not a zero-cost dish. It poisons the month margin.
    const unknownDish=await store.addMenuItem(ctx,'No recipe',17000);
    const unknownOrder=await store.createOrder(ctx,null,`unknown-order-${id}`);
    await store.addOrderItem(ctx,unknownOrder.id,unknownDish.id,1,1,`unknown-line-${id}`);
    for(const [status,revision] of [['SENT',2],['PREPARING',3],['READY',4],['COMPLETED',5]] as const)
      await store.changeOrderStatus(ctx,unknownOrder.id,status,revision,`unknown-${status}-${id}`);
    const incomplete=await store.financeReport(ctx,period);
    assert.equal(incomplete.uncostedOrders,1);assert.equal(incomplete.revenueCents,53000);
    assert.equal(incomplete.knownFoodCostCents,10000);assert.equal(incomplete.foodCostCents,null);
    assert.equal(incomplete.operatingResultCents,null);
  }finally{await store.close();}
});

test('R4 PostgreSQL: cross-tenant expenses + concurrent budget edits protected by revisions',{skip:!available?'DATABASE_URL not configured':false},async()=>{
  await runMigrations();const store=await createPostgresStore(process.env.DATABASE_URL!);
  try{
    const id=randomUUID(),a=await store.bootstrap({email:`r4-sec-a-${id}@example.test`,displayName:'A',passwordHash:'test',organizationName:'A',branchName:'A1'});
    const b=await store.bootstrap({email:`r4-sec-b-${id}@example.test`,displayName:'B',passwordHash:'test',organizationName:'B',branchName:'B1'});
    const aa={userId:a.user.id,organizationId:a.organizationId,branchId:a.branchId,role:'owner' as const};
    const bb={userId:b.user.id,organizationId:b.organizationId,branchId:b.branchId,role:'owner' as const};
    const period=new Date().toISOString().slice(0,7),occurredOn=`${period}-01`;
    const doc=await store.createFinanceExpense(aa,{category:'OTHER',description:'Expense',occurredOn,amountCents:101},`expense-${id}`);
    assert.equal((await store.financeExpenses(bb,period)).length,0);
    await assert.rejects(store.voidFinanceExpense(bb,doc.id,1,'Unrelated organization',`foreign-${id}`),(e:any)=>e.status===404);
    const budget=await store.saveFinanceBudget(aa,period,'REVENUE',10000,0,`budget-${id}`);
    assert.equal(budget.revision,1);
    const res=await Promise.allSettled([
      store.saveFinanceBudget(aa,period,'REVENUE',11000,1,`budget-next-${id}`),
      store.saveFinanceBudget(aa,period,'REVENUE',12000,1,`budget-other-${id}`)
    ]);
    assert.equal(res.filter(x=>x.status==='fulfilled').length,1);
    assert.equal((res.find(x=>x.status==='rejected') as PromiseRejectedResult).reason.code,'STALE_VERSION');
    assert.equal((await store.financeBudgets(aa,period))[0].revision,2);
    assert.equal((await store.financeBudgets(bb,period)).length,0);
  }finally{await store.close();}
});
