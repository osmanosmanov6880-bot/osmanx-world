import test from 'node:test';
import assert from 'node:assert/strict';
import {calculateFinanceReport} from '../src/domain/finance.ts';
import {evaluate,previousPeriod,transition,observation,decisionInput,reviewPeriodAllowed} from '../src/domain/intelligence.ts';
const report=(period:string,orders:number,amount:number,cost:number|null,expenses=0)=>calculateFinanceReport(period,{
  orders:Array.from({length:orders},(_,i)=>({id:`${i}`,amountCents:Math.floor(amount/orders),costCents:cost===null?null:Math.floor(cost/orders),complete:cost!==null})),
  expenses:expenses?[{id:'e',category:'PAYROLL' as const,description:'Тест',amountCents:expenses,occurredOn:`${period}-01`,status:'POSTED' as const,revision:1,createdAt:'',voidedAt:null,voidReason:null}]:[],stockLossCents:0},[]);
test('R6: January previous period handles year boundary',()=>{assert.equal(previousPeriod('2026-01'),'2025-12');});
test('R6: falling revenue at comparable order count yields checkable signal, not causal claim',()=>{
  const a=report('2026-10',20,200000,40000),b=report('2026-11',20,170000,34000);
  const result=evaluate(b,a),signal=result.signals.find(s=>s.id==='REVENUE_TICKET_DROP');
  assert(signal);assert.equal(signal.provenCause,false);assert.equal(signal.evidence[0].before,200000);
  assert(signal.alternatives.length>0);assert(signal.missingData.length>0);
});
test('R6: refuses signals on insufficient sample',()=>{
  assert(!evaluate(report('2026-11',2,1000,100),report('2026-10',2,3000,300)).signals.some(s=>s.id==='REVENUE_DROP'));
});
test('R6: incomplete food cost is not turned into profit',()=>{
  const d=evaluate(report('2026-11',10,100000,null),report('2026-10',10,100000,10000));
  assert(d.signals.some(s=>s.id==='MISSING_FOOD_COST'));
  const m=observation(report('2026-10',10,100000,10000),report('2026-11',10,100000,null),1000);
  assert.equal(m.observedProfitDeltaCents,null);
});
test('R6: cost ratio increase and profit decline are separately explained',()=>{
  const a=report('2026-10',20,200000,40000,20000),b=report('2026-11',20,200000,60000,25000);
  const signals=evaluate(b,a).signals.map(s=>s.id);
  assert(signals.includes('FOOD_COST_RATE_RISE'));
  assert(signals.includes('PROFIT_DOWN_REVENUE_UP'));
});
test('R6: workflow rejects skipping implementation and checks input',()=>{
  assert.throws(()=>transition('PROPOSED','REVIEWED'),(e:any)=>e.code==='DECISION_TRANSITION');
  transition('PROPOSED','IN_PROGRESS');transition('IN_PROGRESS','IMPLEMENTED');transition('IMPLEMENTED','REVIEWED');
  assert.throws(()=>decisionInput({title:'Кратко',hypothesis:'A',action:'B',implementationCostCents:-1}));
});
test('R6: observational comparison is numeric, not a causality or ROI assertion',()=>{
  const a=report('2026-10',10,100000,20000,10000),b=report('2026-11',10,120000,24000,10000);
  const o=observation(a,b,5000);
  assert.equal(o.observedProfitDeltaCents,16000);
  assert.match(o.interpretation,/причинная окупаемость не доказана/);
});

test('R6: future review periods are not accepted as measured data',()=>{assert.equal(reviewPeriodAllowed('2026-10','2099-12',new Date('2026-11-07')),false);assert.equal(reviewPeriodAllowed('2026-10','2026-11',new Date('2026-11-07')),true);});
