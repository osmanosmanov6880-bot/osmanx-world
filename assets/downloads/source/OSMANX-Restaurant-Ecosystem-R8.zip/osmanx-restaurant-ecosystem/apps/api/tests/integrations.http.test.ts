import test from 'node:test';
import assert from 'node:assert/strict';
import {randomBytes,randomUUID} from 'node:crypto';
import type {AddressInfo} from 'node:net';
import {createApiServer} from '../src/http.ts';
import {FakeStore} from './fake-store.ts';
import {MemoryIntegrationRepository} from './integration-memory.ts';
import {IntegrationRuntime} from '../src/integrations/runtime.ts';
import {ProviderError} from '../src/domain/integrations.ts';
const cfg={origin:'http://localhost:3000',sessionSecret:'s'.repeat(64),secureCookies:false};
const key=randomBytes(32).toString('base64');

test('R8 HTTP: onboarding, verify, menus, queue, preview, explicit import, audit and multi-tenant permissions',async()=>{
  const store=new FakeStore();const repo=new MemoryIntegrationRepository();let remoteError=false;
  const runtime=new IntegrationRuntime(repo,{verify:async(_c,id)=>{
    if(remoteError)throw new ProviderError('AUTH_FAILED',false);
    return {id,name:'iiko Coffee'};
  },menus:async()=>[{id:'menu-r8',name:'Главное меню'}],
  catalog:async()=>[{externalId:'espresso',name:'Эспрессо',category:'Кофе',priceCents:16000},
    {externalId:'special',name:'Особое блюдо',category:'Меню',priceCents:null}]},key);
  const server=createApiServer(store,cfg,runtime);
  await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));
  const host=`http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  function client(){let cookie='',csrf='';return {
    async call(path:string,method='GET',body?:unknown,k?:string){const headers:Record<string,string>={};
      if(cookie)headers.cookie=cookie;if(body!==undefined)headers['content-type']='application/json';
      if(method!=='GET'){headers.origin=cfg.origin;if(csrf)headers['x-osmanx-csrf']=csrf;}
      if(k)headers['idempotency-key']=k;
      const response=await fetch(host+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});
      const raw=await response.text();if(response.headers.get('set-cookie'))cookie=response.headers.get('set-cookie')!.split(';')[0];
      return {status:response.status,body:JSON.parse(raw),raw};
    },
    async refresh(){csrf=(await this.call('/api/v1/me')).body.csrfToken;}
  };}
  try{
    const owner=client(),outsider=client(),manager=client(),auditor=client();
    const ownerEmail=`r8-owner-${randomUUID()}@example.test`;
    const start=await owner.call('/api/v1/auth/register','POST',{email:ownerEmail,displayName:'Owner',password:'SafePassR8-123456',
      organizationName:'OSMANX Restaurant',branchName:'Centre'});assert.equal(start.status,201);await owner.refresh();
    const root=`/api/v1/organizations/${start.body.organizationId}`;
    const first=`${root}/branches/${start.body.branchId}/integrations`;
    const branchTwo=await owner.call(`${root}/branches`,'POST',{name:'Other Venue',timezone:'Europe/Moscow'});assert.equal(branchTwo.status,201);
    const second=`${root}/branches/${branchTwo.body.branch.id}/integrations`;
    const remoteOrg=randomUUID();const input={alias:'iiko Cafe',remoteOrganizationId:remoteOrg,appId:'app-id',clientSecret:'secret-value-not-for-log',apiKey:'key-value-secret'};
    const create=await owner.call(first,'POST',input,'r8-create-connection');assert.equal(create.status,201);
    const conn=create.body.connection;const path=`${first}/${conn.id}`;
    for(const secret of ['clientSecret','apiKey','sealedCredentials',input.clientSecret,input.apiKey])assert(!create.raw.includes(secret));
    assert.equal((await owner.call(first,'POST',input,'r8-create-connection')).body.connection.id,conn.id);
    assert.equal((await owner.call(first,'POST',{...input,alias:'Changed'},'r8-create-connection')).status,409);
    assert.equal((await owner.call(`${path}/sync`,'POST',{menuId:'menu-r8'},'r8-sync-before')).status,409);
    assert.equal((await owner.call(`${second}/${conn.id}/catalog`)).status,404);
    const verified=await owner.call(`${path}/verify`,'POST',{expectedRevision:1},'r8-verify-access');
    assert.equal(verified.status,200);assert.equal(verified.body.connection.state,'VERIFIED');
    assert.equal((await owner.call(`${path}/verify`,'POST',{expectedRevision:1},'r8-stale-verification')).status,409);
    assert.equal((await owner.call(`${path}/menus`)).body.menus[0].id,'menu-r8');
    assert.equal((await owner.call(`${path}/sync`,'POST',{menuId:'menu-r8'},'r8-queue-001')).status,202);
    assert.equal((await owner.call(`${path}/sync`,'POST',{menuId:'menu-r8'},'r8-queue-002')).status,409);
    assert.equal(await runtime.runOnce(),'SUCCEEDED');
    const staged=await owner.call(`${path}/catalog`);assert.equal(staged.status,200);
    assert.equal(staged.body.items.length,2);assert.equal(staged.body.items[1].priceCents,null);
    const run=(await owner.call(`${path}/jobs`)).body.jobs[0];assert.equal(run.status,'SUCCEEDED');
    const rejected=await owner.call(`${path}/import`,'POST',{sourceRunId:run.id,externalIds:['special']},'r8-import-unknown');
    assert.equal(rejected.status,409);
    const imported=await owner.call(`${path}/import`,'POST',{sourceRunId:run.id,externalIds:['espresso']},'r8-import-known');
    assert.equal(imported.status,200);assert.equal(imported.body.result.created,1);
    assert.equal((await owner.call(`${path}/import`,'POST',{sourceRunId:run.id,externalIds:['espresso']},'r8-import-known')).body.result.created,1);
    const other=await outsider.call('/api/v1/auth/register','POST',{email:`other-r8-${randomUUID()}@test.example`,password:'SafePassR8-123456',
      displayName:'External',organizationName:'Elsewhere',branchName:'Outsider'});assert.equal(other.status,201);await outsider.refresh();
    assert.equal((await outsider.call(first)).status,404);
    assert.equal((await outsider.call(`${path}/catalog`)).status,404);
    const managerEmail=`manager-${randomUUID()}@test.example`;
    const managerInvite=await owner.call(`${root}/invitations`,'POST',{email:managerEmail,role:'manager',branchIds:[start.body.branchId]});
    assert.equal(managerInvite.status,201);
    const managerToken=new URL(managerInvite.body.invitation.url).searchParams.get('token');
    assert.equal((await manager.call('/api/v1/auth/accept-invite','POST',{token:managerToken,email:managerEmail,
      displayName:'Manager',password:'SafePassR8-123456'})).status,201);await manager.refresh();
    assert.equal((await manager.call(first)).status,200);
    assert.equal((await manager.call(first,'POST',input,'r8-manager-no-create')).status,403);
    assert.equal((await manager.call(`${path}/verify`,'POST',{expectedRevision:2},'r8-manager-no-verify')).status,403);
    const auditorEmail=`auditor-${randomUUID()}@test.example`;
    const auditorInvite=await owner.call(`${root}/invitations`,'POST',{email:auditorEmail,role:'auditor',branchIds:[start.body.branchId]});
    const auditorToken=new URL(auditorInvite.body.invitation.url).searchParams.get('token');
    assert.equal((await auditor.call('/api/v1/auth/accept-invite','POST',{token:auditorToken,email:auditorEmail,
      displayName:'Audit',password:'SafePassR8-123456'})).status,201);await auditor.refresh();
    assert.equal((await auditor.call(`${path}/catalog`)).status,200);
    assert.equal((await auditor.call(`${path}/import`,'POST',{sourceRunId:run.id,externalIds:['espresso']},'r8-auditor-no-import')).status,403);
    const rotated=await owner.call(`${path}/rotate`,'POST',{expectedRevision:2,appId:'new-app',clientSecret:'new-client-secret',apiKey:'new-api-secret'},'r8-rotate-secrets');
    assert.equal(rotated.status,200);assert.equal(rotated.body.connection.state,'UNVERIFIED');
    assert.equal((await owner.call(`${path}/catalog`)).body.items.length,0);
    remoteError=true;
    const invalid=await owner.call(`${path}/verify`,'POST',{expectedRevision:3},'r8-provider-error');
    assert.equal(invalid.status,502);assert.equal(invalid.body.error.code,'AUTH_FAILED');
    const stateAfter=(await owner.call(first)).body.connections[0];assert.equal(stateAfter.state,'ERROR');
    const disable=await owner.call(`${path}/disable`,'POST',{expectedRevision:4},'r8-disable');assert.equal(disable.status,200);
    assert.equal((await owner.call(`${path}/sync`,'POST',{menuId:'menu-r8'},'r8-disabled-sync')).status,409);
  }finally{await new Promise<void>(resolve=>server.close(()=>resolve()));}
});
