import {auditAnswers,withCriterionIds,actionTransition,type NetworkStandard,type StandardInput,type BranchAudit,type AuditAnswerInput,type CorrectiveAction,type ActionStatus} from '../src/domain/network.ts';
import {evaluate,previousPeriod,transition,observation,reviewPeriodAllowed,type Decision,type DecisionStatus} from '../src/domain/intelligence.ts';
// Test-only in-memory adapter. Never used by production or development server.
import {randomUUID} from 'node:crypto';
import {AppError,assert,hasBranchAccess,requireTransition,safeMoneySum} from '../src/domain/rules.ts';
import type {Role} from '../src/domain/rules.ts';
import type {Store,User,Membership,Branch,MenuItem,DiningTable,Order,Ctx,Reservation,ReservationInput,Seated,KitchenTicket,Shift,FloorTable,Employee,Ingredient,Recipe,Supplier,Receipt,StockCount,StockMovement,RestaurantTask} from '../src/store.ts';
import type {OrderStatus} from '../src/domain/rules.ts';
import {overlaps,managesShifts,requireReservationAction,requireSeatDate,requireShiftActor,sameTableCapacity} from '../src/domain/operations.ts';
import type {ReservationAction} from '../src/domain/operations.ts';
import {stockQuantity,recipeComponents,receiptLines,addStock,countVariance,costOfIssue,taskStatusTransition} from '../src/domain/inventory.ts';
import type {StockUnit,TaskStatus,RecipeComponentInput,ReceiptLineInput} from '../src/domain/inventory.ts';
import {calculateFinanceReport,centsSum,financePeriod} from '../src/domain/finance.ts';
import type {Expense,ExpenseCategory,Budget,BudgetCategory,LedgerEntry,FinanceFacts} from '../src/domain/finance.ts';
import {calculateGuestInsights} from '../src/domain/guests.ts';
import type {Guest,GuestInput,Consent,ConsentChannel,ConsentState,GuestVisit,GuestFeedback,GuestFeedbackInput,GuestInsights} from '../src/domain/guests.ts';
export class FakeStore implements Store {
  users=new Map<string,User>(); sessions=new Map<string,string>(); organizations=new Map<string,{name:string;currency:string}>();
  memberMap=new Map<string,{org:string;userId:string;role:Role;grants:string[]}>();
  branchMap=new Map<string,Branch&{org:string}>();menus=new Map<string,MenuItem&{org:string;branch:string}>();
  tableMap=new Map<string,DiningTable&{org:string;branch:string}>();orderMap=new Map<string,Order&{org:string;branch:string}>();
  invites=new Map<string,{org:string;email:string;role:Role;branches:string[];used:boolean}>();idempotency=new Map<string,{fingerprint:string;result:unknown}>();
  bookingMap=new Map<string,Reservation&{org:string;branch:string}>();
  orderReservations=new Map<string,string>();
  shiftMap=new Map<string,Shift&{org:string;branch:string}>();
  kitchenTimes=new Map<string,{sentAt?:string;preparingAt?:string;readyAt?:string}>();
  ingredientMap=new Map<string,Ingredient&{org:string;branch:string}>();
  recipeMap=new Map<string,Recipe>();
  supplierMap=new Map<string,Supplier&{org:string;branch:string}>();
  receiptMap=new Map<string,Receipt&{org:string;branch:string}>();
  movementMap:(StockMovement&{org:string;branch:string})[]=[];
  taskMap=new Map<string,RestaurantTask&{org:string;branch:string}>();
  orderSnapshots=new Map<string,{missing:number;requirements:{ingredientId:string;quantityMilli:number}[]}>();
  financeExpenseMap=new Map<string,Expense&{org:string;branch:string}>();
  budgetMap=new Map<string,Budget&{org:string;branch:string}>();
  orderCompletedAt=new Map<string,string>();
  guestMap=new Map<string,Guest&{org:string;branch:string}>();
  consentMap=new Map<string,Consent&{org:string;branch:string}>();
  feedbackMap=new Map<string,GuestFeedback&{org:string;branch:string}>();
  intelligenceDecisionMap=new Map<string,Decision & {org:string;branch:string}>();
  networkStandardMap=new Map<string,NetworkStandard & {org:string}>();
  networkAuditMap=new Map<string,BranchAudit & {org:string;branch:string}>();
  networkActionMap=new Map<string,CorrectiveAction & {org:string;branch:string}>();
  async networkStandards(organizationId:string):Promise<NetworkStandard[]>{
    return [...this.networkStandardMap.values()].filter(s=>s.org===organizationId)
      .map(({org,...row})=>structuredClone(row)).sort((a,b)=>a.title.localeCompare(b.title));
  }
  async createNetworkStandard(ctx:Ctx,input:StandardInput,key:string):Promise<NetworkStandard>{
    return this.idempotent(ctx,key,{kind:'network-standard-create',input},()=>{
      const now=new Date().toISOString();const s:NetworkStandard&{org:string}={...input,id:randomUUID(),org:ctx.organizationId,
        revision:1,active:true,criteria:withCriterionIds(input.criteria),createdAt:now,updatedAt:now};
      this.networkStandardMap.set(s.id,s);const {org,...publicValue}=s;return publicValue;
    });
  }
  async updateNetworkStandard(ctx:Ctx,id:string,expectedRevision:number,input:StandardInput,active:boolean,key:string):Promise<NetworkStandard>{
    return this.idempotent(ctx,key,{kind:'network-standard-update',id,expectedRevision,input,active},()=>{
      const s=this.networkStandardMap.get(id);assert(s&&s.org===ctx.organizationId,404,'NOT_FOUND','Стандарт не найден');
      assert(s.revision===expectedRevision,409,'VERSION_CONFLICT','Стандарт уже изменился');
      Object.assign(s,{...input,criteria:withCriterionIds(input.criteria),active,revision:s.revision+1,updatedAt:new Date().toISOString()});
      const {org,...publicValue}=s;return publicValue;
    });
  }
  async branchAudits(ctx:Ctx,standardId:string|null):Promise<BranchAudit[]>{
    return [...this.networkAuditMap.values()].filter(a=>a.org===ctx.organizationId&&a.branch===ctx.branchId&&(!standardId||a.standardId===standardId))
      .sort((a,b)=>b.performedAt.localeCompare(a.performedAt)).map(({org,branch,...r})=>structuredClone(r));
  }
  async submitBranchAudit(ctx:Ctx,standardId:string,expectedStandardRevision:number,answers:AuditAnswerInput[],key:string):Promise<BranchAudit>{
    return this.idempotent(ctx,key,{kind:'network-audit',branchId:ctx.branchId,standardId,expectedStandardRevision,answers},()=>{
      const s=this.networkStandardMap.get(standardId);assert(s&&s.org===ctx.organizationId,404,'NOT_FOUND','Стандарт не найден');
      assert(s.active,409,'STANDARD_DISABLED','Стандарт отключён');
      assert(s.revision===expectedStandardRevision,409,'VERSION_CONFLICT','Редакция стандарта изменилась');
      const calculated=auditAnswers(answers,s.criteria);const audit:BranchAudit&{org:string;branch:string}={id:randomUUID(),org:ctx.organizationId,branch:ctx.branchId,
        branchId:ctx.branchId,standardId:s.id,standardTitle:s.title,standardRevision:s.revision,performedAt:new Date().toISOString(),performedBy:ctx.userId,...calculated};
      this.networkAuditMap.set(audit.id,audit);
      for(const a of audit.answers.filter(a=>!a.passed)){
        const already=[...this.networkActionMap.values()].some(x=>x.org===ctx.organizationId&&x.branch===ctx.branchId&&x.standardId===s.id
          &&x.standardRevision===s.revision&&x.criterionId===a.criterionId&&x.status!=='RESOLVED');
        if(already)continue;
        const now=new Date().toISOString();const action:CorrectiveAction&{org:string;branch:string}={id:randomUUID(),org:ctx.organizationId,branch:ctx.branchId,
          branchId:ctx.branchId,auditId:audit.id,standardId:s.id,standardRevision:s.revision,criterionId:a.criterionId,title:a.title,status:'OPEN',revision:1,
          createdAt:now,updatedAt:now,resolution:null};
        this.networkActionMap.set(action.id,action);
      }
      const {org,branch,...publicValue}=audit;return publicValue;
    });
  }
  async branchCorrectiveActions(ctx:Ctx):Promise<CorrectiveAction[]>{
    return [...this.networkActionMap.values()].filter(a=>a.org===ctx.organizationId&&a.branch===ctx.branchId)
      .sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).map(({org,branch,...r})=>structuredClone(r));
  }
  async branchOpenActionCount(ctx:Ctx):Promise<number>{
    return [...this.networkActionMap.values()].filter(a=>a.org===ctx.organizationId&&a.branch===ctx.branchId&&a.status!=='RESOLVED').length;
  }
  async updateCorrectiveAction(ctx:Ctx,id:string,expectedRevision:number,status:ActionStatus,resolution:string|null,key:string):Promise<CorrectiveAction>{
    return this.idempotent(ctx,key,{kind:'network-action',branchId:ctx.branchId,id,expectedRevision,status,resolution},()=>{
      const a=this.networkActionMap.get(id);assert(a&&a.org===ctx.organizationId&&a.branch===ctx.branchId,404,'NOT_FOUND','Действие не найдено');
      assert(a.revision===expectedRevision,409,'VERSION_CONFLICT','Действие уже изменилось');actionTransition(a.status,status,resolution);
      a.status=status;a.resolution=resolution;a.revision++;a.updatedAt=new Date().toISOString();
      const {org,branch,...publicValue}=a;return publicValue;
    });
  }
  async ready(){return true;}
  private membershipKey(org:string,userId:string){return `${org}:${userId}`;}
  private scope(ctx:Ctx,row:{org:string;branch:string}){assert(row.org===ctx.organizationId&&row.branch===ctx.branchId,404,'NOT_FOUND','Не найдено');}
  private idempotent<T>(ctx:Ctx,key:string,request:unknown,create:()=>T):T{
    const k=`${ctx.organizationId}:${ctx.userId}:${key}`,fingerprint=JSON.stringify(request);
    const saved=this.idempotency.get(k);
    if(saved){assert(saved.fingerprint===fingerprint,409,'IDEMPOTENCY_CONFLICT','Конфликт ключа');return structuredClone(saved.result as T);}
    const result=create();this.idempotency.set(k,{fingerprint,result:structuredClone(result)});return structuredClone(result);
  }
  async intelligenceDiagnosis(ctx:Ctx,period:string){
    const [now,before]=await Promise.all([this.financeReport(ctx,period),this.financeReport(ctx,previousPeriod(period))]);
    const result=evaluate(now,before);
    const k=`${ctx.organizationId}:${ctx.branchId}:${period}`;
    this.lastDiagnosis.set(k,result.signals.map(s=>s.id));this.lastReport.set(k,now);
    return result;
  }
  async intelligenceDecisions(ctx:Ctx){return [...this.intelligenceDecisionMap.values()].filter(x=>x.org===ctx.organizationId&&x.branch===ctx.branchId).map(({org,branch,...d})=>structuredClone(d));}
  async createIntelligenceDecision(ctx:Ctx,period:string,signalId:string,input:{title:string;hypothesis:string;action:string;implementationCostCents:number|null},key:string){
    return this.idempotent(ctx,key,{kind:'create-intelligence',period,signalId,input},()=>{
      // These are computed from existing orders and expenses, not entered manually.
      const signal=this.lastDiagnosis?.get(`${ctx.organizationId}:${ctx.branchId}:${period}`);
      assert(signal?.includes(signalId),409,'SIGNAL_NOT_FOUND','Сначала загрузите подтверждённую диагностику');
      const baseline=this.lastReport?.get(`${ctx.organizationId}:${ctx.branchId}:${period}`);
      assert(baseline,409,'SIGNAL_NOT_FOUND','Исходный расчёт отсутствует');
      const now=new Date().toISOString();
      const d:Decision & {org:string;branch:string}={id:randomUUID(),org:ctx.organizationId,branch:ctx.branchId,branchId:ctx.branchId,
        signalId,title:input.title,hypothesis:input.hypothesis,action:input.action,implementationCostCents:input.implementationCostCents,
        baselinePeriod:period,reviewPeriod:null,status:'PROPOSED',revision:1,createdAt:now,updatedAt:now,
        baselineRevenueCents:baseline.revenueCents,baselineProfitCents:baseline.operatingResultCents,
        observedRevenueCents:null,observedProfitCents:null,observedProfitDeltaCents:null,observation:null};
      this.intelligenceDecisionMap.set(d.id,d);const {org,branch,...publicValue}=d;return publicValue;
    });
  }
  lastDiagnosis=new Map<string,string[]>();
  lastReport=new Map<string,import('../src/domain/finance.ts').FinanceReport>();
  async updateIntelligenceDecision(ctx:Ctx,id:string,expectedRevision:number,status:DecisionStatus,reviewPeriod:string|null,observationText:string|null,key:string){
    let measured:null|ReturnType<typeof observation>=null;
    if(status==='REVIEWED'){
      const check=this.intelligenceDecisionMap.get(id);
      assert(check&&check.org===ctx.organizationId&&check.branch===ctx.branchId,404,'NOT_FOUND','Решение не найдено');
      transition(check.status,status);
      assert(reviewPeriod&&observationText&&reviewPeriodAllowed(check.baselinePeriod,reviewPeriod),400,'REVIEW_PERIOD','Проверка должна быть позднее базового периода и не в будущем');
      const d=this.intelligenceDecisionMap.get(id)!;
      const review=await this.financeReport(ctx,reviewPeriod);
      measured=observation({...review,period:d.baselinePeriod,revenueCents:d.baselineRevenueCents,operatingResultCents:d.baselineProfitCents},review,d.implementationCostCents);
    }
    return this.idempotent(ctx,key,{kind:'status-intelligence',id,expectedRevision,status,reviewPeriod,observationText},()=>{
      const d=this.intelligenceDecisionMap.get(id);assert(d&&d.org===ctx.organizationId&&d.branch===ctx.branchId,404,'NOT_FOUND','Решение не найдено');
      assert(d.revision===expectedRevision,409,'VERSION_CONFLICT','Версия устарела');transition(d.status,status);
      assert(status==='REVIEWED'||(!reviewPeriod&&!observationText),400,'REVIEW_ONLY','Нельзя прикрепить результат до проверки');
      if(measured){d.reviewPeriod=reviewPeriod;d.observation=observationText;d.observedRevenueCents=measured.observedRevenueCents;d.observedProfitCents=measured.observedProfitCents;d.observedProfitDeltaCents=measured.observedProfitDeltaCents;}
      d.status=status;d.revision++;d.updatedAt=new Date().toISOString();const {org,branch,...publicValue}=d;return publicValue;
    });
  }
  async bootstrap(a:{email:string;displayName:string;passwordHash:string;organizationName:string;branchName:string}){
    assert(!this.users.has(a.email),409,'DUPLICATE','Такой email уже зарегистрирован');
    const u={id:randomUUID(),email:a.email,displayName:a.displayName,passwordHash:a.passwordHash};this.users.set(u.email,u);
    const org=randomUUID(),b=randomUUID();this.organizations.set(org,{name:a.organizationName,currency:'RUB'});
    this.memberMap.set(this.membershipKey(org,u.id),{org,userId:u.id,role:'owner',grants:[]});
    this.branchMap.set(b,{id:b,name:a.branchName,timezone:'Europe/Moscow',org});
    return {user:u,organizationId:org,branchId:b};
  }
  async findUser(email:string){return this.users.get(email)||null;}
  async createSession(userId:string,tokenHash:string){this.sessions.set(tokenHash,userId);}
  async getSession(tokenHash:string){const id=this.sessions.get(tokenHash);return [...this.users.values()].find(u=>u.id===id)||null;}
  async deleteSession(tokenHash:string){this.sessions.delete(tokenHash);}
  async memberships(userId:string):Promise<Membership[]>{
    return [...this.memberMap.values()].filter(m=>m.userId===userId).map(m=>({organizationId:m.org,organizationName:this.organizations.get(m.org)!.name,
      currency:'RUB',role:m.role,branches:[...this.branchMap.values()].filter(b=>b.org===m.org && hasBranchAccess(m.role,m.grants.includes(b.id))).map(b=>({id:b.id,name:b.name,timezone:b.timezone}))}));
  }
  async branches(organizationId:string){return [...this.branchMap.values()].filter(b=>b.org===organizationId).map(({org,...rest})=>rest);}
  async createBranch(organizationId:string,_actorId:string,name:string,timezone:string){const b={id:randomUUID(),org:organizationId,name,timezone};this.branchMap.set(b.id,b);return b;}
  async createInvitation(org:string,_actorId:string,email:string,role:Role,branchIds:string[],tokenHash:string){
    for(const id of branchIds)assert(this.branchMap.get(id)?.org===org,400,'BRANCH_SCOPE','Неверный филиал');
    this.invites.set(tokenHash,{org,email,role,branches:branchIds,used:false});
  }
  async acceptInvitation(tokenHash:string,email:string,displayName:string,passwordHash:string){
    const invite=this.invites.get(tokenHash);assert(invite&&!invite.used,410,'INVITE_EXPIRED','Приглашение не найдено');
    assert(invite.email===email,403,'INVITE_EMAIL','Неправильный email');
    assert(!this.users.has(email),409,'DUPLICATE','Этот email уже зарегистрирован');
    const u={id:randomUUID(),email,displayName,passwordHash};this.users.set(email,u);invite.used=true;
    this.memberMap.set(this.membershipKey(invite.org,u.id),{org:invite.org,userId:u.id,role:invite.role,grants:invite.branches});return u;
  }
  async menu(ctx:Ctx){return [...this.menus.values()].filter(x=>x.org===ctx.organizationId&&x.branch===ctx.branchId).map(({org,branch,...rest})=>rest);}
  async addMenuItem(ctx:Ctx,name:string,priceCents:number){const m={id:randomUUID(),org:ctx.organizationId,branch:ctx.branchId,name,priceCents,active:true,revision:1};this.menus.set(m.id,m);return m;}
  async updateMenuItem(ctx:Ctx,itemId:string,revision:number,patch:{name?:string;priceCents?:number;active?:boolean}){
    const m=this.menus.get(itemId);assert(m,409,'STALE_VERSION','Нет записи');this.scope(ctx,m);
    assert(m.revision===revision,409,'STALE_VERSION','Конфликт версий');Object.assign(m,patch);m.revision++;return m;
  }
  async tables(ctx:Ctx){return [...this.tableMap.values()].filter(x=>x.org===ctx.organizationId&&x.branch===ctx.branchId).map(({org,branch,...rest})=>rest);}
  async addTable(ctx:Ctx,label:string,capacity:number){
    assert(![...this.tableMap.values()].some(x=>x.org===ctx.organizationId&&x.branch===ctx.branchId&&x.label===label),409,'DUPLICATE','Такой стол существует');
    const t={id:randomUUID(),org:ctx.organizationId,branch:ctx.branchId,label,capacity};this.tableMap.set(t.id,t);return t;
  }
  async floor(ctx:Ctx):Promise<FloorTable[]>{
    const tables=await this.tables(ctx),orders=await this.orders(ctx),bookings=await this.reservations(ctx);
    return tables.map(t=>{
      const active=orders.find(o=>o.tableId===t.id&&!['COMPLETED','CANCELLED'].includes(o.status));
      const upcoming=bookings.filter(b=>b.tableId===t.id&&b.status==='CONFIRMED'&&Date.parse(b.endsAt)>Date.now())
        .sort((a,b)=>a.startsAt.localeCompare(b.startsAt))[0];
      return {...t,state:active?'OCCUPIED':upcoming&&Date.parse(upcoming.startsAt)<=Date.now()+45*60000?'RESERVED':'AVAILABLE',
        activeOrderId:active?.id||null,reservationId:upcoming?.id||null,nextReservationAt:upcoming?.startsAt||null} as FloorTable;
    });
  }
  async reservations(ctx:Ctx):Promise<Reservation[]>{
    return [...this.bookingMap.values()].filter(b=>b.org===ctx.organizationId&&b.branch===ctx.branchId)
      .map(({org,branch,...rest})=>structuredClone(rest)).sort((a,b)=>a.startsAt.localeCompare(b.startsAt));
  }
  async createReservation(ctx:Ctx,input:ReservationInput,key:string):Promise<Reservation>{
    return this.idempotent(ctx,key,{kind:'booking',branchId:ctx.branchId,...input},()=>{
      const t=this.tableMap.get(input.tableId);assert(t,404,'TABLE_NOT_FOUND','Стол не найден');this.scope(ctx,t);
      sameTableCapacity(input.partySize,t.capacity);
      const clashes=[...this.bookingMap.values()].some(b=>b.org===ctx.organizationId&&b.branch===ctx.branchId
        &&b.tableId===t.id&&b.status==='CONFIRMED'&&overlaps(input.startsAt,input.endsAt,b.startsAt,b.endsAt));
      assert(!clashes,409,'RESERVATION_CONFLICT','Это время уже забронировано');
      if(Date.parse(input.startsAt)<=Date.now()+45*60000){
        assert(![...this.orderMap.values()].some(o=>o.org===ctx.organizationId&&o.branch===ctx.branchId&&o.tableId===t.id
          &&o.status!=='COMPLETED'&&o.status!=='CANCELLED'),409,'TABLE_BUSY','Стол занят');
      }
      const b:Reservation&{org:string;branch:string}={...input,id:randomUUID(),status:'CONFIRMED',revision:1,
        createdAt:new Date().toISOString(),orderId:null,org:ctx.organizationId,branch:ctx.branchId};
      this.bookingMap.set(b.id,b);const {org,branch,...result}=b;return result;
    });
  }
  async changeReservation(ctx:Ctx,id:string,to:ReservationAction,expectedRevision:number,key:string):Promise<Reservation>{
    return this.idempotent(ctx,key,{kind:'reservation-status',branchId:ctx.branchId,id,to,expectedRevision},()=>{
      const b=this.bookingMap.get(id);assert(b,404,'NOT_FOUND','Бронь не найдена');this.scope(ctx,b);
      assert(b.revision===expectedRevision,409,'STALE_VERSION','Бронь уже изменилась');requireReservationAction(b.status,to);
      if(to==='NO_SHOW')assert(Date.now()>=Date.parse(b.startsAt)+15*60000,409,'NO_SHOW_EARLY','Рано отмечать неявку');
      b.status=to;b.revision++;const {org,branch,...result}=b;return result;
    });
  }
  async seatReservation(ctx:Ctx,id:string,expectedRevision:number,key:string):Promise<Seated>{
    return this.idempotent(ctx,key,{kind:'reservation-seat',branchId:ctx.branchId,id,expectedRevision},()=>{
      const b=this.bookingMap.get(id);assert(b,404,'NOT_FOUND','Бронь не найдена');this.scope(ctx,b);
      assert(b.revision===expectedRevision,409,'STALE_VERSION','Бронь уже изменилась');
      assert(b.status==='CONFIRMED',409,'RESERVATION_LOCKED','Бронь уже обработана');
      requireSeatDate(b.startsAt,b.endsAt);
      const active=[...this.orderMap.values()].find(o=>o.org===ctx.organizationId&&o.branch===ctx.branchId&&o.tableId===b.tableId
        &&o.status!=='COMPLETED'&&o.status!=='CANCELLED');
      assert(!active,409,'TABLE_BUSY','Стол уже занят');
      const order:Order&{org:string;branch:string}={id:randomUUID(),guestId:null,tableId:b.tableId,org:ctx.organizationId,branch:ctx.branchId,
        status:'OPEN',totalCents:0,revision:1,createdAt:new Date().toISOString(),items:[],actualFoodCostCents:null,missingRecipeLines:null,foodCostComplete:false};
      this.orderMap.set(order.id,order);this.orderReservations.set(order.id,b.id);
      b.status='SEATED';b.revision++;b.orderId=order.id;
      const {org,branch,...reservation}=b;return {reservation,order};
    });
  }
  async kitchen(ctx:Ctx):Promise<KitchenTicket[]>{
    const orders=(await this.orders(ctx)).filter(o=>['SENT','PREPARING','READY'].includes(o.status));
    return orders.map(o=>{
      const times=this.kitchenTimes.get(o.id)||{};
      return {id:o.id,tableId:o.tableId,status:o.status as KitchenTicket['status'],revision:o.revision,
        items:o.items,sentAt:times.sentAt||null,preparingAt:times.preparingAt||null,readyAt:times.readyAt||null};
    }).sort((a,b)=>(a.sentAt||'').localeCompare(b.sentAt||''));
  }
  async staff(ctx:Ctx):Promise<Employee[]>{
    return [...this.memberMap.values()].filter(m=>m.org===ctx.organizationId&&
      (hasBranchAccess(m.role,m.grants.includes(ctx.branchId)))&&(managesShifts(ctx.role)||m.userId===ctx.userId))
      .map(m=>({id:m.userId,displayName:[...this.users.values()].find(u=>u.id===m.userId)!.displayName,role:m.role}));
  }
  async shifts(ctx:Ctx):Promise<Shift[]>{
    return [...this.shiftMap.values()].filter(s=>s.org===ctx.organizationId&&s.branch===ctx.branchId&&
      (managesShifts(ctx.role)||s.userId===ctx.userId)).map(({org,branch,...rest})=>structuredClone(rest));
  }
  async openShift(ctx:Ctx,userId:string,openingNote:string,key:string):Promise<Shift>{
    requireShiftActor(ctx.role,ctx.userId,userId);
    return this.idempotent(ctx,key,{kind:'shift-open',branchId:ctx.branchId,userId,openingNote},()=>{
      const worker=this.memberMap.get(this.membershipKey(ctx.organizationId,userId));
      assert(worker&&hasBranchAccess(worker.role,worker.grants.includes(ctx.branchId)),404,'WORKER_NOT_FOUND','Сотрудник не найден');
      assert(![...this.shiftMap.values()].some(s=>s.org===ctx.organizationId&&s.userId===userId&&s.status==='OPEN'),
        409,'DUPLICATE','У сотрудника уже открыта смена');
      const s:Shift&{org:string;branch:string}={id:randomUUID(),org:ctx.organizationId,branch:ctx.branchId,userId,
        employeeName:[...this.users.values()].find(u=>u.id===userId)!.displayName,status:'OPEN',
        openedAt:new Date().toISOString(),closedAt:null,openingNote,closingNote:'',revision:1};
      this.shiftMap.set(s.id,s);const {org,branch,...result}=s;return result;
    });
  }
  async closeShift(ctx:Ctx,id:string,expectedRevision:number,closingNote:string,key:string):Promise<Shift>{
    return this.idempotent(ctx,key,{kind:'shift-close',branchId:ctx.branchId,id,expectedRevision,closingNote},()=>{
      const s=this.shiftMap.get(id);assert(s,404,'NOT_FOUND','Смена не найдена');this.scope(ctx,s);
      requireShiftActor(ctx.role,ctx.userId,s.userId);
      assert(s.revision===expectedRevision,409,'STALE_VERSION','Версия смены изменилась');
      assert(s.status==='OPEN',409,'SHIFT_CLOSED','Смена уже закрыта');
      s.status='CLOSED';s.closedAt=new Date().toISOString();s.closingNote=closingNote;s.revision++;
      const {org,branch,...result}=s;return result;
    });
  }
  async ingredients(ctx:Ctx):Promise<Ingredient[]>{
    return [...this.ingredientMap.values()].filter(x=>x.org===ctx.organizationId&&x.branch===ctx.branchId)
      .map(({org,branch,...r})=>structuredClone(r)).sort((a,b)=>a.name.localeCompare(b.name));
  }
  async createIngredient(ctx:Ctx,name:string,unit:StockUnit,minQuantityMilli:number,key:string):Promise<Ingredient>{
    return this.idempotent(ctx,key,{kind:'ingredient',branchId:ctx.branchId,name,unit,minQuantityMilli},()=>{
      stockQuantity(minQuantityMilli,'minQuantityMilli',true);
      assert(![...this.ingredientMap.values()].some(i=>i.org===ctx.organizationId&&i.branch===ctx.branchId&&i.name===name),409,'DUPLICATE','Ингредиент существует');
      const i={id:randomUUID(),org:ctx.organizationId,branch:ctx.branchId,name,unit,minQuantityMilli,quantityMilli:0,valueCents:0,revision:1,lowStock:false};
      i.lowStock=i.quantityMilli<i.minQuantityMilli;this.ingredientMap.set(i.id,i);const {org,branch,...result}=i;return result;
    });
  }
  async setIngredientMinimum(ctx:Ctx,id:string,expectedRevision:number,minQuantityMilli:number,key:string):Promise<Ingredient>{
    return this.idempotent(ctx,key,{kind:'minimum',branchId:ctx.branchId,id,expectedRevision,minQuantityMilli},()=>{
      const i=this.ingredientMap.get(id);assert(i,404,'INGREDIENT_NOT_FOUND','Ингредиент не найден');this.scope(ctx,i);
      assert(i.revision===expectedRevision,409,'STALE_VERSION','Склад изменился');
      i.minQuantityMilli=stockQuantity(minQuantityMilli,'minQuantityMilli',true);i.revision++;i.lowStock=i.quantityMilli<i.minQuantityMilli;
      const {org,branch,...result}=i;return result;
    });
  }
  async recipe(ctx:Ctx,menuItemId:string):Promise<Recipe|null>{
    const m=this.menus.get(menuItemId);assert(m,404,'MENU_NOT_FOUND','Блюдо не найдено');this.scope(ctx,m);
    return structuredClone(this.recipeMap.get(menuItemId)||null);
  }
  async saveRecipe(ctx:Ctx,menuItemId:string,expectedRevision:number,components:RecipeComponentInput[],key:string):Promise<Recipe>{
    return this.idempotent(ctx,key,{kind:'recipe',branchId:ctx.branchId,menuItemId,expectedRevision,components},()=>{
      recipeComponents(components);
      const m=this.menus.get(menuItemId);assert(m,404,'MENU_NOT_FOUND','Блюдо не найдено');this.scope(ctx,m);
      const old=this.recipeMap.get(menuItemId);assert((old?.revision||0)===expectedRevision,409,'STALE_VERSION','Рецептура изменена');
      const combined=components.map(c=>{const i=this.ingredientMap.get(c.ingredientId);
        assert(i,404,'INGREDIENT_NOT_FOUND','Ингредиент не найден');this.scope(ctx,i);
        return {ingredientId:i.id,quantityMilli:c.quantityMilli,name:i.name,unit:i.unit};});
      const next={menuItemId,revision:expectedRevision+1,components:combined};this.recipeMap.set(menuItemId,next);return next;
    });
  }
  async suppliers(ctx:Ctx):Promise<Supplier[]>{
    return [...this.supplierMap.values()].filter(x=>x.org===ctx.organizationId&&x.branch===ctx.branchId)
      .map(({org,branch,...r})=>structuredClone(r));
  }
  async createSupplier(ctx:Ctx,name:string,key:string):Promise<Supplier>{
    return this.idempotent(ctx,key,{kind:'supplier',branchId:ctx.branchId,name},()=>{
      const s={id:randomUUID(),name,org:ctx.organizationId,branch:ctx.branchId};this.supplierMap.set(s.id,s);
      const {org,branch,...r}=s;return r;
    });
  }
  async receipts(ctx:Ctx):Promise<Receipt[]>{
    return [...this.receiptMap.values()].filter(x=>x.org===ctx.organizationId&&x.branch===ctx.branchId)
      .map(({org,branch,...r})=>structuredClone(r));
  }
  async receiveStock(ctx:Ctx,supplierId:string|null,reference:string,lines:ReceiptLineInput[],key:string):Promise<Receipt>{
    return this.idempotent(ctx,key,{kind:'receipt',branchId:ctx.branchId,supplierId,reference,lines},()=>{
      receiptLines(lines);
      if(supplierId){const s=this.supplierMap.get(supplierId);assert(s,404,'SUPPLIER_NOT_FOUND','Поставщик не найден');this.scope(ctx,s);}
      assert(!reference||![...this.receiptMap.values()].some(r=>r.org===ctx.organizationId&&r.branch===ctx.branchId&&r.supplierId===supplierId&&r.reference===reference),
        409,'DUPLICATE','Поступление с этим номером накладной уже существует');
      const changes=lines.map(l=>{const i=this.ingredientMap.get(l.ingredientId);
        assert(i,404,'INGREDIENT_NOT_FOUND','Ингредиент не найден');this.scope(ctx,i);
        const b=addStock(i.quantityMilli,i.valueCents,l.quantityMilli,l.totalCostCents);return {i,qty:b.quantityMilli,val:b.valueCents,l};});
      const receipt:Receipt&{org:string;branch:string}={id:randomUUID(),org:ctx.organizationId,branch:ctx.branchId,
        supplierId,reference,totalCostCents:lines.reduce((s,l)=>s+l.totalCostCents,0),receivedAt:new Date().toISOString(),
        lines:changes.map(c=>({ingredientId:c.i.id,name:c.i.name,quantityMilli:c.l.quantityMilli,totalCostCents:c.l.totalCostCents}))};
      for(const c of changes){c.i.quantityMilli=c.qty;c.i.valueCents=c.val;c.i.revision++;c.i.lowStock=c.i.quantityMilli<c.i.minQuantityMilli;
        this.movementMap.push({id:randomUUID(),org:ctx.organizationId,branch:ctx.branchId,ingredientId:c.i.id,
          ingredientName:c.i.name,deltaQuantityMilli:c.l.quantityMilli,deltaValueCents:c.l.totalCostCents,reason:'RECEIPT',
          createdAt:new Date().toISOString(),sourceId:receipt.id});}
      this.receiptMap.set(receipt.id,receipt);const {org,branch,...result}=receipt;return result;
    });
  }
  async countStock(ctx:Ctx,id:string,countedQuantityMilli:number,expectedRevision:number,foundValueCents:number|null,key:string):Promise<StockCount>{
    return this.idempotent(ctx,key,{kind:'stock-count',branchId:ctx.branchId,id,countedQuantityMilli,expectedRevision,foundValueCents},()=>{
      const i=this.ingredientMap.get(id);assert(i,404,'INGREDIENT_NOT_FOUND','Ингредиент не найден');this.scope(ctx,i);
      assert(i.revision===expectedRevision,409,'STALE_VERSION','Остаток изменился');
      const variance=countVariance(i.quantityMilli,i.valueCents,countedQuantityMilli,foundValueCents);
      const result={id:randomUUID(),ingredientId:id,beforeQuantityMilli:i.quantityMilli,countedQuantityMilli,deltaQuantityMilli:variance.deltaMilli,deltaValueCents:variance.deltaValueCents};
      i.quantityMilli=countedQuantityMilli;i.valueCents+=variance.deltaValueCents;i.revision++;i.lowStock=i.quantityMilli<i.minQuantityMilli;
      if(variance.deltaMilli)this.movementMap.push({id:randomUUID(),org:ctx.organizationId,branch:ctx.branchId,ingredientId:id,
        ingredientName:i.name,deltaQuantityMilli:variance.deltaMilli,deltaValueCents:variance.deltaValueCents,
        reason:'COUNT',createdAt:new Date().toISOString(),sourceId:result.id});
      return result;
    });
  }
  async stockMovements(ctx:Ctx):Promise<StockMovement[]>{
    return this.movementMap.filter(x=>x.org===ctx.organizationId&&x.branch===ctx.branchId)
      .map(({org,branch,...r})=>structuredClone(r)).reverse();
  }
  async tasks(ctx:Ctx):Promise<RestaurantTask[]>{
    const manager=managesShifts(ctx.role)||['finance_director','auditor'].includes(ctx.role);
    return [...this.taskMap.values()].filter(x=>x.org===ctx.organizationId&&x.branch===ctx.branchId&&(manager||x.assignedTo===ctx.userId))
      .map(({org,branch,...r})=>structuredClone(r));
  }
  async createTask(ctx:Ctx,title:string,description:string,assignedTo:string|null,dueAt:string|null,key:string):Promise<RestaurantTask>{
    return this.idempotent(ctx,key,{kind:'task',branchId:ctx.branchId,title,description,assignedTo,dueAt},()=>{
      if(assignedTo){const m=this.memberMap.get(this.membershipKey(ctx.organizationId,assignedTo));
        assert(m&&hasBranchAccess(m.role,m.grants.includes(ctx.branchId)),404,'EMPLOYEE_NOT_FOUND','Нет сотрудника');}
      const t:RestaurantTask&{org:string;branch:string}={id:randomUUID(),org:ctx.organizationId,branch:ctx.branchId,title,description,assignedTo,
        employeeName:assignedTo?[...this.users.values()].find(x=>x.id===assignedTo)?.displayName||null:null,createdBy:ctx.userId,
        status:'OPEN',dueAt,completedAt:null,revision:1,createdAt:new Date().toISOString()};
      this.taskMap.set(t.id,t);const {org,branch,...r}=t;return r;
    });
  }
  async changeTaskStatus(ctx:Ctx,id:string,to:TaskStatus,expectedRevision:number,key:string):Promise<RestaurantTask>{
    return this.idempotent(ctx,key,{kind:'task-status',branchId:ctx.branchId,id,to,expectedRevision},()=>{
      const t=this.taskMap.get(id);assert(t,404,'NOT_FOUND','Задача не найдена');this.scope(ctx,t);
      const manager=managesShifts(ctx.role);
      assert(manager||t.assignedTo===ctx.userId,403,'FORBIDDEN','Задача не назначена вам');
      assert(t.revision===expectedRevision,409,'STALE_VERSION','Задача изменена');taskStatusTransition(t.status,to,manager);
      t.status=to;t.revision++;t.completedAt=to==='DONE'?new Date().toISOString():null;
      const {org,branch,...r}=t;return r;
    });
  }

  async guests(ctx:Ctx,after:string|null):Promise<{guests:Guest[];nextCursor:string|null}>{
    const all=[...this.guestMap.values()].filter(g=>g.org===ctx.organizationId&&g.branch===ctx.branchId&&(!after||g.id>after))
      .sort((a,b)=>a.id.localeCompare(b.id));
    return {guests:all.slice(0,100).map(({org,branch,...g})=>structuredClone(g)),nextCursor:all.length>100?all[99].id:null};
  }
  async createGuest(ctx:Ctx,input:GuestInput,key:string):Promise<Guest>{
    return this.idempotent(ctx,key,{kind:'guest-create',branchId:ctx.branchId,input},()=>{
      const g:Guest&{org:string;branch:string}={...input,id:randomUUID(),revision:1,createdAt:new Date().toISOString(),org:ctx.organizationId,branch:ctx.branchId};
      this.guestMap.set(g.id,g);const {org,branch,...result}=g;return result;
    });
  }
  async updateGuest(ctx:Ctx,id:string,revision:number,input:GuestInput,key:string):Promise<Guest>{
    return this.idempotent(ctx,key,{kind:'guest-update',branchId:ctx.branchId,id,revision,input},()=>{
      const g=this.guestMap.get(id);assert(g,404,'GUEST_NOT_FOUND','Гость не найден');this.scope(ctx,g);
      assert(g.revision===revision,409,'STALE_VERSION','Карточка гостя изменилась');Object.assign(g,input);g.revision++;
      const {org,branch,...result}=g;return result;
    });
  }
  async eraseGuest(ctx:Ctx,id:string,revision:number,key:string):Promise<{guestId:string;erased:true}>{
    return this.idempotent(ctx,key,{kind:'guest-erase',branchId:ctx.branchId,id,revision},()=>{
      const g=this.guestMap.get(id);assert(g,404,'GUEST_NOT_FOUND','Гость не найден');this.scope(ctx,g);
      assert(g.revision===revision,409,'STALE_VERSION','Карточка гостя изменилась');
      const orderIds=new Set([...this.orderMap.values()].filter(o=>o.org===ctx.organizationId&&o.branch===ctx.branchId&&o.guestId===id).map(o=>o.id));
      for(const [fid,f] of this.feedbackMap)if(f.org===ctx.organizationId&&f.branch===ctx.branchId&&
        (f.guestId===id||(f.orderId!==null&&orderIds.has(f.orderId))))this.feedbackMap.delete(fid);
      for(const o of this.orderMap.values())if(o.org===ctx.organizationId&&o.branch===ctx.branchId&&o.guestId===id)o.guestId=null;
      for(const [k,c] of this.consentMap)if(c.org===ctx.organizationId&&c.branch===ctx.branchId&&c.guestId===id)this.consentMap.delete(k);
      this.guestMap.delete(id);
      return {guestId:id,erased:true as const};
    });
  }
  private scopedGuest(ctx:Ctx,id:string):Guest&{org:string;branch:string}{
    const g=this.guestMap.get(id);assert(g,404,'GUEST_NOT_FOUND','Гость не найден');this.scope(ctx,g);return g;
  }
  async guestVisits(ctx:Ctx,guestId:string):Promise<GuestVisit[]>{
    this.scopedGuest(ctx,guestId);
    return [...this.orderMap.values()].filter(o=>o.org===ctx.organizationId&&o.branch===ctx.branchId&&o.guestId===guestId&&o.status==='COMPLETED')
      .map(o=>({orderId:o.id,completedAt:this.orderCompletedAt.get(o.id)!,totalCents:o.totalCents}))
      .sort((a,b)=>b.completedAt.localeCompare(a.completedAt)).slice(0,200);
  }
  async guestConsents(ctx:Ctx,guestId:string):Promise<Consent[]>{
    this.scopedGuest(ctx,guestId);
    return [...this.consentMap.values()].filter(c=>c.org===ctx.organizationId&&c.branch===ctx.branchId&&c.guestId===guestId)
      .map(({org,branch,...c})=>structuredClone(c));
  }
  async saveGuestConsent(ctx:Ctx,guestId:string,channel:ConsentChannel,state:ConsentState,evidence:string|null,expectedRevision:number,key:string):Promise<Consent>{
    return this.idempotent(ctx,key,{kind:'guest-consent',branchId:ctx.branchId,guestId,channel,state,evidence,expectedRevision},()=>{
      this.scopedGuest(ctx,guestId);
      const k=`${ctx.organizationId}:${ctx.branchId}:${guestId}:${channel}`,previous=this.consentMap.get(k);
      assert(previous?previous.revision===expectedRevision:expectedRevision===0,409,'STALE_VERSION','Согласие уже изменено');
      const current:Consent&{org:string;branch:string}={guestId,channel,state,evidence,revision:(previous?.revision||0)+1,
        recordedAt:new Date().toISOString(),org:ctx.organizationId,branch:ctx.branchId};
      this.consentMap.set(k,current);const {org,branch,...result}=current;return result;
    });
  }
  async linkOrderGuest(ctx:Ctx,orderId:string,guestId:string|null,expectedRevision:number,key:string):Promise<Order>{
    return this.idempotent(ctx,key,{kind:'order-guest',branchId:ctx.branchId,orderId,guestId,expectedRevision},()=>{
      const o=this.orderMap.get(orderId);assert(o,404,'NOT_FOUND','Заказ не найден');this.scope(ctx,o);
      assert(o.revision===expectedRevision,409,'STALE_VERSION','Версия заказа изменилась');
      assert(o.status==='OPEN',409,'ORDER_LOCKED','Гостя можно указать до отправки заказа на кухню');
      if(guestId)this.scopedGuest(ctx,guestId);
      o.guestId=guestId;o.revision++;
      return o;
    });
  }
  async guestInsights(ctx:Ctx):Promise<GuestInsights>{
    const asOf=new Date(),guests=[...this.guestMap.values()].filter(g=>g.org===ctx.organizationId&&g.branch===ctx.branchId);
    const visits=[...this.orderMap.values()].filter(o=>o.org===ctx.organizationId&&o.branch===ctx.branchId&&o.status==='COMPLETED')
      .map(o=>({guestId:o.guestId,orderId:o.id,totalCents:o.totalCents,completedAt:this.orderCompletedAt.get(o.id)!}));
    return calculateGuestInsights(guests.map(g=>g.id),visits,asOf);
  }
  async guestFeedback(ctx:Ctx):Promise<GuestFeedback[]>{
    return [...this.feedbackMap.values()].filter(f=>f.org===ctx.organizationId&&f.branch===ctx.branchId)
      .map(({org,branch,...f})=>structuredClone(f)).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,200);
  }
  async createGuestFeedback(ctx:Ctx,input:GuestFeedbackInput,key:string):Promise<GuestFeedback>{
    return this.idempotent(ctx,key,{kind:'feedback-create',branchId:ctx.branchId,input},()=>{
      if(input.guestId)this.scopedGuest(ctx,input.guestId);
      if(input.orderId){const o=this.orderMap.get(input.orderId);assert(o,404,'ORDER_NOT_FOUND','Заказ не найден');this.scope(ctx,o);
        assert(!input.guestId||!o.guestId||input.guestId===o.guestId,409,'FEEDBACK_IDENTITY','Гость не совпадает с заказом');}
      const f:GuestFeedback&{org:string;branch:string}={...input,id:randomUUID(),status:'OPEN',resolution:null,revision:1,
        createdAt:new Date().toISOString(),resolvedAt:null,org:ctx.organizationId,branch:ctx.branchId};
      this.feedbackMap.set(f.id,f);const {org,branch,...result}=f;return result;
    });
  }
  async resolveGuestFeedback(ctx:Ctx,id:string,expectedRevision:number,resolution:string,key:string):Promise<GuestFeedback>{
    return this.idempotent(ctx,key,{kind:'feedback-resolve',branchId:ctx.branchId,id,expectedRevision,resolution},()=>{
      const f=this.feedbackMap.get(id);assert(f,404,'FEEDBACK_NOT_FOUND','Обращение не найдено');this.scope(ctx,f);
      assert(f.revision===expectedRevision,409,'STALE_VERSION','Обращение изменилось');
      assert(f.status==='OPEN',409,'FEEDBACK_RESOLVED','Обращение уже закрыто');
      f.status='RESOLVED';f.resolution=resolution;f.revision++;f.resolvedAt=new Date().toISOString();
      const {org,branch,...result}=f;return result;
    });
  }

  async orders(ctx:Ctx){return [...this.orderMap.values()].filter(x=>x.org===ctx.organizationId&&x.branch===ctx.branchId).map(o=>{const copy=structuredClone(o);if(!['owner','finance_director','operations_director','manager','chef','analyst','auditor'].includes(ctx.role)){copy.actualFoodCostCents=null;copy.missingRecipeLines=null;copy.foodCostComplete=false;}return copy;});}
  async createOrder(ctx:Ctx,tableId:string|null,key:string){return this.idempotent(ctx,key,{type:'create',branch:ctx.branchId,tableId},()=>{
    if(tableId){const t=this.tableMap.get(tableId);assert(t,404,'NOT_FOUND','Стол не найден');this.scope(ctx,t);
      assert(![...this.orderMap.values()].some(x=>x.tableId===tableId&&x.status!=='COMPLETED'&&x.status!=='CANCELLED'),409,'TABLE_BUSY','Стол занят');
      assert(![...this.bookingMap.values()].some(b=>b.org===ctx.organizationId&&b.branch===ctx.branchId&&b.tableId===tableId
        &&b.status==='CONFIRMED'&&Date.parse(b.startsAt)<=Date.now()+15*60000&&Date.parse(b.endsAt)>Date.now()),
        409,'TABLE_RESERVED','Стол забронирован');}
    const o:Order&{org:string;branch:string}={id:randomUUID(),guestId:null,tableId,org:ctx.organizationId,branch:ctx.branchId,status:'OPEN',totalCents:0,revision:1,createdAt:new Date().toISOString(),items:[],actualFoodCostCents:null,missingRecipeLines:null,foodCostComplete:false};
    this.orderMap.set(o.id,o);return o;
  });}
  async addOrderItem(ctx:Ctx,orderId:string,itemId:string,quantity:number,expectedRevision:number,key:string){return this.idempotent(ctx,key,{type:'add',branch:ctx.branchId,orderId,itemId,quantity,expectedRevision},()=>{
    const o=this.orderMap.get(orderId);assert(o,404,'NOT_FOUND','Заказ не найден');this.scope(ctx,o);
    assert(o.revision===expectedRevision,409,'STALE_VERSION','Конфликт версий');assert(o.status==='OPEN',409,'ORDER_LOCKED','Заказ закрыт');
    const m=this.menus.get(itemId);assert(m&&m.active,404,'MENU_NOT_FOUND','Блюдо не найдено');this.scope(ctx,m);
    const amount=safeMoneySum([{unitPriceCents:m.priceCents,quantity}]);
    const id=randomUUID();o.items.push({id,menuItemId:itemId,name:m.name,unitPriceCents:m.priceCents,quantity,lineTotalCents:amount});
    o.totalCents=safeMoneySum(o.items);o.revision++;return o;
  });}
  async changeOrderStatus(ctx:Ctx,orderId:string,to:OrderStatus,expectedRevision:number,key:string){return this.idempotent(ctx,key,{type:'status',branch:ctx.branchId,orderId,to,expectedRevision},()=>{
    const o=this.orderMap.get(orderId);assert(o,404,'NOT_FOUND','Заказ не найден');this.scope(ctx,o);
    assert(o.revision===expectedRevision,409,'STALE_VERSION','Конфликт версий');requireTransition(ctx.role,o.status,to);
    if(to==='SENT'){
      assert(o.items.length>0,409,'EMPTY_ORDER','Заказ пуст');
      const requirements:{ingredientId:string;quantityMilli:number}[]=[];let missing=0;
      for(const line of o.items){const r=this.recipeMap.get(line.menuItemId);
        if(!r?.components.length){missing++;continue;}
        for(const c of r.components)requirements.push({ingredientId:c.ingredientId,quantityMilli:c.quantityMilli*line.quantity});
      }
      this.orderSnapshots.set(orderId,{requirements,missing});o.missingRecipeLines=missing;
    }
    if(to==='COMPLETED'){
      const snapshot=this.orderSnapshots.get(orderId);
      if(snapshot){const totals=new Map<string,number>();
        for(const r of snapshot.requirements)totals.set(r.ingredientId,(totals.get(r.ingredientId)||0)+r.quantityMilli);
        const moves:[Ingredient&{org:string;branch:string},number,number][]=[];let cost=0n;
        for(const [ingredientId,used] of [...totals.entries()].sort(([a],[b])=>a.localeCompare(b))){
          const i=this.ingredientMap.get(ingredientId);assert(i,409,'STOCK_MISSING','Ингредиент не найден');this.scope(ctx,i);
          const value=costOfIssue(i.quantityMilli,i.valueCents,used);
          cost+=BigInt(value);assert(cost<=9_999_999_999_999n,409,'AMOUNT_TOO_LARGE','Недопустимая сумма');
          moves.push([i,used,value]);
        }
        for(const [i,used,value] of moves){i.quantityMilli-=used;i.valueCents-=value;i.revision++;i.lowStock=i.quantityMilli<i.minQuantityMilli;
          this.movementMap.push({id:randomUUID(),org:ctx.organizationId,branch:ctx.branchId,ingredientId:i.id,ingredientName:i.name,
            deltaQuantityMilli:-used,deltaValueCents:-value,reason:'ORDER',createdAt:new Date().toISOString(),sourceId:o.id});}
        o.actualFoodCostCents=Number(cost);o.foodCostComplete=snapshot.missing===0;
      }
    }
    o.status=to;o.revision++;
    const time=this.kitchenTimes.get(o.id)||{};
    if(to==='SENT')time.sentAt=new Date().toISOString();
    if(to==='PREPARING')time.preparingAt=new Date().toISOString();
    if(to==='READY')time.readyAt=new Date().toISOString();
    this.kitchenTimes.set(o.id,time);
    if(to==='COMPLETED')this.orderCompletedAt.set(o.id,new Date().toISOString());
    if(to==='COMPLETED'||to==='CANCELLED'){
      const id=this.orderReservations.get(o.id),b=id?this.bookingMap.get(id):undefined;
      if(b?.status==='SEATED'){b.status='COMPLETED';b.revision++;}
    }
    return o;
  });}
  // Test-only financial data. Production uses PostgreSQL; this adapter mirrors the contracts.
  private branchDate(ctx:Ctx,utc:string):string{
    const zone=this.branchMap.get(ctx.branchId)?.timezone||'UTC';
    const parts=new Intl.DateTimeFormat('en-US',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(utc));
    const part=(type:string)=>parts.find(p=>p.type===type)?.value;
    return `${part('year')}-${part('month')}-${part('day')}`;
  }
  async financeExpenses(ctx:Ctx,period:string):Promise<Expense[]>{
    financePeriod(period);
    return [...this.financeExpenseMap.values()].filter(e=>e.org===ctx.organizationId&&e.branch===ctx.branchId&&e.occurredOn.startsWith(period))
      .map(({org,branch,...e})=>structuredClone(e)).sort((a,b)=>b.occurredOn.localeCompare(a.occurredOn));
  }
  async createFinanceExpense(ctx:Ctx,input:{category:ExpenseCategory;description:string;amountCents:number;occurredOn:string},key:string):Promise<Expense>{
    return this.idempotent(ctx,key,{kind:'finance-expense',branchId:ctx.branchId,...input},()=>{
      const e:Expense&{org:string;branch:string}={id:randomUUID(),org:ctx.organizationId,branch:ctx.branchId,
        ...input,status:'POSTED',revision:1,createdAt:new Date().toISOString(),voidedAt:null,voidReason:null};
      this.financeExpenseMap.set(e.id,e);
      const {org,branch,...r}=e;return r;
    });
  }
  async voidFinanceExpense(ctx:Ctx,id:string,expectedRevision:number,reason:string,key:string):Promise<Expense>{
    return this.idempotent(ctx,key,{kind:'finance-expense-void',branchId:ctx.branchId,id,expectedRevision,reason},()=>{
      const e=this.financeExpenseMap.get(id);assert(e,404,'EXPENSE_NOT_FOUND','Расход не найден');this.scope(ctx,e);
      assert(e.revision===expectedRevision,409,'STALE_VERSION','Расход изменён');
      assert(e.status==='POSTED',409,'EXPENSE_VOIDED','Расход уже аннулирован');
      e.status='VOIDED';e.revision++;e.voidReason=reason;e.voidedAt=new Date().toISOString();
      const {org,branch,...r}=e;return r;
    });
  }
  async financeBudgets(ctx:Ctx,period:string):Promise<Budget[]>{
    financePeriod(period);
    return [...this.budgetMap.values()].filter(e=>e.org===ctx.organizationId&&e.branch===ctx.branchId&&e.period===period)
      .map(({org,branch,...b})=>structuredClone(b));
  }
  async saveFinanceBudget(ctx:Ctx,period:string,category:BudgetCategory,amountCents:number,expectedRevision:number,key:string):Promise<Budget>{
    return this.idempotent(ctx,key,{kind:'finance-budget',branchId:ctx.branchId,period,category,amountCents,expectedRevision},()=>{
      const index=`${ctx.organizationId}:${ctx.branchId}:${period}:${category}`;
      const old=this.budgetMap.get(index);
      assert((old?.revision??0)===expectedRevision,409,'STALE_VERSION','Бюджет изменён');
      const row:Budget&{org:string;branch:string}={org:ctx.organizationId,branch:ctx.branchId,period,category,amountCents,revision:expectedRevision+1};
      this.budgetMap.set(index,row);
      const {org,branch,...r}=row;return r;
    });
  }
  private async financeFacts(ctx:Ctx,period:string):Promise<FinanceFacts>{
    const orders=[...this.orderMap.values()].filter(o=>o.org===ctx.organizationId&&o.branch===ctx.branchId&&o.status==='COMPLETED'&&
      this.branchDate(ctx,this.orderCompletedAt.get(o.id)||o.createdAt).startsWith(period))
      .map(o=>({id:o.id,amountCents:o.totalCents,costCents:o.actualFoodCostCents,complete:o.foodCostComplete}));
    const expenses=await this.financeExpenses(ctx,period);
    const stockLossCents=centsSum(this.movementMap.filter(m=>m.org===ctx.organizationId&&m.branch===ctx.branchId
      &&m.reason==='COUNT'&&m.deltaValueCents<0&&this.branchDate(ctx,m.createdAt).startsWith(period))
      .map(m=>-m.deltaValueCents),'Недостачи');
    return {orders,expenses,stockLossCents};
  }
  async financeReport(ctx:Ctx,period:string){
    const facts=await this.financeFacts(ctx,financePeriod(period));
    return calculateFinanceReport(period,facts,await this.financeBudgets(ctx,period));
  }
  async financeLedger(ctx:Ctx,period:string):Promise<LedgerEntry[]>{
    const facts=await this.financeFacts(ctx,financePeriod(period));const result:LedgerEntry[]=[];
    for(const o of facts.orders){const time=this.orderCompletedAt.get(o.id)||new Date().toISOString();
      result.push({id:`sale:${o.id}`,source:'ORDER',sourceId:o.id,description:'Завершённый заказ',occurredAt:time,
        signedAmountCents:o.amountCents,complete:true});
      if(o.costCents!==null)result.push({id:`food:${o.id}`,source:'FOOD_COST',sourceId:o.id,occurredAt:time,
        description:o.complete?'Себестоимость заказа':'Известная часть себестоимости (неполные данные)',
        signedAmountCents:-o.costCents,complete:o.complete});
    }
    for(const e of facts.expenses){result.push({id:`expense:${e.id}`,source:'EXPENSE',sourceId:e.id,
      description:e.status==='VOIDED'?`Аннулирован: ${e.description}`:e.description,
      occurredAt:`${e.occurredOn}T12:00:00.000Z`,signedAmountCents:e.status==='VOIDED'?0:-e.amountCents,
      complete:e.status==='POSTED'});}
    for(const m of this.movementMap.filter(m=>m.org===ctx.organizationId&&m.branch===ctx.branchId&&m.reason==='COUNT'
      &&m.deltaValueCents<0&&this.branchDate(ctx,m.createdAt).startsWith(period))){
      result.push({id:`loss:${m.sourceId}`,source:'STOCK_LOSS',sourceId:m.sourceId,
        description:`Недостача при инвентаризации: ${m.ingredientName}`,occurredAt:m.createdAt,
        signedAmountCents:m.deltaValueCents,complete:true});
    }
    return result.sort((a,b)=>b.occurredAt.localeCompare(a.occurredAt)).slice(0,400);
  }
  async dashboard(ctx:Ctx){const all=await this.orders(ctx);const completed=all.filter(o=>o.status==='COMPLETED'),revenue=completed.reduce((a,b)=>a+b.totalCents,0);
    const active=all.filter(o=>!['COMPLETED','CANCELLED'].includes(o.status));
    const days=Array.from({length:7},(_,i)=>{const d=new Date();d.setUTCDate(d.getUTCDate()-6+i);return {day:d.toISOString().slice(0,10),revenueCents:0};});
    return {lowStockCount:(await this.ingredients(ctx)).filter(i=>i.lowStock).length,revenueCents:revenue,completedOrders:completed.length,averageCheckCents:completed.length?Math.floor(revenue/completed.length):0,activeOrders:active.length,
      menuItems:(await this.menu(ctx)).filter(m=>m.active).length,tables:(await this.tables(ctx)).length,series:days,recentOrders:all.slice(0,5)};
  }
}
