import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {runMigrations} from '../src/migrate.ts';
import {createPostgresStore} from '../src/infra/postgres.ts';
const skip=!process.env.DATABASE_URL?'DATABASE_URL not configured':false;
test('R6 PostgreSQL: migration, scoped decisions, idempotency, transitions and audit',{skip},async()=>{
  await runMigrations();const store=await createPostgresStore(process.env.DATABASE_URL!);
  try{
    const suffix=randomUUID();
    const a=await store.bootstrap({email:`r6-a-${suffix}@example.test`,displayName:'A',passwordHash:'test-only',organizationName:'A',branchName:'A1'});
    const b=await store.bootstrap({email:`r6-b-${suffix}@example.test`,displayName:'B',passwordHash:'test-only',organizationName:'B',branchName:'B1'});
    const ctx={userId:a.user.id,organizationId:a.organizationId,branchId:a.branchId,role:'owner' as const};
    const outsider={userId:b.user.id,organizationId:b.organizationId,branchId:b.branchId,role:'owner' as const};
    // Generate a genuine missing-cost signal from a completed dish without recipe.
    const dish=await store.addMenuItem(ctx,'Dish without recipe',22000);
    const order=await store.createOrder(ctx,null,`order-${suffix}`);
    await store.addOrderItem(ctx,order.id,dish.id,1,1,`line-${suffix}`);
    for(const [status,revision] of [['SENT',2],['PREPARING',3],['READY',4],['COMPLETED',5]] as const)
      await store.changeOrderStatus(ctx,order.id,status,revision,`status-${status}-${suffix}`);
    const parts=new Intl.DateTimeFormat('en-US',{year:'numeric',month:'2-digit',timeZone:'Europe/Moscow'}).formatToParts(new Date());
    const part=(type:string)=>parts.find(x=>x.type===type)!.value;
    const period=`${part('year')}-${part('month')}`;
    const diagnosis=await store.intelligenceDiagnosis(ctx,period);
    assert(diagnosis.signals.some(s=>s.id==='MISSING_FOOD_COST'));
    const input={title:'Проверить недостаток себестоимости',hypothesis:'Часть блюд продаётся без актуальных рецептов',action:'Заполнить рецептуры и проверить журнал списаний',implementationCostCents:0};
    const created=await store.createIntelligenceDecision(ctx,period,'MISSING_FOOD_COST',input,`decision-${suffix}`);
    assert.equal((await store.createIntelligenceDecision(ctx,period,'MISSING_FOOD_COST',input,`decision-${suffix}`)).id,created.id);
    await assert.rejects(store.createIntelligenceDecision(ctx,period,'MISSING_FOOD_COST',{...input,title:'Другая гипотеза'},`decision-${suffix}`),(e:any)=>e.code==='IDEMPOTENCY_CONFLICT');
    assert.equal((await store.intelligenceDecisions(ctx)).length,1);
    assert.equal((await store.intelligenceDecisions(outsider)).length,0);
    await assert.rejects(store.updateIntelligenceDecision(outsider,created.id,1,'IN_PROGRESS',null,null,`foreign-${suffix}`),(e:any)=>e.status===404);
    const update=await store.updateIntelligenceDecision(ctx,created.id,1,'IN_PROGRESS',null,null,`begin-${suffix}`);
    assert.equal(update.revision,2);
    await assert.rejects(store.updateIntelligenceDecision(ctx,created.id,1,'IMPLEMENTED',null,null,`stale-${suffix}`),(e:any)=>e.code==='VERSION_CONFLICT');
    await store.updateIntelligenceDecision(ctx,created.id,2,'IMPLEMENTED',null,null,`implement-${suffix}`);
    // No review until subsequent month; no fake ROI.
    await assert.rejects(store.updateIntelligenceDecision(ctx,created.id,3,'REVIEWED',period,'Наблюдение',`invalid-review-${suffix}`),(e:any)=>e.code==='REVIEW_PERIOD');
  }finally{await store.close();}
});
