import {before,after,test} from 'node:test';
import assert from 'node:assert/strict';
import {createApiServer} from '../src/http.ts';
import {FakeStore} from './fake-store.ts';
import type {Server} from 'node:http';
import type {AddressInfo} from 'node:net';

const store=new FakeStore();
let server:Server,base='',cookie='',csrf='',org='',branch='',table='',booking='',order='',managerId='',waiterCookie='',waiterCsrf='';
const root=()=>`/api/v1/organizations/${org}/branches/${branch}`;
const request=async(path:string,method='GET',body?:unknown,options:{cookie?:string;csrf?:string;key?:string}={})=>{
  const headers:Record<string,string>={};
  if(body!==undefined)headers['content-type']='application/json';
  if(options.cookie||cookie)headers.cookie=options.cookie||cookie;
  if(method!=='GET'){headers.origin='http://localhost:3000';if(options.csrf||csrf)headers['x-osmanx-csrf']=options.csrf||csrf;}
  if(options.key)headers['idempotency-key']=options.key;
  const r=await fetch(`${base}${path}`,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});
  return {status:r.status,data:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]||''};
};
before(async()=>{server=createApiServer(store,{origin:'http://localhost:3000',sessionSecret:'z'.repeat(64),secureCookies:false});await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${(server.address() as AddressInfo).port}`;});
after(async()=>{await new Promise<void>(r=>server.close(()=>r()));});

test('R2 bootstrap and branch floor',async()=>{
  const r=await request('/api/v1/auth/register','POST',{email:'r2-owner@example.test',password:'StrongPassword12345',displayName:'Руководитель',organizationName:'R2 pilot',branchName:'Pilot'});
  assert.equal(r.status,201);cookie=r.cookie;org=r.data.organizationId;branch=r.data.branchId;managerId=r.data.user.id;
  csrf=(await request('/api/v1/me')).data.csrfToken;
  let response=await request(`${root()}/tables`,'POST',{label:'A1',capacity:4});assert.equal(response.status,201);table=response.data.table.id;
  response=await request(`${root()}/floor`);assert.equal(response.status,200);assert.equal(response.data.tables[0].state,'AVAILABLE');
});
test('R2 reservation validation, capacity, conflicts and protected table',async()=>{
  const start=new Date(Date.now()+10*60000).toISOString();
  const body={tableId:table,guestName:'Клиент',partySize:3,startsAt:start,durationMinutes:90};
  let r=await request(`${root()}/reservations`,'POST',{...body,partySize:6},{key:'reserve-size-001'});
  assert.equal(r.status,409);assert.equal(r.data.error.code,'CAPACITY');
  r=await request(`${root()}/reservations`,'POST',body,{key:'reserve-first-001'});
  assert.equal(r.status,201);booking=r.data.reservation.id;
  const again=await request(`${root()}/reservations`,'POST',body,{key:'reserve-first-001'});
  assert.equal(again.data.reservation.id,booking);
  const sameKey=await request(`${root()}/reservations`,'POST',{...body,guestName:'Изменено'},{key:'reserve-first-001'});
  assert.equal(sameKey.status,409);assert.equal(sameKey.data.error.code,'IDEMPOTENCY_CONFLICT');
  const clash=await request(`${root()}/reservations`,'POST',{...body,startsAt:new Date(Date.now()+30*60000).toISOString()},{key:'reserve-clash-001'});
  assert.equal(clash.status,409);assert.equal(clash.data.error.code,'RESERVATION_CONFLICT');
  const blocked=await request(`${root()}/orders`,'POST',{tableId:table},{key:'r2-direct-order-001'});
  assert.equal(blocked.status,409);assert.equal(blocked.data.error.code,'TABLE_RESERVED');
  const floor=await request(`${root()}/floor`);assert.equal(floor.data.tables[0].state,'RESERVED');
  const list=await request(`${root()}/reservations`);assert.equal(list.data.reservations.length,1);
});
test('R2 staff invitation: waiter can seat booking but cannot edit price',async()=>{
  const inv=await request(`/api/v1/organizations/${org}/invitations`,'POST',{email:'r2-waiter@example.test',role:'waiter',branchIds:[branch]});
  assert.equal(inv.status,201);const token=new URL(inv.data.invitation.url).searchParams.get('token');
  const join=await request('/api/v1/auth/accept-invite','POST',{token,email:'r2-waiter@example.test',displayName:'Официант',password:'StrongPassword67890'});
  assert.equal(join.status,201);waiterCookie=join.cookie;
  waiterCsrf=(await request('/api/v1/me','GET',undefined,{cookie:waiterCookie})).data.csrfToken;
  const seat=await request(`${root()}/reservations/${booking}/seat`,'POST',{expectedRevision:1},{key:'r2-seat-first-001',cookie:waiterCookie,csrf:waiterCsrf});
  assert.equal(seat.status,201);order=seat.data.order.id;
  assert.equal(seat.data.reservation.status,'SEATED');assert.equal(seat.data.order.tableId,table);
  const duplicate=await request(`${root()}/reservations/${booking}/seat`,'POST',{expectedRevision:1},{key:'r2-seat-first-001',cookie:waiterCookie,csrf:waiterCsrf});
  assert.equal(duplicate.data.order.id,order);
  const conflict=await request(`${root()}/reservations/${booking}/seat`,'POST',{expectedRevision:1},{key:'r2-seat-other-001',cookie:waiterCookie,csrf:waiterCsrf});
  assert.equal(conflict.status,409);
  const floor=await request(`${root()}/floor`);assert.equal(floor.data.tables[0].state,'OCCUPIED');
});
test('R2 kitchen transitions, permissions and ticket lifecycle',async()=>{
  const menu=await request(`${root()}/menu`,'POST',{name:'Ризотто',priceCents:105000});assert.equal(menu.status,201);
  let r=await request(`${root()}/orders/${order}/items`,'POST',{menuItemId:menu.data.item.id,quantity:2,expectedRevision:1},{key:'r2-item-001',cookie:waiterCookie,csrf:waiterCsrf});
  assert.equal(r.status,200);assert.equal(r.data.order.totalCents,210000);
  r=await request(`${root()}/orders/${order}/status`,'POST',{status:'SENT',expectedRevision:2},{key:'r2-sent-001',cookie:waiterCookie,csrf:waiterCsrf});assert.equal(r.status,200);
  let tickets=await request(`${root()}/kitchen`);assert.equal(tickets.data.tickets.length,1);assert.ok(tickets.data.tickets[0].sentAt);
  const denied=await request(`${root()}/orders/${order}/status`,'POST',{status:'PREPARING',expectedRevision:3},{key:'r2-prepare-deny',cookie:waiterCookie,csrf:waiterCsrf});
  assert.equal(denied.status,403);
  const prepare=await request(`${root()}/orders/${order}/status`,'POST',{status:'PREPARING',expectedRevision:3},{key:'r2-preparing-001'});assert.equal(prepare.status,200);
  const stale=await request(`${root()}/orders/${order}/status`,'POST',{status:'READY',expectedRevision:3},{key:'r2-ready-stale-001'});assert.equal(stale.status,409);
  const ready=await request(`${root()}/orders/${order}/status`,'POST',{status:'READY',expectedRevision:4},{key:'r2-ready-001'});assert.equal(ready.status,200);
  const done=await request(`${root()}/orders/${order}/status`,'POST',{status:'COMPLETED',expectedRevision:5},{key:'r2-done-001',cookie:waiterCookie,csrf:waiterCsrf});assert.equal(done.status,200);
  tickets=await request(`${root()}/kitchen`);assert.equal(tickets.data.tickets.length,0);
  const reservation=await request(`${root()}/reservations`);assert.equal(reservation.data.reservations[0].status,'COMPLETED');
  const dashboard=await request(`${root()}/dashboard`);assert.equal(dashboard.data.dashboard.revenueCents,210000);
  const floor=await request(`${root()}/floor`);assert.equal(floor.data.tables[0].state,'AVAILABLE');
});
test('R2 shifts: self service, manager scope, duplicate, immutable version, closed status',async()=>{
  const workers=await request(`${root()}/staff`);assert.equal(workers.status,200);assert.equal(workers.data.staff.length,2);
  const onlySelf=await request(`${root()}/staff`,'GET',undefined,{cookie:waiterCookie});assert.equal(onlySelf.data.staff.length,1);
  let s=await request(`${root()}/shifts`,'POST',{openingNote:'Начало работы'},{key:'r2-shift-self-001',cookie:waiterCookie,csrf:waiterCsrf});
  assert.equal(s.status,201);const shift=s.data.shift.id;assert.equal(s.data.shift.status,'OPEN');
  const replay=await request(`${root()}/shifts`,'POST',{openingNote:'Начало работы'},{key:'r2-shift-self-001',cookie:waiterCookie,csrf:waiterCsrf});
  assert.equal(replay.data.shift.id,shift);
  const duplicate=await request(`${root()}/shifts`,'POST',{},{key:'r2-shift-self-002',cookie:waiterCookie,csrf:waiterCsrf});assert.equal(duplicate.status,409);
  const denied=await request(`${root()}/shifts`,'POST',{userId:managerId},{key:'r2-shift-other-001',cookie:waiterCookie,csrf:waiterCsrf});assert.equal(denied.status,403);
  const all=await request(`${root()}/shifts`);assert.equal(all.data.shifts.length,1);
  const stale=await request(`${root()}/shifts/${shift}/close`,'POST',{expectedRevision:2},{key:'r2-shift-close-stale'});assert.equal(stale.status,409);
  s=await request(`${root()}/shifts/${shift}/close`,'POST',{expectedRevision:1,closingNote:'Передача смены'},{key:'r2-shift-close-001'});
  assert.equal(s.status,200);assert.equal(s.data.shift.status,'CLOSED');
  const repeat=await request(`${root()}/shifts/${shift}/close`,'POST',{expectedRevision:1,closingNote:'Передача смены'},{key:'r2-shift-close-001'});
  assert.equal(repeat.status,200);
  const cannot=await request(`${root()}/shifts/${shift}/close`,'POST',{expectedRevision:2},{key:'r2-shift-close-002'});assert.equal(cannot.status,409);
});
test('R2 cross-organization access and prohibited role actions',async()=>{
  const newOrg=await request('/api/v1/auth/register','POST',{email:'other-r2@example.test',password:'StrongPassword78901',displayName:'Другой',organizationName:'Другая сеть',branchName:'Второй'});
  const noAccess=await request(`${root()}/reservations`,'GET',undefined,{cookie:newOrg.cookie});assert.equal(noAccess.status,404);
  const noShifts=await request(`${root()}/shifts`,'GET',undefined,{cookie:newOrg.cookie});assert.equal(noShifts.status,404);
  const noKitchen=await request(`${root()}/kitchen`,'GET',undefined,{cookie:newOrg.cookie});assert.equal(noKitchen.status,404);
});
