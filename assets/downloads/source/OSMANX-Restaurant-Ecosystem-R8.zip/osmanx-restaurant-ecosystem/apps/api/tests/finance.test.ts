import test from 'node:test';
import assert from 'node:assert/strict';
import {AppError} from '../src/domain/rules.ts';
import {basisPoints,calculateFinanceReport,centsSum,consolidateReports,expenseCategory,financeDate,financePeriod,positiveFinanceAmount} from '../src/domain/finance.ts';
import type {Expense} from '../src/domain/finance.ts';

const period='2026-11';
const expense=(category:Expense['category'],amountCents:number,status:Expense['status']='POSTED'):Expense=>({
  id:'test',category,description:'Тестовый расход',amountCents,status,occurredOn:`${period}-01`,revision:1,createdAt:'',voidedAt:null,voidReason:null
});

test('R4: calendar, money and category are strictly validated',()=>{
  assert.equal(financePeriod('2026-11'),'2026-11');assert.equal(financeDate('2024-02-29'),'2024-02-29');
  assert.throws(()=>financeDate('2026-02-29'),(e:any)=>e.code==='FINANCE_DATE');
  assert.throws(()=>financePeriod('2026-13'),(e:any)=>e.code==='FINANCE_PERIOD');
  assert.throws(()=>positiveFinanceAmount(0),(e:any)=>e.code==='VALIDATION');
  assert.throws(()=>positiveFinanceAmount(1.35),(e:any)=>e.code==='VALIDATION');
  assert.throws(()=>expenseCategory('PERSONAL'),(e:any)=>e.code==='FINANCE_CATEGORY');
});

test('R4: bigint arithmetic, rounded bps and signed results',()=>{
  assert.equal(centsSum([9_000_000_000_000,1]),9_000_000_000_001);
  assert.throws(()=>centsSum([9_999_999_999_999,1]),(e:any)=>e.code==='AMOUNT_TOO_LARGE');
  assert.equal(basisPoints(1,3),3333);assert.equal(basisPoints(1,6),1667);
  assert.equal(basisPoints(-1,6),-1667);assert.equal(basisPoints(0,0),null);
});

test('R4: recognized purchase stock is NOT a P&L expense; known food cost and shrinkage are',()=>{
  const result=calculateFinanceReport(period,{orders:[
    {id:'o1',amountCents:40000,costCents:11000,complete:true},
    {id:'o2',amountCents:60000,costCents:19000,complete:true}
  ],expenses:[expense('PAYROLL',22000),expense('RENT',10000),expense('SERVICES',1200),expense('MARKETING',500,'VOIDED')],stockLossCents:1300},[
    {period,category:'REVENUE',amountCents:120000,revision:1},
    {period,category:'FOOD_COST',amountCents:25000,revision:1},
    {period,category:'PAYROLL',amountCents:20000,revision:1}
  ]);
  assert.equal(result.revenueCents,100000);
  assert.equal(result.foodCostCents,30000);
  assert.equal(result.grossProfitCents,70000);
  assert.equal(result.laborCostCents,22000);
  assert.equal(result.expensesCents,33200);
  assert.equal(result.operatingResultCents,35500); // 100k - 30k - 33.2k - 1.3k
  assert.equal(result.foodCostRateBps,3000);
  assert.equal(result.laborCostRateBps,2200);
  assert.equal(result.planFact.find(x=>x.category==='REVENUE')?.varianceCents,-20000);
  assert.equal(result.planFact.find(x=>x.category==='PAYROLL')?.varianceCents,2000);
  assert.equal(result.planFact.find(x=>x.category==='RENT')?.plannedCents,null);
  assert.equal(result.expenseCoverage,'UNVERIFIED');
});

test('R4: missing recipe stops false margin and preserves known costs',()=>{
  const r=calculateFinanceReport(period,{orders:[
    {id:'known',amountCents:20000,costCents:5000,complete:true},
    {id:'unknown',amountCents:5000,costCents:0,complete:false},
    {id:'historic',amountCents:3000,costCents:null,complete:false}
  ],expenses:[expense('PAYROLL',10000)],stockLossCents:0},[
    {period,category:'FOOD_COST',amountCents:8000,revision:1}
  ]);
  assert.equal(r.revenueCents,28000);assert.equal(r.knownFoodCostCents,5000);
  assert.equal(r.uncostedOrders,2);assert.equal(r.foodCostCents,null);
  assert.equal(r.grossProfitCents,null);assert.equal(r.operatingResultCents,null);
  assert.equal(r.planFact.find(x=>x.category==='FOOD_COST')?.varianceCents,null);
});

test('R4: no sales is a zero report, percentage is undefined rather than 0%',()=>{
  const r=calculateFinanceReport(period,{orders:[],expenses:[expense('RENT',9000)],stockLossCents:0},[]);
  assert.equal(r.completedOrders,0);assert.equal(r.revenueCents,0);assert.equal(r.foodCostCents,0);
  assert.equal(r.operatingResultCents,-9000);assert.equal(r.operatingMarginBps,null);
});

test('R4: consolidated P&L does not conceal one branch with unknown food cost',()=>{
  const complete=calculateFinanceReport(period,{orders:[{id:'one',amountCents:9000,costCents:2000,complete:true}],expenses:[],stockLossCents:0},[]);
  const partial=calculateFinanceReport(period,{orders:[{id:'two',amountCents:12000,costCents:1000,complete:false}],expenses:[expense('RENT',2000)],stockLossCents:0},[]);
  const total=consolidateReports(period,[complete,partial]);
  assert.equal(total.completedOrders,2);assert.equal(total.uncostedOrders,1);
  assert.equal(total.knownFoodCostCents,3000);assert.equal(total.foodCostCents,null);
  assert.equal(total.revenueCents,21000);assert.equal(total.operatingResultCents,null);
});

test('R4: consolidated complete branches sum actual values and separate budgets',()=>{
  const branch=(sales:number,cost:number)=>calculateFinanceReport(period,{orders:[{id:'one',amountCents:sales,costCents:cost,complete:true}],expenses:[expense('PAYROLL',1000)],stockLossCents:100},[]);
  const total=consolidateReports(period,[branch(20000,5000),branch(30000,8000)]);
  assert.equal(total.revenueCents,50000);assert.equal(total.foodCostCents,13000);
  assert.equal(total.laborCostCents,2000);assert.equal(total.stockLossCents,200);
  assert.equal(total.operatingResultCents,34800);
});
