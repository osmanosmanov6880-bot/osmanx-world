import test from 'node:test';
import assert from 'node:assert/strict';
import {AppError,can,hasBranchAccess,requireTransition,safeMoneySum,moneyCents,integerField,textField,emailField} from '../src/domain/rules.ts';

test('RBAC: владелец управляет филиалами, аудитору разрешено только чтение',()=>{
  assert.equal(can('owner','branches:write'),true);
  assert.equal(can('auditor','dashboard:read'),true);
  assert.equal(can('auditor','orders:create'),false);
  assert.equal(can('waiter','menu:write'),false);
  assert.equal(can('kitchen','orders:advance'),true);
  assert.equal(hasBranchAccess('owner',false),true);
  assert.equal(hasBranchAccess('manager',false),false);
  assert.equal(hasBranchAccess('manager',true),true);
});
test('Переходы заказа: кухня, официант, отмена',()=>{
  assert.doesNotThrow(()=>requireTransition('waiter','OPEN','SENT'));
  assert.doesNotThrow(()=>requireTransition('kitchen','SENT','PREPARING'));
  assert.doesNotThrow(()=>requireTransition('chef','PREPARING','READY'));
  assert.doesNotThrow(()=>requireTransition('manager','READY','COMPLETED'));
  assert.throws(()=>requireTransition('kitchen','READY','COMPLETED'),{status:403,code:'FORBIDDEN'});
  assert.throws(()=>requireTransition('waiter','SENT','PREPARING'),{status:403,code:'FORBIDDEN'});
  assert.throws(()=>requireTransition('manager','COMPLETED','OPEN'),{status:409,code:'INVALID_TRANSITION'});
  assert.throws(()=>requireTransition('manager','OPEN','COMPLETED'),{status:409});
});
test('Денежные значения считаются в копейках без float',()=>{
  assert.equal(safeMoneySum([{unitPriceCents:199,quantity:3},{unitPriceCents:1299,quantity:2}]),3195);
  assert.equal(safeMoneySum([]),0);
  assert.throws(()=>moneyCents(-1),AppError);
  assert.throws(()=>moneyCents(1.35),AppError);
  assert.throws(()=>safeMoneySum([{unitPriceCents:999_999_999_999,quantity:30}]),{code:'AMOUNT_TOO_LARGE'});
});
test('Валидация не принимает NaN, управляющие символы и некорректные email',()=>{
  assert.throws(()=>integerField(NaN,'quantity',1,30),AppError);
  assert.throws(()=>textField('  ','name'),AppError);
  assert.throws(()=>textField('bad\x01field','name'),AppError);
  assert.equal(emailField(' User@Example.COM '),'user@example.com');
  assert.throws(()=>emailField('not-email'),AppError);
});
