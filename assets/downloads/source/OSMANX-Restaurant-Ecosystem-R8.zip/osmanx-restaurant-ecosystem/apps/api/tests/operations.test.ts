import test from 'node:test';
import assert from 'node:assert/strict';
import {bookingWindow,overlaps,requireSeatDate,requireShiftActor,requireReservationAction,sameTableCapacity} from '../src/domain/operations.ts';
import {AppError,can} from '../src/domain/rules.ts';

const now=new Date('2026-11-07T12:00:00.000Z');
test('booking windows: UTC, duration, 90-day horizon and half-open overlap',()=>{
  const a=bookingWindow('2026-11-07T12:15:00Z',90,now);
  assert.deepEqual(a,{startsAt:'2026-11-07T12:15:00.000Z',endsAt:'2026-11-07T13:45:00.000Z'});
  assert.equal(overlaps(a.startsAt,a.endsAt,'2026-11-07T13:45:00.000Z','2026-11-07T15:00:00.000Z'),false);
  assert.equal(overlaps(a.startsAt,a.endsAt,'2026-11-07T13:44:00.000Z','2026-11-07T15:00:00.000Z'),true);
  for(const [time,duration] of [['not-date',60],['2026-11-07T12:00:00+03:00',60],['2026-11-07T12:30:00Z',10],['2027-05-01T11:00:00Z',60]]){
    assert.throws(()=>bookingWindow(time,duration,now),(e:any)=>e.status===400);
  }
});
test('capacity, access, forbidden status transition and seating time',()=>{
  assert.throws(()=>sameTableCapacity(6,4),(e:any)=>e.code==='CAPACITY');
  assert.doesNotThrow(()=>sameTableCapacity(4,4));
  assert.throws(()=>requireShiftActor('waiter','one','two'),(e:any)=>e.status===403);
  assert.doesNotThrow(()=>requireShiftActor('manager','one','two'));
  assert.throws(()=>requireReservationAction('SEATED','CANCELLED'),(e:any)=>e.status===409);
  assert.throws(()=>requireSeatDate('2026-11-07T14:00:00Z','2026-11-07T15:30:00Z',now),(e:any)=>e.code==='RESERVATION_NOT_DUE');
  assert.doesNotThrow(()=>requireSeatDate('2026-11-07T12:10:00Z','2026-11-07T13:40:00Z',now));
  assert.equal(can('kitchen','reservations:write'),false);
  assert.equal(can('waiter','reservations:seat'),true);
  assert.equal(can('auditor','shifts:open'),false);
});
