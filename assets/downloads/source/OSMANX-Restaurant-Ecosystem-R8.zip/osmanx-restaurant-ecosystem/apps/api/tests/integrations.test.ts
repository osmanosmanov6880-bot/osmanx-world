import test from 'node:test';
import assert from 'node:assert/strict';
import {randomBytes,randomUUID} from 'node:crypto';
import {decimalRubToCents,normalizeIikoMenu,ProviderError} from '../src/domain/integrations.ts';
import {sealCredentials,openCredentials,encryptionKey} from '../src/infra/integration-crypto.ts';
import {IikoClient} from '../src/infra/iiko.ts';
import {MemoryIntegrationRepository} from './integration-memory.ts';
import {IntegrationRuntime} from '../src/integrations/runtime.ts';

const cred={appId:'app123',clientSecret:'private-value-long',apiKey:'api-secret-value'};
const org=randomUUID(),branch=randomUUID(),otherOrg=randomUUID();
const ctx={userId:randomUUID(),organizationId:org,branchId:branch,role:'owner' as const};
const key=randomBytes(32);
const menu={itemCategories:[{name:'Напитки',items:[{itemId:'id-1',name:'Эспрессо',itemSizes:[{prices:[{organizationId:org,price:149.5}]}]},
  {itemId:'id-2',name:'Капучино',itemSizes:[{prices:[{organizationId:org,price:0},{organizationId:org,price:200}]}]}]}]};

test('R8 AES-256-GCM: круговой проход, изоляция AAD, модификация и отсутствие открытого секрета',()=>{
  const sealed=sealCredentials(key,ctx,'connector-1',cred);
  assert(!sealed.includes(cred.apiKey));assert(!sealed.includes(cred.clientSecret));
  assert.deepEqual(openCredentials(key,ctx,'connector-1',sealed),cred);
  assert.throws(()=>openCredentials(key,{...ctx,organizationId:otherOrg},'connector-1',sealed),(e:any)=>e.code==='SECRET_DECRYPT_FAILED');
  assert.throws(()=>openCredentials(randomBytes(32),ctx,'connector-1',sealed),(e:any)=>e.code==='SECRET_DECRYPT_FAILED');
  assert.throws(()=>openCredentials(key,ctx,'connector-2',sealed),(e:any)=>e.code==='SECRET_DECRYPT_FAILED');
  assert.throws(()=>openCredentials(key,ctx,'connector-1',sealed.slice(0,-4)+'aaaa'),(e:any)=>e.code==='SECRET_DECRYPT_FAILED');
  assert.equal(encryptionKey(key.toString('base64'))?.length,32);
});
test('R8 money: exact cents, never infer zero from missing or ambiguous price',()=>{
  assert.equal(decimalRubToCents(149.5),14950);assert.equal(decimalRubToCents('0.01'),1);
  for(const invalid of [null,undefined,'1.005',1.005,-1,'1e2','10,50',NaN])assert.equal(decimalRubToCents(invalid),null);
  const rows=normalizeIikoMenu(menu,org);
  assert.equal(rows.length,2);assert.equal(rows[0].priceCents,14950);assert.equal(rows[1].priceCents,null);
  assert.throws(()=>normalizeIikoMenu({itemCategories:[{name:'Broken',items:[{itemId:'x',name:'A'},{itemId:'x',name:'B'}]}]},org),
    (e:any)=>e.code==='INVALID_MENU');
  assert.throws(()=>normalizeIikoMenu({categories:[]},org),(e:any)=>e.code==='BAD_RESPONSE');
});
test('R8 official iiko requests: pinned hostname, token, real organization and menu endpoints',async()=>{
  const requests:{path:string;auth:string|null;body:any}[]=[];
  const fakeFetch:typeof fetch=async(url,init)=>{
    const path=new URL(String(url)).pathname;const body=JSON.parse(String(init?.body));
    assert.equal(new URL(String(url)).hostname,'api-ru.iiko.services');assert.equal(init?.method,'POST');
    requests.push({path,auth:new Headers(init?.headers).get('authorization'),body});
    if(path==='/api/v2/access_token')return Response.json({token:'test-jwt-token-secure'});
    if(path==='/api/1/organizations')return Response.json({organizations:[{id:org,name:'Restaurant A'}]});
    if(path==='/api/2/menu')return Response.json({externalMenus:[{id:'main',name:'Основное меню'}]});
    if(path==='/api/menu/v3/by_id')return Response.json(menu);
    throw Error('Unexpected provider path');
  };
  const client=new IikoClient(fakeFetch);
  const verified=await client.verify(cred,org);assert.equal(verified.name,'Restaurant A');
  assert.equal((await client.menus(cred,org))[0].id,'main');
  assert.equal((await client.catalog(cred,org,'main'))[0].priceCents,14950);
  assert(requests.some(r=>r.path==='/api/v2/access_token'&&r.body.clientSecret===cred.clientSecret));
  assert(requests.some(r=>r.path==='/api/menu/v3/by_id'&&r.body.externalMenuId==='main'));
  assert(requests.filter(r=>r.path!=='/api/v2/access_token').every(r=>r.auth==='Bearer test-jwt-token-secure'));
  await assert.rejects(client.verify(cred,otherOrg),(e:any)=>e.code==='ORG_NOT_FOUND');
});
test('R8 provider failures are coded, no raw response or secrets',async()=>{
  for(const [status,code,retryable] of [[401,'AUTH_FAILED',false],[429,'RATE_LIMIT',true],[503,'UNAVAILABLE',true]] as const){
    const client=new IikoClient(async()=>new Response(JSON.stringify({secret:'SHOULD_NOT_BE_EXPOSED'}),{status}));
    await assert.rejects(client.verify(cred,org),(e:any)=>e.code===code&&e.retryable===retryable&&!e.message.includes('SHOULD'));
  }
});
test('R8 official API guards body size before parsing and during streaming',async()=>{
  const over=String(8*1024*1024+1);
  const badHeader=new IikoClient(async()=>new Response('{', {headers:{'content-length':over}}));
  await assert.rejects(badHeader.accessToken(cred),(e:any)=>e.code==='BAD_RESPONSE'&&!e.retryable);
  const streaming=new IikoClient(async()=>new Response(new ReadableStream<Uint8Array>({
    start(controller){controller.enqueue(new Uint8Array(5*1024*1024));controller.enqueue(new Uint8Array(4*1024*1024));controller.close();}
  })));
  await assert.rejects(streaming.accessToken(cred),(e:any)=>e.code==='BAD_RESPONSE');
});
test('R8 worker: durable jobs, deduplication, atomic snapshots, stale lease and explicit import',async()=>{
  const repo=new MemoryIntegrationRepository();let fail=false;
  const runtime=new IntegrationRuntime(repo,{verify:async()=>({id:org,name:'Restaurant A'}),menus:async()=>[{id:'main',name:'Меню'}],
    catalog:async()=>{if(fail)throw new ProviderError('RATE_LIMIT',true);return normalizeIikoMenu(menu,org);}},key.toString('base64'));
  const conn=await runtime.create(ctx,{alias:'Cafe',remoteOrganizationId:org,...cred},'create-test-123');
  assert.equal(conn.state,'UNVERIFIED');
  const same=await runtime.create(ctx,{alias:'Cafe',remoteOrganizationId:org,...cred},'create-test-123');assert.equal(same.id,conn.id);
  await assert.rejects(runtime.create(ctx,{alias:'Other',remoteOrganizationId:org,...cred},'create-test-123'),(e:any)=>e.code==='IDEMPOTENCY_CONFLICT');
  const verified=await runtime.verify(ctx,conn.id,1,'verify-test-123');assert.equal(verified.state,'VERIFIED');
  const job=await repo.enqueue(ctx,conn.id,'main','queue-test-123');
  await assert.rejects(repo.enqueue(ctx,conn.id,'main','queue-test-456'),(e:any)=>e.code==='SYNC_BUSY');
  assert.equal(await runtime.runOnce(),'SUCCEEDED');
  assert.equal(await runtime.runOnce(),'IDLE');
  const items=await repo.catalog(ctx,conn.id);assert.equal(items.length,2);assert.equal(items[1].priceCents,null);
  await assert.rejects(repo.importCatalog(ctx,conn.id,job.id,['id-2'],'invalid-price-1'),(e:any)=>e.code==='MISSING_PRICE');
  const imported=await repo.importCatalog(ctx,conn.id,job.id,['id-1'],'valid-price-123');assert.deepEqual(imported,{imported:1,created:1,updated:0});
  assert.deepEqual(await repo.importCatalog(ctx,conn.id,job.id,['id-1'],'valid-price-123'),imported);
  assert.equal((await repo.catalog(ctx,conn.id))[0].importedMenuItemId!==null,true);
  const newJob=await repo.enqueue(ctx,conn.id,'main','queue-test-789');fail=true;
  assert.equal(await runtime.runOnce(),'RETRY');assert.equal((await repo.jobs(ctx,conn.id)).find(j=>j.id===newJob.id)?.status,'RETRY');
  fail=false;assert.equal(await runtime.runOnce(),'SUCCEEDED');
  await assert.rejects(repo.importCatalog(ctx,conn.id,job.id,['id-1'],'stale-run-123'),(e:any)=>e.code==='STALE_CATALOG');
  const updated=await repo.importCatalog(ctx,conn.id,newJob.id,['id-1'],'reimport-123');assert.equal(updated.updated,1);
  await assert.rejects(repo.catalog({...ctx,organizationId:otherOrg},conn.id),(e:any)=>e.status===404);
  const rotated=await runtime.rotate(ctx,conn.id,verified.revision,cred,'rotate-test-123');assert.equal(rotated.state,'UNVERIFIED');
  assert.equal((await repo.catalog(ctx,conn.id)).length,0);
});
