import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {runMigrations} from '../src/migrate.ts';
import {createPostgresStore} from '../src/infra/postgres.ts';

const available=!!process.env.DATABASE_URL;
test('R2 PostgreSQL: overlapping reservations, seating, kitchen and staff-shift concurrency',{
  skip:!available?'DATABASE_URL is not configured':false
},async()=>{
  await runMigrations();
  const store=await createPostgresStore(process.env.DATABASE_URL!);
  try{
    const uid=randomUUID();
    const a=await store.bootstrap({email:`r2-${uid}@example.test`,displayName:'Владелец',passwordHash:'test-only',organizationName:'Chain R2',branchName:'Branch R2'});
    const b=await store.bootstrap({email:`r2-other-${uid}@example.test`,displayName:'Другой',passwordHash:'test-only',organizationName:'Outside',branchName:'Outside'});
    const ctx={userId:a.user.id,organizationId:a.organizationId,branchId:a.branchId,role:'owner' as const};
    const outside={userId:b.user.id,organizationId:b.organizationId,branchId:b.branchId,role:'owner' as const};
    const table=await store.addTable(ctx,'A-001',4);
    const start=new Date(Date.now()+10*60_000).toISOString();
    const end=new Date(Date.parse(start)+90*60_000).toISOString();
    const body={tableId:table.id,guestName:'Гость',partySize:3,startsAt:start,endsAt:end};
    await assert.rejects(store.createReservation(ctx,{...body,partySize:5},`capacity-${uid}`),(e:any)=>e.code==='CAPACITY');
    await assert.rejects(store.createReservation(outside,body,`foreign-table-${uid}`),(e:any)=>e.status===404);
    const race=await Promise.allSettled([
      store.createReservation(ctx,body,`reservation-1-${uid}`),
      store.createReservation(ctx,{...body,guestName:'Второй гость'},`reservation-2-${uid}`)
    ]);
    assert.equal(race.filter(v=>v.status==='fulfilled').length,1);
    const failure=race.find(v=>v.status==='rejected') as PromiseRejectedResult;
    assert.equal(failure.reason.code,'RESERVATION_CONFLICT');
    const confirmed=(race.find(v=>v.status==='fulfilled') as PromiseFulfilledResult<Awaited<ReturnType<typeof store.createReservation>>>).value;
    assert.equal((await store.floor(ctx))[0].state,'RESERVED');
    await assert.rejects(store.createOrder(ctx,table.id,`direct-${uid}`),(e:any)=>e.code==='TABLE_RESERVED');
    const seated=await Promise.allSettled([
      store.seatReservation(ctx,confirmed.id,1,`seat-1-${uid}`),
      store.seatReservation(ctx,confirmed.id,1,`seat-2-${uid}`)
    ]);
    assert.equal(seated.filter(v=>v.status==='fulfilled').length,1);
    assert.equal(seated.filter(v=>v.status==='rejected').length,1);
    const {order,reservation}=(seated.find(v=>v.status==='fulfilled') as PromiseFulfilledResult<Awaited<ReturnType<typeof store.seatReservation>>>).value;
    assert.equal(reservation.status,'SEATED');assert.equal(reservation.orderId,order.id);
    assert.equal((await store.floor(ctx))[0].state,'OCCUPIED');
    assert.equal((await store.reservations(ctx)).find(r=>r.id===reservation.id)?.orderId,order.id);
    const menu=await store.addMenuItem(ctx,'Стейк',289900);
    let updated=await store.addOrderItem(ctx,order.id,menu.id,2,1,`item-${uid}`);
    assert.equal(updated.totalCents,579800);
    for(const [to,expectedRevision] of [['SENT',2],['PREPARING',3],['READY',4],['COMPLETED',5]] as const){
      updated=await store.changeOrderStatus(ctx,order.id,to,expectedRevision,`status-${to}-${uid}`);
      if(to==='SENT')assert.ok((await store.kitchen(ctx))[0].sentAt);
      if(to==='PREPARING')assert.ok((await store.kitchen(ctx))[0].preparingAt);
      if(to==='READY')assert.ok((await store.kitchen(ctx))[0].readyAt);
    }
    assert.equal((await store.kitchen(ctx)).length,0);
    assert.equal((await store.reservations(ctx)).find(r=>r.id===reservation.id)?.status,'COMPLETED');
    assert.equal((await store.dashboard(ctx)).revenueCents,579800);
    const email=`r2-staff-${uid}@example.test`;
    const tokenHash=randomUUID().replaceAll('-','').padEnd(64,'0');
    await store.createInvitation(a.organizationId,a.user.id,email,'waiter',[a.branchId],tokenHash);
    const staff=await store.acceptInvitation(tokenHash,email,'Официант','test-only');
    const waiterCtx={...ctx,userId:staff.id,role:'waiter' as const};
    assert.equal((await store.staff(waiterCtx)).length,1);
    assert.ok((await store.staff(ctx)).some(w=>w.id===staff.id));
    const simultaneous=await Promise.allSettled([
      store.openShift(waiterCtx,staff.id,'Начало',`shift1-${uid}`),
      store.openShift(waiterCtx,staff.id,'Начало',`shift2-${uid}`)
    ]);
    assert.equal(simultaneous.filter(x=>x.status==='fulfilled').length,1);
    const shift=(simultaneous.find(x=>x.status==='fulfilled') as PromiseFulfilledResult<Awaited<ReturnType<typeof store.openShift>>>).value;
    assert.equal(shift.status,'OPEN');
    await assert.rejects(store.closeShift(waiterCtx,shift.id,2,'Слишком старая версия',`close-stale-${uid}`),(e:any)=>e.code==='STALE_VERSION');
    const closed=await store.closeShift(ctx,shift.id,1,'Сдана касса',`close-${uid}`);
    assert.equal(closed.status,'CLOSED');assert.ok(closed.closedAt);
    const replay=await store.closeShift(ctx,shift.id,1,'Сдана касса',`close-${uid}`);
    assert.equal(closed.id,replay.id);
    assert.equal((await store.shifts(waiterCtx)).length,1);
    assert.equal((await store.shifts(outside)).length,0);
    await assert.rejects(store.openShift(waiterCtx,b.user.id,'',`foreign-user-${uid}`),(e:any)=>e.status===403||e.status===404);
  }finally{await store.close();}
});
