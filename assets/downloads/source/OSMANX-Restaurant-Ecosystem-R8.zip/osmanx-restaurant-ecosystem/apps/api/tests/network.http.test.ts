import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import type {AddressInfo} from 'node:net';
import {createApiServer} from '../src/http.ts';
import {FakeStore} from './fake-store.ts';
const cfg={origin:'http://localhost:3000',sessionSecret:'r'.repeat(64),secureCookies:false};

test('R7 HTTP: стандарты, аудиты, действия, версии, RBAC и сеть',async()=>{
  const store=new FakeStore();const server=createApiServer(store,cfg);
  await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));
  const host=`http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  function client(){let cookie='',csrf='';return {
    async call(path:string,method='GET',body?:unknown,key?:string){const headers:Record<string,string>={};
      if(cookie)headers.cookie=cookie;
      if(body!==undefined)headers['content-type']='application/json';
      if(method!=='GET'){headers.origin=cfg.origin;if(csrf)headers['x-osmanx-csrf']=csrf;}
      if(key)headers['idempotency-key']=key;
      const r=await fetch(host+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});
      if(r.headers.get('set-cookie'))cookie=r.headers.get('set-cookie')!.split(';')[0];
      return {status:r.status,body:await r.json() as any};
    },
    async refresh(){csrf=(await this.call('/api/v1/me')).body.csrfToken;}
  };}
  try{
    const owner=client();const outsider=client();const auditor=client();
    const registered=await owner.call('/api/v1/auth/register','POST',{email:`r7-${randomUUID()}@test.example`,password:'SafePassR7-123456',
      displayName:'Owner',organizationName:'Restaurant Group',branchName:'Moscow'});assert.equal(registered.status,201);
    await owner.refresh();
    const org=registered.body.organizationId;const first=registered.body.branchId;const root=`/api/v1/organizations/${org}`;
    const added=await owner.call(`${root}/branches`,'POST',{name:'Kazan',timezone:'Europe/Moscow'});assert.equal(added.status,201);
    const second=added.body.branch.id;
    const standardInput={title:'Сервисная дисциплина',description:'Сеть ресторанов',criteria:[
      {title:'Соблюдение санитарных норм',weight:5,critical:true},{title:'Время подачи',weight:3,critical:false}
    ]};
    const created=await owner.call(`${root}/standards`,'POST',standardInput,'r7-standard-create');assert.equal(created.status,201);
    const repeated=await owner.call(`${root}/standards`,'POST',standardInput,'r7-standard-create');assert.equal(repeated.body.standard.id,created.body.standard.id);
    assert.equal((await owner.call(`${root}/standards`,'POST',{...standardInput,title:'Другое'},'r7-standard-create')).status,409);
    const id=created.body.standard.id;
    const answers=[{criterionId:'c-1',passed:false,note:'Санитарные нарушения обнаружены'},{criterionId:'c-2',passed:true,note:''}];
    const base=`${root}/branches/${first}`;
    const audit=await owner.call(`${base}/audits`,'POST',{standardId:id,expectedStandardRevision:1,answers},'r7-audit-first');
    assert.equal(audit.status,201);assert.equal(audit.body.audit.scoreBps,3750);assert.equal(audit.body.audit.criticalFailures,1);
    assert.equal((await owner.call(`${base}/audits`,'POST',{standardId:id,expectedStandardRevision:1,answers},'r7-audit-first')).body.audit.id,audit.body.audit.id);
    const independentRepeat=await owner.call(`${base}/audits`,'POST',{standardId:id,expectedStandardRevision:1,answers},'r7-independent-audit');
    assert.equal(independentRepeat.status,201);assert.notEqual(independentRepeat.body.audit.id,audit.body.audit.id);
    const actions=await owner.call(`${base}/corrective-actions`);assert.equal(actions.body.actions.length,1);
    assert.equal(actions.body.actions[0].standardRevision,1);
    const actionId=actions.body.actions[0].id;
    const fail=await owner.call(`${base}/corrective-actions/${actionId}/status`,'POST',{expectedRevision:1,status:'RESOLVED',resolution:'нет'},'r7-action-invalid');assert.equal(fail.status,400);
    const progress=await owner.call(`${base}/corrective-actions/${actionId}/status`,'POST',{expectedRevision:1,status:'IN_PROGRESS'},'r7-action-progress');assert.equal(progress.status,200);
    assert.equal((await owner.call(`${base}/corrective-actions/${actionId}/status`,'POST',{expectedRevision:1,status:'RESOLVED',resolution:'Исправлено и проверено'},'r7-action-stale')).status,409);
    const complete=await owner.call(`${base}/corrective-actions/${actionId}/status`,'POST',{expectedRevision:2,status:'RESOLVED',resolution:'Исправлено и проверено'},'r7-action-resolve');assert.equal(complete.status,200);
    const before=await owner.call(`${root}/network/quality?standardId=${id}`);assert.equal(before.body.quality.comparable,false);
    assert.equal(before.body.quality.branches[0].openActions,0);
    const audit2=await owner.call(`${root}/branches/${second}/audits`,'POST',{standardId:id,expectedStandardRevision:1,
      answers:[{criterionId:'c-1',passed:true,note:''},{criterionId:'c-2',passed:true,note:''}]},'r7-audit-second');assert.equal(audit2.status,201);
    const comparable=await owner.call(`${root}/network/quality?standardId=${id}`);assert.equal(comparable.body.quality.comparable,true);
    assert.equal(comparable.body.quality.branches.length,2);
    const updated=await owner.call(`${root}/standards/${id}`,'PATCH',{...standardInput,expectedRevision:1,active:true},'r7-standard-revision');
    assert.equal(updated.status,200);assert.equal(updated.body.standard.revision,2);
    const old=await owner.call(`${base}/audits?standardId=${id}`);assert.equal(old.body.audits[0].standardRevision,1);
    const outdated=await owner.call(`${root}/network/quality?standardId=${id}`);assert.equal(outdated.body.quality.comparable,false);
    assert(outdated.body.quality.branches.every((b:any)=>b.scoreBps===null&&b.outdated));
    assert.equal((await owner.call(`${base}/audits`,'POST',{standardId:id,expectedStandardRevision:1,answers},'r7-stale-audit')).status,409);
    const external=await outsider.call('/api/v1/auth/register','POST',{email:`other-${randomUUID()}@test.example`,password:'SafePassR7-123456',
      displayName:'Other',organizationName:'External',branchName:'Other'});assert.equal(external.status,201);await outsider.refresh();
    assert.equal((await outsider.call(`${root}/standards`)).status,404);
    assert.equal((await outsider.call(`${base}/audits`)).status,404);
    const invitation=await owner.call(`${root}/invitations`,'POST',{email:`audit-${randomUUID()}@test.example`,role:'auditor',branchIds:[first]});
    assert.equal(invitation.status,201);
    const token=new URL(invitation.body.invitation.url).searchParams.get('token');
    const joined=await auditor.call('/api/v1/auth/accept-invite','POST',{token,email:invitation.body.invitation.email,
      displayName:'Independent auditor',password:'SafePassR7-123456'});assert.equal(joined.status,201);await auditor.refresh();
    assert.equal((await auditor.call(`${root}/standards`)).status,200);
    assert.equal((await auditor.call(`${base}/audits`)).status,200);
    assert.equal((await auditor.call(`${root}/branches/${second}/audits`)).status,404);
    assert.equal((await auditor.call(`${base}/audits`,'POST',{standardId:id,expectedStandardRevision:2,answers},'r7-auditor-denied')).status,403);
    assert.equal((await auditor.call(`${root}/standards`,'POST',standardInput,'r7-auditor-std')).status,403);
    assert.equal((await auditor.call(`${root}/network/quality?standardId=${id}`)).body.quality.branches.length,1);
  }finally{await new Promise<void>(resolve=>server.close(()=>resolve()));}
});
