import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {runMigrations} from '../src/migrate.ts';
import {createPostgresStore} from '../src/infra/postgres.ts';

const skip=!process.env.DATABASE_URL?'DATABASE_URL not configured':false;
test('R7 PostgreSQL: network standards, versioned audit snapshots, corrective actions and tenant isolation',{skip},async()=>{
  await runMigrations();const store=await createPostgresStore(process.env.DATABASE_URL!);
  try{
    const suffix=randomUUID();
    const a=await store.bootstrap({email:`r7-a-${suffix}@example.test`,displayName:'A',passwordHash:'only-for-tests',organizationName:'A Group',branchName:'A1'});
    const b=await store.bootstrap({email:`r7-b-${suffix}@example.test`,displayName:'B',passwordHash:'only-for-tests',organizationName:'B Group',branchName:'B1'});
    const ctx={userId:a.user.id,organizationId:a.organizationId,branchId:a.branchId,role:'owner' as const};
    const foreign={userId:b.user.id,organizationId:b.organizationId,branchId:b.branchId,role:'owner' as const};
    const second=await store.createBranch(a.organizationId,a.user.id,'A2','Europe/Moscow');
    const secondCtx={...ctx,branchId:second.id};
    const standardInput={title:'Кухонный стандарт',description:'Единые требования',criteria:[
      {title:'Температура склада',weight:4,critical:true},{title:'Подача заказа вовремя',weight:2,critical:false}]};
    const key=`standard-${suffix}`;
    const s=await store.createNetworkStandard(ctx,standardInput,key);
    assert.equal(s.revision,1);assert.equal(s.criteria.length,2);
    assert.equal((await store.createNetworkStandard(ctx,standardInput,key)).id,s.id);
    await assert.rejects(store.createNetworkStandard(ctx,{...standardInput,title:'Другой стандарт'},key),(e:any)=>e.code==='IDEMPOTENCY_CONFLICT');
    assert.equal((await store.networkStandards(foreign.organizationId)).length,0);
    const answers=[{criterionId:'c-1',passed:false,note:'Нарушен журнал контроля температуры'},{criterionId:'c-2',passed:true,note:''}];
    const audit=await store.submitBranchAudit(ctx,s.id,1,answers,`audit-${suffix}`);
    assert.equal(audit.scoreBps,3333);assert.equal(audit.failedCount,1);
    assert.equal((await store.submitBranchAudit(ctx,s.id,1,answers,`audit-${suffix}`)).id,audit.id);
    assert.equal((await store.branchAudits(foreign,s.id)).length,0);
    assert.equal((await store.branchAudits(secondCtx,s.id)).length,0);
    assert.equal((await store.branchOpenActionCount(ctx)),1);
    const independent=await store.submitBranchAudit(ctx,s.id,1,answers,`audit-second-${suffix}`);
    assert.notEqual(independent.id,audit.id);
    assert.equal((await store.branchOpenActionCount(ctx)),1); // new audit, same unresolved finding.
    const actions=await store.branchCorrectiveActions(ctx);assert.equal(actions.length,1);
    const id=actions[0].id;
    await assert.rejects(store.updateCorrectiveAction(secondCtx,id,1,'IN_PROGRESS',null,`foreign-branch-${suffix}`),(e:any)=>e.status===404);
    await assert.rejects(store.updateCorrectiveAction(foreign,id,1,'IN_PROGRESS',null,`foreign-org-${suffix}`),(e:any)=>e.status===404);
    const work=await store.updateCorrectiveAction(ctx,id,1,'IN_PROGRESS',null,`action-work-${suffix}`);assert.equal(work.revision,2);
    await assert.rejects(store.updateCorrectiveAction(ctx,id,1,'RESOLVED','Устранено и перепроверено',`action-stale-${suffix}`),(e:any)=>e.code==='VERSION_CONFLICT');
    const resolved=await store.updateCorrectiveAction(ctx,id,2,'RESOLVED','Норма хранения восстановлена',`action-resolve-${suffix}`);
    assert.equal(resolved.status,'RESOLVED');assert.equal((await store.branchOpenActionCount(ctx)),0);
    // Concurrent independent audits must not create duplicate OPEN actions for one finding.
    await Promise.all([
      store.submitBranchAudit(ctx,s.id,1,answers,`concurrent-a-${suffix}`),
      store.submitBranchAudit(ctx,s.id,1,answers,`concurrent-b-${suffix}`)
    ]);
    assert.equal((await store.branchOpenActionCount(ctx)),1);
    const revision=await store.updateNetworkStandard(ctx,s.id,1,standardInput,true,`standard-revise-${suffix}`);
    assert.equal(revision.revision,2);
    await assert.rejects(store.submitBranchAudit(ctx,s.id,1,answers,`audit-stale-${suffix}`),(e:any)=>e.code==='VERSION_CONFLICT');
    assert.equal((await store.branchAudits(ctx,s.id))[0].standardRevision,1);
    const auditSecond=await store.submitBranchAudit(secondCtx,s.id,2,[{criterionId:'c-1',passed:true,note:''},{criterionId:'c-2',passed:true,note:''}],`audit2-${suffix}`);
    assert.equal(auditSecond.scoreBps,10000);
  }finally{await store.close();}
});
