import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {runMigrations} from '../src/migrate.ts';
import {createPostgresStore} from '../src/infra/postgres.ts';

const available=!!process.env.DATABASE_URL;
test('PostgreSQL 16: миграции, реальная изоляция, транзакции и идемпотентность',{skip:!available?'DATABASE_URL is not configured':false},async()=>{
  const migrated=await runMigrations();assert.ok(migrated>=0);
  const store=await createPostgresStore(process.env.DATABASE_URL!);
  try{
    assert.equal(await store.ready(),true);
    const suffix=randomUUID();
    const a=await store.bootstrap({email:`owner-${suffix}@example.test`,displayName:'Владелец',passwordHash:'test-only-hash',organizationName:'Сеть A',branchName:'A1'});
    const b=await store.bootstrap({email:`other-${suffix}@example.test`,displayName:'Другой',passwordHash:'test-only-hash',organizationName:'Сеть B',branchName:'B1'});
    const aa={userId:a.user.id,organizationId:a.organizationId,branchId:a.branchId,role:'owner' as const};
    const bb={userId:b.user.id,organizationId:b.organizationId,branchId:b.branchId,role:'owner' as const};
    const aMember=await store.memberships(a.user.id);
    assert.equal(aMember[0].role,'owner');assert.deepEqual(aMember[0].branches.map(v=>v.id),[a.branchId]);
    assert.equal((await store.memberships(b.user.id))[0].organizationId,b.organizationId);
    const item=await store.addMenuItem(aa,'Капучино',39900);
    const seat=await store.addTable(aa,'Стол 04',4);
    const order=await store.createOrder(aa,seat.id,`order-${suffix}`);
    const duplicate=await store.createOrder(aa,seat.id,`order-${suffix}`);
    assert.equal(order.id,duplicate.id);
    await assert.rejects(store.createOrder(aa,seat.id,`another-${suffix}`),(e:any)=>e.status===409);
    await assert.rejects(store.createOrder(aa,b.branchId,`cross-${suffix}`),(e:any)=>e.status===404);
    assert.equal((await store.menu(bb)).length,0);
    const appended=await store.addOrderItem(aa,order.id,item.id,2,1,`line-${suffix}`);
    assert.equal(appended.totalCents,79800);
    const repeated=await store.addOrderItem(aa,order.id,item.id,2,1,`line-${suffix}`);
    assert.equal(repeated.items.length,1);
    const patched=await store.updateMenuItem(aa,item.id,1,{priceCents:49900});
    assert.equal(patched.revision,2);
    assert.equal((await store.orders(aa))[0].items[0].unitPriceCents,39900);
    const writes=await Promise.allSettled([
      store.addOrderItem(aa,order.id,item.id,1,2,`race-one-${suffix}`),
      store.addOrderItem(aa,order.id,item.id,1,2,`race-two-${suffix}`)
    ]);
    assert.equal(writes.filter(r=>r.status==='fulfilled').length,1);
    assert.equal(writes.filter(r=>r.status==='rejected').length,1);
    assert.equal((await store.orders(aa))[0].revision,3);
    for (const [status,revision] of [['SENT',3],['PREPARING',4],['READY',5],['COMPLETED',6]] as const){
      await store.changeOrderStatus(aa,order.id,status,revision,`status-${status}-${suffix}`);
    }
    const completed=await store.dashboard(aa);
    assert.equal(completed.completedOrders,1);assert.equal(completed.revenueCents,129700);
    const tokenHash=randomUUID().replaceAll('-','').padEnd(64,'a');
    await store.createInvitation(a.organizationId,a.user.id,`waiter-${suffix}@example.test`,'waiter',[a.branchId],tokenHash);
    const hired=await store.acceptInvitation(tokenHash,`waiter-${suffix}@example.test`,'Официант','test-only-hash');
    assert.deepEqual((await store.memberships(hired.id))[0].branches.map(v=>v.id),[a.branchId]);
    await assert.rejects(store.acceptInvitation(tokenHash,`waiter-${suffix}@example.test`,'Официант','test-only-hash'),(e:any)=>e.status===410);
    const extra=await store.createBranch(a.organizationId,a.user.id,'A2','Europe/Moscow');
    assert.ok((await store.memberships(a.user.id))[0].branches.some(v=>v.id===extra.id));
    assert.equal((await store.memberships(hired.id))[0].branches.some(v=>v.id===extra.id),false);
    assert.equal((await store.orders(bb)).length,0);
  } finally {await store.close();}
});
