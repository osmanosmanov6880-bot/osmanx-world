import {before,after,test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import type {AddressInfo} from 'node:net';
import type {Server} from 'node:http';
import {createApiServer} from '../src/http.ts';
import {FakeStore} from './fake-store.ts';

const store=new FakeStore(),config={origin:'http://localhost:3000',sessionSecret:'f'.repeat(64),secureCookies:false};
let server:Server,base='',cookie='',csrf='',org='',branch='',branchB='',expenseId='',secondOrg='',secondBranch='';
const period=new Date().toISOString().slice(0,7);
const date=new Date().toISOString().slice(0,10);
const orgBase=()=>`/api/v1/organizations/${org}`;
const root=(branchId=branch)=>`${orgBase()}/branches/${branchId}`;
async function request(path:string,method='GET',body?:unknown,auth:{cookie?:string;csrf?:string;key?:string}={}){
  const headers:Record<string,string>={};
  if(body!==undefined)headers['content-type']='application/json';
  if(auth.cookie||cookie)headers.cookie=auth.cookie||cookie;
  if(method!=='GET'){headers.origin=config.origin;if(auth.csrf||csrf)headers['x-osmanx-csrf']=auth.csrf||csrf;}
  if(auth.key)headers['idempotency-key']=auth.key;
  const res=await fetch(`${base}${path}`,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});
  return {status:res.status,data:await res.json(),cookie:res.headers.get('set-cookie')?.split(';')[0]||''};
}
async function createAccount(email:string){
  return request('/api/v1/auth/register','POST',{email,password:'FinanceSecurePassword-123',displayName:'Owner',organizationName:'Finance restaurants',branchName:'A'});
}
before(async()=>{
  server=createApiServer(store,config);
  await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));
  base=`http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  const owner=await createAccount(`owner-r4-${randomUUID()}@example.test`);
  assert.equal(owner.status,201);cookie=owner.cookie;org=owner.data.organizationId;branch=owner.data.branchId;
  csrf=(await request('/api/v1/me')).data.csrfToken;
  const b=await request(`${orgBase()}/branches`,'POST',{name:'B',timezone:'Europe/Moscow'});
  assert.equal(b.status,201);branchB=b.data.branch.id;
});
after(async()=>{await new Promise<void>(resolve=>server.close(()=>resolve()));});

test('R4 HTTP: finance expenses, idempotency, journal and reversal',async()=>{
  const invalid=await request(`${root()}/finance/expenses`,'POST',{category:'RENT',description:'Аренда',amountCents:100,occurredOn:'2026-02-30'},{key:'finance-invalid-date'});
  assert.equal(invalid.status,400);assert.equal(invalid.data.error.code,'FINANCE_DATE');
  const noKey=await request(`${root()}/finance/expenses`,'POST',{category:'RENT',description:'Аренда',amountCents:4000,occurredOn:date});
  assert.equal(noKey.status,400);assert.equal(noKey.data.error.code,'IDEMPOTENCY_KEY');
  const body={category:'RENT',description:'Аренда месяца',amountCents:4000,occurredOn:date};
  const created=await request(`${root()}/finance/expenses`,'POST',body,{key:'finance-expense-1'});
  assert.equal(created.status,201);expenseId=created.data.expense.id;
  assert.equal(created.data.expense.status,'POSTED');
  assert.equal((await request(`${root()}/finance/expenses`,'POST',body,{key:'finance-expense-1'})).data.expense.id,expenseId);
  const conflict=await request(`${root()}/finance/expenses`,'POST',{...body,amountCents:5000},{key:'finance-expense-1'});
  assert.equal(conflict.status,409);assert.equal(conflict.data.error.code,'IDEMPOTENCY_CONFLICT');
  const summary=(await request(`${root()}/finance/report?period=${period}`)).data.report;
  assert.equal(summary.expensesCents,4000);assert.equal(summary.operatingResultCents,-4000);
  assert.equal((await request(`${root()}/finance/ledger?period=${period}`)).data.entries[0].signedAmountCents,-4000);
  const invalidRevision=await request(`${root()}/finance/expenses/${expenseId}/void`,'POST',{expectedRevision:2,reason:'Неверный документ'},{key:'finance-void-stale'});
  assert.equal(invalidRevision.status,409);
  const voided=await request(`${root()}/finance/expenses/${expenseId}/void`,'POST',{expectedRevision:1,reason:'Дублированный документ'},{key:'finance-void-ok-1'});
  assert.equal(voided.status,200);assert.equal(voided.data.expense.status,'VOIDED');assert.equal(voided.data.expense.revision,2);
  assert.equal((await request(`${root()}/finance/expenses/${expenseId}/void`,'POST',{expectedRevision:1,reason:'Дублированный документ'},{key:'finance-void-ok-1'})).data.expense.status,'VOIDED');
  const again=await request(`${root()}/finance/expenses/${expenseId}/void`,'POST',{expectedRevision:2,reason:'Повтор'},{key:'finance-void-again'});
  assert.equal(again.status,409);
  assert.equal((await request(`${root()}/finance/report?period=${period}`)).data.report.expensesCents,0);
  assert.equal((await request(`${root()}/finance/expenses?period=${period}`)).data.expenses[0].status,'VOIDED');
});

test('R4 HTTP: budgets, versioning and plan/fact reporting',async()=>{
  const create=await request(`${root()}/finance/budgets/REVENUE`,'PUT',{period,amountCents:100000,expectedRevision:0},{key:'budget-r4-new-1'});
  assert.equal(create.status,200);assert.equal(create.data.budget.revision,1);
  const stale=await request(`${root()}/finance/budgets/REVENUE`,'PUT',{period,amountCents:200000,expectedRevision:0},{key:'budget-r4-stale'});
  assert.equal(stale.status,409);
  const next=await request(`${root()}/finance/budgets/REVENUE`,'PUT',{period,amountCents:150000,expectedRevision:1},{key:'budget-r4-new-2'});
  assert.equal(next.status,200);assert.equal(next.data.budget.revision,2);
  assert.equal((await request(`${root()}/finance/budgets/REVENUE`,'PUT',{period,amountCents:150000,expectedRevision:1},{key:'budget-r4-new-2'})).data.budget.revision,2);
  const report=(await request(`${root()}/finance/report?period=${period}`)).data.report;
  assert.equal(report.planFact.find((x:any)=>x.category==='REVENUE').plannedCents,150000);
  assert.equal(report.planFact.find((x:any)=>x.category==='REVENUE').varianceCents,-150000);
  const invalid=await request(`${root()}/finance/budgets/CRYPTO`,'PUT',{period,amountCents:1,expectedRevision:0},{key:'budget-r4-invalid'});
  assert.equal(invalid.status,400);
});

test('R4 HTTP: network total includes only authorized branches, excludes other organizations',async()=>{
  const record=await request(`${root(branchB)}/finance/expenses`,'POST',{category:'PAYROLL',description:'Оплата смен',occurredOn:date,amountCents:9000},{key:'finance-branch-b'});
  assert.equal(record.status,201);
  const overview=await request(`${orgBase()}/finance/overview?period=${period}`);
  assert.equal(overview.status,200);
  assert.equal(overview.data.overview.branches.length,2);
  assert.equal(overview.data.overview.totals.expensesCents,9000);
  const foreign=await createAccount(`other-r4-${randomUUID()}@example.test`);
  assert.equal(foreign.status,201);secondOrg=foreign.data.organizationId;secondBranch=foreign.data.branchId;
  const forbidden=await request(`/api/v1/organizations/${secondOrg}/branches/${secondBranch}/finance/report?period=${period}`);
  assert.equal(forbidden.status,404);
  const missing=await request(`${root(secondBranch)}/finance/report?period=${period}`);
  assert.equal(missing.status,404);
});

test('R4 HTTP: an auditor reads financials but cannot change expenses or budgets',async()=>{
  const invite=await request(`${orgBase()}/invitations`,'POST',{email:'r4-auditor@example.test',role:'auditor',branchIds:[branch]});
  assert.equal(invite.status,201);
  const token=new URL(invite.data.invitation.url).searchParams.get('token');
  const person=await request('/api/v1/auth/accept-invite','POST',{token,email:'r4-auditor@example.test',displayName:'Auditor',password:'FinanceSecurePassword-123'});
  assert.equal(person.status,201);
  const auditorCookie=person.cookie;
  const auditorCsrf=(await request('/api/v1/me','GET',undefined,{cookie:auditorCookie})).data.csrfToken;
  const opt={cookie:auditorCookie,csrf:auditorCsrf};
  assert.equal((await request(`${root()}/finance/report?period=${period}`,'GET',undefined,opt)).status,200);
  assert.equal((await request(`${root(branchB)}/finance/report?period=${period}`,'GET',undefined,opt)).status,404);
  const ownOverview=await request(`${orgBase()}/finance/overview?period=${period}`,'GET',undefined,opt);
  assert.equal(ownOverview.data.overview.branches.length,1);
  assert.equal(ownOverview.data.overview.totals.expensesCents,0);
  const write=await request(`${root()}/finance/expenses`,'POST',{category:'OTHER',description:'Запрещено',amountCents:100,occurredOn:date},{...opt,key:'audit-exp-r4'});
  assert.equal(write.status,403);
  const budget=await request(`${root()}/finance/budgets/PAYROLL`,'PUT',{period,amountCents:1200,expectedRevision:0},{...opt,key:'audit-plan-r4'});
  assert.equal(budget.status,403);
  const reversal=await request(`${root()}/finance/expenses/${expenseId}/void`,'POST',{expectedRevision:2,reason:'Запрещено'},{...opt,key:'audit-void-r4'});
  assert.equal(reversal.status,403);
});

test('R4 HTTP: incomplete historical order blocks fabricated profitability',async()=>{
  const item=await request(`${root()}/menu`,'POST',{name:'Неописанная услуга',priceCents:10000});
  const ord=await request(`${root()}/orders`,'POST',{tableId:null},{key:'finance-order-r4-1'});
  const id=ord.data.order.id;
  let r=await request(`${root()}/orders/${id}/items`,'POST',{menuItemId:item.data.item.id,quantity:1,expectedRevision:1},{key:'finance-order-r4-2'});
  assert.equal(r.status,200);
  for(const [status,revision,key] of [['SENT',2,'fin-status-1'],['PREPARING',3,'fin-status-2'],['READY',4,'fin-status-3'],['COMPLETED',5,'fin-status-4']] as const){
    r=await request(`${root()}/orders/${id}/status`,'POST',{status,expectedRevision:revision},{key});
    assert.equal(r.status,200);
  }
  const report=(await request(`${root()}/finance/report?period=${period}`)).data.report;
  assert.equal(report.revenueCents,10000);assert.equal(report.uncostedOrders,1);
  assert.equal(report.grossProfitCents,null);assert.equal(report.operatingResultCents,null);
  assert.equal(report.planFact.find((x:any)=>x.category==='FOOD_COST').actualCents,null);
});
