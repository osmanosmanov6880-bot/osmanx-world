import test from 'node:test';
import assert from 'node:assert/strict';
import {auditAnswers,standardInput,networkQuality,actionTransition,withCriterionIds} from '../src/domain/network.ts';
import {can} from '../src/domain/rules.ts';

test('R7: версии стандарта и баллы аудита вычисляются из обязательных ответов',()=>{
  const input=standardInput({title:' Контроль кухни ',description:'Единые правила',criteria:[
    {title:'Санитария',weight:5,critical:true},{title:'Скорость подачи',weight:3,critical:false},{title:'Хранение',weight:2,critical:true}
  ]});
  const criteria=withCriterionIds(input.criteria);
  const scored=auditAnswers([
    {criterionId:'c-3',passed:true,note:''},{criterionId:'c-1',passed:false,note:'Есть нарушение хранения журнала'},{criterionId:'c-2',passed:true,note:''}
  ],criteria);
  assert.equal(scored.scoreBps,5000);assert.equal(scored.failedCount,1);assert.equal(scored.criticalFailures,1);
  assert.deepEqual(scored.answers.map(a=>a.criterionId),['c-1','c-2','c-3']);
});
test('R7: неполные, повторные, недостоверные ответы отклоняются',()=>{
  const criteria=withCriterionIds([{title:'Проверка',weight:1,critical:true}]);
  assert.throws(()=>auditAnswers([],criteria),{code:'AUDIT_INCOMPLETE'});
  assert.throws(()=>auditAnswers([{criterionId:'other',passed:true,note:''}],criteria),{code:'AUDIT_CRITERION'});
  assert.throws(()=>auditAnswers([{criterionId:'c-1',passed:false,note:'плохо'}],criteria),{code:'AUDIT_EVIDENCE'});
  assert.throws(()=>auditAnswers([{criterionId:'c-1',passed:'true',note:''}],criteria),{code:'VALIDATION'});
  assert.throws(()=>standardInput({title:'X',description:'',criteria:[{title:'A',weight:1.5,critical:true}]}),{code:'VALIDATION'});
});
test('R7: закрытие корректирующего действия требует подтверждённого результата',()=>{
  assert.doesNotThrow(()=>actionTransition('OPEN','IN_PROGRESS',null));
  assert.doesNotThrow(()=>actionTransition('IN_PROGRESS','RESOLVED','Устранены замечания')); 
  assert.throws(()=>actionTransition('OPEN','RESOLVED','готово'),{code:'ACTION_RESOLUTION'});
  assert.throws(()=>actionTransition('RESOLVED','IN_PROGRESS',null),{code:'ACTION_TRANSITION'});
});
test('R7: сеть не рейтингует филиалы по разным версиям или отсутствующим аудитам',()=>{
  const now=new Date().toISOString();
  const standard={id:'standard-id',title:'Кухня',description:'',revision:2,active:true,criteria:[],createdAt:now,updatedAt:now};
  const audit=(revision:number,scoreBps:number)=>({id:'audit',branchId:'branch',standardId:'standard-id',standardTitle:'Кухня',
    standardRevision:revision,performedAt:now,performedBy:'user',scoreBps,criticalFailures:0,failedCount:0,answers:[]});
  const r1=networkQuality(standard,[{id:'A',name:'А',latest:audit(2,8000),openActions:1},{id:'B',name:'Б',latest:audit(1,10000),openActions:0}]);
  assert.equal(r1.comparable,false);assert.equal(r1.branches[1].scoreBps,null);assert.equal(r1.branches[1].outdated,true);
  const r2=networkQuality(standard,[{id:'A',name:'А',latest:audit(2,8000),openActions:1},{id:'B',name:'Б',latest:audit(2,10000),openActions:0}]);
  assert.equal(r2.comparable,true);
  const past=audit(2,9000);past.performedAt='2025-01-01T10:00:00.000Z';
  const r3=networkQuality(standard,[{id:'A',name:'А',latest:audit(2,8000),openActions:1},{id:'B',name:'Б',latest:past,openActions:0}]);
  assert.equal(r3.comparable,false);assert(r3.limitations.some(x=>x.includes('разным календарным')));
  assert.equal(can('auditor','network:standards:write'),false);
  assert.equal(can('manager','network:audits:write'),true);
});
