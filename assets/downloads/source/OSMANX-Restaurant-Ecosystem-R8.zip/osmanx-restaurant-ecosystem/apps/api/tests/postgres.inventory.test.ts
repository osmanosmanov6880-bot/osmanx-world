import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {runMigrations} from '../src/migrate.ts';
import {createPostgresStore} from '../src/infra/postgres.ts';

const available=!!process.env.DATABASE_URL;
test('R3 PostgreSQL: scoped stock, recipe snapshot, concurrent completion and audit',{skip:!available?'DATABASE_URL not configured':false},async()=>{
  await runMigrations();const store=await createPostgresStore(process.env.DATABASE_URL!);
  try{
    const uid=randomUUID();
    const a=await store.bootstrap({email:`pg-r3-${uid}@example.test`,displayName:'Owner',passwordHash:'test-only',organizationName:'R3 main',branchName:'A'});
    const b=await store.bootstrap({email:`pg-r3-alt-${uid}@example.test`,displayName:'Owner',passwordHash:'test-only',organizationName:'R3 other',branchName:'B'});
    const ctx={userId:a.user.id,organizationId:a.organizationId,branchId:a.branchId,role:'owner' as const};
    const outside={userId:b.user.id,organizationId:b.organizationId,branchId:b.branchId,role:'owner' as const};
    const ingredient=await store.createIngredient(ctx,'Кофе','g',18000,`ing-${uid}`);
    await assert.rejects(store.countStock(outside,ingredient.id,5,1,100,`cross-${uid}`),(e:any)=>e.status===404);
    const supplier=await store.createSupplier(ctx,'Поставщик',`sup-${uid}`);
    const lines=[{ingredientId:ingredient.id,quantityMilli:80000,totalCostCents:40000}];
    const receipt=await store.receiveStock(ctx,supplier.id,'PG R3',lines,`receipt-${uid}`);
    assert.equal((await store.receiveStock(ctx,supplier.id,'PG R3',lines,`receipt-${uid}`)).id,receipt.id);
    await assert.rejects(store.receiveStock(ctx,supplier.id,'PG R3',lines,`receipt-again-${uid}`),(e:any)=>e.status===409&&e.code==='DUPLICATE');
    assert.equal((await store.ingredients(ctx))[0].quantityMilli,80000);
    await assert.rejects(store.receiveStock(outside,null,'X',lines,`bad-receipt-${uid}`),(e:any)=>e.code==='INGREDIENT_NOT_FOUND');
    const menu=await store.addMenuItem(ctx,'Кофе',25000);
    await store.saveRecipe(ctx,menu.id,0,[{ingredientId:ingredient.id,quantityMilli:45000}],`recipe1-${uid}`);
    const makeReady=async (suffix:string)=>{
      const order=await store.createOrder(ctx,null,`create-${suffix}-${uid}`);
      await store.addOrderItem(ctx,order.id,menu.id,1,1,`add-${suffix}-${uid}`);
      await store.changeOrderStatus(ctx,order.id,'SENT',2,`sent-${suffix}-${uid}`);
      await store.changeOrderStatus(ctx,order.id,'PREPARING',3,`prep-${suffix}-${uid}`);
      await store.changeOrderStatus(ctx,order.id,'READY',4,`ready-${suffix}-${uid}`);
      return order.id;
    };
    const first=await makeReady('a'),second=await makeReady('b');
    // Recipe edits cannot change the snapshots already captured for A and B.
    await store.saveRecipe(ctx,menu.id,1,[{ingredientId:ingredient.id,quantityMilli:5000}],`recipe2-${uid}`);
    const result=await Promise.allSettled([
      store.changeOrderStatus(ctx,first,'COMPLETED',5,`finish-a-${uid}`),
      store.changeOrderStatus(ctx,second,'COMPLETED',5,`finish-b-${uid}`)
    ]);
    assert.equal(result.filter(x=>x.status==='fulfilled').length,1);
    const rejected=result.find(x=>x.status==='rejected') as PromiseRejectedResult;
    assert.equal(rejected.reason.code,'STOCK_SHORTAGE');
    const completed=(result.find(x=>x.status==='fulfilled') as PromiseFulfilledResult<any>).value;
    assert.equal(completed.actualFoodCostCents,22500);assert.equal(completed.foodCostComplete,true);
    assert.equal((await store.ingredients(ctx))[0].quantityMilli,35000);
    assert.equal((await store.stockMovements(ctx)).filter(x=>x.reason==='ORDER').length,1);
    assert.equal((await store.dashboard(ctx)).revenueCents,25000);
    assert.equal((await store.dashboard(ctx)).lowStockCount,0);
    const c=await store.countStock(ctx,ingredient.id,20000,(await store.ingredients(ctx))[0].revision,null,`count-${uid}`);
    assert.equal(c.deltaQuantityMilli,-15000);
    assert.equal((await store.ingredients(ctx))[0].valueCents,10000);
    const task=await store.createTask(ctx,'Закупить запас','',null,null,`task-${uid}`);
    assert.equal((await store.changeTaskStatus(ctx,task.id,'DONE',1,`task-done-${uid}`)).status,'DONE');
    assert.equal((await store.tasks(outside)).length,0);
  }finally{await store.close();}
});

test('R3 PostgreSQL: single-key idempotency and version conflicts under simultaneous receipts',{skip:!available?'DATABASE_URL not configured':false},async()=>{
  await runMigrations();const store=await createPostgresStore(process.env.DATABASE_URL!);
  try{
    const uid=randomUUID(),a=await store.bootstrap({email:`pg-r3-race-${uid}@example.test`,displayName:'Owner',passwordHash:'x',organizationName:'R3',branchName:'A'});
    const ctx={userId:a.user.id,organizationId:a.organizationId,branchId:a.branchId,role:'owner' as const};
    const item=await store.createIngredient(ctx,'Мука','g',0,`ing-${uid}`);
    const line=[{ingredientId:item.id,quantityMilli:1000,totalCostCents:100}];
    const races=await Promise.all([store.receiveStock(ctx,null,'Receipt 42',line,`same-${uid}`),store.receiveStock(ctx,null,'Receipt 42',line,`same-${uid}`)]);
    assert.equal(races[0].id,races[1].id);
    assert.equal((await store.ingredients(ctx))[0].quantityMilli,1000);
    const revision=(await store.ingredients(ctx))[0].revision;
    const counted=await Promise.allSettled([store.countStock(ctx,item.id,500,revision,null,`count-a-${uid}`),
      store.countStock(ctx,item.id,400,revision,null,`count-b-${uid}`)]);
    assert.equal(counted.filter(x=>x.status==='fulfilled').length,1);
    assert.equal((counted.find(x=>x.status==='rejected') as PromiseRejectedResult).reason.code,'STALE_VERSION');
    assert.equal((await store.stockMovements(ctx)).filter(x=>x.reason==='RECEIPT').length,1);
  }finally{await store.close();}
});
