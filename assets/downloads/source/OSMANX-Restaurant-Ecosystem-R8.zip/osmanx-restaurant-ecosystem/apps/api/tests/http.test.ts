import {before,after,test} from 'node:test';
import assert from 'node:assert/strict';
import type {AddressInfo} from 'node:net';
import type {Server} from 'node:http';
import {createApiServer} from '../src/http.ts';
import {FakeStore} from './fake-store.ts';

const store=new FakeStore(),config={origin:'http://localhost:3000',sessionSecret:'x'.repeat(64),secureCookies:false};
let server:Server,base:string,cookie='',csrf='',org='',branch='',menu='',table='',order='',owner='';
async function request(path:string,method='GET',body?:unknown,options:{cookie?:string;csrf?:string;origin?:string;key?:string}={}){
  const headers:Record<string,string>={};
  if(body!==undefined)headers['content-type']='application/json';
  if(options.cookie||cookie)headers['cookie']=options.cookie||cookie;
  if(method!=='GET'){
    headers['origin']=options.origin||'http://localhost:3000';
    if(options.csrf||csrf)headers['x-osmanx-csrf']=options.csrf||csrf;
  }
  if(options.key)headers['idempotency-key']=options.key;
  const res=await fetch(`${base}${path}`,{method,headers,body:body===undefined?undefined:JSON.stringify(body),redirect:'manual'});
  return {status:res.status,data:await res.json(),cookie:res.headers.get('set-cookie')?.split(';')[0]||''};
}
before(async()=>{server=createApiServer(store,config);await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${(server.address() as AddressInfo).port}`;});
after(async()=>{await new Promise<void>(r=>server.close(()=>r()));});

test('Bootstrap: создание владельца, организации и филиала, /me',async()=>{
  const r=await request('/api/v1/auth/register','POST',{email:'owner@osmanx.test',password:'SecurePassword-001',displayName:'Владелец',organizationName:'OSMANX Pilot',branchName:'Первый ресторан'});
  assert.equal(r.status,201);cookie=r.cookie;owner=r.data.user.id;org=r.data.organizationId;branch=r.data.branchId;
  assert.ok(cookie.startsWith('osmanx_session='));
  const me=await request('/api/v1/me');assert.equal(me.status,200);csrf=me.data.csrfToken;
  assert.equal(me.data.memberships[0].role,'owner');assert.equal(me.data.memberships[0].branches[0].id,branch);
  assert.equal(me.data.user.passwordHash,undefined);
});
test('CSRF и Origin: чужие сайты и неподписанные изменения запрещены',async()=>{
  const path=`/api/v1/organizations/${org}/branches/${branch}/menu`;
  const missing=await request(path,'POST',{name:'Тест',priceCents:200},{csrf:'invalid'});
  assert.equal(missing.status,403);assert.equal(missing.data.error.code,'CSRF');
  const hostile=await request(path,'POST',{name:'Тест',priceCents:200},{origin:'https://attacker.test'});
  assert.equal(hostile.status,403);assert.equal(hostile.data.error.code,'ORIGIN');
});
test('Меню: создание, версия, ограничение цены, редактирование',async()=>{
  const path=`/api/v1/organizations/${org}/branches/${branch}/menu`;
  const invalid=await request(path,'POST',{name:'Кофе',priceCents:-1});assert.equal(invalid.status,400);
  const added=await request(path,'POST',{name:'Капучино',priceCents:39000});assert.equal(added.status,201);menu=added.data.item.id;
  const changed=await request(`${path}/${menu}`,'PATCH',{priceCents:41000,revision:1});assert.equal(changed.status,200);
  const stale=await request(`${path}/${menu}`,'PATCH',{priceCents:35000,revision:1});assert.equal(stale.status,409);
  const list=await request(path);assert.equal(list.data.items[0].priceCents,41000);
});
test('Столы и заказ: идемпотентность, запрет дубля стола, версии',async()=>{
  const root=`/api/v1/organizations/${org}/branches/${branch}`;
  const t=await request(`${root}/tables`,'POST',{label:'Стол 1',capacity:4});assert.equal(t.status,201);table=t.data.table.id;
  const first=await request(`${root}/orders`,'POST',{tableId:table},{key:'new-order-0001'});assert.equal(first.status,201);order=first.data.order.id;
  const repeated=await request(`${root}/orders`,'POST',{tableId:table},{key:'new-order-0001'});
  assert.equal(repeated.status,201);assert.equal(repeated.data.order.id,order);
  const collision=await request(`${root}/orders`,'POST',{tableId:null},{key:'new-order-0001'});
  assert.equal(collision.status,409);
  const busy=await request(`${root}/orders`,'POST',{tableId:table},{key:'new-order-0002'});assert.equal(busy.status,409);
  const a=await request(`${root}/orders/${order}/items`,'POST',{menuItemId:menu,quantity:2,expectedRevision:1},{key:'add-line-0001'});
  assert.equal(a.status,200);assert.equal(a.data.order.totalCents,82000);assert.equal(a.data.order.revision,2);
  const duplicate=await request(`${root}/orders/${order}/items`,'POST',{menuItemId:menu,quantity:2,expectedRevision:1},{key:'add-line-0001'});
  assert.equal(duplicate.status,200);assert.equal(duplicate.data.order.items.length,1);
  const version=await request(`${root}/orders/${order}/items`,'POST',{menuItemId:menu,quantity:1,expectedRevision:1},{key:'add-line-0002'});
  assert.equal(version.status,409);
});
test('Кухонный цикл: пустой заказ запрещён, продажа только после завершения',async()=>{
  const root=`/api/v1/organizations/${org}/branches/${branch}`;
  let d=await request(`${root}/dashboard`);assert.equal(d.data.dashboard.revenueCents,0);
  let revision=2;
  for(const [status,key] of [['SENT','send-order-001'],['PREPARING','prepare-order-001'],['READY','ready-order-001'],['COMPLETED','complete-order-001']] as const){
    const r=await request(`${root}/orders/${order}/status`,'POST',{status,expectedRevision:revision++},{key});assert.equal(r.status,200);
  }
  const wrong=await request(`${root}/orders/${order}/status`,'POST',{status:'OPEN',expectedRevision:6},{key:'reopen-order-001'});assert.equal(wrong.status,409);
  d=await request(`${root}/dashboard`);assert.equal(d.data.dashboard.revenueCents,82000);assert.equal(d.data.dashboard.completedOrders,1);
  assert.equal(d.data.dashboard.averageCheckCents,82000);
});
test('Межорганизационная изоляция: второй владелец не читает чужой филиал',async()=>{
  const created=await request('/api/v1/auth/register','POST',{email:'other@osmanx.test',password:'SecurePassword-003',displayName:'Другой',organizationName:'Другой холдинг',branchName:'Второй'});
  assert.equal(created.status,201);
  const me=await request('/api/v1/me','GET',undefined,{cookie:created.cookie});assert.equal(me.status,200);
  const forbidden=await request(`/api/v1/organizations/${org}/branches/${branch}/orders`,'GET',undefined,{cookie:created.cookie});
  assert.equal(forbidden.status,404);
  const forbiddenOrg=await request(`/api/v1/organizations/${created.data.organizationId}/branches/${created.data.branchId}/menu`);
  assert.equal(forbiddenOrg.status,404);
});
test('Приглашения: официанту доступен филиал, но запрещено редактировать меню',async()=>{
  const invite=await request(`/api/v1/organizations/${org}/invitations`,'POST',{email:'staff@osmanx.test',role:'waiter',branchIds:[branch]});
  assert.equal(invite.status,201);const token=new URL(invite.data.invitation.url).searchParams.get('token');
  const redeem=await request('/api/v1/auth/accept-invite','POST',{token,email:'staff@osmanx.test',displayName:'Сотрудник',password:'SecurePassword-002'});
  assert.equal(redeem.status,201);const employeeCookie=redeem.cookie;
  const employeeMe=await request('/api/v1/me','GET',undefined,{cookie:employeeCookie});assert.equal(employeeMe.data.memberships[0].role,'waiter');
  const forbidden=await request(`/api/v1/organizations/${org}/branches/${branch}/menu`,'POST',{name:'Запрещено',priceCents:300},{cookie:employeeCookie,csrf:employeeMe.data.csrfToken});
  assert.equal(forbidden.status,403);
  const visible=await request(`/api/v1/organizations/${org}/branches/${branch}/menu`,'GET',undefined,{cookie:employeeCookie});assert.equal(visible.status,200);
  const again=await request('/api/v1/auth/accept-invite','POST',{token,email:'staff@osmanx.test',displayName:'Сотрудник',password:'SecurePassword-002'});
  assert.equal(again.status,410);
});
test('Неверный пароль и logout инвалидируют сессию',async()=>{
  const wrong=await request('/api/v1/auth/login','POST',{email:'owner@osmanx.test',password:'SecurePassword-Wrong'});
  assert.equal(wrong.status,401);
  const signout=await request('/api/v1/auth/logout','POST',{});assert.equal(signout.status,200);
  const stale=await request('/api/v1/me');assert.equal(stale.status,401);
});
