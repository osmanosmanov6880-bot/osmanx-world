import {assert,integerField} from './rules.ts';

/** R4 finances: all amounts are integer minor units, never IEEE-754 money arithmetic. */
export const EXPENSE_CATEGORIES=['PAYROLL','RENT','UTILITIES','MARKETING','SERVICES','OTHER'] as const;
export type ExpenseCategory=typeof EXPENSE_CATEGORIES[number];
export const BUDGET_CATEGORIES=['REVENUE','FOOD_COST',...EXPENSE_CATEGORIES] as const;
export type BudgetCategory=typeof BUDGET_CATEGORIES[number];
export type ExpenseStatus='POSTED'|'VOIDED';
export const FINANCIAL_LIMIT=9_999_999_999_999;
export const FINANCIAL_LABELS:Record<BudgetCategory,string>={
  REVENUE:'Выручка',FOOD_COST:'Себестоимость блюд',PAYROLL:'Фонд оплаты труда',RENT:'Аренда',
  UTILITIES:'Коммунальные расходы',MARKETING:'Маркетинг',SERVICES:'Услуги и сервисы',OTHER:'Прочие расходы'
};
export interface Expense {
  id:string; category:ExpenseCategory;description:string;amountCents:number;occurredOn:string;
  status:ExpenseStatus;revision:number;createdAt:string;voidedAt:string|null;voidReason:string|null;
}
export interface Budget {period:string;category:BudgetCategory;amountCents:number;revision:number;}
export interface CostedOrder {id:string;amountCents:number;costCents:number|null;complete:boolean;}
export interface FinanceFacts {orders:CostedOrder[];expenses:Expense[];stockLossCents:number;}
export interface PlanFact {category:BudgetCategory;plannedCents:number|null;actualCents:number|null;varianceCents:number|null;}
export interface FinanceReport {
  period:string; revenueCents:number;completedOrders:number;uncostedOrders:number;
  knownFoodCostCents:number;foodCostCents:number|null;stockLossCents:number;
  expensesCents:number;laborCostCents:number;expensesByCategory:Record<ExpenseCategory,number>;
  grossProfitCents:number|null;operatingResultCents:number|null;
  foodCostRateBps:number|null;laborCostRateBps:number|null;operatingMarginBps:number|null;
  planFact:PlanFact[];expenseCoverage:'UNVERIFIED';
}
export interface FinanceNetwork {
  period:string;currency:string;branches:{id:string;name:string;report:FinanceReport}[];
  totals:FinanceReport;
}
export type LedgerSource='ORDER'|'FOOD_COST'|'EXPENSE'|'STOCK_LOSS';
export interface LedgerEntry {
  id:string;source:LedgerSource;sourceId:string;description:string;occurredAt:string;
  signedAmountCents:number;complete:boolean;
}
export function financeAmount(value:unknown,label='amountCents'):number{
  return integerField(value,label,0,FINANCIAL_LIMIT);
}
export function positiveFinanceAmount(value:unknown,label='amountCents'):number{
  return integerField(value,label,1,FINANCIAL_LIMIT);
}
export function expenseCategory(v:unknown):ExpenseCategory{
  assert(typeof v==='string'&&EXPENSE_CATEGORIES.includes(v as ExpenseCategory),400,'FINANCE_CATEGORY','Недопустимая категория расхода');
  return v as ExpenseCategory;
}
export function budgetCategory(v:unknown):BudgetCategory{
  assert(typeof v==='string'&&BUDGET_CATEGORIES.includes(v as BudgetCategory),400,'FINANCE_CATEGORY','Недопустимая категория бюджета');
  return v as BudgetCategory;
}
export function financePeriod(value:unknown):string{
  assert(typeof value==='string'&&/^(20\d\d|2100)-(0[1-9]|1[0-2])$/.test(value),400,'FINANCE_PERIOD','Период должен быть в формате ГГГГ-ММ');
  return value;
}
export function financeDate(value:unknown):string{
  assert(typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value),400,'FINANCE_DATE','Дата расхода должна быть в формате ГГГГ-ММ-ДД');
  const day=new Date(`${value}T00:00:00.000Z`);
  assert(Number.isFinite(day.getTime())&&day.toISOString().slice(0,10)===value,400,'FINANCE_DATE','Не существует такой даты');
  financePeriod(value.slice(0,7));
  return value;
}
export function centsSum(values:readonly number[],label='amount'):number{
  let sum=0n;
  for(const v of values){assert(Number.isSafeInteger(v),500,'INTEGRITY',`${label}: повреждённое значение`);sum+=BigInt(v);}
  assert(sum<=BigInt(FINANCIAL_LIMIT)&&sum>=-BigInt(FINANCIAL_LIMIT),409,'AMOUNT_TOO_LARGE',`${label}: превышен лимит`);
  return Number(sum);
}
export function basisPoints(numerator:number,denominator:number):number|null{
  assert(Number.isSafeInteger(numerator)&&Number.isSafeInteger(denominator)&&denominator>=0,500,'INTEGRITY','Некорректное деление');
  if(!denominator)return null;
  const top=BigInt(numerator)*10000n;
  const numeratorAbs=top<0n?-top:top;
  const result=(numeratorAbs+BigInt(denominator)/2n)/BigInt(denominator);
  assert(result<=BigInt(Number.MAX_SAFE_INTEGER),409,'AMOUNT_TOO_LARGE','Недопустимый коэффициент');
  return Number(top<0n?-result:result);
}
function emptyCategories():Record<ExpenseCategory,number>{
  return {PAYROLL:0,RENT:0,UTILITIES:0,MARKETING:0,SERVICES:0,OTHER:0};
}
export function calculateFinanceReport(period:string,facts:FinanceFacts,budgets:Budget[]):FinanceReport{
  financePeriod(period);
  const orders=facts.orders;
  const revenueCents=centsSum(orders.map(o=>o.amountCents),'Выручка');
  const incomplete=orders.filter(o=>!o.complete||o.costCents===null).length;
  const knownFoodCostCents=centsSum(orders.map(o=>o.costCents??0),'Известная себестоимость');
  const foodCostCents=incomplete>0?null:knownFoodCostCents;
  const expensesByCategory=emptyCategories();
  for(const category of EXPENSE_CATEGORIES){
    expensesByCategory[category]=centsSum(facts.expenses.filter(x=>x.category===category&&x.status==='POSTED').map(x=>x.amountCents),category);
  }
  const expensesCents=centsSum(Object.values(expensesByCategory),'Расходы');
  const stockLossCents=financeAmount(facts.stockLossCents,'stockLossCents');
  const grossProfitCents=foodCostCents===null?null:centsSum([revenueCents,-foodCostCents],'Валовая прибыль');
  // Recorded operating result, NOT a complete statutory/net P&L: unentered costs/taxes are unknown.
  const operatingResultCents=grossProfitCents===null?null:centsSum([grossProfitCents,-expensesCents,-stockLossCents],'Операционный результат');
  const budgetsByCategory=new Map(budgets.filter(b=>b.period===period).map(b=>[b.category,b.amountCents]));
  const actual:Record<BudgetCategory,number|null>={...expensesByCategory,REVENUE:revenueCents,FOOD_COST:foodCostCents};
  const planFact:BUDGET_COMPARISON[]=BUDGET_CATEGORIES.map(category=>{
    const plannedCents=budgetsByCategory.get(category)??null;
    const actualCents=actual[category];
    return {category,plannedCents,actualCents,varianceCents:plannedCents===null||actualCents===null?null:centsSum([actualCents,-plannedCents],'Отклонение')};
  });
  return {period,revenueCents,completedOrders:orders.length,uncostedOrders:incomplete,
    knownFoodCostCents,foodCostCents,stockLossCents,expensesCents,laborCostCents:expensesByCategory.PAYROLL,
    expensesByCategory,grossProfitCents,operatingResultCents,
    foodCostRateBps:foodCostCents===null?null:basisPoints(foodCostCents,revenueCents),
    laborCostRateBps:basisPoints(expensesByCategory.PAYROLL,revenueCents),
    operatingMarginBps:operatingResultCents===null?null:basisPoints(operatingResultCents,revenueCents),
    planFact,expenseCoverage:'UNVERIFIED'};
}
type BUDGET_COMPARISON=PlanFact;
/** A branch with incomplete cost poisons consolidated cost/profit instead of silently appearing as zero. */
export function consolidateReports(period:string,reports:FinanceReport[],budgets:Budget[]=[]):FinanceReport{
  const orders:CostedOrder[]=[];
  const expenses:Expense[]=[];
  let stockLossCents=0;
  for(const r of reports){
    assert(r.period===period,400,'FINANCE_PERIOD','Периоды филиалов не совпадают');
    // Aggregate from trusted summaries without inventing cost for incomplete branches.
    orders.push(...(r.completedOrders?[{id:'aggregate',amountCents:r.revenueCents,costCents:r.foodCostCents??r.knownFoodCostCents,complete:r.uncostedOrders===0}]:[]));
    if(!r.completedOrders&&r.revenueCents)throw new Error('Invalid financial summary');
    for(const category of EXPENSE_CATEGORIES){
      if(r.expensesByCategory[category])expenses.push({id:'aggregate',category,amountCents:r.expensesByCategory[category],
        description:'',status:'POSTED',revision:1,occurredOn:`${period}-01`,createdAt:'',voidedAt:null,voidReason:null});
    }
    stockLossCents=centsSum([stockLossCents,r.stockLossCents]);
  }
  const consolidated=calculateFinanceReport(period,{orders,expenses,stockLossCents},budgets);
  consolidated.completedOrders=reports.reduce((v,r)=>v+r.completedOrders,0);
  consolidated.uncostedOrders=reports.reduce((v,r)=>v+r.uncostedOrders,0);
  return consolidated;
}
