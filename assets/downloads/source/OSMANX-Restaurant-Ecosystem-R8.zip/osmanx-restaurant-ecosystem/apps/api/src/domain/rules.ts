export const ROLE_NAMES = ['owner','finance_director','operations_director','manager','chef','kitchen','waiter','cashier','marketer','analyst','auditor'] as const;
export type Role = typeof ROLE_NAMES[number];
export type Permission = 'branches:write'|'staff:invite'|'dashboard:read'|'menu:read'|'menu:write'|'tables:read'|'tables:write'|'orders:read'|'orders:create'|'orders:add'|'orders:advance'|'reservations:read'|'reservations:write'|'reservations:seat'|'kitchen:read'|'shifts:read'|'shifts:open'|'shifts:manage'|'inventory:read'|'inventory:write'|'recipes:read'|'recipes:write'|'procurement:read'|'procurement:write'|'tasks:read'|'tasks:write'|'tasks:status'|'finance:read'|'finance:write'|'finance:void'|'finance:budget'|'guests:read'|'guests:write'|'guests:erase'|'guests:consent'|'guests:analytics'|'orders:link_guest'|'feedback:read'|'feedback:write'|'feedback:resolve'|'intelligence:read'|'intelligence:write'|'network:standards:read'|'network:standards:write'|'network:audits:read'|'network:audits:write'|'network:actions:read'|'network:actions:write'|'integrations:read'|'integrations:manage'|'integrations:import';
export type OrderStatus = 'OPEN'|'SENT'|'PREPARING'|'READY'|'COMPLETED'|'CANCELLED';

const permissions: Record<Permission, readonly Role[]> = {
  'branches:write': ['owner','operations_director'],
  'staff:invite': ['owner'],
  'dashboard:read': ['owner','finance_director','operations_director','manager','analyst','auditor'],
  'menu:read': ROLE_NAMES,
  'menu:write': ['owner','operations_director','manager','chef'],
  'tables:read': ROLE_NAMES,
  'tables:write': ['owner','operations_director','manager'],
  'orders:read': ['owner','finance_director','operations_director','manager','chef','kitchen','waiter','cashier','analyst','auditor'],
  'orders:create': ['owner','operations_director','manager','waiter','cashier'],
  'orders:add': ['owner','operations_director','manager','waiter','cashier'],
  'orders:advance': ['owner','operations_director','manager','chef','kitchen','waiter','cashier'],
  'reservations:read': ['owner','operations_director','manager','waiter','cashier','analyst','auditor'],
  'reservations:write': ['owner','operations_director','manager','waiter','cashier'],
  'reservations:seat': ['owner','operations_director','manager','waiter','cashier'],
  'kitchen:read': ['owner','operations_director','manager','chef','kitchen','waiter','cashier','auditor'],
  'shifts:read': ROLE_NAMES,
  'shifts:open': ['owner','finance_director','operations_director','manager','chef','kitchen','waiter','cashier','marketer','analyst'],
  'shifts:manage': ['owner','operations_director','manager'],
  'inventory:read': ['owner','finance_director','operations_director','manager','chef','analyst','auditor'],
  'inventory:write': ['owner','operations_director','manager','chef'],
  'recipes:read': ['owner','finance_director','operations_director','manager','chef','kitchen','analyst','auditor'],
  'recipes:write': ['owner','operations_director','manager','chef'],
  'procurement:read': ['owner','finance_director','operations_director','manager','chef','analyst','auditor'],
  'procurement:write': ['owner','operations_director','manager'],
  'finance:read': ['owner','finance_director','operations_director','manager','analyst','auditor'],
  'finance:write': ['owner','finance_director','operations_director','manager'],
  'finance:void': ['owner','finance_director','operations_director'],
  'finance:budget': ['owner','finance_director','operations_director'],
  'tasks:read': ROLE_NAMES,
  'tasks:write': ['owner','operations_director','manager'],
  'tasks:status': ['owner','finance_director','operations_director','manager','chef','kitchen','waiter','cashier','marketer','analyst'],
  'guests:read': ['owner','operations_director','manager','marketer','waiter','cashier'],
  'guests:write': ['owner','operations_director','manager','marketer','waiter','cashier'],
  'guests:erase': ['owner','operations_director'],
  'guests:consent': ['owner','operations_director','manager','marketer'],
  'guests:analytics': ['owner','operations_director','manager','marketer','analyst','auditor'],
  'orders:link_guest': ['owner','operations_director','manager','waiter','cashier'],
  'feedback:read': ['owner','operations_director','manager','marketer','analyst','auditor'],
  'feedback:write': ['owner','operations_director','manager','marketer','waiter','cashier'],
  'feedback:resolve': ['owner','operations_director','manager','marketer'],
  'intelligence:read': ['owner','finance_director','operations_director','manager','analyst','auditor'],
  'intelligence:write': ['owner','finance_director','operations_director','manager'],
  'network:standards:read':['owner','finance_director','operations_director','manager','chef','analyst','auditor'],
  'network:standards:write':['owner','operations_director'],
  'network:audits:read':['owner','finance_director','operations_director','manager','chef','analyst','auditor'],
  'network:audits:write':['owner','operations_director','manager'],
  'network:actions:read':['owner','finance_director','operations_director','manager','chef','analyst','auditor'],
  'network:actions:write':['owner','operations_director','manager'],
  'integrations:read':['owner','finance_director','operations_director','manager','analyst','auditor'],
  'integrations:manage':['owner','operations_director'],
  'integrations:import':['owner','operations_director','manager']
};
export const GLOBAL_BRANCH_ROLES: readonly Role[] = ['owner','finance_director','operations_director'];
export const can = (role: Role, permission: Permission): boolean => permissions[permission].includes(role);
export const hasBranchAccess = (role: Role, granted: boolean): boolean => GLOBAL_BRANCH_ROLES.includes(role) || granted;

export class AppError extends Error {
  status: number; code: string;
  constructor(status: number, code: string, message: string) { super(message); this.name = 'AppError'; this.status=status;this.code=code; }
}
export function assert(condition: unknown, status: number, code: string, message: string): asserts condition {
  if (!condition) throw new AppError(status,code,message);
}
export const isRole = (value: unknown): value is Role => typeof value === 'string' && ROLE_NAMES.includes(value as Role);
export const isUuid = (v: unknown): v is string => typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
export function textField(v: unknown, key: string, max = 160, min = 1): string {
  assert(typeof v === 'string',400,'VALIDATION',`${key}: ожидается строка`);
  const normalized = v.trim();
  assert(normalized.length >= min && normalized.length <= max,400,'VALIDATION',`${key}: допустимая длина ${min}–${max}`);
  assert(!/[\x00-\x08\x0B\x0C\x0E-\x1F]/.test(normalized),400,'VALIDATION',`${key}: недопустимые символы`);
  return normalized;
}
export function emailField(v: unknown): string {
  const email = textField(v,'email',254,3).toLowerCase();
  assert(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email),400,'VALIDATION','Неправильный email');
  return email;
}
export function passwordField(v: unknown): string {
  assert(typeof v==='string' && v.length >= 12 && v.length <= 128,400,'VALIDATION','Пароль: от 12 до 128 символов');
  return v;
}
export function integerField(v: unknown, field: string, min: number, max: number): number {
  assert(typeof v === 'number' && Number.isSafeInteger(v) && v >= min && v <= max,400,'VALIDATION',`${field}: целое число от ${min} до ${max}`);
  return v;
}
export function moneyCents(v: unknown): number {
  return integerField(v,'priceCents',0,999_999_999_999);
}
export function safeMoneySum(items: readonly {unitPriceCents:number; quantity:number}[]): number {
  let cents = 0n;
  for (const item of items) {
    moneyCents(item.unitPriceCents);
    integerField(item.quantity,'quantity',1,30);
    cents += BigInt(item.unitPriceCents) * BigInt(item.quantity);
  }
  assert(cents <= 9_999_999_999_999n,400,'AMOUNT_TOO_LARGE','Сумма заказа превышает разрешённый предел');
  return Number(cents);
}
export function requireTransition(role: Role, from: OrderStatus, to: OrderStatus): void {
  const next: Record<OrderStatus,OrderStatus[]> = {
    OPEN: ['SENT','CANCELLED'], SENT: ['PREPARING','CANCELLED'],
    PREPARING: ['READY','CANCELLED'], READY: ['COMPLETED','CANCELLED'],
    COMPLETED: [], CANCELLED: []
  };
  assert(next[from]?.includes(to),409,'INVALID_TRANSITION',`Переход ${from} → ${to} недоступен`);
  const canKitchen = role === 'chef' || role === 'kitchen';
  const canFront = role === 'waiter' || role === 'cashier';
  if (canKitchen) assert((from==='SENT' && to==='PREPARING') || (from==='PREPARING' && to==='READY'),403,'FORBIDDEN','Этап недоступен кухне');
  if (canFront) assert((from==='OPEN' && to==='SENT') || (from==='READY' && to==='COMPLETED'),403,'FORBIDDEN','Этап недоступен залу');
}
export function requirePermission(role: Role, permission: Permission): void {
  assert(can(role,permission),403,'FORBIDDEN','Недостаточно прав');
}
