// R8: public types, external-data normalization and security input validation.
import {AppError,assert,integerField,isUuid,textField} from './rules.ts';
export type IntegrationState='UNVERIFIED'|'VERIFIED'|'ERROR'|'DISABLED';
export type SyncState='QUEUED'|'RUNNING'|'RETRY'|'SUCCEEDED'|'FAILED'|'CANCELLED';
export interface IntegrationConnection {
  id:string;branchId:string;provider:'IIKO';alias:string;remoteOrganizationId:string;
  state:IntegrationState;revision:number;remoteOrganizationName:string|null;
  verifiedAt:string|null;lastErrorCode:string|null;lastSyncAt:string|null;
  createdAt:string;updatedAt:string;
}
export interface StoredIntegration extends IntegrationConnection { sealedCredentials:string; }
export interface Credentials {appId:string;clientSecret:string;apiKey:string;}
export interface RemoteOrganization {id:string;name:string;}
export interface RemoteMenu {id:string;name:string;}
export interface CatalogItem {externalId:string;name:string;category:string;priceCents:number|null;
  importedMenuItemId:string|null;sourceRunId:string;}
export interface CatalogProduct {externalId:string;name:string;category:string;priceCents:number|null;}
export interface SyncJob {id:string;connectionId:string;menuId:string;status:SyncState;
  attemptCount:number;nextAttemptAt:string;lastErrorCode:string|null;
  createdAt:string;completedAt:string|null;itemsCount:number|null;}
export interface ClaimedSync {id:string;connectionId:string;organizationId:string;branchId:string;menuId:string;
  leaseToken:string;attemptCount:number;sealedCredentials:string;remoteOrganizationId:string;}
export function credentialsInput(input:Record<string,unknown>):Credentials {
  const appId=textField(input.appId,'appId',180,2);
  const clientSecret=textField(input.clientSecret,'clientSecret',250,8);
  const apiKey=textField(input.apiKey,'apiKey',250,8);
  return {appId,clientSecret,apiKey};
}
export function integrationInput(input:Record<string,unknown>){
  return {alias:textField(input.alias,'alias',100),remoteOrganizationId:remoteId(input.remoteOrganizationId),
    credentials:credentialsInput(input)};
}
export function remoteId(value:unknown):string {
  assert(isUuid(value),400,'VALIDATION','Нужен UUID организации iiko');return value;
}
export function menuId(value:unknown):string {return textField(value,'menuId',120,1);}
export function selectedExternalIds(value:unknown):string[] {
  assert(Array.isArray(value)&&value.length>0&&value.length<=50,400,'VALIDATION','Выберите от 1 до 50 блюд');
  const ids=value.map(v=>textField(v,'externalId',180,1));
  assert(new Set(ids).size===ids.length,400,'VALIDATION','Повторяющиеся блюда');return ids;
}
export function checkRevision(value:unknown){return integerField(value,'expectedRevision',1,1_000_000_000);}
// Provider errors must never expose credentials, raw HTTP bodies, private headers or URLs.
export class ProviderError extends Error {
  code:'AUTH_FAILED'|'RATE_LIMIT'|'UNAVAILABLE'|'TIMEOUT'|'BAD_RESPONSE'|'ORG_NOT_FOUND'|'INVALID_MENU';
  retryable:boolean;
  constructor(code:ProviderError['code'],retryable:boolean){
    super(code);this.name='ProviderError';this.code=code;this.retryable=retryable;
  }
}
export function safeProviderError(error:unknown):ProviderError{
  if(error instanceof ProviderError)return error;
  return new ProviderError('UNAVAILABLE',true);
}
// Monetary data must be exactly representable in cents. Unknown/ambiguous price is NULL, never zero.
export function decimalRubToCents(input:unknown):number|null {
  if(typeof input!=='string'&&typeof input!=='number')return null;
  if(typeof input==='number'&&!Number.isFinite(input))return null;
  const v=String(input);
  if(!/^\d{1,10}(?:\.\d{1,2})?$/.test(v))return null;
  const [whole,dec='']=v.split('.');const cents=BigInt(whole)*100n+BigInt((dec+'00').slice(0,2));
  if(cents>999_999_999_999n)return null;
  return Number(cents);
}
const rec=(x:unknown):Record<string,unknown>|null=>x&&typeof x==='object'&&!Array.isArray(x)?x as Record<string,unknown>:null;
function cleanText(x:unknown,max=160):string|null{
  if(typeof x!=='string')return null;
  const v=x.trim();return v&&v.length<=max&&!/[\x00-\x1f]/.test(v)?v:null;
}
/** Safe partial v3 external-menu parser. Multi-size or multi-price dishes stay unresolved (null). */
export function normalizeIikoMenu(payload:unknown,remoteOrganizationId:string):CatalogProduct[]{
  const data=rec(payload);
  if(!data||!Array.isArray(data.itemCategories))throw new ProviderError('BAD_RESPONSE',false);
  const result:CatalogProduct[]=[];const seen=new Set<string>();
  for(const rawCat of data.itemCategories){
    const cat=rec(rawCat);if(!cat)throw new ProviderError('BAD_RESPONSE',false);
    const category=cleanText(cat.name)||'Без категории';
    if(!Array.isArray(cat.items))throw new ProviderError('BAD_RESPONSE',false);
    for(const rawItem of cat.items){
      const item=rec(rawItem);if(!item)throw new ProviderError('BAD_RESPONSE',false);
      const id=cleanText(item.itemId)||cleanText(item.id);
      const name=cleanText(item.name);
      if(!id||!name)throw new ProviderError('BAD_RESPONSE',false);
      if(seen.has(id))throw new ProviderError('INVALID_MENU',false);seen.add(id);
      let priceCents:number|null=null;
      const sizes=item.itemSizes;
      if(Array.isArray(sizes)&&sizes.length===1){
        const size=rec(sizes[0]);const prices=size?.prices;
        if(Array.isArray(prices)){
          const matched=prices.map(rec).filter(p=>p&&(p.organizationId===remoteOrganizationId||!p.organizationId));
          // Ambiguous price-category or multi-price data must be resolved at POS, not guessed.
          if(matched.length===1)priceCents=decimalRubToCents(matched[0]!.price);
        }
      }
      result.push({externalId:id,name,category,priceCents});
      if(result.length>5000)throw new ProviderError('INVALID_MENU',false);
    }
  }
  return result;
}
