import {standardInput,networkQuality,type AuditAnswerInput,type ActionStatus} from './domain/network.ts';
import {previousPeriod,decisionInput,type DecisionStatus} from './domain/intelligence.ts';
import type {IntegrationRuntime} from './integrations/runtime.ts';
import {menuId,selectedExternalIds,checkRevision} from './domain/integrations.ts';
import http, {type IncomingMessage,type ServerResponse} from 'node:http';
import {URL} from 'node:url';
import {AppError,assert,can,emailField,hasBranchAccess,integerField,isRole,isUuid,moneyCents,passwordField,requirePermission,textField} from './domain/rules.ts';
import type {Ctx,Membership,Store,User} from './store.ts';
import type {OrderStatus,Permission} from './domain/rules.ts';
import {bookingWindow,noteField,reservationGuest} from './domain/operations.ts';
import {stockQuantity,stockValue,stockUnit,recipeComponents,receiptLines,taskDeadline,referenceField} from './domain/inventory.ts';
import type {RecipeComponentInput,ReceiptLineInput,TaskStatus} from './domain/inventory.ts';
import type {ReservationAction} from './domain/operations.ts';
import {financePeriod,financeDate,expenseCategory,budgetCategory,financeAmount,positiveFinanceAmount,consolidateReports} from './domain/finance.ts';
import {guestInput,consentChannel,consentState,consentEvidence,feedbackInput} from './domain/guests.ts';
import {clearSessionCookie,cookieValue,csrfToken,hashPassword,newToken,RateLimiter,sessionCookie,sha256,validateRequestOrigin,verifyCsrf,verifyPassword} from './infra/security.ts';

export interface ApiConfig { origin:string; sessionSecret:string; secureCookies:boolean; }
const MAX_BODY_BYTES=64*1024;
const mutating=(method:string)=>['POST','PUT','PATCH','DELETE'].includes(method);
const json=(res:ServerResponse,status:number,payload:unknown,headers:Record<string,string>={})=>{
  const body=JSON.stringify(payload);
  res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'no-referrer',...headers});
  res.end(body);
};
const object=(v:unknown):Record<string,unknown>=>{
  assert(typeof v==='object' && v!==null && !Array.isArray(v),400,'VALIDATION','Ожидается JSON-объект');
  return v as Record<string,unknown>;
};
const optionalUuid=(v:unknown,label='id'):string|null=>{
  assert(v===null || isUuid(v),400,'VALIDATION',`Неверный ${label}`);return v as string|null;
};
const requiredUuid=(v:unknown,label='id'):string=>{
  assert(isUuid(v),400,'VALIDATION',`Неверный ${label}`);return v;
};
const requestKey=(req:IncomingMessage):string=>{
  const key=req.headers['idempotency-key'];
  assert(typeof key==='string' && /^[a-zA-Z0-9_-]{8,100}$/.test(key),400,'IDEMPOTENCY_KEY','Нужен уникальный заголовок Idempotency-Key');
  return key;
};
async function bodyObject(req:IncomingMessage):Promise<Record<string,unknown>>{
  assert((req.headers['content-type']||'').toLowerCase().startsWith('application/json'),415,'CONTENT_TYPE','Ожидается application/json');
  const chunks:Buffer[]=[];let length=0;
  for await(const chunk of req){length+=chunk.length;assert(length<=MAX_BODY_BYTES,413,'BODY_TOO_LARGE','Слишком большой запрос');chunks.push(chunk);}
  let parsed:unknown;
  try{parsed=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw new AppError(400,'JSON','Ошибка JSON');}
  return object(parsed);
}
const findMembership=(memberships:Membership[],orgId:string):Membership=>{
  const match=memberships.find(m=>m.organizationId===orgId);
  assert(match,404,'NOT_FOUND','Организация не найдена');return match;
};
const branchContext=(member:Membership,userId:string,branchId:string):Ctx=>{
  const grant=member.branches.some(b=>b.id===branchId);
  assert(hasBranchAccess(member.role,grant) && grant,404,'NOT_FOUND','Филиал недоступен');
  return {userId,organizationId:member.organizationId,branchId,role:member.role};
};
const uniqueIds=(v:unknown):string[]=>{
  assert(Array.isArray(v) && v.length<=50,400,'VALIDATION','branchIds: ожидается список до 50 филиалов');
  const ids=v.map(x=>requiredUuid(x,'branchId'));
  assert(ids.length===new Set(ids).size,400,'VALIDATION','Дубли филиалов');
  return ids;
};
export function createApiServer(store:Store,config:ApiConfig,integrations?:IntegrationRuntime):http.Server{
  assert(config.sessionSecret.length>=32,500,'CONFIG','SESSION_SECRET должен содержать минимум 32 символа');
  const limiter=new RateLimiter();
  const providerLimiter=new RateLimiter(15,15*60*1000);
  return http.createServer(async(req,res)=>{
    try{
      const method=req.method||'GET';
      const requestUrl=new URL(req.url||'/',config.origin);
      const pathname=requestUrl.pathname.replace(/\/$/,'')||'/';
      if(method==='GET' && pathname==='/health/live')return json(res,200,{status:'live'});
      if(method==='GET' && pathname==='/health/ready'){const ready=await store.ready();return json(res,ready?200:503,{status:ready?'ready':'not_ready'});}
      if(!pathname.startsWith('/api/v1/'))throw new AppError(404,'NOT_FOUND','Маршрут не найден');
      if(mutating(method))validateRequestOrigin(req.headers.origin,config.origin);
      const createSession=async(u:User,status=200,extra:Record<string,unknown>={})=>{
        const raw=newToken();await store.createSession(u.id,sha256(raw));
        return json(res,status,{user:{id:u.id,email:u.email,displayName:u.displayName},...extra},{'set-cookie':sessionCookie(raw,config.secureCookies)});
      };
      if(method==='POST' && pathname==='/api/v1/auth/register'){
        const b=await bodyObject(req);
        const email=emailField(b.email);const password=passwordField(b.password);
        limiter.check(`register:${req.socket.remoteAddress||'unknown'}`);
        const created=await store.bootstrap({email,displayName:textField(b.displayName,'displayName',120),passwordHash:await hashPassword(password),
          organizationName:textField(b.organizationName,'organizationName'),branchName:textField(b.branchName,'branchName')});
        return createSession(created.user,201,{organizationId:created.organizationId,branchId:created.branchId});
      }
      if(method==='POST' && pathname==='/api/v1/auth/login'){
        const b=await bodyObject(req);const email=emailField(b.email);const password=passwordField(b.password);
        limiter.check(`login:${req.socket.remoteAddress||'unknown'}:${email}`);
        const u=await store.findUser(email);
        if(!u){await hashPassword(password);throw new AppError(401,'LOGIN_FAILED','Неверный email или пароль');}
        assert(await verifyPassword(password,u.passwordHash),401,'LOGIN_FAILED','Неверный email или пароль');
        return createSession(u);
      }
      if(method==='POST' && pathname==='/api/v1/auth/accept-invite'){
        const b=await bodyObject(req);
        limiter.check(`accept:${req.socket.remoteAddress||'unknown'}`);
        const raw=textField(b.token,'token',120,30);
        const u=await store.acceptInvitation(sha256(raw),emailField(b.email),textField(b.displayName,'displayName',120),await hashPassword(passwordField(b.password)));
        return createSession(u,201);
      }
      const rawCookie=cookieValue(req.headers.cookie,'osmanx_session');
      assert(rawCookie && /^[a-zA-Z0-9_-]{40,60}$/.test(rawCookie),401,'UNAUTHORIZED','Войдите в аккаунт');
      const tokenHash=sha256(rawCookie);
      const u=await store.getSession(tokenHash);
      assert(u,401,'UNAUTHORIZED','Сессия отсутствует или истекла');
      if(mutating(method))verifyCsrf(csrfToken(tokenHash,config.sessionSecret),req.headers['x-osmanx-csrf'] as string|undefined);
      if(method==='POST' && pathname==='/api/v1/auth/logout'){
        await store.deleteSession(tokenHash);
        return json(res,200,{success:true},{'set-cookie':clearSessionCookie(config.secureCookies)});
      }
      const memberships=await store.memberships(u.id);
      if(method==='GET' && pathname==='/api/v1/me'){
        return json(res,200,{user:{id:u.id,email:u.email,displayName:u.displayName},memberships,csrfToken:csrfToken(tokenHash,config.sessionSecret)});
      }
      if(method==='GET' && pathname==='/api/v1/organizations')return json(res,200,{organizations:memberships});
      const parts=pathname.split('/').filter(Boolean);
      assert(parts[0]==='api'&&parts[1]==='v1'&&parts[2]==='organizations',404,'NOT_FOUND','Маршрут не найден');
      const orgId=requiredUuid(parts[3],'organizationId');
      const member=findMembership(memberships,orgId);
      if(parts.length===5 && parts[4]==='branches'){
        if(method==='GET')return json(res,200,{branches:member.branches});
        if(method==='POST'){
          requirePermission(member.role,'branches:write');
          const b=await bodyObject(req);
          const timezone=textField(b.timezone,'timezone',60);
          try{new Intl.DateTimeFormat('en',{timeZone:timezone});}catch{throw new AppError(400,'TIMEZONE','Неверный часовой пояс');}
          return json(res,201,{branch:await store.createBranch(orgId,u.id,textField(b.name,'name'),timezone)});
        }
      }
      if(parts.length===5&&parts[4]==='invitations'&&method==='POST'){
        requirePermission(member.role,'staff:invite');
        const b=await bodyObject(req);const email=emailField(b.email);const role=b.role;
        assert(isRole(role)&&role!=='owner',400,'VALIDATION','Недопустимая роль');
        const branchIds=uniqueIds(b.branchIds);
        assert(['finance_director','operations_director'].includes(role)||branchIds.length>0,400,'BRANCH_SCOPE','Нужен минимум один филиал');
        const token=newToken();
        await store.createInvitation(orgId,u.id,email,role,branchIds,sha256(token));
        return json(res,201,{invitation:{email,role,expiresInHours:48,url:`${config.origin}/invite?token=${encodeURIComponent(token)}`}});
      }
      if(parts.length===5&&parts[4]==='standards'){
        requirePermission(member.role,'network:standards:read');
        if(method==='GET')return json(res,200,{standards:await store.networkStandards(orgId)});
        if(method==='POST'){
          requirePermission(member.role,'network:standards:write');const b=await bodyObject(req);
          const branchId=member.branches[0]?.id;assert(branchId,403,'BRANCH_SCOPE','Нет доступных филиалов');
          return json(res,201,{standard:await store.createNetworkStandard(branchContext(member,u.id,branchId),standardInput(b),requestKey(req))});
        }
      }
      if(parts.length===6&&parts[4]==='standards'&&method==='PATCH'){
        requirePermission(member.role,'network:standards:write');const b=await bodyObject(req);
        assert(typeof b.active==='boolean',400,'VALIDATION','active должен быть boolean');
        const branchId=member.branches[0]?.id;assert(branchId,403,'BRANCH_SCOPE','Нет доступных филиалов');
        return json(res,200,{standard:await store.updateNetworkStandard(branchContext(member,u.id,branchId),requiredUuid(parts[5],'standardId'),
          integerField(b.expectedRevision,'expectedRevision',1,1000000000),standardInput(b),b.active,requestKey(req))});
      }
      if(parts.length===6&&parts[4]==='network'&&parts[5]==='quality'&&method==='GET'){
        requirePermission(member.role,'network:audits:read');requirePermission(member.role,'network:standards:read');
        const standards=await store.networkStandards(orgId);
        const requested=requestUrl.searchParams.get('standardId');
        const standard=requested?standards.find(s=>s.id===requiredUuid(requested,'standardId'))||null:standards.find(s=>s.active)||null;
        assert(!requested||standard,404,'NOT_FOUND','Стандарт не найден');
        const branches=await Promise.all(member.branches.map(async b=>{
          const ctx=branchContext(member,u.id,b.id);
          const [audits,openActions]=await Promise.all([standard?store.branchAudits(ctx,standard.id):Promise.resolve([]),store.branchOpenActionCount(ctx)]);
          return {id:b.id,name:b.name,latest:audits[0]||null,openActions};
        }));
        return json(res,200,{quality:networkQuality(standard,branches),standards});
      }
      if(parts.length===6&&parts[4]==='network'&&parts[5]==='actions'&&method==='GET'){
        requirePermission(member.role,'network:actions:read');
        const actions=(await Promise.all(member.branches.map(async b=>(await store.branchCorrectiveActions(branchContext(member,u.id,b.id)))
          .map(a=>({...a,branchName:b.name}))))).flat();
        return json(res,200,{actions});
      }
      if(parts.length===6&&parts[4]==='finance'&&parts[5]==='overview'&&method==='GET'){
        requirePermission(member.role,'finance:read');
        const period=financePeriod(requestUrl.searchParams.get('period'));
        const branches=member.branches;
        const detailed=await Promise.all(branches.map(async b=>({id:b.id,name:b.name,
          report:await store.financeReport({userId:u.id,organizationId:orgId,branchId:b.id,role:member.role},period)})));
        return json(res,200,{overview:{period,currency:member.currency,branches:detailed,
          totals:consolidateReports(period,detailed.map(b=>b.report))}});
      }
      assert(parts.length>=7&&parts[4]==='branches',404,'NOT_FOUND','Маршрут не найден');
      const branchId=requiredUuid(parts[5],'branchId');
      const ctx=branchContext(member,u.id,branchId);
      const resource=parts[6];
      const itemId=parts[7];
      const action=parts[8];
      const secure=<T>(permission:Permission,fn:()=>Promise<T>)=>{requirePermission(ctx.role,permission);return fn();};
      if(resource==='integrations'){
        requirePermission(ctx.role,'integrations:read');
        assert(integrations,503,'INTEGRATIONS_DISABLED','Интеграции не настроены на сервере');
        const service=integrations;
        if(parts.length===7){
          if(method==='GET')return json(res,200,{connections:await service.repo.list(ctx)});
          if(method==='POST'){
            requirePermission(ctx.role,'integrations:manage');providerLimiter.check(`create:${ctx.userId}`);const b=await bodyObject(req);
            return json(res,201,{connection:await service.create(ctx,b,requestKey(req))});
          }
        }
        const connectionId=requiredUuid(itemId,'connectionId');
        if(parts.length===9&&action==='verify'&&method==='POST'){
          requirePermission(ctx.role,'integrations:manage');providerLimiter.check(`verify:${ctx.userId}:${connectionId}`);const b=await bodyObject(req);
          return json(res,200,{connection:await service.verify(ctx,connectionId,checkRevision(b.expectedRevision),requestKey(req))});
        }
        if(parts.length===9&&action==='rotate'&&method==='POST'){
          requirePermission(ctx.role,'integrations:manage');const b=await bodyObject(req);
          return json(res,200,{connection:await service.rotate(ctx,connectionId,checkRevision(b.expectedRevision),b,requestKey(req))});
        }
        if(parts.length===9&&action==='disable'&&method==='POST'){
          requirePermission(ctx.role,'integrations:manage');const b=await bodyObject(req);
          return json(res,200,{connection:await service.repo.transition(ctx,connectionId,checkRevision(b.expectedRevision),'DISABLE',{},requestKey(req))});
        }
        if(parts.length===9&&action==='menus'&&method==='GET'){
          providerLimiter.check(`menus:${ctx.userId}:${connectionId}`);
          return json(res,200,{menus:await service.menus(ctx,connectionId)});
        }
        if(parts.length===9&&action==='sync'&&method==='POST'){
          requirePermission(ctx.role,'integrations:manage');const b=await bodyObject(req);
          return json(res,202,{job:await service.repo.enqueue(ctx,connectionId,menuId(b.menuId),requestKey(req))});
        }
        if(parts.length===9&&action==='jobs'&&method==='GET')return json(res,200,{jobs:await service.repo.jobs(ctx,connectionId)});
        if(parts.length===9&&action==='catalog'&&method==='GET')return json(res,200,{items:await service.repo.catalog(ctx,connectionId)});
        if(parts.length===9&&action==='import'&&method==='POST'){
          requirePermission(ctx.role,'integrations:import');
          assert(member.currency==='RUB',409,'CURRENCY_MISMATCH','Импорт iiko доступен только для ресторанов с валютой RUB');
          const b=await bodyObject(req);
          return json(res,200,{result:await service.repo.importCatalog(ctx,connectionId,
            requiredUuid(b.sourceRunId,'sourceRunId'),selectedExternalIds(b.externalIds),requestKey(req))});
        }
      }
      if(resource==='audits'){
        if(parts.length===7&&method==='GET'){
          const standardId=requestUrl.searchParams.get('standardId');
          return json(res,200,{audits:await secure('network:audits:read',()=>store.branchAudits(ctx,standardId?requiredUuid(standardId,'standardId'):null))});
        }
        if(parts.length===7&&method==='POST'){
          requirePermission(ctx.role,'network:audits:write');const b=await bodyObject(req);
          assert(Array.isArray(b.answers)&&b.answers.length<=20,400,'AUDIT_INCOMPLETE','Неверный список ответов');
          return json(res,201,{audit:await store.submitBranchAudit(ctx,requiredUuid(b.standardId,'standardId'),
            integerField(b.expectedStandardRevision,'expectedStandardRevision',1,1000000000),b.answers as AuditAnswerInput[],requestKey(req))});
        }
      }
      if(resource==='corrective-actions'){
        if(parts.length===7&&method==='GET')return json(res,200,{actions:await secure('network:actions:read',()=>store.branchCorrectiveActions(ctx))});
        if(parts.length===9&&action==='status'&&method==='POST'){
          requirePermission(ctx.role,'network:actions:write');const b=await bodyObject(req);
          assert(['OPEN','IN_PROGRESS','RESOLVED'].includes(String(b.status)),400,'ACTION_STATUS','Неверный статус действия');
          return json(res,200,{action:await store.updateCorrectiveAction(ctx,requiredUuid(itemId,'actionId'),
            integerField(b.expectedRevision,'expectedRevision',1,1000000000),b.status as ActionStatus,
            b.resolution===null||b.resolution===undefined?null:textField(b.resolution,'resolution',1000,8),requestKey(req))});
        }
      }
      if(resource==='floor'&&parts.length===7&&method==='GET')return json(res,200,{tables:await secure('tables:read',()=>store.floor(ctx))});
      if(resource==='staff'&&parts.length===7&&method==='GET')return json(res,200,{staff:await secure('shifts:read',()=>store.staff(ctx))});
      if(resource==='shifts'){
        if(parts.length===7&&method==='GET')return json(res,200,{shifts:await secure('shifts:read',()=>store.shifts(ctx))});
        if(parts.length===7&&method==='POST'){
          requirePermission(ctx.role,'shifts:open');const b=await bodyObject(req);
          const worker=b.userId===undefined?u.id:requiredUuid(b.userId,'userId');
          return json(res,201,{shift:await store.openShift(ctx,worker,noteField(b.openingNote??'','openingNote'),requestKey(req))});
        }
        if(parts.length===9&&action==='close'&&method==='POST'){
          requirePermission(ctx.role,'shifts:open');const b=await bodyObject(req);
          return json(res,200,{shift:await store.closeShift(ctx,requiredUuid(itemId,'shiftId'),
            integerField(b.expectedRevision,'expectedRevision',1,1_000_000_000),noteField(b.closingNote??'','closingNote'),requestKey(req))});
        }
      }
      if(resource==='reservations'){
        if(parts.length===7&&method==='GET')return json(res,200,{reservations:await secure('reservations:read',()=>store.reservations(ctx))});
        if(parts.length===7&&method==='POST'){
          requirePermission(ctx.role,'reservations:write');const b=await bodyObject(req);
          const when=bookingWindow(b.startsAt,b.durationMinutes);
          const guest=reservationGuest(b.guestName,b.partySize);
          return json(res,201,{reservation:await store.createReservation(ctx,{tableId:requiredUuid(b.tableId,'tableId'),...guest,...when},requestKey(req))});
        }
        if(parts.length===9&&method==='POST'&&action==='status'){
          requirePermission(ctx.role,'reservations:write');const b=await bodyObject(req);
          assert(b.status==='CANCELLED'||b.status==='NO_SHOW',400,'VALIDATION','Допустимы CANCELLED и NO_SHOW');
          return json(res,200,{reservation:await store.changeReservation(ctx,requiredUuid(itemId,'reservationId'),
            b.status as ReservationAction,integerField(b.expectedRevision,'expectedRevision',1,1_000_000_000),requestKey(req))});
        }
        if(parts.length===9&&method==='POST'&&action==='seat'){
          requirePermission(ctx.role,'reservations:seat');const b=await bodyObject(req);
          return json(res,201,await store.seatReservation(ctx,requiredUuid(itemId,'reservationId'),
            integerField(b.expectedRevision,'expectedRevision',1,1_000_000_000),requestKey(req)));
        }
      }
      if(resource==='kitchen'&&parts.length===7&&method==='GET')return json(res,200,{tickets:await secure('kitchen:read',()=>store.kitchen(ctx))});
      if(resource==='ingredients'){
        if(parts.length===7&&method==='GET')return json(res,200,{ingredients:await secure('inventory:read',()=>store.ingredients(ctx))});
        if(parts.length===7&&method==='POST'){
          requirePermission(ctx.role,'inventory:write');const b=await bodyObject(req);
          return json(res,201,{ingredient:await store.createIngredient(ctx,textField(b.name,'name'),stockUnit(b.unit),
            stockQuantity(b.minQuantityMilli??0,'minQuantityMilli',true),requestKey(req))});
        }
        if(parts.length===9&&action==='minimum'&&method==='POST'){
          requirePermission(ctx.role,'inventory:write');const b=await bodyObject(req);
          return json(res,200,{ingredient:await store.setIngredientMinimum(ctx,requiredUuid(itemId,'ingredientId'),
            integerField(b.expectedRevision,'expectedRevision',1,1_000_000_000),stockQuantity(b.minQuantityMilli,'minQuantityMilli',true),requestKey(req))});
        }
        if(parts.length===9&&action==='count'&&method==='POST'){
          requirePermission(ctx.role,'inventory:write');const b=await bodyObject(req);
          return json(res,200,{count:await store.countStock(ctx,requiredUuid(itemId,'ingredientId'),
            stockQuantity(b.countedQuantityMilli,'countedQuantityMilli',true),integerField(b.expectedRevision,'expectedRevision',1,1_000_000_000),
            b.foundValueCents===undefined||b.foundValueCents===null?null:stockValue(b.foundValueCents,'foundValueCents'),requestKey(req))});
        }
      }
      if(resource==='recipes'&&parts.length===8){
        const id=requiredUuid(itemId,'menuItemId');
        if(method==='GET')return json(res,200,{recipe:await secure('recipes:read',()=>store.recipe(ctx,id))});
        if(method==='PUT'){
          requirePermission(ctx.role,'recipes:write');const b=await bodyObject(req);
          assert(Array.isArray(b.components)&&b.components.length<=60,400,'RECIPE_COMPONENTS','Неверный состав рецептуры');
          const components:RecipeComponentInput[]=recipeComponents(b.components.map(row=>{
            const c=object(row);return {ingredientId:requiredUuid(c.ingredientId,'ingredientId'),quantityMilli:stockQuantity(c.quantityMilli)};
          }));
          return json(res,200,{recipe:await store.saveRecipe(ctx,id,integerField(b.expectedRevision,'expectedRevision',0,1_000_000_000),components,requestKey(req))});
        }
      }
      if(resource==='suppliers'&&parts.length===7){
        if(method==='GET')return json(res,200,{suppliers:await secure('procurement:read',()=>store.suppliers(ctx))});
        if(method==='POST'){
          requirePermission(ctx.role,'procurement:write');const b=await bodyObject(req);
          return json(res,201,{supplier:await store.createSupplier(ctx,textField(b.name,'name'),requestKey(req))});
        }
      }
      if(resource==='receipts'&&parts.length===7){
        if(method==='GET')return json(res,200,{receipts:await secure('procurement:read',()=>store.receipts(ctx))});
        if(method==='POST'){
          requirePermission(ctx.role,'procurement:write');const b=await bodyObject(req);
          assert(Array.isArray(b.lines)&&b.lines.length<=50,400,'RECEIPT_LINES','Неверный список поступления');
          const lines:ReceiptLineInput[]=receiptLines(b.lines.map(row=>{const l=object(row);return {
            ingredientId:requiredUuid(l.ingredientId,'ingredientId'),quantityMilli:stockQuantity(l.quantityMilli),
            totalCostCents:stockValue(l.totalCostCents,'totalCostCents')};}));
          return json(res,201,{receipt:await store.receiveStock(ctx,b.supplierId===undefined||b.supplierId===null?null:requiredUuid(b.supplierId,'supplierId'),
            referenceField(b.reference),lines,requestKey(req))});
        }
      }
      if(resource==='stock-movements'&&parts.length===7&&method==='GET')
        return json(res,200,{movements:await secure('inventory:read',()=>store.stockMovements(ctx))});
      if(resource==='tasks'){
        if(parts.length===7&&method==='GET')return json(res,200,{tasks:await secure('tasks:read',()=>store.tasks(ctx))});
        if(parts.length===7&&method==='POST'){
          requirePermission(ctx.role,'tasks:write');const b=await bodyObject(req);
          return json(res,201,{task:await store.createTask(ctx,textField(b.title,'title'),
            b.description===undefined?'':textField(b.description,'description',1000,0),
            b.assignedTo===undefined||b.assignedTo===null||b.assignedTo===''?null:requiredUuid(b.assignedTo,'assignedTo'),
            taskDeadline(b.dueAt),requestKey(req))});
        }
        if(parts.length===9&&action==='status'&&method==='POST'){
          requirePermission(ctx.role,'tasks:status');const b=await bodyObject(req);
          assert(['OPEN','IN_PROGRESS','DONE','CANCELLED'].includes(String(b.status)),400,'TASK_STATUS','Неверный статус задачи');
          return json(res,200,{task:await store.changeTaskStatus(ctx,requiredUuid(itemId,'taskId'),b.status as TaskStatus,
            integerField(b.expectedRevision,'expectedRevision',1,1_000_000_000),requestKey(req))});
        }
      }
      if(resource==='intelligence'){
        const sub=parts[7];
        if(sub==='diagnosis'&&parts.length===8&&method==='GET'){
          return json(res,200,{diagnosis:await secure('intelligence:read',()=>store.intelligenceDiagnosis(ctx,financePeriod(requestUrl.searchParams.get('period'))))});
        }
        if(sub==='decisions'&&parts.length===8&&method==='GET'){
          return json(res,200,{decisions:await secure('intelligence:read',()=>store.intelligenceDecisions(ctx))});
        }
        if(sub==='decisions'&&parts.length===8&&method==='POST'){
          requirePermission(ctx.role,'intelligence:write');const b=await bodyObject(req);
          const input=decisionInput({title:b.title,hypothesis:b.hypothesis,action:b.action,implementationCostCents:b.implementationCostCents??null});
          return json(res,201,{decision:await store.createIntelligenceDecision(ctx,financePeriod(b.period),textField(b.signalId,'signalId',80),input,requestKey(req))});
        }
        if(sub==='decisions'&&parts.length===10&&parts[9]==='status'&&method==='POST'){
          requirePermission(ctx.role,'intelligence:write');const b=await bodyObject(req);
          assert(['IN_PROGRESS','IMPLEMENTED','REVIEWED','CANCELLED'].includes(String(b.status)),400,'DECISION_STATUS','Неверный статус');
          return json(res,200,{decision:await store.updateIntelligenceDecision(ctx,requiredUuid(parts[8],'decisionId'),
            integerField(b.expectedRevision,'expectedRevision',1,1000000000),b.status as DecisionStatus,
            b.reviewPeriod===undefined||b.reviewPeriod===null?null:financePeriod(b.reviewPeriod),
            b.observation===undefined||b.observation===null?null:textField(b.observation,'observation',1200,5),requestKey(req))});
        }
      }
      if(resource==='finance'){
        const sub=parts[7],id=parts[8],act=parts[9];
        if(sub==='report'&&parts.length===8&&method==='GET'){
          return json(res,200,{report:await secure('finance:read',()=>store.financeReport(ctx,financePeriod(requestUrl.searchParams.get('period'))))});
        }
        if(sub==='ledger'&&parts.length===8&&method==='GET'){
          return json(res,200,{entries:await secure('finance:read',()=>store.financeLedger(ctx,financePeriod(requestUrl.searchParams.get('period'))))});
        }
        if(sub==='expenses'){
          if(parts.length===8&&method==='GET'){
            return json(res,200,{expenses:await secure('finance:read',()=>store.financeExpenses(ctx,financePeriod(requestUrl.searchParams.get('period'))))});
          }
          if(parts.length===8&&method==='POST'){
            requirePermission(ctx.role,'finance:write');const b=await bodyObject(req);
            return json(res,201,{expense:await store.createFinanceExpense(ctx,{category:expenseCategory(b.category),
              description:textField(b.description,'description',500),
              amountCents:positiveFinanceAmount(b.amountCents),occurredOn:financeDate(b.occurredOn)},requestKey(req))});
          }
          if(parts.length===10&&act==='void'&&method==='POST'){
            requirePermission(ctx.role,'finance:void');const b=await bodyObject(req);
            return json(res,200,{expense:await store.voidFinanceExpense(ctx,requiredUuid(id,'expenseId'),
              integerField(b.expectedRevision,'expectedRevision',1,1000000000),textField(b.reason,'reason',500,3),requestKey(req))});
          }
        }
        if(sub==='budgets'){
          if(parts.length===8&&method==='GET'){
            return json(res,200,{budgets:await secure('finance:read',()=>store.financeBudgets(ctx,financePeriod(requestUrl.searchParams.get('period'))))});
          }
          if(parts.length===9&&method==='PUT'){
            requirePermission(ctx.role,'finance:budget');const b=await bodyObject(req);
            return json(res,200,{budget:await store.saveFinanceBudget(ctx,financePeriod(b.period),budgetCategory(id),
              financeAmount(b.amountCents),integerField(b.expectedRevision,'expectedRevision',0,1000000000),requestKey(req))});
          }
        }
      }
      if(resource==='guests'){
        if(parts.length===7&&method==='GET')return json(res,200,await secure('guests:read',()=>store.guests(ctx,
          requestUrl.searchParams.has('after')?requiredUuid(requestUrl.searchParams.get('after'),'after'):null)));
        if(parts.length===7&&method==='POST'){
          requirePermission(ctx.role,'guests:write');const b=await bodyObject(req);
          return json(res,201,{guest:await store.createGuest(ctx,guestInput({displayName:b.displayName,email:b.email,phone:b.phone}),requestKey(req))});
        }
        if(parts.length===8&&method==='PATCH'){
          requirePermission(ctx.role,'guests:write');const b=await bodyObject(req);
          return json(res,200,{guest:await store.updateGuest(ctx,requiredUuid(itemId,'guestId'),integerField(b.expectedRevision,'expectedRevision',1,1000000000),
            guestInput({displayName:b.displayName,email:b.email,phone:b.phone}),requestKey(req))});
        }
        if(parts.length===8&&method==='DELETE'){
          requirePermission(ctx.role,'guests:erase');const b=await bodyObject(req);
          return json(res,200,{result:await store.eraseGuest(ctx,requiredUuid(itemId,'guestId'),integerField(b.expectedRevision,'expectedRevision',1,1000000000),requestKey(req))});
        }
        if(parts.length===9&&action==='visits'&&method==='GET')
          return json(res,200,{visits:await secure('guests:read',()=>store.guestVisits(ctx,requiredUuid(itemId,'guestId')))});
        if(parts.length===9&&action==='consents'&&method==='GET')
          return json(res,200,{consents:await secure('guests:read',()=>store.guestConsents(ctx,requiredUuid(itemId,'guestId')))});
        if(parts.length===10&&action==='consents'&&method==='PUT'){
          requirePermission(ctx.role,'guests:consent');const b=await bodyObject(req);const state=consentState(b.state);
          return json(res,200,{consent:await store.saveGuestConsent(ctx,requiredUuid(itemId,'guestId'),consentChannel(parts[9]),state,
            consentEvidence(state,b.evidence),integerField(b.expectedRevision,'expectedRevision',0,1000000000),requestKey(req))});
        }
      }
      if(resource==='guest-insights'&&parts.length===7&&method==='GET'){
        requirePermission(ctx.role,'guests:analytics');
        const result=await store.guestInsights(ctx);
        // Auditors/analysts see aggregated facts, never guest-level IDs that enable correlation.
        return json(res,200,{insights:can(ctx.role,'guests:read')?result:{...result,guests:[]}});
      }
      if(resource==='feedback'){
        if(parts.length===7&&method==='GET')return json(res,200,{feedback:await secure('feedback:read',()=>store.guestFeedback(ctx))});
        if(parts.length===7&&method==='POST'){
          requirePermission(ctx.role,'feedback:write');const b=await bodyObject(req);
          return json(res,201,{feedback:await store.createGuestFeedback(ctx,feedbackInput(b,isUuid),requestKey(req))});
        }
        if(parts.length===9&&action==='resolve'&&method==='POST'){
          requirePermission(ctx.role,'feedback:resolve');const b=await bodyObject(req);
          return json(res,200,{feedback:await store.resolveGuestFeedback(ctx,requiredUuid(itemId,'feedbackId'),
            integerField(b.expectedRevision,'expectedRevision',1,1000000000),textField(b.resolution,'resolution',1000,5),requestKey(req))});
        }
      }
      if(resource==='dashboard'&&parts.length===7&&method==='GET')return json(res,200,{dashboard:await secure('dashboard:read',()=>store.dashboard(ctx))});
      if(resource==='menu'){
        if(parts.length===7&&method==='GET')return json(res,200,{items:await secure('menu:read',()=>store.menu(ctx))});
        if(parts.length===7&&method==='POST'){
          requirePermission(ctx.role,'menu:write');const b=await bodyObject(req);
          return json(res,201,{item:await store.addMenuItem(ctx,textField(b.name,'name'),moneyCents(b.priceCents))});
        }
        if(parts.length===8&&method==='PATCH'){
          requirePermission(ctx.role,'menu:write');const id=requiredUuid(itemId,'itemId');const b=await bodyObject(req);
          const patch:{name?:string;priceCents?:number;active?:boolean}={};
          if(b.name!==undefined)patch.name=textField(b.name,'name');
          if(b.priceCents!==undefined)patch.priceCents=moneyCents(b.priceCents);
          if(b.active!==undefined){assert(typeof b.active==='boolean',400,'VALIDATION','active должен быть boolean');patch.active=b.active;}
          return json(res,200,{item:await store.updateMenuItem(ctx,id,integerField(b.revision,'revision',1,1_000_000_000),patch)});
        }
      }
      if(resource==='tables'&&parts.length===7){
        if(method==='GET')return json(res,200,{tables:await secure('tables:read',()=>store.tables(ctx))});
        if(method==='POST'){
          requirePermission(ctx.role,'tables:write');const b=await bodyObject(req);
          return json(res,201,{table:await store.addTable(ctx,textField(b.label,'label',30),integerField(b.capacity,'capacity',1,40))});
        }
      }
      if(resource==='orders'){
        if(parts.length===7&&method==='GET')return json(res,200,{orders:await secure('orders:read',()=>store.orders(ctx))});
        if(parts.length===7&&method==='POST'){
          requirePermission(ctx.role,'orders:create');const b=await bodyObject(req);
          return json(res,201,{order:await store.createOrder(ctx,optionalUuid(b.tableId??null,'tableId'),requestKey(req))});
        }
        if(parts.length===9&&method==='POST'){
          const id=requiredUuid(itemId,'orderId');const b=await bodyObject(req);const key=requestKey(req);
          if(action==='guest'){
            requirePermission(ctx.role,'orders:link_guest');
            return json(res,200,{order:await store.linkOrderGuest(ctx,id,
              b.guestId===null?null:requiredUuid(b.guestId,'guestId'),
              integerField(b.expectedRevision,'expectedRevision',1,1000000000),key)});
          }
          if(action==='items'){
            requirePermission(ctx.role,'orders:add');
            return json(res,200,{order:await store.addOrderItem(ctx,id,requiredUuid(b.menuItemId,'menuItemId'),integerField(b.quantity,'quantity',1,30),integerField(b.expectedRevision,'expectedRevision',1,1_000_000_000),key)});
          }
          if(action==='status'){
            requirePermission(ctx.role,'orders:advance');
            assert(typeof b.status==='string'&&['OPEN','SENT','PREPARING','READY','COMPLETED','CANCELLED'].includes(b.status),400,'VALIDATION','Неверный статус');
            return json(res,200,{order:await store.changeOrderStatus(ctx,id,b.status as OrderStatus,integerField(b.expectedRevision,'expectedRevision',1,1_000_000_000),key)});
          }
        }
      }
      throw new AppError(404,'NOT_FOUND','Маршрут не найден');
    } catch(error){
      const e=error instanceof AppError?error:new AppError(500,'INTERNAL','Внутренняя ошибка сервера');
      if(e.status>=500)console.error('[API]',error);
      if(!res.headersSent)json(res,e.status,{error:{code:e.code,message:e.message}});
    }
  });
}
