import {AppError,assert,integerField,textField} from './rules.ts';

export const STOCK_UNITS=['g','ml','pcs'] as const;
export type StockUnit=typeof STOCK_UNITS[number];
export type TaskStatus='OPEN'|'IN_PROGRESS'|'DONE'|'CANCELLED';
export interface RecipeComponentInput {ingredientId:string;quantityMilli:number;}
export interface ReceiptLineInput {ingredientId:string;quantityMilli:number;totalCostCents:number;}
export const STOCK_LIMIT=999_999_999_999;
export const VALUE_LIMIT=9_999_999_999_999;

export function stockQuantity(value:unknown,label='quantityMilli',zero=false):number{
  return integerField(value,label,zero?0:1,STOCK_LIMIT);
}
export function stockValue(value:unknown,label='totalCostCents'):number{
  return integerField(value,label,0,VALUE_LIMIT);
}
export function stockUnit(value:unknown):StockUnit{
  assert(typeof value==='string' && STOCK_UNITS.includes(value as StockUnit),400,'STOCK_UNIT','Единица должна быть g, ml или pcs');
  return value as StockUnit;
}
export function recipeComponents<T extends {ingredientId:string;quantityMilli:number}>(rows:T[]):T[]{
  assert(rows.length>=1&&rows.length<=60,400,'RECIPE_COMPONENTS','Рецептура должна содержать от 1 до 60 ингредиентов');
  assert(new Set(rows.map(r=>r.ingredientId)).size===rows.length,400,'RECIPE_DUPLICATE','Один ингредиент не должен повторяться в рецептуре');
  for(const r of rows)stockQuantity(r.quantityMilli);
  return rows;
}
export function receiptLines<T extends {ingredientId:string;quantityMilli:number;totalCostCents:number}>(rows:T[]):T[]{
  assert(rows.length>=1&&rows.length<=50,400,'RECEIPT_LINES','Поступление должно содержать от 1 до 50 позиций');
  assert(new Set(rows.map(r=>r.ingredientId)).size===rows.length,400,'RECEIPT_DUPLICATE','Ингредиенты поступления не должны повторяться');
  for(const r of rows){stockQuantity(r.quantityMilli);stockValue(r.totalCostCents);}
  const total=rows.reduce((s,r)=>s+BigInt(r.totalCostCents),0n);
  assert(total<=BigInt(VALUE_LIMIT),400,'AMOUNT_TOO_LARGE','Общая сумма поступления слишком велика');
  return rows;
}
// Integer proportional moving-average allocation, half-up rounding. Never use IEEE-754 division for money.
export function costOfIssue(onHandMilli:number,onHandValueCents:number,issuedMilli:number):number{
  stockQuantity(onHandMilli,'onHandMilli',true);
  stockValue(onHandValueCents,'onHandValueCents');
  stockQuantity(issuedMilli,'issuedMilli');
  assert(onHandMilli>=issuedMilli,409,'STOCK_SHORTAGE','Недостаточно ингредиента на складе');
  if(issuedMilli===onHandMilli)return onHandValueCents;
  const num=BigInt(onHandValueCents)*BigInt(issuedMilli);
  return Number((num+BigInt(onHandMilli)/2n)/BigInt(onHandMilli));
}
export function addStock(onHandMilli:number,onHandCents:number,quantityMilli:number,valueCents:number){
  const quantity=BigInt(onHandMilli)+BigInt(stockQuantity(quantityMilli));
  const value=BigInt(onHandCents)+BigInt(stockValue(valueCents));
  assert(quantity<=BigInt(STOCK_LIMIT)&&value<=BigInt(VALUE_LIMIT),409,'STOCK_LIMIT','Превышен предел складского остатка');
  return {quantityMilli:Number(quantity),valueCents:Number(value)};
}
export function countVariance(onHandMilli:number,onHandCents:number,countedMilli:number,foundValueCents:number|null){
  stockQuantity(countedMilli,'countedQuantityMilli',true);
  assert(countedMilli<=STOCK_LIMIT,400,'VALIDATION','Превышен лимит остатка');
  const deltaMilli=countedMilli-onHandMilli;
  if(deltaMilli===0)return {deltaMilli:0,deltaValueCents:0};
  if(deltaMilli<0)return {deltaMilli,deltaValueCents:-costOfIssue(onHandMilli,onHandCents,-deltaMilli)};
  assert(foundValueCents!==null,400,'COUNT_GAIN_VALUE','Для излишка укажите фактическую стоимость найденного товара');
  stockValue(foundValueCents,'foundValueCents');
  addStock(onHandMilli,onHandCents,deltaMilli,foundValueCents);
  return {deltaMilli,deltaValueCents:foundValueCents};
}
export function taskDeadline(input:unknown):string|null{
  if(input===null || input===undefined || input==='')return null;
  assert(typeof input==='string'&&/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?Z$/.test(input),400,'TASK_DATE','Срок должен быть в UTC ISO 8601');
  const ms=Date.parse(input);
  assert(Number.isFinite(ms)&&ms>Date.now()-86400000&&ms<Date.now()+2*365*86400000,400,'TASK_DATE','Срок задачи должен быть в допустимом периоде');
  return new Date(ms).toISOString();
}
export function taskStatusTransition(from:TaskStatus,to:TaskStatus,manager:boolean){
  const allowed:Record<TaskStatus,TaskStatus[]>={OPEN:['IN_PROGRESS','DONE','CANCELLED'],IN_PROGRESS:['DONE','CANCELLED'],DONE:[],CANCELLED:[]};
  assert(allowed[from]?.includes(to),409,'TASK_TRANSITION','Недопустимый статус задачи');
  assert(manager || to!=='CANCELLED',403,'FORBIDDEN','Отмена задачи доступна руководителю');
}
export const referenceField=(value:unknown):string=> value===undefined||value===null||value===''?'':textField(value,'reference',100);
