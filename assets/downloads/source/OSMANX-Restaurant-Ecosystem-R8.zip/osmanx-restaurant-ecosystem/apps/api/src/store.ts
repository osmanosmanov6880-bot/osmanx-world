import type {StandardInput,NetworkStandard,AuditAnswerInput,BranchAudit,CorrectiveAction,ActionStatus} from './domain/network.ts';
import type {Diagnosis,Decision,DecisionStatus} from './domain/intelligence.ts';
import type {Role, OrderStatus} from './domain/rules.ts';
import type {ReservationAction,ReservationStatus} from './domain/operations.ts';
import type {StockUnit,TaskStatus,RecipeComponentInput,ReceiptLineInput} from './domain/inventory.ts';
import type {Expense,ExpenseCategory,Budget,BudgetCategory,FinanceReport,LedgerEntry} from './domain/finance.ts';
import type {Guest,GuestInput,Consent,ConsentChannel,ConsentState,GuestVisit,GuestFeedback,GuestFeedbackInput,GuestInsights} from './domain/guests.ts';

export interface User { id:string; email:string; displayName:string; passwordHash:string; }
export interface Membership { organizationId:string; organizationName:string; currency:string; role:Role; branches:{id:string;name:string;timezone:string}[]; }
export interface Authenticated { user:User; memberships:Membership[]; tokenHash:string; }
export interface Branch { id:string; name:string; timezone:string; }
export interface MenuItem {id:string; name:string; priceCents:number; active:boolean; revision:number;}
export interface DiningTable {id:string; label:string; capacity:number;}
export interface OrderLine {id:string; menuItemId:string; name:string; unitPriceCents:number; quantity:number; lineTotalCents:number;}
export interface Order {id:string; guestId:string|null; tableId:string|null; status:OrderStatus; totalCents:number; revision:number; createdAt:string; items:OrderLine[]; actualFoodCostCents:number|null; missingRecipeLines:number|null; foodCostComplete:boolean;}
export interface Reservation {id:string;tableId:string;guestName:string;partySize:number;startsAt:string;endsAt:string;status:ReservationStatus;revision:number;orderId:string|null;createdAt:string;}
export interface ReservationInput {tableId:string;guestName:string;partySize:number;startsAt:string;endsAt:string;}
export interface Seated {reservation:Reservation;order:Order;}
export interface KitchenTicket {id:string;tableId:string|null;status:'SENT'|'PREPARING'|'READY';sentAt:string|null;preparingAt:string|null;readyAt:string|null;revision:number;items:OrderLine[];}
export interface Employee {id:string;displayName:string;role:Role;}
export interface Shift {id:string;userId:string;employeeName:string;status:'OPEN'|'CLOSED';openedAt:string;closedAt:string|null;openingNote:string;closingNote:string;revision:number;}
export interface FloorTable extends DiningTable {state:'AVAILABLE'|'OCCUPIED'|'RESERVED';activeOrderId:string|null;nextReservationAt:string|null;reservationId:string|null;}
export interface Ingredient {id:string;name:string;unit:StockUnit;minQuantityMilli:number;quantityMilli:number;valueCents:number;revision:number;lowStock:boolean;}
export interface RecipeComponent extends RecipeComponentInput {name:string;unit:StockUnit;}
export interface Recipe {menuItemId:string;revision:number;components:RecipeComponent[];}
export interface Supplier {id:string;name:string;}
export interface Receipt {id:string;supplierId:string|null;reference:string;totalCostCents:number;receivedAt:string;lines:(ReceiptLineInput & {name:string})[];}
export interface StockMovement {id:string;ingredientId:string;ingredientName:string;deltaQuantityMilli:number;deltaValueCents:number;reason:'RECEIPT'|'ORDER'|'COUNT';createdAt:string;sourceId:string;}
export interface StockCount {id:string;ingredientId:string;beforeQuantityMilli:number;countedQuantityMilli:number;deltaQuantityMilli:number;deltaValueCents:number;}
export interface RestaurantTask {id:string;title:string;description:string;assignedTo:string|null;employeeName:string|null;createdBy:string;status:TaskStatus;dueAt:string|null;completedAt:string|null;revision:number;createdAt:string;}
export interface Ctx {userId:string; organizationId:string; branchId:string; role:Role;}
export interface Store {
  networkStandards(organizationId:string):Promise<NetworkStandard[]>;
  createNetworkStandard(ctx:Ctx,input:StandardInput,key:string):Promise<NetworkStandard>;
  updateNetworkStandard(ctx:Ctx,id:string,expectedRevision:number,input:StandardInput,active:boolean,key:string):Promise<NetworkStandard>;
  branchAudits(ctx:Ctx,standardId:string|null):Promise<BranchAudit[]>;
  submitBranchAudit(ctx:Ctx,standardId:string,expectedStandardRevision:number,answers:AuditAnswerInput[],key:string):Promise<BranchAudit>;
  branchCorrectiveActions(ctx:Ctx):Promise<CorrectiveAction[]>;
  branchOpenActionCount(ctx:Ctx):Promise<number>;
  updateCorrectiveAction(ctx:Ctx,id:string,expectedRevision:number,status:ActionStatus,resolution:string|null,key:string):Promise<CorrectiveAction>;
  ready():Promise<boolean>;
  bootstrap(args:{email:string;displayName:string;passwordHash:string;organizationName:string;branchName:string}):Promise<{user:User;organizationId:string;branchId:string}>;
  findUser(email:string):Promise<User|null>;
  createSession(userId:string,tokenHash:string):Promise<void>;
  getSession(tokenHash:string):Promise<User|null>;
  deleteSession(tokenHash:string):Promise<void>;
  memberships(userId:string):Promise<Membership[]>;
  branches(organizationId:string):Promise<Branch[]>;
  createBranch(organizationId:string,actorId:string,name:string,timezone:string):Promise<Branch>;
  createInvitation(organizationId:string,actorId:string,email:string,role:Role,branchIds:string[],tokenHash:string):Promise<void>;
  acceptInvitation(tokenHash:string,email:string,displayName:string,passwordHash:string):Promise<User>;
  menu(ctx:Ctx):Promise<MenuItem[]>;
  addMenuItem(ctx:Ctx,name:string,priceCents:number):Promise<MenuItem>;
  updateMenuItem(ctx:Ctx,itemId:string,revision:number,patch:{name?:string;priceCents?:number;active?:boolean}):Promise<MenuItem>;
  tables(ctx:Ctx):Promise<DiningTable[]>;
  addTable(ctx:Ctx,label:string,capacity:number):Promise<DiningTable>;
  floor(ctx:Ctx):Promise<FloorTable[]>;
  reservations(ctx:Ctx):Promise<Reservation[]>;
  createReservation(ctx:Ctx,input:ReservationInput,key:string):Promise<Reservation>;
  changeReservation(ctx:Ctx,reservationId:string,to:ReservationAction,expectedRevision:number,key:string):Promise<Reservation>;
  seatReservation(ctx:Ctx,reservationId:string,expectedRevision:number,key:string):Promise<Seated>;
  kitchen(ctx:Ctx):Promise<KitchenTicket[]>;
  staff(ctx:Ctx):Promise<Employee[]>;
  shifts(ctx:Ctx):Promise<Shift[]>;
  openShift(ctx:Ctx,userId:string,openingNote:string,key:string):Promise<Shift>;
  closeShift(ctx:Ctx,shiftId:string,expectedRevision:number,closingNote:string,key:string):Promise<Shift>;
  ingredients(ctx:Ctx):Promise<Ingredient[]>;
  createIngredient(ctx:Ctx,name:string,unit:StockUnit,minQuantityMilli:number,key:string):Promise<Ingredient>;
  setIngredientMinimum(ctx:Ctx,ingredientId:string,expectedRevision:number,minQuantityMilli:number,key:string):Promise<Ingredient>;
  recipe(ctx:Ctx,menuItemId:string):Promise<Recipe|null>;
  saveRecipe(ctx:Ctx,menuItemId:string,expectedRevision:number,components:RecipeComponentInput[],key:string):Promise<Recipe>;
  suppliers(ctx:Ctx):Promise<Supplier[]>;
  createSupplier(ctx:Ctx,name:string,key:string):Promise<Supplier>;
  receipts(ctx:Ctx):Promise<Receipt[]>;
  receiveStock(ctx:Ctx,supplierId:string|null,reference:string,lines:ReceiptLineInput[],key:string):Promise<Receipt>;
  countStock(ctx:Ctx,ingredientId:string,countedQuantityMilli:number,expectedRevision:number,foundValueCents:number|null,key:string):Promise<StockCount>;
  stockMovements(ctx:Ctx):Promise<StockMovement[]>;
  tasks(ctx:Ctx):Promise<RestaurantTask[]>;
  createTask(ctx:Ctx,title:string,description:string,assignedTo:string|null,dueAt:string|null,key:string):Promise<RestaurantTask>;
  changeTaskStatus(ctx:Ctx,taskId:string,to:TaskStatus,expectedRevision:number,key:string):Promise<RestaurantTask>;
  financeExpenses(ctx:Ctx,period:string):Promise<Expense[]>;
  createFinanceExpense(ctx:Ctx,input:{category:ExpenseCategory;description:string;amountCents:number;occurredOn:string},key:string):Promise<Expense>;
  voidFinanceExpense(ctx:Ctx,id:string,expectedRevision:number,reason:string,key:string):Promise<Expense>;
  financeBudgets(ctx:Ctx,period:string):Promise<Budget[]>;
  saveFinanceBudget(ctx:Ctx,period:string,category:BudgetCategory,amountCents:number,expectedRevision:number,key:string):Promise<Budget>;
  financeReport(ctx:Ctx,period:string):Promise<FinanceReport>;
  financeLedger(ctx:Ctx,period:string):Promise<LedgerEntry[]>;
  guests(ctx:Ctx,after:string|null):Promise<{guests:Guest[];nextCursor:string|null}>;
  createGuest(ctx:Ctx,input:GuestInput,key:string):Promise<Guest>;
  updateGuest(ctx:Ctx,id:string,revision:number,input:GuestInput,key:string):Promise<Guest>;
  eraseGuest(ctx:Ctx,id:string,revision:number,key:string):Promise<{guestId:string;erased:true}>;
  guestVisits(ctx:Ctx,guestId:string):Promise<GuestVisit[]>;
  guestConsents(ctx:Ctx,guestId:string):Promise<Consent[]>;
  saveGuestConsent(ctx:Ctx,guestId:string,channel:ConsentChannel,state:ConsentState,evidence:string|null,expectedRevision:number,key:string):Promise<Consent>;
  linkOrderGuest(ctx:Ctx,orderId:string,guestId:string|null,expectedRevision:number,key:string):Promise<Order>;
  guestInsights(ctx:Ctx):Promise<GuestInsights>;
  guestFeedback(ctx:Ctx):Promise<GuestFeedback[]>;
  createGuestFeedback(ctx:Ctx,input:GuestFeedbackInput,key:string):Promise<GuestFeedback>;
  resolveGuestFeedback(ctx:Ctx,id:string,expectedRevision:number,resolution:string,key:string):Promise<GuestFeedback>;
  intelligenceDiagnosis(ctx:Ctx,period:string):Promise<Diagnosis>;
  intelligenceDecisions(ctx:Ctx):Promise<Decision[]>;
  createIntelligenceDecision(ctx:Ctx,period:string,signalId:string,input:{title:string;hypothesis:string;action:string;implementationCostCents:number|null},key:string):Promise<Decision>;
  updateIntelligenceDecision(ctx:Ctx,id:string,expectedRevision:number,status:DecisionStatus,reviewPeriod:string|null,observationText:string|null,key:string):Promise<Decision>;
  orders(ctx:Ctx):Promise<Order[]>;
  createOrder(ctx:Ctx,tableId:string|null,key:string):Promise<Order>;
  addOrderItem(ctx:Ctx,orderId:string,itemId:string,quantity:number,expectedRevision:number,key:string):Promise<Order>;
  changeOrderStatus(ctx:Ctx,orderId:string,to:OrderStatus,expectedRevision:number,key:string):Promise<Order>;
  dashboard(ctx:Ctx):Promise<{lowStockCount:number;revenueCents:number;completedOrders:number;averageCheckCents:number;activeOrders:number;menuItems:number;tables:number;series:{day:string;revenueCents:number}[];recentOrders:Order[]}>;
  close?():Promise<void>;
}
