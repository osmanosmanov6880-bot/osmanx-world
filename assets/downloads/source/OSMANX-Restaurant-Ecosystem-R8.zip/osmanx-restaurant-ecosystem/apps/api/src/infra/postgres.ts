import {PgIntegrationRepository} from '../integrations/postgres-repository.ts';
import {auditAnswers,withCriterionIds,actionTransition,type NetworkStandard,type StandardInput,type BranchAudit,type AuditAnswerInput,type CorrectiveAction,type ActionStatus} from '../domain/network.ts';
import {evaluate,previousPeriod,transition,observation,reviewPeriodAllowed,type Diagnosis,type Decision,type DecisionStatus} from '../domain/intelligence.ts';
import {sha256} from './security.ts';
import {AppError, assert, can, requireTransition} from '../domain/rules.ts';
import type {Role,OrderStatus} from '../domain/rules.ts';
import {requireReservationAction,requireSeatDate,sameTableCapacity,managesShifts,requireShiftActor} from '../domain/operations.ts';
import type {ReservationAction} from '../domain/operations.ts';
import {costOfIssue,addStock,countVariance,recipeComponents,receiptLines,taskStatusTransition,STOCK_LIMIT,VALUE_LIMIT} from '../domain/inventory.ts';
import type {StockUnit,RecipeComponentInput,ReceiptLineInput,TaskStatus} from '../domain/inventory.ts';
import type {Store,User,Membership,Branch,Ctx,MenuItem,DiningTable,Order,Reservation,ReservationInput,Seated,KitchenTicket,Shift,FloorTable,Employee,Ingredient,Recipe,Supplier,Receipt,StockCount,StockMovement,RestaurantTask} from '../store.ts';
import {calculateFinanceReport,centsSum,financeDate,financePeriod} from '../domain/finance.ts';
import type {Expense,ExpenseCategory,Budget,BudgetCategory,FinanceFacts,FinanceReport,LedgerEntry} from '../domain/finance.ts';
import {calculateGuestInsights} from '../domain/guests.ts';
import type {Guest,GuestInput,Consent,ConsentChannel,ConsentState,GuestVisit,GuestFeedback,GuestFeedbackInput,GuestInsights} from '../domain/guests.ts';

type Row=Record<string,any>;
type DB = {query:(sql:string,params?:unknown[])=>Promise<{rows:Row[];rowCount:number|null}>};
type PoolLike=DB & {connect:()=>Promise<DB & {release:()=>void}>;end:()=>Promise<void>};
const n=(val:unknown):number=>{
  assert(val!==null&&val!==undefined&&val!=='',500,'INTEGRITY','Отсутствует обязательное денежное значение в БД');
  const parsed=typeof val==='number'?val:Number(val);
  assert(Number.isSafeInteger(parsed),500,'INTEGRITY','Недопустимое денежное значение в БД');
  return parsed;
};
const user=(r:Row):User=>({id:r.id,email:r.email,displayName:r.display_name,passwordHash:r.password_hash});
const branch=(r:Row):Branch=>({id:r.id,name:r.name,timezone:r.timezone});
const menuItem=(r:Row):MenuItem=>({id:r.id,name:r.name,priceCents:n(r.price_cents),active:r.active,revision:r.revision});
const table=(r:Row):DiningTable=>({id:r.id,label:r.label,capacity:r.capacity});
const reservation=(r:Row):Reservation=>({id:r.id,tableId:r.table_id,guestName:r.guest_name,partySize:r.party_size,
  startsAt:new Date(r.starts_at).toISOString(),endsAt:new Date(r.ends_at).toISOString(),status:r.status,revision:r.revision,
  orderId:r.order_id||null,createdAt:new Date(r.created_at).toISOString()});
const shift=(r:Row):Shift=>({id:r.id,userId:r.user_id,employeeName:r.display_name,status:r.status,
  openedAt:new Date(r.opened_at).toISOString(),closedAt:r.closed_at?new Date(r.closed_at).toISOString():null,
  openingNote:r.opening_note,closingNote:r.closing_note,revision:r.revision});
const order=(r:Row):Order=>({
  id:r.id,guestId:r.guest_id??null,tableId:r.table_id,status:r.status,totalCents:n(r.total_cents),revision:r.revision,
  createdAt:new Date(r.created_at).toISOString(),
  actualFoodCostCents:r.costed_at?n(r.actual_food_cost_cents):null,missingRecipeLines:r.recipe_missing_lines??null,
  foodCostComplete:!!r.costed_at && r.recipe_missing_lines===0,
  items:(r.items||[]).map((i:Row)=>({id:i.id,menuItemId:i.menu_item_id,name:i.name,unitPriceCents:n(i.unit_price_cents),quantity:i.quantity,lineTotalCents:n(i.line_total_cents)}))
});
function friendlyDBError(e:unknown):never {
  if (e instanceof AppError) throw e;
  const err=e as {code?:string;constraint?:string};
  if(err?.code==='23P01') throw new AppError(409,'RESERVATION_CONFLICT','Стол уже забронирован на выбранное время');
  if(err?.code==='23505') throw new AppError(409,'DUPLICATE',err.constraint==='one_active_order_per_table_idx'?'У этого стола уже есть незакрытый заказ':err.constraint==='one_open_shift_per_worker_idx'?'У сотрудника уже открыта смена':'Такая запись уже существует');
  if(err?.code==='23503') throw new AppError(409,'FOREIGN_KEY','Связанная запись не существует или не принадлежит филиалу');
  if(err?.code==='23514'||err?.code==='22P02') throw new AppError(400,'VALIDATION','Некорректные данные');
  throw e;
}
export class PostgresStore implements Store {
  private pool:PoolLike;
  constructor(pool:PoolLike){this.pool=pool;}
  integrationRepository(){return new PgIntegrationRepository(this.pool);}
  async close(){await this.pool.end();}
  async ready(){try{await this.pool.query('SELECT 1');return true;}catch{return false;}}
  private async transaction<T>(fn:(db:DB)=>Promise<T>):Promise<T>{
    const client=await this.pool.connect();
    try {await client.query('BEGIN');const result=await fn(client);await client.query('COMMIT');return result;}
    catch(e){await client.query('ROLLBACK');friendlyDBError(e);}
    finally{client.release();}
  }
  private async readSnapshot<T>(fn:(db:DB)=>Promise<T>):Promise<T>{
    const client=await this.pool.connect();
    try{
      await client.query('BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY');
      const result=await fn(client);
      await client.query('COMMIT');
      return result;
    }catch(e){await client.query('ROLLBACK');friendlyDBError(e);}
    finally{client.release();}
  }
  private async audit(db:DB,ctx:{organizationId:string;branchId?:string|null;userId:string},action:string,type:string,entityId:string,metadata:Row={}){
    await db.query(`INSERT INTO audit_events(organization_id,branch_id,actor_id,action,entity_type,entity_id,metadata) VALUES($1,$2,$3,$4,$5,$6,$7)`,
      [ctx.organizationId,ctx.branchId||null,ctx.userId,action,type,entityId,JSON.stringify(metadata)]);
  }
  private standardRow(r:Row):NetworkStandard{
    return {id:r.id,title:r.title,description:r.description,active:r.active,revision:r.revision,
      criteria:r.criteria as NetworkStandard['criteria'],createdAt:new Date(r.created_at).toISOString(),updatedAt:new Date(r.updated_at).toISOString()};
  }
  private networkAuditRow(r:Row):BranchAudit{
    return {id:r.id,branchId:r.branch_id,standardId:r.standard_id,standardTitle:r.standard_title,standardRevision:r.standard_revision,
      scoreBps:r.score_bps,failedCount:r.failed_count,criticalFailures:r.critical_failures,
      answers:r.answers as BranchAudit['answers'],performedAt:new Date(r.performed_at).toISOString(),performedBy:r.performed_by};
  }
  private networkActionRow(r:Row):CorrectiveAction{
    return {id:r.id,branchId:r.branch_id,auditId:r.audit_id,standardId:r.standard_id,standardRevision:r.standard_revision,criterionId:r.criterion_id,
      title:r.title,status:r.status,revision:r.revision,createdAt:new Date(r.created_at).toISOString(),
      updatedAt:new Date(r.updated_at).toISOString(),resolution:r.resolution};
  }
  private async networkCommand<T>(ctx:Ctx,key:string,fingerprint:string,run:(db:DB)=>Promise<T>):Promise<T>{
    return this.transaction(async db=>{
      await db.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',[`${ctx.organizationId}:${ctx.userId}:${key}`]);
      const existing=(await db.query(`SELECT fingerprint,result FROM network_commands WHERE organization_id=$1 AND actor_id=$2 AND idempotency_key=$3`,
        [ctx.organizationId,ctx.userId,key])).rows[0];
      if(existing){assert(existing.fingerprint===fingerprint,409,'IDEMPOTENCY_CONFLICT','Конфликт ключа');return existing.result as T;}
      const result=await run(db);
      await db.query(`INSERT INTO network_commands(organization_id,actor_id,idempotency_key,fingerprint,result) VALUES($1,$2,$3,$4,$5)`,
        [ctx.organizationId,ctx.userId,key,fingerprint,JSON.stringify(result)]);
      return result;
    });
  }
  async networkStandards(organizationId:string):Promise<NetworkStandard[]>{
    const q=await this.pool.query(`SELECT * FROM network_standards WHERE organization_id=$1 ORDER BY title,id LIMIT 200`,[organizationId]);
    return q.rows.map(r=>this.standardRow(r));
  }
  async createNetworkStandard(ctx:Ctx,input:StandardInput,key:string):Promise<NetworkStandard>{
    return this.networkCommand(ctx,key,JSON.stringify({kind:'network-standard-create',input}),async db=>{
      const q=await db.query(`INSERT INTO network_standards(organization_id,title,description,criteria,created_by) VALUES($1,$2,$3,$4,$5) RETURNING *`,
        [ctx.organizationId,input.title,input.description,JSON.stringify(withCriterionIds(input.criteria)),ctx.userId]);
      await this.audit(db,{organizationId:ctx.organizationId,userId:ctx.userId},'network.standard.create','network_standard',q.rows[0].id,{revision:1});
      return this.standardRow(q.rows[0]);
    });
  }
  async updateNetworkStandard(ctx:Ctx,id:string,expectedRevision:number,input:StandardInput,active:boolean,key:string):Promise<NetworkStandard>{
    return this.networkCommand(ctx,key,JSON.stringify({kind:'network-standard-update',id,expectedRevision,input,active}),async db=>{
      const prior=(await db.query(`SELECT * FROM network_standards WHERE organization_id=$1 AND id=$2 FOR UPDATE`,[ctx.organizationId,id])).rows[0];
      assert(prior,404,'NOT_FOUND','Стандарт не найден');
      assert(prior.revision===expectedRevision,409,'VERSION_CONFLICT','Стандарт уже изменился');
      const q=await db.query(`UPDATE network_standards SET title=$3,description=$4,criteria=$5,active=$6,revision=revision+1,updated_at=now()
        WHERE organization_id=$1 AND id=$2 RETURNING *`,[ctx.organizationId,id,input.title,input.description,JSON.stringify(withCriterionIds(input.criteria)),active]);
      await this.audit(db,{organizationId:ctx.organizationId,userId:ctx.userId},'network.standard.update','network_standard',id,{from:expectedRevision,to:expectedRevision+1,active});
      return this.standardRow(q.rows[0]);
    });
  }
  async branchAudits(ctx:Ctx,standardId:string|null):Promise<BranchAudit[]>{
    const q=await this.pool.query(`SELECT * FROM network_audits WHERE organization_id=$1 AND branch_id=$2 AND ($3::uuid IS NULL OR standard_id=$3::uuid)
      ORDER BY performed_at DESC,id DESC LIMIT 200`,[ctx.organizationId,ctx.branchId,standardId]);
    return q.rows.map(r=>this.networkAuditRow(r));
  }
  async submitBranchAudit(ctx:Ctx,standardId:string,expectedStandardRevision:number,answers:AuditAnswerInput[],key:string):Promise<BranchAudit>{
    return this.networkCommand(ctx,key,JSON.stringify({kind:'network-audit',branchId:ctx.branchId,standardId,expectedStandardRevision,answers}),async db=>{
      // Serialize actions for the same branch and standard, even for different actors/keys.
      await db.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',
        [`${ctx.organizationId}:${ctx.branchId}:standard:${standardId}:corrective`]);
      const row=(await db.query(`SELECT * FROM network_standards WHERE organization_id=$1 AND id=$2 FOR SHARE`,[ctx.organizationId,standardId])).rows[0];
      assert(row,404,'NOT_FOUND','Стандарт не найден');assert(row.active,409,'STANDARD_DISABLED','Стандарт отключён');
      assert(row.revision===expectedStandardRevision,409,'VERSION_CONFLICT','Стандарт уже изменился');
      const result=auditAnswers(answers,row.criteria as NetworkStandard['criteria']);
      const q=await db.query(`INSERT INTO network_audits(organization_id,branch_id,standard_id,standard_title,standard_revision,answers,score_bps,failed_count,critical_failures,performed_by)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,[ctx.organizationId,ctx.branchId,standardId,row.title,row.revision,
        JSON.stringify(result.answers),result.scoreBps,result.failedCount,result.criticalFailures,ctx.userId]);
      const audit=this.networkAuditRow(q.rows[0]);
      for(const failed of result.answers.filter(a=>!a.passed)){
        const existing=await db.query(`SELECT 1 FROM network_corrective_actions WHERE organization_id=$1 AND branch_id=$2
          AND standard_id=$3 AND standard_revision=$4 AND criterion_id=$5 AND status<>'RESOLVED' LIMIT 1`,
          [ctx.organizationId,ctx.branchId,standardId,row.revision,failed.criterionId]);
        if(existing.rowCount)continue;
        const action=await db.query(`INSERT INTO network_corrective_actions(organization_id,branch_id,audit_id,standard_id,standard_revision,criterion_id,title)
          VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,[ctx.organizationId,ctx.branchId,audit.id,standardId,row.revision,failed.criterionId,failed.title]);
        await this.audit(db,ctx,'network.action.create','network_corrective_action',action.rows[0].id,{auditId:audit.id,criterionId:failed.criterionId});
      }
      await this.audit(db,ctx,'network.audit.submit','network_audit',audit.id,{standardId,scoreBps:audit.scoreBps,criticalFailures:audit.criticalFailures});
      return audit;
    });
  }
  async branchCorrectiveActions(ctx:Ctx):Promise<CorrectiveAction[]>{
    const q=await this.pool.query(`SELECT * FROM network_corrective_actions WHERE organization_id=$1 AND branch_id=$2 ORDER BY created_at DESC,id DESC LIMIT 300`,
      [ctx.organizationId,ctx.branchId]);
    return q.rows.map(r=>this.networkActionRow(r));
  }
  async branchOpenActionCount(ctx:Ctx):Promise<number>{
    const q=await this.pool.query(`SELECT COUNT(*)::integer AS count FROM network_corrective_actions WHERE organization_id=$1 AND branch_id=$2 AND status<>$3`,
      [ctx.organizationId,ctx.branchId,'RESOLVED']);
    return n(q.rows[0].count);
  }
  async updateCorrectiveAction(ctx:Ctx,id:string,expectedRevision:number,status:ActionStatus,resolution:string|null,key:string):Promise<CorrectiveAction>{
    return this.networkCommand(ctx,key,JSON.stringify({kind:'network-action',branchId:ctx.branchId,id,expectedRevision,status,resolution}),async db=>{
      const prior=(await db.query(`SELECT * FROM network_corrective_actions WHERE id=$1 AND organization_id=$2 AND branch_id=$3 FOR UPDATE`,
        [id,ctx.organizationId,ctx.branchId])).rows[0];
      assert(prior,404,'NOT_FOUND','Действие не найдено');
      assert(prior.revision===expectedRevision,409,'VERSION_CONFLICT','Действие уже изменилось');
      actionTransition(prior.status,status,resolution);
      const q=await db.query(`UPDATE network_corrective_actions SET status=$4,resolution=$5,revision=revision+1,updated_at=now()
        WHERE id=$1 AND organization_id=$2 AND branch_id=$3 RETURNING *`,[id,ctx.organizationId,ctx.branchId,status,resolution]);
      await this.audit(db,ctx,'network.action.status','network_corrective_action',id,{from:prior.status,to:status});
      return this.networkActionRow(q.rows[0]);
    });
  }
  private decisionRow(r:Row):Decision{
    return {id:r.id,branchId:r.branch_id,signalId:r.signal_id,title:r.title,hypothesis:r.hypothesis,action:r.action,
      baselinePeriod:r.baseline_period.trim(),reviewPeriod:r.review_period?.trim()??null,
      implementationCostCents:r.implementation_cost_cents===null?null:n(r.implementation_cost_cents),
      status:r.status,revision:r.revision,createdAt:new Date(r.created_at).toISOString(),updatedAt:new Date(r.updated_at).toISOString(),
      baselineRevenueCents:n(r.baseline_revenue_cents),baselineProfitCents:r.baseline_profit_cents===null?null:n(r.baseline_profit_cents),
      observedRevenueCents:r.observed_revenue_cents===null?null:n(r.observed_revenue_cents),
      observedProfitCents:r.observed_profit_cents===null?null:n(r.observed_profit_cents),
      observedProfitDeltaCents:r.observed_profit_delta_cents===null?null:n(r.observed_profit_delta_cents),observation:r.observation};
  }
  async intelligenceDiagnosis(ctx:Ctx,period:string):Promise<Diagnosis>{
    const [now,before]=await Promise.all([this.financeReport(ctx,period),this.financeReport(ctx,previousPeriod(period))]);
    return evaluate(now,before);
  }
  async intelligenceDecisions(ctx:Ctx):Promise<Decision[]>{
    const q=await this.pool.query(`SELECT * FROM intelligence_decisions WHERE organization_id=$1 AND branch_id=$2 ORDER BY created_at DESC LIMIT 200`,[ctx.organizationId,ctx.branchId]);
    return q.rows.map(r=>this.decisionRow(r));
  }
  private async decisionCommand(ctx:Ctx,key:string,fingerprint:string,run:(db:DB)=>Promise<Decision>):Promise<Decision>{
    return this.transaction(async db=>{
      await db.query(`SELECT pg_advisory_xact_lock(hashtextextended($1,0))`,[`${ctx.organizationId}:${ctx.branchId}:${ctx.userId}:${key}`]);
      const saved=(await db.query(`SELECT fingerprint,result FROM intelligence_commands WHERE organization_id=$1 AND branch_id=$2 AND actor_id=$3 AND idempotency_key=$4`,
        [ctx.organizationId,ctx.branchId,ctx.userId,key])).rows[0];
      if(saved){assert(saved.fingerprint===fingerprint,409,'IDEMPOTENCY_CONFLICT','Конфликт ключа');return saved.result as Decision;}
      const value=await run(db);
      await db.query(`INSERT INTO intelligence_commands(organization_id,branch_id,actor_id,idempotency_key,fingerprint,result) VALUES($1,$2,$3,$4,$5,$6)`,
        [ctx.organizationId,ctx.branchId,ctx.userId,key,fingerprint,JSON.stringify(value)]);
      return value;
    });
  }
  async createIntelligenceDecision(ctx:Ctx,period:string,signalId:string,input:{title:string;hypothesis:string;action:string;implementationCostCents:number|null},key:string):Promise<Decision>{
    const fingerprint=JSON.stringify({kind:'create',period,signalId,input});
    return this.decisionCommand(ctx,key,fingerprint,async db=>{
      const diagnosis=await this.intelligenceDiagnosis(ctx,period);
      assert(diagnosis.signals.some(s=>s.id===signalId),409,'SIGNAL_NOT_FOUND','Сигнал больше не подтверждён расчётом');
      const report=await this.financeReport(ctx,period);
      const q=await db.query(`INSERT INTO intelligence_decisions
        (organization_id,branch_id,actor_id,signal_id,title,hypothesis,action,baseline_period,implementation_cost_cents,baseline_revenue_cents,baseline_profit_cents)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
        [ctx.organizationId,ctx.branchId,ctx.userId,signalId,input.title,input.hypothesis,input.action,period,input.implementationCostCents,report.revenueCents,report.operatingResultCents]);
      await this.audit(db,ctx,'intelligence.decision.create','intelligence_decision',q.rows[0].id,{signalId,period});
      return this.decisionRow(q.rows[0]);
    });
  }
  async updateIntelligenceDecision(ctx:Ctx,id:string,expectedRevision:number,status:DecisionStatus,reviewPeriod:string|null,observationText:string|null,key:string):Promise<Decision>{
    const fingerprint=JSON.stringify({kind:'status',id,expectedRevision,status,reviewPeriod,observationText});
    return this.decisionCommand(ctx,key,fingerprint,async db=>{
      const found=(await db.query(`SELECT * FROM intelligence_decisions WHERE id=$1 AND organization_id=$2 AND branch_id=$3 FOR UPDATE`,[id,ctx.organizationId,ctx.branchId])).rows[0];
      assert(found,404,'NOT_FOUND','Решение не найдено');
      assert(found.revision===expectedRevision,409,'VERSION_CONFLICT','Решение уже изменено');
      transition(found.status,status);
      let observed:{observedRevenueCents:number|null;observedProfitCents:number|null;observedProfitDeltaCents:number|null}={observedRevenueCents:null,observedProfitCents:null,observedProfitDeltaCents:null};
      if(status==='REVIEWED'){
        assert(reviewPeriod&&reviewPeriodAllowed(found.baseline_period.trim(),reviewPeriod),400,'REVIEW_PERIOD','Проверка должна быть позднее базового месяца');
        assert(observationText,400,'REVIEW_NOTE','Укажите фактическое наблюдение');
        const review=await this.financeReport(ctx,reviewPeriod);
        const baseline={...review,period:found.baseline_period.trim(),revenueCents:n(found.baseline_revenue_cents),
          operatingResultCents:found.baseline_profit_cents===null?null:n(found.baseline_profit_cents)};
        observed=observation(baseline,review,found.implementation_cost_cents===null?null:n(found.implementation_cost_cents));
      }else{assert(reviewPeriod===null&&observationText===null,400,'REVIEW_ONLY','Наблюдение доступно только при REVIEWED');}
      const q=await db.query(`UPDATE intelligence_decisions SET status=$4,revision=revision+1,updated_at=now(),review_period=$5,observation=$6,
        observed_revenue_cents=$7,observed_profit_cents=$8,observed_profit_delta_cents=$9 WHERE id=$1 AND organization_id=$2 AND branch_id=$3 RETURNING *`,
        [id,ctx.organizationId,ctx.branchId,status,reviewPeriod,observationText,observed.observedRevenueCents,observed.observedProfitCents,observed.observedProfitDeltaCents]);
      await this.audit(db,ctx,'intelligence.decision.status','intelligence_decision',id,{from:found.status,to:status,reviewPeriod});
      return this.decisionRow(q.rows[0]);
    });
  }
  async bootstrap(args:{email:string;displayName:string;passwordHash:string;organizationName:string;branchName:string}){
    return this.transaction(async db=>{
      const u=(await db.query(`INSERT INTO users(email,display_name,password_hash) VALUES($1,$2,$3) RETURNING *`,[args.email,args.displayName,args.passwordHash])).rows[0];
      const org=(await db.query(`INSERT INTO organizations(name) VALUES($1) RETURNING id`,[args.organizationName])).rows[0];
      const b=(await db.query(`INSERT INTO branches(organization_id,name) VALUES($1,$2) RETURNING id`,[org.id,args.branchName])).rows[0];
      await db.query(`INSERT INTO memberships(organization_id,user_id,role) VALUES($1,$2,'owner')`,[org.id,u.id]);
      await this.audit(db,{organizationId:org.id,branchId:b.id,userId:u.id},'organization.bootstrap','organization',org.id);
      return {user:user(u),organizationId:org.id,branchId:b.id};
    });
  }
  async findUser(email:string):Promise<User|null>{
    const r=await this.pool.query('SELECT * FROM users WHERE email=$1',[email]);return r.rows[0]?user(r.rows[0]):null;
  }
  async createSession(userId:string,tokenHash:string){
    await this.pool.query(`INSERT INTO sessions(user_id,token_hash,expires_at) VALUES($1,$2,now()+interval '7 days')`,[userId,tokenHash]);
  }
  async getSession(tokenHash:string):Promise<User|null>{
    const r=await this.pool.query(`SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>now()`,[tokenHash]);
    return r.rows[0]?user(r.rows[0]):null;
  }
  async deleteSession(tokenHash:string){await this.pool.query('DELETE FROM sessions WHERE token_hash=$1',[tokenHash]);}
  async memberships(userId:string):Promise<Membership[]>{
    const found=await this.pool.query(`
      SELECT m.organization_id, o.name AS organization_name,o.currency,m.role,
        COALESCE(json_agg(json_build_object('id',b.id,'name',b.name,'timezone',b.timezone) ORDER BY b.name)
        FILTER(WHERE b.id IS NOT NULL),'[]') AS branches
      FROM memberships m JOIN organizations o ON o.id=m.organization_id
      LEFT JOIN branches b ON b.organization_id=m.organization_id AND
        (m.role IN ('owner','finance_director','operations_director') OR EXISTS
        (SELECT 1 FROM branch_grants g WHERE g.organization_id=b.organization_id AND g.branch_id=b.id AND g.user_id=m.user_id))
      WHERE m.user_id=$1 GROUP BY m.organization_id,o.name,o.currency,m.role ORDER BY o.name`,[userId]);
    return found.rows.map(r=>({organizationId:r.organization_id,organizationName:r.organization_name,currency:r.currency,role:r.role as Role,branches:r.branches}));
  }
  async branches(organizationId:string){const r=await this.pool.query('SELECT id,name,timezone FROM branches WHERE organization_id=$1 ORDER BY name',[organizationId]);return r.rows.map(branch);}
  async createBranch(organizationId:string,actorId:string,name:string,timezone:string){
    return this.transaction(async db=>{
      const b=(await db.query(`INSERT INTO branches(organization_id,name,timezone) VALUES($1,$2,$3) RETURNING *`,[organizationId,name,timezone])).rows[0];
      await this.audit(db,{organizationId,userId:actorId,branchId:b.id},'branch.create','branch',b.id);
      return branch(b);
    });
  }
  async createInvitation(organizationId:string,actorId:string,email:string,role:Role,branchIds:string[],tokenHash:string){
    await this.transaction(async db=>{
      const branches=await db.query('SELECT id FROM branches WHERE organization_id=$1 AND id=ANY($2::uuid[])',[organizationId,branchIds]);
      assert(branches.rows.length===new Set(branchIds).size,400,'BRANCH_SCOPE','Филиал приглашения не принадлежит организации');
      await db.query(`INSERT INTO invitations(token_hash,organization_id,email,role,branch_ids,issued_by,expires_at) VALUES($1,$2,$3,$4,$5,$6,now()+interval '48 hours')`,
        [tokenHash,organizationId,email,role,branchIds,actorId]);
      await this.audit(db,{organizationId,userId:actorId},'invite.create','organization',organizationId,{role,branchIds});
    });
  }
  async acceptInvitation(tokenHash:string,email:string,displayName:string,passwordHash:string):Promise<User>{
    return this.transaction(async db=>{
      const invitation=(await db.query(`SELECT * FROM invitations WHERE token_hash=$1 FOR UPDATE`,[tokenHash])).rows[0];
      assert(invitation && !invitation.redeemed_at && new Date(invitation.expires_at).getTime()>Date.now(),410,'INVITE_EXPIRED','Приглашение истекло или уже использовано');
      assert(invitation.email===email,403,'INVITE_EMAIL','Email не совпадает с приглашением');
      const u=(await db.query(`INSERT INTO users(email,display_name,password_hash) VALUES($1,$2,$3) RETURNING *`,[email,displayName,passwordHash])).rows[0];
      await db.query(`INSERT INTO memberships(organization_id,user_id,role) VALUES($1,$2,$3)`,[invitation.organization_id,u.id,invitation.role]);
      for(const branchId of invitation.branch_ids){
        await db.query(`INSERT INTO branch_grants(organization_id,branch_id,user_id) VALUES($1,$2,$3)`,[invitation.organization_id,branchId,u.id]);
      }
      await db.query(`UPDATE invitations SET redeemed_at=now() WHERE token_hash=$1`,[tokenHash]);
      await this.audit(db,{organizationId:invitation.organization_id,userId:u.id},'invite.redeem','organization',invitation.organization_id);
      return user(u);
    });
  }
  async menu(ctx:Ctx):Promise<MenuItem[]>{
    const r=await this.pool.query(`SELECT id,name,price_cents,active,revision FROM menu_items WHERE organization_id=$1 AND branch_id=$2 ORDER BY created_at DESC`,[ctx.organizationId,ctx.branchId]);
    return r.rows.map(menuItem);
  }
  async addMenuItem(ctx:Ctx,name:string,priceCents:number):Promise<MenuItem>{
    return this.transaction(async db=>{
      const r=(await db.query(`INSERT INTO menu_items(organization_id,branch_id,name,price_cents) VALUES($1,$2,$3,$4) RETURNING *`,[ctx.organizationId,ctx.branchId,name,priceCents])).rows[0];
      await this.audit(db,ctx,'menu.create','menu_item',r.id,{priceCents});
      return menuItem(r);
    });
  }
  async updateMenuItem(ctx:Ctx,itemId:string,revision:number,patch:{name?:string;priceCents?:number;active?:boolean}):Promise<MenuItem>{
    return this.transaction(async db=>{
      const keys:string[]=[];const values:unknown[]=[ctx.organizationId,ctx.branchId,itemId,revision];
      for(const [field,column] of [['name','name'],['priceCents','price_cents'],['active','active']] as const){
        if(patch[field]!==undefined){values.push(patch[field]);keys.push(`${column}=$${values.length}`);}
      }
      assert(keys.length>0,400,'VALIDATION','Нет изменений');
      const r=await db.query(`UPDATE menu_items SET ${keys.join(',')},revision=revision+1 WHERE organization_id=$1 AND branch_id=$2 AND id=$3 AND revision=$4 RETURNING *`,values);
      assert(r.rows[0],409,'STALE_VERSION','Позиция изменилась или отсутствует. Обновите страницу');
      await this.audit(db,ctx,'menu.update','menu_item',itemId,{fields:Object.keys(patch)});
      return menuItem(r.rows[0]);
    });
  }
  async tables(ctx:Ctx){const r=await this.pool.query('SELECT id,label,capacity FROM dining_tables WHERE organization_id=$1 AND branch_id=$2 ORDER BY label',[ctx.organizationId,ctx.branchId]);return r.rows.map(table);}
  async addTable(ctx:Ctx,label:string,capacity:number):Promise<DiningTable>{
    return this.transaction(async db=>{
      const r=(await db.query('INSERT INTO dining_tables(organization_id,branch_id,label,capacity) VALUES($1,$2,$3,$4) RETURNING *',[ctx.organizationId,ctx.branchId,label,capacity])).rows[0];
      await this.audit(db,ctx,'table.create','dining_table',r.id,{capacity});
      return table(r);
    });
  }
  private async getOrder(db:DB,ctx:Ctx,orderId:string):Promise<Order>{
    const r=await db.query(`SELECT o.id,o.guest_id,o.table_id,o.status,o.total_cents,o.revision,o.created_at,o.actual_food_cost_cents,o.recipe_missing_lines,o.costed_at,
      COALESCE(json_agg(json_build_object('id',l.id,'menu_item_id',l.menu_item_id,'name',l.name_snapshot,
      'unit_price_cents',l.unit_price_cents,'quantity',l.quantity,'line_total_cents',l.line_total_cents)
      ORDER BY l.id) FILTER (WHERE l.id IS NOT NULL),'[]') AS items
      FROM orders o LEFT JOIN order_lines l ON l.order_id=o.id AND l.organization_id=o.organization_id AND l.branch_id=o.branch_id
      WHERE o.organization_id=$1 AND o.branch_id=$2 AND o.id=$3
      GROUP BY o.id`,[ctx.organizationId,ctx.branchId,orderId]);
    assert(r.rows[0],404,'NOT_FOUND','Заказ не найден');
    const result=order(r.rows[0]);
    if(!can(ctx.role,'inventory:read')){result.actualFoodCostCents=null;result.missingRecipeLines=null;result.foodCostComplete=false;}
    return result;
  }
  // Reservations and floor state are built from authoritative orders/bookings, not mutable UI flags.
  async floor(ctx:Ctx):Promise<FloorTable[]> {
    const r=await this.pool.query(`SELECT t.id,t.label,t.capacity,
      active.id AS active_order_id, future.id AS reservation_id, future.starts_at AS next_reservation_at
      FROM dining_tables t
      LEFT JOIN LATERAL (SELECT o.id FROM orders o
        WHERE o.organization_id=t.organization_id AND o.branch_id=t.branch_id
          AND o.table_id=t.id AND o.status NOT IN ('COMPLETED','CANCELLED') LIMIT 1) active ON true
      LEFT JOIN LATERAL (SELECT b.id,b.starts_at FROM reservations b
        WHERE b.organization_id=t.organization_id AND b.branch_id=t.branch_id
          AND b.table_id=t.id AND b.status='CONFIRMED' AND b.ends_at>now()
        ORDER BY b.starts_at ASC LIMIT 1) future ON true
      WHERE t.organization_id=$1 AND t.branch_id=$2 ORDER BY t.label`,[ctx.organizationId,ctx.branchId]);
    const near=Date.now()+45*60000;
    return r.rows.map(row=>({...table(row),
      state:row.active_order_id?'OCCUPIED':row.reservation_id && new Date(row.next_reservation_at).getTime()<=near?'RESERVED':'AVAILABLE',
      activeOrderId:row.active_order_id||null,
      reservationId:row.reservation_id||null,
      nextReservationAt:row.next_reservation_at?new Date(row.next_reservation_at).toISOString():null
    }));
  }
  private async getReservation(db:DB,ctx:Ctx,id:string):Promise<Reservation>{
    const r=await db.query(`SELECT r.*, o.id AS order_id FROM reservations r
      LEFT JOIN orders o ON o.organization_id=r.organization_id AND o.branch_id=r.branch_id AND o.reservation_id=r.id
      WHERE r.organization_id=$1 AND r.branch_id=$2 AND r.id=$3`,[ctx.organizationId,ctx.branchId,id]);
    assert(r.rows[0],404,'NOT_FOUND','Бронь не найдена');return reservation(r.rows[0]);
  }
  async reservations(ctx:Ctx):Promise<Reservation[]>{
    const r=await this.pool.query(`SELECT r.*,o.id AS order_id FROM reservations r
      LEFT JOIN orders o ON o.organization_id=r.organization_id AND o.branch_id=r.branch_id AND o.reservation_id=r.id
      WHERE r.organization_id=$1 AND r.branch_id=$2 AND r.starts_at >= now() - interval '7 days'
      ORDER BY r.starts_at ASC LIMIT 200`,[ctx.organizationId,ctx.branchId]);
    return r.rows.map(reservation);
  }
  private async lockTable(db:DB,ctx:Ctx,tableId:string){
    const row=(await db.query(`SELECT capacity FROM dining_tables
      WHERE organization_id=$1 AND branch_id=$2 AND id=$3 FOR UPDATE`,[ctx.organizationId,ctx.branchId,tableId])).rows[0];
    assert(row,404,'TABLE_NOT_FOUND','Стол не найден');return row.capacity as number;
  }
  async createReservation(ctx:Ctx,input:ReservationInput,key:string):Promise<Reservation>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'booking',branchId:ctx.branchId,...input},async()=>{
      const capacity=await this.lockTable(db,ctx,input.tableId);
      sameTableCapacity(input.partySize,capacity);
      // For immediate arrival, refuse a new booking while a table has an open check.
      if(Date.parse(input.startsAt)<=Date.now()+45*60000){
        const busy=await db.query(`SELECT 1 FROM orders WHERE organization_id=$1 AND branch_id=$2 AND table_id=$3
          AND status NOT IN ('COMPLETED','CANCELLED') LIMIT 1`,[ctx.organizationId,ctx.branchId,input.tableId]);
        assert(!busy.rows[0],409,'TABLE_BUSY','У стола уже есть активный заказ');
      }
      const row=(await db.query(`INSERT INTO reservations
        (organization_id,branch_id,table_id,guest_name,party_size,starts_at,ends_at,created_by)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
        [ctx.organizationId,ctx.branchId,input.tableId,input.guestName,input.partySize,input.startsAt,input.endsAt,ctx.userId])).rows[0];
      await this.audit(db,ctx,'reservation.create','reservation',row.id,{tableId:input.tableId,startsAt:input.startsAt,partySize:input.partySize});
      return this.getReservation(db,ctx,row.id);
    }));
  }
  async changeReservation(ctx:Ctx,id:string,to:ReservationAction,expectedRevision:number,key:string):Promise<Reservation>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'reservation-status',branchId:ctx.branchId,id,to,expectedRevision},async()=>{
      const row=(await db.query(`SELECT * FROM reservations WHERE organization_id=$1 AND branch_id=$2 AND id=$3 FOR UPDATE`,
        [ctx.organizationId,ctx.branchId,id])).rows[0];
      assert(row,404,'NOT_FOUND','Бронь не найдена');
      assert(row.revision===expectedRevision,409,'STALE_VERSION','Бронь уже изменилась');
      requireReservationAction(row.status,to);
      if(to==='NO_SHOW')assert(Date.now()>=new Date(row.starts_at).getTime()+15*60000,409,'NO_SHOW_EARLY','Неявку фиксируют не ранее 15 минут после начала брони');
      await db.query(`UPDATE reservations SET status=$4,revision=revision+1,updated_at=now()
        WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,[ctx.organizationId,ctx.branchId,id,to]);
      await this.audit(db,ctx,`reservation.${to.toLowerCase()}`,'reservation',id);
      return this.getReservation(db,ctx,id);
    }));
  }
  async seatReservation(ctx:Ctx,id:string,expectedRevision:number,key:string):Promise<Seated>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'reservation-seat',branchId:ctx.branchId,id,expectedRevision},async()=>{
      const lookup=(await db.query(`SELECT table_id FROM reservations WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,
        [ctx.organizationId,ctx.branchId,id])).rows[0];
      assert(lookup,404,'NOT_FOUND','Бронь не найдена');
      await this.lockTable(db,ctx,lookup.table_id);
      const b=(await db.query(`SELECT * FROM reservations WHERE organization_id=$1 AND branch_id=$2 AND id=$3 FOR UPDATE`,
        [ctx.organizationId,ctx.branchId,id])).rows[0];
      assert(b.revision===expectedRevision,409,'STALE_VERSION','Бронь уже изменилась');
      assert(b.status==='CONFIRMED',409,'RESERVATION_LOCKED','Бронь уже обработана');
      requireSeatDate(new Date(b.starts_at).toISOString(),new Date(b.ends_at).toISOString());
      const open=(await db.query(`SELECT 1 FROM orders WHERE organization_id=$1 AND branch_id=$2 AND table_id=$3
        AND status NOT IN ('COMPLETED','CANCELLED') LIMIT 1`,[ctx.organizationId,ctx.branchId,b.table_id])).rows[0];
      assert(!open,409,'TABLE_BUSY','Стол уже занят другим заказом');
      const newOrder=(await db.query(`INSERT INTO orders(organization_id,branch_id,table_id,created_by,reservation_id)
        VALUES($1,$2,$3,$4,$5) RETURNING id`,[ctx.organizationId,ctx.branchId,b.table_id,ctx.userId,id])).rows[0];
      await db.query(`UPDATE reservations SET status='SEATED',revision=revision+1,updated_at=now()
        WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,[ctx.organizationId,ctx.branchId,id]);
      await this.audit(db,ctx,'reservation.seat','reservation',id,{orderId:newOrder.id});
      return {reservation:await this.getReservation(db,ctx,id),order:await this.getOrder(db,ctx,newOrder.id)};
    }));
  }
  async kitchen(ctx:Ctx):Promise<KitchenTicket[]>{
    const rows=await this.pool.query(`SELECT id,sent_at,preparing_at,ready_at FROM orders
      WHERE organization_id=$1 AND branch_id=$2 AND status IN ('SENT','PREPARING','READY')
      ORDER BY sent_at ASC NULLS LAST,created_at ASC LIMIT 120`,[ctx.organizationId,ctx.branchId]);
    return Promise.all(rows.rows.map(async row=>{
      const o=await this.getOrder(this.pool,ctx,row.id);
      return {id:o.id,tableId:o.tableId,status:o.status as KitchenTicket['status'],revision:o.revision,items:o.items,
        sentAt:row.sent_at?new Date(row.sent_at).toISOString():null,
        preparingAt:row.preparing_at?new Date(row.preparing_at).toISOString():null,
        readyAt:row.ready_at?new Date(row.ready_at).toISOString():null};
    }));
  }
  private async getShift(db:DB,ctx:Ctx,id:string):Promise<Shift>{
    const values=[ctx.organizationId,ctx.branchId,id];
    const r=await db.query(`SELECT s.*,u.display_name FROM staff_shifts s JOIN users u ON u.id=s.user_id
      WHERE s.organization_id=$1 AND s.branch_id=$2 AND s.id=$3`,values);
    assert(r.rows[0],404,'NOT_FOUND','Смена не найдена');return shift(r.rows[0]);
  }
  async staff(ctx:Ctx):Promise<Employee[]>{
    const readAll=managesShifts(ctx.role);
    const r=await this.pool.query(`SELECT u.id,u.display_name,m.role FROM memberships m
      JOIN users u ON u.id=m.user_id WHERE m.organization_id=$1 AND
      (m.role IN ('owner','finance_director','operations_director') OR EXISTS
        (SELECT 1 FROM branch_grants g WHERE g.organization_id=$1 AND g.branch_id=$2 AND g.user_id=m.user_id))
      AND ($3::boolean OR u.id=$4) ORDER BY u.display_name LIMIT 150`,
      [ctx.organizationId,ctx.branchId,readAll,ctx.userId]);
    return r.rows.map(row=>({id:row.id,displayName:row.display_name,role:row.role}));
  }
  async shifts(ctx:Ctx):Promise<Shift[]>{
    const visible=managesShifts(ctx.role)?'':' AND s.user_id=$3';
    const values=managesShifts(ctx.role)?[ctx.organizationId,ctx.branchId]:[ctx.organizationId,ctx.branchId,ctx.userId];
    const r=await this.pool.query(`SELECT s.*,u.display_name FROM staff_shifts s JOIN users u ON u.id=s.user_id
      WHERE s.organization_id=$1 AND s.branch_id=$2${visible}
      ORDER BY s.opened_at DESC LIMIT 100`,values);
    return r.rows.map(shift);
  }
  async openShift(ctx:Ctx,userId:string,openingNote:string,key:string):Promise<Shift>{
    requireShiftActor(ctx.role,ctx.userId,userId);
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'shift-open',branchId:ctx.branchId,userId,openingNote},async()=>{
      const valid=(await db.query(`SELECT 1 FROM memberships m WHERE m.organization_id=$1 AND m.user_id=$2
        AND (m.role IN ('owner','finance_director','operations_director') OR EXISTS
          (SELECT 1 FROM branch_grants g WHERE g.organization_id=$1 AND g.branch_id=$3 AND g.user_id=m.user_id))`,
        [ctx.organizationId,userId,ctx.branchId])).rows[0];
      assert(valid,404,'WORKER_NOT_FOUND','Сотрудник не имеет доступа к филиалу');
      const row=(await db.query(`INSERT INTO staff_shifts(organization_id,branch_id,user_id,opened_by,opening_note)
        VALUES($1,$2,$3,$4,$5) RETURNING id`,[ctx.organizationId,ctx.branchId,userId,ctx.userId,openingNote])).rows[0];
      await this.audit(db,ctx,'shift.open','staff_shift',row.id,{userId});
      return this.getShift(db,ctx,row.id);
    }));
  }
  async closeShift(ctx:Ctx,id:string,expectedRevision:number,closingNote:string,key:string):Promise<Shift>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'shift-close',branchId:ctx.branchId,id,expectedRevision,closingNote},async()=>{
      const row=(await db.query(`SELECT * FROM staff_shifts WHERE organization_id=$1 AND branch_id=$2 AND id=$3 FOR UPDATE`,
        [ctx.organizationId,ctx.branchId,id])).rows[0];
      assert(row,404,'NOT_FOUND','Смена не найдена');
      requireShiftActor(ctx.role,ctx.userId,row.user_id);
      assert(row.revision===expectedRevision,409,'STALE_VERSION','Версия смены изменилась');
      assert(row.status==='OPEN',409,'SHIFT_CLOSED','Смена уже закрыта');
      await db.query(`UPDATE staff_shifts SET status='CLOSED',closed_at=now(),closed_by=$4,closing_note=$5,revision=revision+1
        WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,[ctx.organizationId,ctx.branchId,id,ctx.userId,closingNote]);
      await this.audit(db,ctx,'shift.close','staff_shift',id,{userId:row.user_id});
      return this.getShift(db,ctx,id);
    }));
  }
  // R3 inventory: all writes are tenant-scoped, audited, idempotent and transactional.
  private ingredientRow(r:Row):Ingredient {
    return {id:r.id,name:r.name,unit:r.unit,minQuantityMilli:n(r.min_quantity_milli),quantityMilli:n(r.quantity_milli),
      valueCents:n(r.value_cents),revision:r.revision,lowStock:n(r.quantity_milli)<n(r.min_quantity_milli)};
  }
  private async getIngredient(db:DB,ctx:Ctx,id:string):Promise<Ingredient>{
    const r=await db.query(`SELECT i.id,i.name,i.unit,i.min_quantity_milli,b.quantity_milli,b.value_cents,b.revision
      FROM ingredients i JOIN stock_balances b ON b.organization_id=i.organization_id AND b.branch_id=i.branch_id AND b.ingredient_id=i.id
      WHERE i.organization_id=$1 AND i.branch_id=$2 AND i.id=$3`,[ctx.organizationId,ctx.branchId,id]);
    assert(r.rows[0],404,'INGREDIENT_NOT_FOUND','Ингредиент не найден');return this.ingredientRow(r.rows[0]);
  }
  async ingredients(ctx:Ctx):Promise<Ingredient[]>{
    const r=await this.pool.query(`SELECT i.id,i.name,i.unit,i.min_quantity_milli,b.quantity_milli,b.value_cents,b.revision
      FROM ingredients i JOIN stock_balances b ON b.organization_id=i.organization_id AND b.branch_id=i.branch_id AND b.ingredient_id=i.id
      WHERE i.organization_id=$1 AND i.branch_id=$2 ORDER BY i.name`,[ctx.organizationId,ctx.branchId]);
    return r.rows.map(x=>this.ingredientRow(x));
  }
  async createIngredient(ctx:Ctx,name:string,unit:StockUnit,minQuantityMilli:number,key:string):Promise<Ingredient>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'ingredient',branchId:ctx.branchId,name,unit,minQuantityMilli},async()=>{
      const r=(await db.query(`INSERT INTO ingredients(organization_id,branch_id,name,unit,min_quantity_milli)
        VALUES($1,$2,$3,$4,$5) RETURNING id`,[ctx.organizationId,ctx.branchId,name,unit,minQuantityMilli])).rows[0];
      await db.query(`INSERT INTO stock_balances(organization_id,branch_id,ingredient_id) VALUES($1,$2,$3)`,[ctx.organizationId,ctx.branchId,r.id]);
      await this.audit(db,ctx,'inventory.ingredient_create','ingredient',r.id,{unit,minQuantityMilli});
      return this.getIngredient(db,ctx,r.id);
    }));
  }
  async setIngredientMinimum(ctx:Ctx,id:string,expectedRevision:number,minQuantityMilli:number,key:string):Promise<Ingredient>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'minimum',branchId:ctx.branchId,id,expectedRevision,minQuantityMilli},async()=>{
      const previous=(await db.query(`SELECT revision FROM stock_balances WHERE organization_id=$1 AND branch_id=$2 AND ingredient_id=$3 FOR UPDATE`,
        [ctx.organizationId,ctx.branchId,id])).rows[0];
      assert(previous,404,'INGREDIENT_NOT_FOUND','Ингредиент не найден');
      assert(previous.revision===expectedRevision,409,'STALE_VERSION','Склад изменился, обновите данные');
      await db.query(`UPDATE ingredients SET min_quantity_milli=$4 WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,
        [ctx.organizationId,ctx.branchId,id,minQuantityMilli]);
      await db.query(`UPDATE stock_balances SET revision=revision+1 WHERE organization_id=$1 AND branch_id=$2 AND ingredient_id=$3`,
        [ctx.organizationId,ctx.branchId,id]);
      await this.audit(db,ctx,'inventory.minimum','ingredient',id,{minQuantityMilli});
      return this.getIngredient(db,ctx,id);
    }));
  }
  private async getRecipe(db:DB,ctx:Ctx,menuItemId:string):Promise<Recipe|null>{
    const header=(await db.query(`SELECT revision FROM menu_recipes WHERE organization_id=$1 AND branch_id=$2 AND menu_item_id=$3`,
      [ctx.organizationId,ctx.branchId,menuItemId])).rows[0];
    if(!header)return null;
    const r=await db.query(`SELECT c.ingredient_id,c.quantity_milli,i.name,i.unit FROM recipe_components c JOIN ingredients i
      ON i.organization_id=c.organization_id AND i.branch_id=c.branch_id AND i.id=c.ingredient_id
      WHERE c.organization_id=$1 AND c.branch_id=$2 AND c.menu_item_id=$3 ORDER BY i.name`,[ctx.organizationId,ctx.branchId,menuItemId]);
    return {menuItemId,revision:header.revision,components:r.rows.map(row=>({ingredientId:row.ingredient_id,quantityMilli:n(row.quantity_milli),name:row.name,unit:row.unit}))};
  }
  async recipe(ctx:Ctx,menuItemId:string):Promise<Recipe|null>{
    const item=await this.pool.query('SELECT 1 FROM menu_items WHERE organization_id=$1 AND branch_id=$2 AND id=$3',
      [ctx.organizationId,ctx.branchId,menuItemId]);
    assert(item.rows[0],404,'MENU_NOT_FOUND','Позиция меню не найдена');
    return this.getRecipe(this.pool,ctx,menuItemId);
  }
  async saveRecipe(ctx:Ctx,menuItemId:string,expectedRevision:number,components:RecipeComponentInput[],key:string):Promise<Recipe>{
    recipeComponents(components);
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'recipe',branchId:ctx.branchId,menuItemId,expectedRevision,components},async()=>{
      // Lock menu item first: concurrent writers cannot both create revision 1.
      const item=(await db.query(`SELECT id FROM menu_items WHERE organization_id=$1 AND branch_id=$2 AND id=$3 FOR UPDATE`,
        [ctx.organizationId,ctx.branchId,menuItemId])).rows[0];
      assert(item,404,'MENU_NOT_FOUND','Блюдо не найдено');
      const current=(await db.query(`SELECT revision FROM menu_recipes WHERE organization_id=$1 AND branch_id=$2 AND menu_item_id=$3`,
        [ctx.organizationId,ctx.branchId,menuItemId])).rows[0];
      assert((current?.revision??0)===expectedRevision,409,'STALE_VERSION','Рецептура изменена другим сотрудником');
      const valid=await db.query(`SELECT id FROM ingredients WHERE organization_id=$1 AND branch_id=$2 AND id=ANY($3::uuid[])`,
        [ctx.organizationId,ctx.branchId,components.map(x=>x.ingredientId)]);
      assert(valid.rows.length===components.length,404,'INGREDIENT_NOT_FOUND','Ингредиент не принадлежит филиалу');
      if(current){
        await db.query(`UPDATE menu_recipes SET revision=revision+1,updated_at=now() WHERE organization_id=$1 AND branch_id=$2 AND menu_item_id=$3`,[ctx.organizationId,ctx.branchId,menuItemId]);
        await db.query(`DELETE FROM recipe_components WHERE organization_id=$1 AND branch_id=$2 AND menu_item_id=$3`,[ctx.organizationId,ctx.branchId,menuItemId]);
      }else{
        await db.query(`INSERT INTO menu_recipes(organization_id,branch_id,menu_item_id) VALUES($1,$2,$3)`,[ctx.organizationId,ctx.branchId,menuItemId]);
      }
      for(const c of components)await db.query(`INSERT INTO recipe_components(organization_id,branch_id,menu_item_id,ingredient_id,quantity_milli)
        VALUES($1,$2,$3,$4,$5)`,[ctx.organizationId,ctx.branchId,menuItemId,c.ingredientId,c.quantityMilli]);
      await this.audit(db,ctx,'recipe.save','menu_item',menuItemId,{expectedRevision,ingredientCount:components.length});
      return (await this.getRecipe(db,ctx,menuItemId))!;
    }));
  }
  async suppliers(ctx:Ctx):Promise<Supplier[]>{
    const r=await this.pool.query('SELECT id,name FROM suppliers WHERE organization_id=$1 AND branch_id=$2 ORDER BY name',
      [ctx.organizationId,ctx.branchId]);return r.rows.map(x=>({id:x.id,name:x.name}));
  }
  async createSupplier(ctx:Ctx,name:string,key:string):Promise<Supplier>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'supplier',branchId:ctx.branchId,name},async()=>{
      const r=(await db.query(`INSERT INTO suppliers(organization_id,branch_id,name) VALUES($1,$2,$3) RETURNING id,name`,
        [ctx.organizationId,ctx.branchId,name])).rows[0];
      await this.audit(db,ctx,'supplier.create','supplier',r.id);return {id:r.id,name:r.name};
    }));
  }
  private async getReceipt(db:DB,ctx:Ctx,id:string):Promise<Receipt>{
    const r=(await db.query(`SELECT * FROM purchase_receipts WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,
      [ctx.organizationId,ctx.branchId,id])).rows[0];
    assert(r,404,'NOT_FOUND','Поступление не найдено');
    const lines=await db.query(`SELECT l.ingredient_id,l.quantity_milli,l.total_cost_cents,i.name FROM purchase_receipt_lines l
      JOIN ingredients i ON i.id=l.ingredient_id AND i.organization_id=l.organization_id AND i.branch_id=l.branch_id
      WHERE l.organization_id=$1 AND l.branch_id=$2 AND l.receipt_id=$3 ORDER BY i.name`,[ctx.organizationId,ctx.branchId,id]);
    return {id:r.id,supplierId:r.supplier_id||null,reference:r.reference,totalCostCents:n(r.total_cost_cents),
      receivedAt:new Date(r.received_at).toISOString(),lines:lines.rows.map(x=>({ingredientId:x.ingredient_id,name:x.name,
        quantityMilli:n(x.quantity_milli),totalCostCents:n(x.total_cost_cents)}))};
  }
  async receipts(ctx:Ctx):Promise<Receipt[]>{
    const ids=await this.pool.query(`SELECT id FROM purchase_receipts WHERE organization_id=$1 AND branch_id=$2 ORDER BY received_at DESC LIMIT 80`,
      [ctx.organizationId,ctx.branchId]);
    return Promise.all(ids.rows.map(x=>this.getReceipt(this.pool,ctx,x.id)));
  }
  async receiveStock(ctx:Ctx,supplierId:string|null,reference:string,lines:ReceiptLineInput[],key:string):Promise<Receipt>{
    receiptLines(lines);
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'receipt',branchId:ctx.branchId,supplierId,reference,lines},async()=>{
      if(supplierId){const supplier=(await db.query(`SELECT 1 FROM suppliers WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,
        [ctx.organizationId,ctx.branchId,supplierId])).rows[0];assert(supplier,404,'SUPPLIER_NOT_FOUND','Поставщик не найден');}
      const ids=lines.map(l=>l.ingredientId).sort();
      const balances=await db.query(`SELECT ingredient_id,quantity_milli,value_cents FROM stock_balances
        WHERE organization_id=$1 AND branch_id=$2 AND ingredient_id=ANY($3::uuid[]) ORDER BY ingredient_id FOR UPDATE`,
        [ctx.organizationId,ctx.branchId,ids]);
      assert(balances.rows.length===ids.length,404,'INGREDIENT_NOT_FOUND','Ингредиент не принадлежит филиалу');
      const previous=new Map(balances.rows.map(r=>[r.ingredient_id,r]));
      for(const line of lines){const b=previous.get(line.ingredientId);
        assert(b,404,'INGREDIENT_NOT_FOUND','Ингредиент не принадлежит филиалу');
        addStock(n(b.quantity_milli),n(b.value_cents),line.quantityMilli,line.totalCostCents);}
      const total=lines.reduce((v,l)=>v+BigInt(l.totalCostCents),0n);
      const receipt=(await db.query(`INSERT INTO purchase_receipts(organization_id,branch_id,supplier_id,reference,total_cost_cents,received_by)
        VALUES($1,$2,$3,$4,$5,$6) RETURNING id`,[ctx.organizationId,ctx.branchId,supplierId,reference,total.toString(),ctx.userId])).rows[0];
      for(const line of lines){
        await db.query(`INSERT INTO purchase_receipt_lines(organization_id,branch_id,receipt_id,ingredient_id,quantity_milli,total_cost_cents)
          VALUES($1,$2,$3,$4,$5,$6)`,[ctx.organizationId,ctx.branchId,receipt.id,line.ingredientId,line.quantityMilli,line.totalCostCents]);
        await db.query(`UPDATE stock_balances SET quantity_milli=quantity_milli+$4::bigint,value_cents=value_cents+$5::bigint,revision=revision+1
          WHERE organization_id=$1 AND branch_id=$2 AND ingredient_id=$3`,[ctx.organizationId,ctx.branchId,line.ingredientId,line.quantityMilli,line.totalCostCents]);
        await db.query(`INSERT INTO stock_movements(organization_id,branch_id,ingredient_id,delta_quantity_milli,delta_value_cents,reason,source_id,actor_id)
          VALUES($1,$2,$3,$4,$5,'RECEIPT',$6,$7)`,[ctx.organizationId,ctx.branchId,line.ingredientId,line.quantityMilli,line.totalCostCents,receipt.id,ctx.userId]);
      }
      await this.audit(db,ctx,'stock.receipt','purchase_receipt',receipt.id,{lineCount:lines.length,totalCents:Number(total)});
      return this.getReceipt(db,ctx,receipt.id);
    }));
  }
  async countStock(ctx:Ctx,id:string,countedQuantityMilli:number,expectedRevision:number,foundValueCents:number|null,key:string):Promise<StockCount>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'stock-count',branchId:ctx.branchId,id,countedQuantityMilli,expectedRevision,foundValueCents},async()=>{
      const balance=(await db.query(`SELECT quantity_milli,value_cents,revision FROM stock_balances WHERE organization_id=$1 AND branch_id=$2 AND ingredient_id=$3 FOR UPDATE`,
        [ctx.organizationId,ctx.branchId,id])).rows[0];
      assert(balance,404,'INGREDIENT_NOT_FOUND','Ингредиент не найден');
      assert(balance.revision===expectedRevision,409,'STALE_VERSION','Остаток уже изменился. Повторите подсчёт');
      const before=n(balance.quantity_milli);
      const variance=countVariance(before,n(balance.value_cents),countedQuantityMilli,foundValueCents);
      const count=(await db.query(`INSERT INTO stock_counts(organization_id,branch_id,ingredient_id,before_quantity_milli,
        counted_quantity_milli,delta_quantity_milli,delta_value_cents,actor_id) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
        [ctx.organizationId,ctx.branchId,id,before,countedQuantityMilli,variance.deltaMilli,variance.deltaValueCents,ctx.userId])).rows[0];
      await db.query(`UPDATE stock_balances SET quantity_milli=$4,value_cents=value_cents+$5::bigint,revision=revision+1
        WHERE organization_id=$1 AND branch_id=$2 AND ingredient_id=$3`,[ctx.organizationId,ctx.branchId,id,countedQuantityMilli,variance.deltaValueCents]);
      if(variance.deltaMilli!==0)await db.query(`INSERT INTO stock_movements(organization_id,branch_id,ingredient_id,delta_quantity_milli,delta_value_cents,reason,source_id,actor_id)
        VALUES($1,$2,$3,$4,$5,'COUNT',$6,$7)`,[ctx.organizationId,ctx.branchId,id,variance.deltaMilli,variance.deltaValueCents,count.id,ctx.userId]);
      await this.audit(db,ctx,'stock.count','ingredient',id,{countId:count.id,...variance});
      return {id:count.id,ingredientId:id,beforeQuantityMilli:before,countedQuantityMilli,deltaQuantityMilli:variance.deltaMilli,deltaValueCents:variance.deltaValueCents};
    }));
  }
  async stockMovements(ctx:Ctx):Promise<StockMovement[]>{
    const r=await this.pool.query(`SELECT m.id,m.ingredient_id,i.name,m.delta_quantity_milli,m.delta_value_cents,m.reason,m.source_id,m.created_at
      FROM stock_movements m JOIN ingredients i ON i.organization_id=m.organization_id AND i.branch_id=m.branch_id AND i.id=m.ingredient_id
      WHERE m.organization_id=$1 AND m.branch_id=$2 ORDER BY m.created_at DESC,m.id DESC LIMIT 150`,[ctx.organizationId,ctx.branchId]);
    return r.rows.map(x=>({id:x.id,ingredientId:x.ingredient_id,ingredientName:x.name,
      deltaQuantityMilli:n(x.delta_quantity_milli),deltaValueCents:n(x.delta_value_cents),reason:x.reason,
      sourceId:x.source_id,createdAt:new Date(x.created_at).toISOString()}));
  }
  private taskRow(r:Row):RestaurantTask{
    return {id:r.id,title:r.title,description:r.description,assignedTo:r.assigned_to||null,employeeName:r.display_name||null,createdBy:r.created_by,
      status:r.status,dueAt:r.due_at?new Date(r.due_at).toISOString():null,completedAt:r.completed_at?new Date(r.completed_at).toISOString():null,
      revision:r.revision,createdAt:new Date(r.created_at).toISOString()};
  }
  private async getTask(db:DB,ctx:Ctx,id:string):Promise<RestaurantTask>{
    const r=await db.query(`SELECT t.*,u.display_name FROM restaurant_tasks t LEFT JOIN users u ON u.id=t.assigned_to
      WHERE t.organization_id=$1 AND t.branch_id=$2 AND t.id=$3`,[ctx.organizationId,ctx.branchId,id]);
    assert(r.rows[0],404,'NOT_FOUND','Задача не найдена');return this.taskRow(r.rows[0]);
  }
  async tasks(ctx:Ctx):Promise<RestaurantTask[]>{
    const manager=managesShifts(ctx.role)||['finance_director','auditor'].includes(ctx.role);
    const r=await this.pool.query(`SELECT t.*,u.display_name FROM restaurant_tasks t LEFT JOIN users u ON u.id=t.assigned_to
      WHERE t.organization_id=$1 AND t.branch_id=$2 AND ($3::boolean OR t.assigned_to=$4)
      ORDER BY (t.status IN ('OPEN','IN_PROGRESS')) DESC,t.due_at ASC NULLS LAST,t.created_at DESC LIMIT 200`,
      [ctx.organizationId,ctx.branchId,manager,ctx.userId]);
    return r.rows.map(x=>this.taskRow(x));
  }
  async createTask(ctx:Ctx,title:string,description:string,assignedTo:string|null,dueAt:string|null,key:string):Promise<RestaurantTask>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'task',branchId:ctx.branchId,title,description,assignedTo,dueAt},async()=>{
      if(assignedTo){
        const member=(await db.query(`SELECT 1 FROM memberships m WHERE m.organization_id=$1 AND m.user_id=$2 AND
          (m.role IN ('owner','finance_director','operations_director') OR EXISTS
          (SELECT 1 FROM branch_grants g WHERE g.organization_id=$1 AND g.branch_id=$3 AND g.user_id=$2))`,
          [ctx.organizationId,assignedTo,ctx.branchId])).rows[0];
        assert(member,404,'EMPLOYEE_NOT_FOUND','Сотрудник не имеет доступа к филиалу');
      }
      const r=(await db.query(`INSERT INTO restaurant_tasks(organization_id,branch_id,title,description,assigned_to,created_by,due_at)
        VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,[ctx.organizationId,ctx.branchId,title,description,assignedTo,ctx.userId,dueAt])).rows[0];
      await this.audit(db,ctx,'task.create','restaurant_task',r.id,{assignedTo,dueAt});return this.getTask(db,ctx,r.id);
    }));
  }
  async changeTaskStatus(ctx:Ctx,id:string,to:TaskStatus,expectedRevision:number,key:string):Promise<RestaurantTask>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'task-status',branchId:ctx.branchId,id,to,expectedRevision},async()=>{
      const r=(await db.query(`SELECT * FROM restaurant_tasks WHERE organization_id=$1 AND branch_id=$2 AND id=$3 FOR UPDATE`,
        [ctx.organizationId,ctx.branchId,id])).rows[0];
      assert(r,404,'NOT_FOUND','Задача не найдена');
      const manager=managesShifts(ctx.role);
      assert(manager||r.assigned_to===ctx.userId,403,'FORBIDDEN','Изменять задачу может исполнитель или управляющий');
      assert(r.revision===expectedRevision,409,'STALE_VERSION','Задача изменена другим сотрудником');
      taskStatusTransition(r.status,to,manager);
      await db.query(`UPDATE restaurant_tasks SET status=$4,revision=revision+1,completed_at=CASE WHEN $4='DONE' THEN now() ELSE NULL END
        WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,[ctx.organizationId,ctx.branchId,id,to]);
      await this.audit(db,ctx,'task.status','restaurant_task',id,{from:r.status,to});return this.getTask(db,ctx,id);
    }));
  }
  private async captureRecipeSnapshot(db:DB,ctx:Ctx,orderId:string):Promise<void>{
    // Lock menu items in stable ID order. Recipe editors lock these same rows FOR UPDATE,
    // preventing a partially replaced recipe from being read during kitchen dispatch.
    await db.query(`SELECT id FROM menu_items WHERE organization_id=$1 AND branch_id=$2 AND id IN
      (SELECT DISTINCT menu_item_id FROM order_lines WHERE organization_id=$1 AND branch_id=$2 AND order_id=$3)
      ORDER BY id FOR SHARE`,[ctx.organizationId,ctx.branchId,orderId]);
    // The recipe at SENT is immutable for this order, even if the chef edits it later.
    const missing=await db.query(`SELECT COUNT(*)::int AS count FROM order_lines l WHERE l.organization_id=$1 AND l.branch_id=$2 AND l.order_id=$3
      AND NOT EXISTS (SELECT 1 FROM recipe_components c WHERE c.organization_id=l.organization_id AND c.branch_id=l.branch_id AND c.menu_item_id=l.menu_item_id)`,
      [ctx.organizationId,ctx.branchId,orderId]);
    await db.query(`INSERT INTO order_recipe_snapshots(organization_id,branch_id,order_line_id,ingredient_id,quantity_milli)
      SELECT l.organization_id,l.branch_id,l.id,c.ingredient_id,c.quantity_milli*l.quantity
      FROM order_lines l JOIN recipe_components c ON c.organization_id=l.organization_id AND c.branch_id=l.branch_id AND c.menu_item_id=l.menu_item_id
      WHERE l.organization_id=$1 AND l.branch_id=$2 AND l.order_id=$3`,[ctx.organizationId,ctx.branchId,orderId]);
    await db.query(`UPDATE orders SET recipe_missing_lines=$4 WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,
      [ctx.organizationId,ctx.branchId,orderId,missing.rows[0].count]);
  }
  private async consumeStockForOrder(db:DB,ctx:Ctx,orderId:string):Promise<number>{
    const requirements=await db.query(`SELECT ingredient_id,SUM(quantity_milli)::bigint AS quantity_milli FROM order_recipe_snapshots
      WHERE organization_id=$1 AND branch_id=$2 AND order_line_id IN
        (SELECT id FROM order_lines WHERE organization_id=$1 AND branch_id=$2 AND order_id=$3)
      GROUP BY ingredient_id ORDER BY ingredient_id`,[ctx.organizationId,ctx.branchId,orderId]);
    if(!requirements.rows.length)return 0;
    const ids=requirements.rows.map(r=>r.ingredient_id);
    const found=await db.query(`SELECT ingredient_id,quantity_milli,value_cents FROM stock_balances
      WHERE organization_id=$1 AND branch_id=$2 AND ingredient_id=ANY($3::uuid[])
      ORDER BY ingredient_id FOR UPDATE`,[ctx.organizationId,ctx.branchId,ids]);
    assert(found.rows.length===ids.length,409,'STOCK_MISSING','Складские позиции недоступны');
    const balance=new Map(found.rows.map(r=>[r.ingredient_id,r]));
    let cost=0n;
    for(const row of requirements.rows){
      const current=balance.get(row.ingredient_id);
      assert(current,409,'STOCK_MISSING','Складской остаток не найден');
      const used=n(row.quantity_milli);
      assert(used<=STOCK_LIMIT,409,'STOCK_LIMIT','Объём ингредиентов превышает лимит');
      const value=costOfIssue(n(current.quantity_milli),n(current.value_cents),used);
      cost+=BigInt(value);
      assert(cost<=BigInt(VALUE_LIMIT),409,'AMOUNT_TOO_LARGE','Превышен предел себестоимости заказа');
      await db.query(`UPDATE stock_balances SET quantity_milli=quantity_milli-$4::bigint,value_cents=value_cents-$5::bigint,revision=revision+1
        WHERE organization_id=$1 AND branch_id=$2 AND ingredient_id=$3`,[ctx.organizationId,ctx.branchId,row.ingredient_id,used,value]);
      await db.query(`INSERT INTO stock_movements(organization_id,branch_id,ingredient_id,delta_quantity_milli,delta_value_cents,reason,source_id,actor_id)
        VALUES($1,$2,$3,$4,$5,'ORDER',$6,$7)`,[ctx.organizationId,ctx.branchId,row.ingredient_id,-used,-value,orderId,ctx.userId]);
    }
    return Number(cost);
  }

  async orders(ctx:Ctx):Promise<Order[]>{
    const ids=await this.pool.query('SELECT id FROM orders WHERE organization_id=$1 AND branch_id=$2 ORDER BY created_at DESC LIMIT 80',[ctx.organizationId,ctx.branchId]);
    return Promise.all(ids.rows.map(r=>this.getOrder(this.pool,ctx,r.id)));
  }
  private async idempotent<T>(db:DB,ctx:Ctx,key:string,request:unknown,operation:()=>Promise<T>):Promise<T>{
    const fingerprint=sha256(JSON.stringify(request));
    await db.query(`INSERT INTO idempotency_records(organization_id,actor_id,operation_key,fingerprint)
      VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING`,[ctx.organizationId,ctx.userId,key,fingerprint]);
    const row=(await db.query(`SELECT * FROM idempotency_records WHERE organization_id=$1 AND actor_id=$2 AND operation_key=$3 FOR UPDATE`,[ctx.organizationId,ctx.userId,key])).rows[0];
    assert(row?.fingerprint===fingerprint,409,'IDEMPOTENCY_CONFLICT','Ключ повторён с другими данными');
    if(row.response!==null && row.response!==undefined) return row.response as T;
    const result=await operation();
    await db.query(`UPDATE idempotency_records SET response=$4::jsonb,status_code=200 WHERE organization_id=$1 AND actor_id=$2 AND operation_key=$3`,
      [ctx.organizationId,ctx.userId,key,JSON.stringify(result)]);
    return result;
  }
  async createOrder(ctx:Ctx,tableId:string|null,key:string):Promise<Order>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'createOrder',branchId:ctx.branchId,tableId},async()=>{
      if(tableId){
        await this.lockTable(db,ctx,tableId);
        const due=await db.query(`SELECT 1 FROM reservations WHERE organization_id=$1 AND branch_id=$2
          AND table_id=$3 AND status='CONFIRMED' AND starts_at<=now()+interval '15 minutes'
          AND ends_at>now() LIMIT 1`,[ctx.organizationId,ctx.branchId,tableId]);
        assert(!due.rows[0],409,'TABLE_RESERVED','Стол зарезервирован для гостя');
      }
      const r=(await db.query('INSERT INTO orders(organization_id,branch_id,table_id,created_by) VALUES($1,$2,$3,$4) RETURNING id',[ctx.organizationId,ctx.branchId,tableId,ctx.userId])).rows[0];
      await this.audit(db,ctx,'order.create','order',r.id,{tableId});
      return this.getOrder(db,ctx,r.id);
    }));
  }
  async addOrderItem(ctx:Ctx,orderId:string,itemId:string,quantity:number,expectedRevision:number,key:string):Promise<Order>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'addItem',branchId:ctx.branchId,orderId,itemId,quantity,expectedRevision},async()=>{
      const row=(await db.query(`SELECT revision,status,total_cents FROM orders WHERE organization_id=$1 AND branch_id=$2 AND id=$3 FOR UPDATE`,[ctx.organizationId,ctx.branchId,orderId])).rows[0];
      assert(row,404,'NOT_FOUND','Заказ не найден');
      assert(row.revision===expectedRevision,409,'STALE_VERSION','Заказ изменился. Обновите данные');
      assert(row.status==='OPEN',409,'ORDER_LOCKED','Добавлять блюда можно только до отправки на кухню');
      const m=(await db.query(`SELECT id,name,price_cents FROM menu_items WHERE organization_id=$1 AND branch_id=$2 AND id=$3 AND active=true`,[ctx.organizationId,ctx.branchId,itemId])).rows[0];
      assert(m,404,'MENU_NOT_FOUND','Активное блюдо не найдено');
      const amount=BigInt(m.price_cents)*BigInt(quantity);
      assert(BigInt(row.total_cents)+amount<=9_999_999_999_999n,400,'AMOUNT_TOO_LARGE','Превышен предел суммы заказа');
      await db.query(`INSERT INTO order_lines(organization_id,branch_id,order_id,menu_item_id,name_snapshot,unit_price_cents,quantity)
        VALUES($1,$2,$3,$4,$5,$6,$7)`,[ctx.organizationId,ctx.branchId,orderId,m.id,m.name,m.price_cents,quantity]);
      await db.query(`UPDATE orders SET total_cents=total_cents+$4::bigint,revision=revision+1 WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,[ctx.organizationId,ctx.branchId,orderId,amount.toString()]);
      await this.audit(db,ctx,'order.add_item','order',orderId,{itemId,quantity});
      return this.getOrder(db,ctx,orderId);
    }));
  }
  async changeOrderStatus(ctx:Ctx,orderId:string,to:OrderStatus,expectedRevision:number,key:string):Promise<Order>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'status',branchId:ctx.branchId,orderId,to,expectedRevision},async()=>{
      const row=(await db.query(`SELECT revision,status,total_cents,recipe_missing_lines FROM orders WHERE organization_id=$1 AND branch_id=$2 AND id=$3 FOR UPDATE`,[ctx.organizationId,ctx.branchId,orderId])).rows[0];
      assert(row,404,'NOT_FOUND','Заказ не найден');
      assert(row.revision===expectedRevision,409,'STALE_VERSION','Заказ изменился. Обновите данные');
      requireTransition(ctx.role,row.status as OrderStatus,to);
      if(to==='SENT'){
        const lines=await db.query('SELECT 1 FROM order_lines WHERE organization_id=$1 AND branch_id=$2 AND order_id=$3 LIMIT 1',[ctx.organizationId,ctx.branchId,orderId]);
        assert(lines.rows[0],409,'EMPTY_ORDER','Нельзя отправить пустой заказ');
        await this.captureRecipeSnapshot(db,ctx,orderId);
      }
      // Old orders already SENT before R3 are not silently back-costed against a changed recipe.
      if(to==='COMPLETED' && row.recipe_missing_lines!==null){
        const recordedCost=await this.consumeStockForOrder(db,ctx,orderId);
        await db.query(`UPDATE orders SET actual_food_cost_cents=$4,costed_at=now() WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,
          [ctx.organizationId,ctx.branchId,orderId,recordedCost]);
      }
      await db.query(`UPDATE orders SET status=$4,revision=revision+1,
        sent_at=CASE WHEN $4='SENT' THEN now() ELSE sent_at END,
        preparing_at=CASE WHEN $4='PREPARING' THEN now() ELSE preparing_at END,
        ready_at=CASE WHEN $4='READY' THEN now() ELSE ready_at END,
        completed_at=CASE WHEN $4='COMPLETED' THEN now() ELSE NULL END
        WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,[ctx.organizationId,ctx.branchId,orderId,to]);
      if(to==='COMPLETED'||to==='CANCELLED'){
        const linked=(await db.query('SELECT reservation_id FROM orders WHERE organization_id=$1 AND branch_id=$2 AND id=$3',
          [ctx.organizationId,ctx.branchId,orderId])).rows[0];
        if(linked?.reservation_id){
          await db.query(`UPDATE reservations SET status='COMPLETED',revision=revision+1,updated_at=now()
            WHERE organization_id=$1 AND branch_id=$2 AND id=$3 AND status='SEATED'`,[ctx.organizationId,ctx.branchId,linked.reservation_id]);
        }
      }
      await this.audit(db,ctx,'order.status','order',orderId,{from:row.status,to});
      return this.getOrder(db,ctx,orderId);
    }));
  }
  // R4: Manual expenses remain distinct from inventory acquisitions (no double counting purchases).
  private expenseRow(row:Row):Expense{
    // PostgreSQL DATE is a calendar date, not an instant: never convert it through a JS timezone.
    const day=financeDate(String(row.occurred_on_iso));
    return {id:row.id,category:row.category,description:row.description,amountCents:n(row.amount_cents),
      occurredOn:day,status:row.status,revision:row.revision,createdAt:new Date(row.created_at).toISOString(),
      voidedAt:row.voided_at?new Date(row.voided_at).toISOString():null,voidReason:row.void_reason??null};
  }
  private budgetRow(row:Row):Budget{
    return {period:row.period,category:row.category,amountCents:n(row.amount_cents),revision:row.revision};
  }
  private start(period:string):string{return `${financePeriod(period)}-01`;}
  private async expensesFrom(db:DB,ctx:Ctx,period:string):Promise<Expense[]>{
    const first=this.start(period);
    const result=await db.query(`SELECT *, occurred_on::text AS occurred_on_iso FROM finance_expenses WHERE organization_id=$1 AND branch_id=$2
      AND occurred_on >= $3::date AND occurred_on < ($3::date + interval '1 month')
      ORDER BY occurred_on DESC,created_at DESC`,[ctx.organizationId,ctx.branchId,first]);
    return result.rows.map(r=>this.expenseRow(r));
  }
  async financeExpenses(ctx:Ctx,period:string):Promise<Expense[]>{
    return this.expensesFrom(this.pool,ctx,period);
  }
  async createFinanceExpense(ctx:Ctx,input:{category:ExpenseCategory;description:string;amountCents:number;occurredOn:string},key:string):Promise<Expense>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'finance-expense',branchId:ctx.branchId,...input},async()=>{
      const row=(await db.query(`INSERT INTO finance_expenses(organization_id,branch_id,category,description,amount_cents,occurred_on,created_by)
        VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *, occurred_on::text AS occurred_on_iso`,
        [ctx.organizationId,ctx.branchId,input.category,input.description,input.amountCents,input.occurredOn,ctx.userId])).rows[0];
      await this.audit(db,ctx,'finance.expense_create','finance_expense',row.id,{amountCents:input.amountCents,category:input.category,occurredOn:input.occurredOn});
      return this.expenseRow(row);
    }));
  }
  async voidFinanceExpense(ctx:Ctx,id:string,expectedRevision:number,reason:string,key:string):Promise<Expense>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'finance-expense-void',branchId:ctx.branchId,id,expectedRevision,reason},async()=>{
      const previous=(await db.query(`SELECT id,revision,status FROM finance_expenses
        WHERE organization_id=$1 AND branch_id=$2 AND id=$3 FOR UPDATE`,[ctx.organizationId,ctx.branchId,id])).rows[0];
      assert(previous,404,'EXPENSE_NOT_FOUND','Расход не найден');
      assert(previous.revision===expectedRevision,409,'STALE_VERSION','Расход изменён другим сотрудником');
      assert(previous.status==='POSTED',409,'EXPENSE_VOIDED','Расход уже аннулирован');
      const updated=(await db.query(`UPDATE finance_expenses SET status='VOIDED',revision=revision+1,
        voided_at=now(),voided_by=$4,void_reason=$5 WHERE organization_id=$1 AND branch_id=$2 AND id=$3 RETURNING *, occurred_on::text AS occurred_on_iso`,
        [ctx.organizationId,ctx.branchId,id,ctx.userId,reason])).rows[0];
      await this.audit(db,ctx,'finance.expense_void','finance_expense',id,{reason});
      return this.expenseRow(updated);
    }));
  }
  private async budgetsFrom(db:DB,ctx:Ctx,period:string):Promise<Budget[]>{
    const rows=await db.query(`SELECT period,category,amount_cents,revision FROM finance_budgets
      WHERE organization_id=$1 AND branch_id=$2 AND period=$3 ORDER BY category`,[ctx.organizationId,ctx.branchId,financePeriod(period)]);
    return rows.rows.map(row=>this.budgetRow(row));
  }
  async financeBudgets(ctx:Ctx,period:string):Promise<Budget[]>{return this.budgetsFrom(this.pool,ctx,period);}
  async saveFinanceBudget(ctx:Ctx,period:string,category:BudgetCategory,amountCents:number,expectedRevision:number,key:string):Promise<Budget>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'finance-budget',branchId:ctx.branchId,period,category,amountCents,expectedRevision},async()=>{
      let row:Row|undefined;
      if(expectedRevision===0){
        row=(await db.query(`INSERT INTO finance_budgets(organization_id,branch_id,period,category,amount_cents,updated_by)
          VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT DO NOTHING RETURNING *`,
          [ctx.organizationId,ctx.branchId,period,category,amountCents,ctx.userId])).rows[0];
      }else{
        row=(await db.query(`UPDATE finance_budgets SET amount_cents=$5,revision=revision+1,updated_at=now(),updated_by=$6
          WHERE organization_id=$1 AND branch_id=$2 AND period=$3 AND category=$4 AND revision=$7 RETURNING *`,
          [ctx.organizationId,ctx.branchId,period,category,amountCents,ctx.userId,expectedRevision])).rows[0];
      }
      assert(row,409,'STALE_VERSION','План уже изменён, обновите данные');
      await this.audit(db,ctx,'finance.budget_save','branch',ctx.branchId,{period,category,amountCents,revision:row.revision});
      return this.budgetRow(row);
    }));
  }
  private async financeFacts(db:DB,ctx:Ctx,period:string):Promise<FinanceFacts>{
    const first=this.start(period);
    const [orders,expenses,stock]=await Promise.all([
      db.query(`SELECT o.id,o.total_cents,o.actual_food_cost_cents,o.costed_at,o.recipe_missing_lines
        FROM orders o JOIN branches b ON b.organization_id=o.organization_id AND b.id=o.branch_id
        WHERE o.organization_id=$1 AND o.branch_id=$2 AND o.status='COMPLETED'
          AND (o.completed_at AT TIME ZONE b.timezone)::date >= $3::date
          AND (o.completed_at AT TIME ZONE b.timezone)::date < ($3::date + interval '1 month')`,[ctx.organizationId,ctx.branchId,first]),
      this.expensesFrom(db,ctx,period),
      db.query(`SELECT sc.delta_value_cents FROM stock_counts sc JOIN branches b ON b.organization_id=sc.organization_id AND b.id=sc.branch_id
        WHERE sc.organization_id=$1 AND sc.branch_id=$2 AND sc.delta_value_cents<0
          AND (sc.counted_at AT TIME ZONE b.timezone)::date >= $3::date
          AND (sc.counted_at AT TIME ZONE b.timezone)::date < ($3::date + interval '1 month')`,[ctx.organizationId,ctx.branchId,first])
    ]);
    return {orders:orders.rows.map(r=>({id:r.id,amountCents:n(r.total_cents),
      costCents:r.costed_at===null?null:n(r.actual_food_cost_cents),
      complete:r.costed_at!==null&&r.recipe_missing_lines===0})),
      expenses,stockLossCents:centsSum(stock.rows.map(r=>-n(r.delta_value_cents)),'Потери склада')};
  }
  async financeReport(ctx:Ctx,period:string):Promise<FinanceReport>{
    return this.readSnapshot(async db=>{
      const [facts,budgets]=await Promise.all([this.financeFacts(db,ctx,period),this.budgetsFrom(db,ctx,period)]);
      return calculateFinanceReport(period,facts,budgets);
    });
  }
  async financeLedger(ctx:Ctx,period:string):Promise<LedgerEntry[]>{
    return this.readSnapshot(async db=>{
      const first=this.start(period);
      const [orders,expenses,losses]=await Promise.all([
        db.query(`SELECT o.id,o.total_cents,o.actual_food_cost_cents,o.costed_at,o.recipe_missing_lines,o.completed_at
          FROM orders o JOIN branches b ON b.organization_id=o.organization_id AND b.id=o.branch_id
          WHERE o.organization_id=$1 AND o.branch_id=$2 AND o.status='COMPLETED'
          AND (o.completed_at AT TIME ZONE b.timezone)::date >= $3::date
          AND (o.completed_at AT TIME ZONE b.timezone)::date < ($3::date + interval '1 month')
          ORDER BY o.completed_at DESC LIMIT 400`,[ctx.organizationId,ctx.branchId,first]),
        this.expensesFrom(db,ctx,period),
        db.query(`SELECT s.id,s.delta_value_cents,s.counted_at,i.name FROM stock_counts s
          JOIN ingredients i ON i.id=s.ingredient_id AND i.organization_id=s.organization_id AND i.branch_id=s.branch_id
          JOIN branches b ON b.organization_id=s.organization_id AND b.id=s.branch_id
          WHERE s.organization_id=$1 AND s.branch_id=$2 AND s.delta_value_cents<0
          AND (s.counted_at AT TIME ZONE b.timezone)::date >= $3::date
          AND (s.counted_at AT TIME ZONE b.timezone)::date < ($3::date + interval '1 month')
          ORDER BY s.counted_at DESC LIMIT 400`,[ctx.organizationId,ctx.branchId,first])
      ]);
      const ledger:LedgerEntry[]=[];
      for(const o of orders.rows){const complete=o.costed_at!==null&&o.recipe_missing_lines===0;
        const time=new Date(o.completed_at).toISOString();
        ledger.push({id:`sale:${o.id}`,source:'ORDER',sourceId:o.id,description:'Завершённый заказ',occurredAt:time,signedAmountCents:n(o.total_cents),complete:true});
        if(o.costed_at!==null){ledger.push({id:`food:${o.id}`,source:'FOOD_COST',sourceId:o.id,
          description:complete?'Себестоимость заказа':'Известная часть себестоимости (неполные данные)',
          occurredAt:time,signedAmountCents:-n(o.actual_food_cost_cents),complete});}
      }
      for(const e of expenses){ledger.push({id:`expense:${e.id}`,source:'EXPENSE',sourceId:e.id,
        description:e.status==='VOIDED'?`Аннулирован: ${e.description}`:e.description,
        occurredAt:`${e.occurredOn}T12:00:00.000Z`,signedAmountCents:e.status==='POSTED'?-e.amountCents:0,complete:e.status==='POSTED'});}
      for(const l of losses.rows)ledger.push({id:`loss:${l.id}`,source:'STOCK_LOSS',sourceId:l.id,
        description:`Недостача при инвентаризации: ${l.name}`,occurredAt:new Date(l.counted_at).toISOString(),
        signedAmountCents:n(l.delta_value_cents),complete:true});
      return ledger.sort((a,b)=>b.occurredAt.localeCompare(a.occurredAt)).slice(0,400);
    });
  }
  // R5: branch-scoped guest registry. No automatic identity matching or marketing sends.
  private guestRow(r:Row):Guest{
    return {id:r.id,displayName:r.display_name,email:r.email,phone:r.phone,revision:r.revision,createdAt:new Date(r.created_at).toISOString()};
  }
  private consentRow(r:Row):Consent{
    return {guestId:r.guest_id,channel:r.channel,state:r.state,evidence:r.evidence,revision:r.revision,recordedAt:new Date(r.recorded_at).toISOString()};
  }
  private feedbackRow(r:Row):GuestFeedback{
    return {id:r.id,guestId:r.guest_id,orderId:r.order_id,kind:r.kind,rating:r.rating,comment:r.comment,
      status:r.status,resolution:r.resolution,revision:r.revision,createdAt:new Date(r.created_at).toISOString(),
      resolvedAt:r.resolved_at?new Date(r.resolved_at).toISOString():null};
  }
  private async lockGuest(db:DB,ctx:Ctx,id:string){
    const row=(await db.query(`SELECT * FROM crm_guests WHERE organization_id=$1 AND branch_id=$2 AND id=$3 FOR UPDATE`,
      [ctx.organizationId,ctx.branchId,id])).rows[0];
    assert(row,404,'GUEST_NOT_FOUND','Гость не найден в этом ресторане');return row;
  }
  async guests(ctx:Ctx,after:string|null):Promise<{guests:Guest[];nextCursor:string|null}>{
    const rows=(await this.pool.query(`SELECT * FROM crm_guests WHERE organization_id=$1 AND branch_id=$2
      AND ($3::uuid IS NULL OR id>$3::uuid) ORDER BY id LIMIT 101`,[ctx.organizationId,ctx.branchId,after])).rows;
    const selected=rows.slice(0,100);
    return {guests:selected.map(r=>this.guestRow(r)),nextCursor:rows.length>100?selected.at(-1)!.id:null};
  }
  async createGuest(ctx:Ctx,input:GuestInput,key:string):Promise<Guest>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'guest-create',branchId:ctx.branchId,input},async()=>{
      const row=(await db.query(`INSERT INTO crm_guests(organization_id,branch_id,display_name,email,phone)
        VALUES($1,$2,$3,$4,$5) RETURNING *`,[ctx.organizationId,ctx.branchId,input.displayName,input.email,input.phone])).rows[0];
      await this.audit(db,ctx,'guest.create','crm_guest',row.id);
      return this.guestRow(row);
    }));
  }
  async updateGuest(ctx:Ctx,id:string,revision:number,input:GuestInput,key:string):Promise<Guest>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'guest-update',branchId:ctx.branchId,id,revision,input},async()=>{
      const old=await this.lockGuest(db,ctx,id);
      assert(old.revision===revision,409,'STALE_VERSION','Карточка гостя изменена другим сотрудником');
      const row=(await db.query(`UPDATE crm_guests SET display_name=$4,email=$5,phone=$6,revision=revision+1,updated_at=now()
        WHERE organization_id=$1 AND branch_id=$2 AND id=$3 RETURNING *`,
        [ctx.organizationId,ctx.branchId,id,input.displayName,input.email,input.phone])).rows[0];
      await this.audit(db,ctx,'guest.update','crm_guest',id,{fields:['displayName','email','phone']});
      return this.guestRow(row);
    }));
  }
  async eraseGuest(ctx:Ctx,id:string,revision:number,key:string):Promise<{guestId:string;erased:true}>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'guest-erase',branchId:ctx.branchId,id,revision},async()=>{
      const old=await this.lockGuest(db,ctx,id);
      assert(old.revision===revision,409,'STALE_VERSION','Карточка гостя изменилась');
      // Delete guest-related free-text feedback (including feedback attached by order), not just its guest_id.
      await db.query(`DELETE FROM guest_feedback WHERE organization_id=$1 AND branch_id=$2 AND (guest_id=$3 OR order_id IN
        (SELECT id FROM orders WHERE organization_id=$1 AND branch_id=$2 AND guest_id=$3))`,
        [ctx.organizationId,ctx.branchId,id]);
      await db.query(`UPDATE orders SET guest_id=NULL WHERE organization_id=$1 AND branch_id=$2 AND guest_id=$3`,
        [ctx.organizationId,ctx.branchId,id]);
      await db.query(`DELETE FROM crm_guests WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,
        [ctx.organizationId,ctx.branchId,id]);
      await this.audit(db,ctx,'guest.erase','crm_guest',id,{scope:'primary-database',contactDataRemoved:true});
      return {guestId:id,erased:true};
    }));
  }
  async guestVisits(ctx:Ctx,guestId:string):Promise<GuestVisit[]>{
    await this.lockGuest(this.pool,ctx,guestId);
    const rows=(await this.pool.query(`SELECT id,completed_at,total_cents FROM orders WHERE organization_id=$1 AND branch_id=$2
      AND guest_id=$3 AND status='COMPLETED' ORDER BY completed_at DESC LIMIT 200`,[ctx.organizationId,ctx.branchId,guestId])).rows;
    return rows.map(r=>({orderId:r.id,completedAt:new Date(r.completed_at).toISOString(),totalCents:n(r.total_cents)}));
  }
  async guestConsents(ctx:Ctx,guestId:string):Promise<Consent[]>{
    await this.lockGuest(this.pool,ctx,guestId);
    const rows=(await this.pool.query(`SELECT * FROM guest_consents WHERE organization_id=$1 AND branch_id=$2 AND guest_id=$3 ORDER BY channel`,
      [ctx.organizationId,ctx.branchId,guestId])).rows;
    return rows.map(r=>this.consentRow(r));
  }
  async saveGuestConsent(ctx:Ctx,guestId:string,channel:ConsentChannel,state:ConsentState,evidence:string|null,
    expectedRevision:number,key:string):Promise<Consent>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'guest-consent',branchId:ctx.branchId,guestId,channel,state,evidence,expectedRevision},async()=>{
      await this.lockGuest(db,ctx,guestId);
      let row:Row|undefined;
      if(expectedRevision===0){
        row=(await db.query(`INSERT INTO guest_consents(organization_id,branch_id,guest_id,channel,state,evidence,recorded_by)
          VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT DO NOTHING RETURNING *`,
          [ctx.organizationId,ctx.branchId,guestId,channel,state,evidence,ctx.userId])).rows[0];
      }else{
        row=(await db.query(`UPDATE guest_consents SET state=$5,evidence=$6,recorded_by=$7,
          recorded_at=now(),revision=revision+1
          WHERE organization_id=$1 AND branch_id=$2 AND guest_id=$3 AND channel=$4 AND revision=$8 RETURNING *`,
          [ctx.organizationId,ctx.branchId,guestId,channel,state,evidence,ctx.userId,expectedRevision])).rows[0];
      }
      assert(row,409,'STALE_VERSION','Согласие уже изменено. Обновите данные');
      await this.audit(db,ctx,'guest.consent','crm_guest',guestId,{channel,state,revision:row.revision});
      return this.consentRow(row);
    }));
  }
  async linkOrderGuest(ctx:Ctx,orderId:string,guestId:string|null,expectedRevision:number,key:string):Promise<Order>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'order-guest',branchId:ctx.branchId,orderId,guestId,expectedRevision},async()=>{
      const row=(await db.query(`SELECT revision,status FROM orders WHERE organization_id=$1 AND branch_id=$2 AND id=$3 FOR UPDATE`,
        [ctx.organizationId,ctx.branchId,orderId])).rows[0];
      assert(row,404,'NOT_FOUND','Заказ не найден');
      assert(row.revision===expectedRevision,409,'STALE_VERSION','Версия заказа изменилась');
      assert(row.status==='OPEN',409,'ORDER_LOCKED','Гостя можно указать до отправки заказа на кухню');
      if(guestId)await this.lockGuest(db,ctx,guestId);
      await db.query(`UPDATE orders SET guest_id=$4,revision=revision+1 WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,
        [ctx.organizationId,ctx.branchId,orderId,guestId]);
      await this.audit(db,ctx,'order.guest_link','order',orderId,{linked:guestId!==null});
      return this.getOrder(db,ctx,orderId);
    }));
  }
  async guestInsights(ctx:Ctx):Promise<GuestInsights>{
    return this.readSnapshot(async db=>{
      const asOf=new Date();
      const guests=(await db.query(`SELECT id FROM crm_guests WHERE organization_id=$1 AND branch_id=$2`,[ctx.organizationId,ctx.branchId])).rows;
      const visits=(await db.query(`SELECT guest_id, id, total_cents, completed_at FROM orders
        WHERE organization_id=$1 AND branch_id=$2 AND status='COMPLETED' AND completed_at <= $3::timestamptz
          AND completed_at >= $3::timestamptz - interval '365 days'`,[ctx.organizationId,ctx.branchId,asOf.toISOString()])).rows;
      return calculateGuestInsights(guests.map(r=>r.id),visits.map(r=>({guestId:r.guest_id,orderId:r.id,
        totalCents:n(r.total_cents),completedAt:new Date(r.completed_at).toISOString()})),asOf);
    });
  }
  async guestFeedback(ctx:Ctx):Promise<GuestFeedback[]>{
    const rows=(await this.pool.query(`SELECT * FROM guest_feedback WHERE organization_id=$1 AND branch_id=$2
      ORDER BY created_at DESC LIMIT 200`,[ctx.organizationId,ctx.branchId])).rows;
    return rows.map(r=>this.feedbackRow(r));
  }
  async createGuestFeedback(ctx:Ctx,input:GuestFeedbackInput,key:string):Promise<GuestFeedback>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'feedback-create',branchId:ctx.branchId,input},async()=>{
      if(input.guestId)await this.lockGuest(db,ctx,input.guestId);
      if(input.orderId){const order=(await db.query(`SELECT guest_id FROM orders WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,
        [ctx.organizationId,ctx.branchId,input.orderId])).rows[0];
        assert(order,404,'ORDER_NOT_FOUND','Заказ не найден');
        assert(!input.guestId || !order.guest_id || order.guest_id===input.guestId,409,'FEEDBACK_IDENTITY','Гость не совпадает с заказом');}
      const row=(await db.query(`INSERT INTO guest_feedback(organization_id,branch_id,guest_id,order_id,kind,rating,comment,created_by)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,[ctx.organizationId,ctx.branchId,input.guestId,input.orderId,
        input.kind,input.rating,input.comment,ctx.userId])).rows[0];
      await this.audit(db,ctx,'feedback.create','guest_feedback',row.id,{kind:input.kind,rating:input.rating});
      return this.feedbackRow(row);
    }));
  }
  async resolveGuestFeedback(ctx:Ctx,id:string,expectedRevision:number,resolution:string,key:string):Promise<GuestFeedback>{
    return this.transaction(db=>this.idempotent(db,ctx,key,{kind:'feedback-resolve',branchId:ctx.branchId,id,expectedRevision,resolution},async()=>{
      const old=(await db.query(`SELECT * FROM guest_feedback WHERE organization_id=$1 AND branch_id=$2 AND id=$3 FOR UPDATE`,
        [ctx.organizationId,ctx.branchId,id])).rows[0];
      assert(old,404,'FEEDBACK_NOT_FOUND','Обращение не найдено');
      assert(old.revision===expectedRevision,409,'STALE_VERSION','Обращение изменилось');
      assert(old.status==='OPEN',409,'FEEDBACK_RESOLVED','Обращение уже закрыто');
      const row=(await db.query(`UPDATE guest_feedback SET status='RESOLVED',revision=revision+1,
        resolution=$4,resolved_by=$5,resolved_at=now() WHERE organization_id=$1 AND branch_id=$2 AND id=$3 RETURNING *`,
        [ctx.organizationId,ctx.branchId,id,resolution,ctx.userId])).rows[0];
      await this.audit(db,ctx,'feedback.resolve','guest_feedback',id);
      return this.feedbackRow(row);
    }));
  }

  async dashboard(ctx:Ctx){
    const result=await this.pool.query(`SELECT
      COALESCE(SUM(total_cents) FILTER(WHERE status='COMPLETED'),0)::bigint AS revenue,
      COUNT(*) FILTER(WHERE status='COMPLETED')::int AS completed,
      COUNT(*) FILTER(WHERE status NOT IN ('COMPLETED','CANCELLED'))::int AS active
      FROM orders WHERE organization_id=$1 AND branch_id=$2`,[ctx.organizationId,ctx.branchId]);
    const stat=result.rows[0];
    const [menuCount,tableCount,trend,ids,lowStock]=await Promise.all([
      this.pool.query('SELECT COUNT(*)::int AS count FROM menu_items WHERE organization_id=$1 AND branch_id=$2 AND active=true',[ctx.organizationId,ctx.branchId]),
      this.pool.query('SELECT COUNT(*)::int AS count FROM dining_tables WHERE organization_id=$1 AND branch_id=$2',[ctx.organizationId,ctx.branchId]),
      this.pool.query(`SELECT to_char(day_series.day,'YYYY-MM-DD') AS day,COALESCE(SUM(o.total_cents),0)::bigint AS revenue
        FROM generate_series((now() AT TIME ZONE $3)::date - interval '6 days',(now() AT TIME ZONE $3)::date,interval '1 day') AS day_series(day)
        LEFT JOIN orders o ON o.organization_id=$1 AND o.branch_id=$2 AND o.status='COMPLETED'
          AND (o.completed_at AT TIME ZONE $3)::date=day_series.day::date
        GROUP BY day_series.day ORDER BY day_series.day`,[ctx.organizationId,ctx.branchId,(await this.pool.query('SELECT timezone FROM branches WHERE organization_id=$1 AND id=$2',[ctx.organizationId,ctx.branchId])).rows[0]?.timezone||'UTC']),
      this.pool.query('SELECT id FROM orders WHERE organization_id=$1 AND branch_id=$2 ORDER BY created_at DESC LIMIT 5',[ctx.organizationId,ctx.branchId]),
      this.pool.query(`SELECT COUNT(*)::int AS count FROM ingredients i JOIN stock_balances b ON b.organization_id=i.organization_id
        AND b.branch_id=i.branch_id AND b.ingredient_id=i.id WHERE i.organization_id=$1 AND i.branch_id=$2
        AND b.quantity_milli < i.min_quantity_milli`,[ctx.organizationId,ctx.branchId])
    ]);
    const revenue=n(stat.revenue),completed=stat.completed as number;
    return {revenueCents:revenue,completedOrders:completed,averageCheckCents:completed?Number(BigInt(revenue)/BigInt(completed)):0,
      activeOrders:stat.active as number,menuItems:menuCount.rows[0].count,tables:tableCount.rows[0].count,lowStockCount:lowStock.rows[0].count,
      series:trend.rows.map(r=>({day:r.day,revenueCents:n(r.revenue)})),
      recentOrders:await Promise.all(ids.rows.map(r=>this.getOrder(this.pool,ctx,r.id)))};
  }
}
export function postgresConnectionString(connectionString:string):string{
  if(!process.env.DB_PASSWORD)return connectionString;
  const url=new URL(connectionString);url.password=process.env.DB_PASSWORD;return url.toString();
}
export async function createPostgresStore(connectionString:string):Promise<PostgresStore>{
  const pg=(await import('pg')).default;
  const pool=new pg.Pool({connectionString:postgresConnectionString(connectionString),max:12,connectionTimeoutMillis:5000,idleTimeoutMillis:30000});
  return new PostgresStore(pool as unknown as PoolLike);
}
