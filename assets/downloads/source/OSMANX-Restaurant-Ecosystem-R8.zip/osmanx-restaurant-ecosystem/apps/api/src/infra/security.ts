import { createHash, createHmac, randomBytes, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto';
import { AppError, assert } from '../domain/rules.ts';
const scryptAsync=(password:string,salt:Buffer)=>new Promise<Buffer>((resolve,reject)=>{
  scryptCallback(password,salt,64,SCRYPT_PARAMS,(error,derived)=>error?reject(error):resolve(derived));
});
const SCRYPT_PARAMS = { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const hash = await scryptAsync(password,salt);
  return `scrypt$32768$8$1$${salt.toString('hex')}$${hash.toString('hex')}`;
}
export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parts = stored.split('$');
  if (parts.length!==6 || parts[0]!=='scrypt') return false;
  const [n,r,p] = parts.slice(1,4).map(Number);
  if (n!==32768 || r!==8 || p!==1) return false;
  if (!/^[0-9a-f]{32}$/i.test(parts[4]) || !/^[0-9a-f]{128}$/i.test(parts[5])) return false;
  const hash = await scryptAsync(password,Buffer.from(parts[4],'hex'));
  return timingSafeEqual(hash,Buffer.from(parts[5],'hex'));
}
export const newToken = (): string => randomBytes(32).toString('base64url');
export const sha256 = (value: string): string => createHash('sha256').update(value).digest('hex');
export function csrfToken(tokenHash: string, secret: string): string {
  return createHmac('sha256',secret).update(`csrf:${tokenHash}`).digest('hex');
}
export function verifyCsrf(expected: string, submitted: string | undefined): void {
  const expectedBytes=Buffer.from(expected,'hex');
  const submittedBytes=Buffer.from(submitted||'','hex');
  assert(submittedBytes.length===32 && timingSafeEqual(submittedBytes,expectedBytes),403,'CSRF','Неверный CSRF-токен');
}
export function cookieValue(cookieHeader: string | undefined, name: string): string | undefined {
  return cookieHeader?.split(';').map(s=>s.trim()).find(s=>s.startsWith(`${name}=`))?.slice(name.length+1);
}
export function sessionCookie(token: string, secure: boolean): string {
  return `osmanx_session=${encodeURIComponent(token)}; HttpOnly; Path=/; SameSite=Lax; Max-Age=604800${secure?'; Secure':''}`;
}
export function clearSessionCookie(secure: boolean): string {
  return `osmanx_session=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0${secure?'; Secure':''}`;
}
export function validateRequestOrigin(origin: string | undefined, allowedOrigin: string): void {
  if (!origin) return; // Non-browser clients rely on the session CSRF token.
  let actual:string;
  try { actual = new URL(origin).origin; } catch { throw new AppError(403,'ORIGIN','Недопустимый Origin'); }
  assert(actual === new URL(allowedOrigin).origin,403,'ORIGIN','Запрос с другого сайта запрещён');
}
export class RateLimiter {
  private hits = new Map<string,{count:number;reset:number}>();
  private limit:number; private windowMs:number;
  constructor(limit=8, windowMs=15*60*1000) {this.limit=limit;this.windowMs=windowMs;}
  check(key:string, now=Date.now()): void {
    if(this.hits.size>20000) for(const [k,v] of this.hits) if(v.reset<=now) this.hits.delete(k);
    const prev=this.hits.get(key);
    const value= !prev || prev.reset<=now ? {count:1,reset:now+this.windowMs} : {count:prev.count+1,reset:prev.reset};
    this.hits.set(key,value);
    assert(value.count<=this.limit,429,'RATE_LIMIT','Слишком много попыток. Попробуйте позднее');
  }
}
