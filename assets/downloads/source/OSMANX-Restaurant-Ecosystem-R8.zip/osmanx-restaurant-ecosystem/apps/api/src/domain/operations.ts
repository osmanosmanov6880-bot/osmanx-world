import {AppError,assert,integerField,textField} from './rules.ts';
import type {Role} from './rules.ts';
export const RESERVATION_STATUSES=['CONFIRMED','SEATED','COMPLETED','CANCELLED','NO_SHOW'] as const;
export type ReservationStatus=typeof RESERVATION_STATUSES[number];
export type ReservationAction='CANCELLED'|'NO_SHOW';
export const managesShifts=(role:Role)=>['owner','operations_director','manager'].includes(role);
export function bookingWindow(startsAt:unknown,durationMinutes:unknown,now=new Date()):{startsAt:string;endsAt:string}{
  assert(typeof startsAt==='string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,3})?Z$/.test(startsAt),400,'BOOKING_DATE','Время брони должно быть в UTC ISO 8601');
  const ms=Date.parse(startsAt);
  assert(Number.isFinite(ms) && new Date(ms).toISOString()===new Date(startsAt).toISOString(),400,'BOOKING_DATE','Неверная дата');
  const minutes=integerField(durationMinutes,'durationMinutes',30,240);
  assert(ms>=now.getTime()-15*60_000 && ms<=now.getTime()+90*86400_000,400,'BOOKING_RANGE','Брони допустимы на ближайшие 90 дней, с допуском 15 минут');
  return {startsAt:new Date(ms).toISOString(),endsAt:new Date(ms+minutes*60_000).toISOString()};
}
export const overlaps=(aStart:string,aEnd:string,bStart:string,bEnd:string)=>aStart<bEnd&&bStart<aEnd;
export function reservationGuest(name:unknown,partySize:unknown){return {guestName:textField(name,'guestName',120),partySize:integerField(partySize,'partySize',1,40)};}
export function requireReservationAction(status:ReservationStatus,action:ReservationAction){
  assert(status==='CONFIRMED',409,'RESERVATION_LOCKED',`Бронь в статусе ${status} больше нельзя отменить или отметить неявку`);
  assert(action==='CANCELLED'||action==='NO_SHOW',400,'VALIDATION','Недопустимое действие с бронью');
}
export function requireShiftActor(role:Role,actorId:string,workerId:string){
  assert(managesShifts(role)||actorId===workerId,403,'FORBIDDEN','Чужой сменой может управлять только руководитель');
}
export function noteField(value:unknown,key:string){
  assert(typeof value==='string' && value.length<=500 && !/[\x00-\x08\x0B\x0C\x0E-\x1F]/.test(value),400,'VALIDATION',`${key}: максимум 500 символов`);
  return value.trim();
}
export function requireSeatDate(start:string,end:string,now=new Date()){
  assert(now.getTime()>=Date.parse(start)-30*60_000 && now.getTime()<Date.parse(end)+30*60_000,
    409,'RESERVATION_NOT_DUE','Посадка доступна за 30 минут до брони и не позднее 30 минут после её окончания');
}
export function sameTableCapacity(partySize:number,capacity:number){
  assert(partySize<=capacity,409,'CAPACITY','Количество гостей превышает вместимость стола');
}
