import {createCipheriv,createDecipheriv,randomBytes} from 'node:crypto';
import {AppError,assert} from '../domain/rules.ts';
import type {Credentials} from '../domain/integrations.ts';

export function encryptionKey(value:string|undefined):Buffer|null {
  if(!value)return null;
  const key=Buffer.from(value,'base64');
  assert(key.length===32&&key.toString('base64')===value,500,'CONFIG','INTEGRATION_ENCRYPTION_KEY must be 32 bytes base64');
  return key;
}
export function requireKey(key:Buffer|null):Buffer{
  if(!key)throw new AppError(503,'INTEGRATIONS_DISABLED','Нужно настроить INTEGRATION_ENCRYPTION_KEY на сервере');
  return key;
}
const aad=(orgId:string,branchId:string,id:string)=>Buffer.from(`osmanx:v1:${orgId}:${branchId}:${id}`,'utf8');
export function sealCredentials(key:Buffer,ctx:{organizationId:string;branchId:string},id:string,secret:Credentials):string{
  assert(key.length===32,500,'CONFIG','Некорректный ключ шифрования');
  const nonce=randomBytes(12);const cipher=createCipheriv('aes-256-gcm',key,nonce);
  cipher.setAAD(aad(ctx.organizationId,ctx.branchId,id));
  const ciphertext=Buffer.concat([cipher.update(JSON.stringify(secret),'utf8'),cipher.final()]);
  return ['v1',nonce.toString('base64url'),cipher.getAuthTag().toString('base64url'),ciphertext.toString('base64url')].join('.');
}
export function openCredentials(key:Buffer,ctx:{organizationId:string;branchId:string},id:string,sealed:string):Credentials{
  assert(key.length===32,500,'CONFIG','Некорректный ключ шифрования');
  try{
    const [version,iv,tag,data,...extra]=sealed.split('.');
    if(version!=='v1'||!iv||!tag||!data||extra.length)throw new Error('invalid cipher');
    const decipher=createDecipheriv('aes-256-gcm',key,Buffer.from(iv,'base64url'));
    decipher.setAAD(aad(ctx.organizationId,ctx.branchId,id));
    decipher.setAuthTag(Buffer.from(tag,'base64url'));
    const raw=Buffer.concat([decipher.update(Buffer.from(data,'base64url')),decipher.final()]);
    const parsed=JSON.parse(raw.toString('utf8'));
    if(typeof parsed.appId!=='string'||typeof parsed.clientSecret!=='string'||typeof parsed.apiKey!=='string')throw new Error('invalid fields');
    return parsed;
  }catch{throw new AppError(500,'SECRET_DECRYPT_FAILED','Не удалось открыть ключ интеграции; проверьте конфигурацию сервера');}
}
