import {assert,integerField,textField} from './rules.ts';

export interface CriterionInput {title:string;weight:number;critical:boolean;}
export interface StandardInput {title:string;description:string;criteria:CriterionInput[];}
export interface Criterion extends CriterionInput {id:string;}
export interface NetworkStandard {id:string;title:string;description:string;revision:number;active:boolean;criteria:Criterion[];createdAt:string;updatedAt:string;}
export interface AuditAnswerInput {criterionId:string;passed:boolean;note:string;}
export interface AuditAnswer extends AuditAnswerInput {title:string;weight:number;critical:boolean;}
export interface BranchAudit {id:string;branchId:string;standardId:string;standardTitle:string;standardRevision:number;performedAt:string;performedBy:string;scoreBps:number;criticalFailures:number;failedCount:number;answers:AuditAnswer[];}
export type ActionStatus='OPEN'|'IN_PROGRESS'|'RESOLVED';
export interface CorrectiveAction {id:string;branchId:string;auditId:string;standardId:string;standardRevision:number;criterionId:string;title:string;status:ActionStatus;revision:number;createdAt:string;updatedAt:string;resolution:string|null;}
export interface BranchQuality {branchId:string;branchName:string;scoreBps:number|null;auditAt:string|null;criticalFailures:number|null;openActions:number;outdated:boolean;}
export interface NetworkQuality {standardId:string|null;standardTitle:string|null;standardRevision:number|null;branches:BranchQuality[];comparable:boolean;limitations:string[];}

export function standardInput(value:Record<string,unknown>):StandardInput{
  const title=textField(value.title,'title',160);
  const description=textField(value.description,'description',500,0);
  assert(Array.isArray(value.criteria) && value.criteria.length>=1&&value.criteria.length<=20,400,'STANDARD_CRITERIA','От 1 до 20 пунктов стандарта');
  const criteria=value.criteria.map((v,i)=>{
    assert(typeof v==='object'&&v!==null&&!Array.isArray(v),400,'VALIDATION','Неверный пункт стандарта');
    const c=v as Record<string,unknown>;
    assert(typeof c.critical==='boolean',400,'VALIDATION','critical должен быть boolean');
    return {title:textField(c.title,`criteria[${i}].title`,160),weight:integerField(c.weight,'weight',1,10),critical:c.critical};
  });
  assert(new Set(criteria.map(c=>c.title.toLowerCase())).size===criteria.length,400,'STANDARD_DUPLICATE','Повторяющиеся пункты стандарта');
  return {title,description,criteria};
}
export function withCriterionIds(criteria:CriterionInput[]):Criterion[]{return criteria.map((c,i)=>({...c,id:`c-${i+1}`}));}
export function auditAnswers(value:unknown,criteria:Criterion[]):{answers:AuditAnswer[];scoreBps:number;failedCount:number;criticalFailures:number}{
  assert(Array.isArray(value) && value.length===criteria.length,400,'AUDIT_INCOMPLETE','Ответьте на каждый пункт стандарта');
  const received=new Map<string,AuditAnswerInput>();
  for(const item of value){
    assert(typeof item==='object'&&item!==null&&!Array.isArray(item),400,'VALIDATION','Неверный ответ');
    const r=item as Record<string,unknown>;
    const id=textField(r.criterionId,'criterionId',40);
    assert(!received.has(id),400,'AUDIT_DUPLICATE','Повтор одного пункта');
    assert(typeof r.passed==='boolean',400,'VALIDATION','passed должен быть boolean');
    const note=textField(r.note??'','note',1000,0);
    assert(r.passed || note.length>=8,400,'AUDIT_EVIDENCE','Опишите нарушение минимум восемью символами');
    received.set(id,{criterionId:id,passed:r.passed,note});
  }
  const answers=criteria.map(c=>{
    const a=received.get(c.id);
    assert(a,400,'AUDIT_CRITERION','Неизвестный или пропущенный пункт');
    return {...a,title:c.title,weight:c.weight,critical:c.critical};
  });
  assert(received.size===answers.length,400,'AUDIT_CRITERION','Неизвестный пункт');
  const weights=criteria.reduce((s,c)=>s+c.weight,0);
  const passed=answers.reduce((s,a)=>s+(a.passed?a.weight:0),0);
  return {answers,scoreBps:Math.round(passed*10_000/weights),failedCount:answers.filter(a=>!a.passed).length,
    criticalFailures:answers.filter(a=>!a.passed&&a.critical).length};
}
export function actionTransition(from:ActionStatus,to:ActionStatus,resolution:string|null):void{
  const allowed:Record<ActionStatus,ActionStatus[]>={OPEN:['IN_PROGRESS','RESOLVED'],IN_PROGRESS:['OPEN','RESOLVED'],RESOLVED:['OPEN']};
  assert(allowed[from]?.includes(to),409,'ACTION_TRANSITION','Недопустимый переход действия');
  assert(to==='RESOLVED'?typeof resolution==='string'&&resolution.trim().length>=8:resolution===null,
    400,'ACTION_RESOLUTION','Для закрытия действия требуется описание результата');
}
export function networkQuality(standard:NetworkStandard|null,branches:{id:string;name:string;latest:BranchAudit|null;openActions:number}[]):NetworkQuality{
  const result=branches.map(b=>{
    const outdated=!!standard && !!b.latest && b.latest.standardRevision!==standard.revision;
    return {branchId:b.id,branchName:b.name,scoreBps:b.latest&&!outdated?b.latest.scoreBps:null,
      auditAt:b.latest?.performedAt||null,criticalFailures:b.latest&&!outdated?b.latest.criticalFailures:null,
      openActions:b.openActions,outdated};
  });
  const periods=result.map(x=>x.auditAt?.slice(0,7)).filter(Boolean);
  const samePeriod=periods.length===result.length && new Set(periods).size===1;
  const comparable=!!standard&&standard.active&&result.length>1&&result.every(x=>x.scoreBps!==null)&&samePeriod;
  const limitations:string[]=[];
  if(!standard)limitations.push('В организации ещё нет стандартов качества.');
  if(standard&&!standard.active)limitations.push('Стандарт отключён. Актуальную оценку сети не рассчитываем.');
  if(result.some(r=>r.auditAt===null))limitations.push('Часть филиалов ещё не проходила аудит по выбранному стандарту.');
  if(result.some(r=>r.outdated))limitations.push('Есть аудиты по старой редакции стандарта: их баллы исключены из сравнения.');
  if(!samePeriod&&result.length>1&&result.every(x=>x.auditAt!==null))limitations.push('Аудиты относятся к разным календарным месяцам UTC: прямое сравнение недоступно.');
  if(!comparable)limitations.push('Рейтинг филиалов не формируется без сопоставимых актуальных аудитов как минимум двух филиалов.');
  limitations.push('Оценка отражает заполненный чек-лист, а не независимую гарантию качества обслуживания.');
  return {standardId:standard?.id||null,standardTitle:standard?.title||null,standardRevision:standard?.revision||null,
    branches:result,comparable,limitations};
}
