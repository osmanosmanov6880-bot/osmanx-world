import {createApiServer} from './http.ts';
import {createPostgresStore} from './infra/postgres.ts';
import {IntegrationRuntime} from './integrations/runtime.ts';
import {IikoClient} from './infra/iiko.ts';

async function main(){
  const db=process.env.DATABASE_URL;
  const secret=process.env.SESSION_SECRET;
  if(!db||!secret||secret.length<32)throw new Error('DATABASE_URL and SESSION_SECRET (>=32 characters) must be configured');
  const store=await createPostgresStore(db);
  const integrations=new IntegrationRuntime(store.integrationRepository(),new IikoClient(),process.env.INTEGRATION_ENCRYPTION_KEY);
  const api=createApiServer(store,{
    origin:process.env.APP_ORIGIN||'http://localhost:3000',
    sessionSecret:secret,
    secureCookies:process.env.COOKIE_SECURE==='true' || (process.env.NODE_ENV==='production' && process.env.COOKIE_SECURE!=='false')
  },integrations);
  let working=false;
  const interval=setInterval(()=>{if(working)return;working=true;void integrations.runOnce().catch(error=>console.error('[integration worker] failed without credential details',error instanceof Error?error.name:'unknown')).finally(()=>{working=false;});},5000);
  interval.unref();
  const host=process.env.API_HOST||'0.0.0.0',port=Number(process.env.API_PORT||4000);
  api.listen(port,host,()=>console.log(`OSMANX API on ${host}:${port}`));
  for(const signal of ['SIGTERM','SIGINT'] as const){process.once(signal,()=>(clearInterval(interval),api.close(()=>store.close().finally(()=>process.exit(0)))));}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
