import {AppError,assert,emailField,integerField,textField} from './rules.ts';

export type ConsentChannel='EMAIL'|'SMS';
export type ConsentState='GRANTED'|'REVOKED';
export type FeedbackKind='COMPLAINT'|'COMPLIMENT'|'SUGGESTION';
export type FeedbackStatus='OPEN'|'RESOLVED';
export interface GuestInput {displayName:string;email:string|null;phone:string|null;}
export interface Guest extends GuestInput {id:string;revision:number;createdAt:string;}
export interface Consent {guestId:string;channel:ConsentChannel;state:ConsentState;evidence:string|null;revision:number;recordedAt:string;}
export interface GuestVisit {orderId:string;completedAt:string;totalCents:number;}
export interface GuestFeedback {id:string;guestId:string|null;orderId:string|null;kind:FeedbackKind;rating:number|null;comment:string|null;status:FeedbackStatus;resolution:string|null;revision:number;createdAt:string;resolvedAt:string|null;}
export interface GuestFeedbackInput {guestId:string|null;orderId:string|null;kind:FeedbackKind;rating:number|null;comment:string|null;}
export interface ObservedVisit extends GuestVisit {guestId:string|null;}
export interface GuestScore {guestId:string;visits365:number;spend365Cents:number;lastVisitAt:string|null;recencyDays:number|null;recencyScore:number|null;frequencyScore:number|null;monetaryScore:number|null;segment:'NEW'|'LOYAL'|'AT_RISK'|'OTHER'|'NO_VISITS';}
export interface GuestInsights {asOf:string;windowDays:number;totalCompletedOrders:number;identifiedCompletedOrders:number;identificationCoveragePercent:number|null;identifiedGuestsWithVisits:number;repeatGuests:number;repeatShareOfIdentifiedPercent:number|null;monetaryScoringAvailable:boolean;guests:GuestScore[];limitations:string[];}
export function guestInput(value:{displayName:unknown;email:unknown;phone:unknown}):GuestInput{
  const displayName=textField(value.displayName,'displayName',120,2);
  const email=value.email===null||value.email===''||value.email===undefined?null:emailField(value.email);
  const phone=value.phone===null||value.phone===''||value.phone===undefined?null:textField(value.phone,'phone',32,7);
  if(phone)assert(/^\+?[0-9][0-9 ()-]{5,30}$/.test(phone),400,'PHONE','Неверный номер телефона');
  return {displayName,email,phone};
}
export function consentChannel(value:unknown):ConsentChannel{
  assert(value==='EMAIL'||value==='SMS',400,'CONSENT_CHANNEL','Неверный канал');return value;
}
export function consentState(value:unknown):ConsentState{
  assert(value==='GRANTED'||value==='REVOKED',400,'CONSENT_STATE','Неверное состояние согласия');return value;
}
export function consentEvidence(state:ConsentState,value:unknown):string|null{
  if(state==='GRANTED')return textField(value,'evidence',240,8);
  return value===undefined||value===null||value===''?null:textField(value,'evidence',240,3);
}
export function feedbackInput(value:Record<string,unknown>,isUuid:(v:unknown)=>v is string):GuestFeedbackInput{
  assert(value.kind==='COMPLAINT'||value.kind==='COMPLIMENT'||value.kind==='SUGGESTION',400,'FEEDBACK_KIND','Неверный вид обращения');
  const guestId=value.guestId===null||value.guestId===undefined?null:value.guestId;
  const orderId=value.orderId===null||value.orderId===undefined?null:value.orderId;
  assert(guestId===null||isUuid(guestId),400,'FEEDBACK_GUEST','Неверный идентификатор гостя');
  assert(orderId===null||isUuid(orderId),400,'FEEDBACK_ORDER','Неверный идентификатор заказа');
  const rating=value.rating===null||value.rating===undefined?null:integerField(value.rating,'rating',1,5);
  const comment=value.comment===null||value.comment===undefined||value.comment===''?null:textField(value.comment,'comment',1000,3);
  assert(rating!==null||comment!==null,400,'FEEDBACK_EMPTY','Укажите оценку или комментарий');
  return {guestId,orderId,kind:value.kind,rating,comment};
}
const scoreRecency=(d:number)=>d<=7?5:d<=30?4:d<=90?3:d<=180?2:1;
const scoreFrequency=(f:number)=>f>=12?5:f>=6?4:f>=3?3:f>=2?2:1;
const roundShare=(part:number,total:number)=>total?Math.round(part*10000/total)/100:null;
/** Pure, reproducible observational RFM. Monetary quintiles only with >=5 guests. Not churn prediction. */
export function calculateGuestInsights(guestIds:readonly string[],visits:readonly ObservedVisit[],asOf:Date=new Date()):GuestInsights{
  assert(!Number.isNaN(asOf.getTime()),400,'DATE','Неверная дата анализа');
  const today=asOf.getTime(),start=today-365*86400000,guestSet=new Set(guestIds);
  const data=new Map<string,GuestVisit[]>();for(const id of guestIds)data.set(id,[]);
  let total=0,identified=0;
  for(const v of visits){
    const t=Date.parse(v.completedAt);
    if(!Number.isFinite(t)||t>today||t<start)continue;
    assert(Number.isSafeInteger(v.totalCents)&&v.totalCents>=0,500,'INTEGRITY','Неверная сумма посещения');
    total++;
    if(v.guestId!==null){identified++;if(guestSet.has(v.guestId))data.get(v.guestId)!.push(v);}
  }
  const spend=new Map<string,number>();
  for(const [id,rows] of data){const s=rows.reduce((acc,x)=>acc+BigInt(x.totalCents),0n);assert(s<=BigInt(Number.MAX_SAFE_INTEGER),500,'INTEGRITY','Превышение денежного предела');spend.set(id,Number(s));}
  const activeIds=[...data.keys()].filter(id=>data.get(id)!.length>0),canScore=activeIds.length>=5;
  const ranked=[...activeIds].sort((a,b)=>spend.get(a)!-spend.get(b)!);
  const monetaryRank=new Map<string,number>();
  if(canScore)for(const id of ranked){const less=ranked.filter(x=>spend.get(x)!<spend.get(id)!).length;
    monetaryRank.set(id,Math.min(5,1+Math.floor(less*5/ranked.length)));}
  let repeats=0;
  const guests=guestIds.map(guestId=>{
    const rows=data.get(guestId)||[];
    const last=rows.length?rows.map(v=>v.completedAt).sort().at(-1)!:null;
    const days=last===null?null:Math.max(0,Math.floor((today-Date.parse(last))/86400000));
    const frequency=rows.length;if(frequency>=2)repeats++;
    const recencyScore=days===null?null:scoreRecency(days),frequencyScore=frequency?scoreFrequency(frequency):null;
    const monetaryScore=canScore&&frequency?monetaryRank.get(guestId)!:null;
    const segment:GuestScore['segment']=!frequency?'NO_VISITS':days!==null&&days>90&&frequency>=2?'AT_RISK':frequency>=3&&days!==null&&days<=30?'LOYAL':frequency===1?'NEW':'OTHER';
    return {guestId,visits365:frequency,spend365Cents:spend.get(guestId)||0,lastVisitAt:last,recencyDays:days,recencyScore,frequencyScore,monetaryScore,segment};
  });
  return {asOf:asOf.toISOString(),windowDays:365,totalCompletedOrders:total,identifiedCompletedOrders:identified,
    identificationCoveragePercent:roundShare(identified,total),identifiedGuestsWithVisits:activeIds.length,repeatGuests:repeats,
    repeatShareOfIdentifiedPercent:roundShare(repeats,activeIds.length),monetaryScoringAvailable:canScore,guests,
    limitations:['Только завершённые заказы за 365 дней; один заказ считается одним наблюдаемым визитом.',
      'Неидентифицированные заказы не могут участвовать в анализе повторных визитов.',
      'Повторность измеряется только среди идентифицированных гостей, не среди всех посетителей.',
      'Сегменты описательные; не доказывают причины поведения и не предсказывают отток.',
      ...(!canScore?['Денежный RFM-балл скрыт: для квинтилей нужно минимум 5 гостей с заказами.']:[])]};
}
