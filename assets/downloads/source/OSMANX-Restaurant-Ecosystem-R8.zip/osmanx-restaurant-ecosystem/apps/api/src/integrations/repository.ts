import type {Ctx} from '../store.ts';
import type {CatalogItem,CatalogProduct,ClaimedSync,IntegrationConnection,StoredIntegration,SyncJob,IntegrationState} from '../domain/integrations.ts';
export interface IntegrationRepository {
  list(ctx:Ctx):Promise<IntegrationConnection[]>;
  read(ctx:Ctx,id:string):Promise<StoredIntegration>;
  create(ctx:Ctx,input:{id:string;alias:string;remoteOrganizationId:string;sealedCredentials:string;fingerprint:string},key:string):Promise<IntegrationConnection>;
  transition(ctx:Ctx,id:string,revision:number,action:'VERIFY'|'ERROR'|'DISABLE'|'ROTATE',
    value:{remoteOrganizationName?:string;errorCode?:string;sealedCredentials?:string;fingerprint?:string},key:string):Promise<IntegrationConnection>;
  enqueue(ctx:Ctx,id:string,menuId:string,key:string):Promise<SyncJob>;
  jobs(ctx:Ctx,id:string):Promise<SyncJob[]>;
  catalog(ctx:Ctx,id:string):Promise<CatalogItem[]>;
  importCatalog(ctx:Ctx,id:string,jobId:string,ids:string[],key:string):Promise<{imported:number;created:number;updated:number}>;
  claim():Promise<ClaimedSync|null>;
  succeed(job:ClaimedSync,items:CatalogProduct[]):Promise<boolean>;
  fail(job:ClaimedSync,code:string):Promise<boolean>;
}
