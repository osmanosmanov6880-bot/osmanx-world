// Read-only adapter using published iikoCloud endpoints. No client-supplied URLs.
import {ProviderError,normalizeIikoMenu,type Credentials,type RemoteOrganization,type RemoteMenu,type CatalogProduct} from '../domain/integrations.ts';
const BASE='https://api-ru.iiko.services';
const MAX_RESPONSE_BYTES=8*1024*1024;
async function limitedBody(response:Response):Promise<string>{
  const claimed=response.headers.get('content-length');
  if(claimed&&/^\d+$/.test(claimed)&&BigInt(claimed)>BigInt(MAX_RESPONSE_BYTES))throw new ProviderError('BAD_RESPONSE',false);
  if(!response.body)return '';
  const reader=response.body.getReader();const chunks:Uint8Array[]=[];let length=0;
  try{
    while(true){
      const {value,done}=await reader.read();if(done)break;
      length+=value.byteLength;
      if(length>MAX_RESPONSE_BYTES){await reader.cancel().catch(()=>{});throw new ProviderError('BAD_RESPONSE',false);}
      chunks.push(value);
    }
  }finally{reader.releaseLock();}
  return Buffer.concat(chunks.map(c=>Buffer.from(c.buffer,c.byteOffset,c.byteLength)),length).toString('utf8');
}

export type Transport=typeof fetch;
type Json=Record<string,unknown>;
function asRecord(x:unknown):Json {if(!x||typeof x!=='object'||Array.isArray(x))throw new ProviderError('BAD_RESPONSE',false);return x as Json;}
export class IikoClient {
  private transport:Transport;
  constructor(transport:Transport=fetch){this.transport=transport;}
  private async post(path:string,payload:Json,token?:string):Promise<Json>{
    try{
      const response=await this.transport(`${BASE}${path}`,{method:'POST',redirect:'error',signal:AbortSignal.timeout(12000),
        headers:{'content-type':'application/json',...(token?{authorization:`Bearer ${token}`}:{})},
        body:JSON.stringify(payload)});
      if(response.status===401||response.status===403)throw new ProviderError('AUTH_FAILED',false);
      if(response.status===429)throw new ProviderError('RATE_LIMIT',true);
      if(response.status>=500)throw new ProviderError('UNAVAILABLE',true);
      if(!response.ok)throw new ProviderError('BAD_RESPONSE',false);
      // Read with an actual byte limit rather than buffering an unbounded provider response.
      const raw=await limitedBody(response);
      let parsed:unknown;
      try{parsed=JSON.parse(raw);}catch{throw new ProviderError('BAD_RESPONSE',false);}
      return asRecord(parsed);
    }catch(error){if(error instanceof ProviderError)throw error;
      if(error instanceof Error&&/timeout|abort/i.test(error.name))throw new ProviderError('TIMEOUT',true);
      throw new ProviderError('UNAVAILABLE',true);
    }
  }
  async accessToken(c:Credentials):Promise<string>{
    const data=await this.post('/api/v2/access_token',{appId:c.appId,clientSecret:c.clientSecret,apiKey:c.apiKey});
    if(typeof data.token!=='string'||data.token.length<10)throw new ProviderError('BAD_RESPONSE',false);
    return data.token;
  }
  async organizations(c:Credentials):Promise<RemoteOrganization[]>{
    const token=await this.accessToken(c);
    const data=await this.post('/api/1/organizations',{},token);
    if(!Array.isArray(data.organizations))throw new ProviderError('BAD_RESPONSE',false);
    return data.organizations.map(raw=>{const r=asRecord(raw);
      if(typeof r.id!=='string'||typeof r.name!=='string')throw new ProviderError('BAD_RESPONSE',false);
      return {id:r.id,name:r.name};
    });
  }
  async verify(c:Credentials,remoteOrganizationId:string):Promise<RemoteOrganization>{
    const orgs=await this.organizations(c);
    const found=orgs.find(o=>o.id.toLowerCase()===remoteOrganizationId.toLowerCase());
    if(!found)throw new ProviderError('ORG_NOT_FOUND',false);
    return found;
  }
  async menus(c:Credentials,remoteOrganizationId:string):Promise<RemoteMenu[]>{
    const token=await this.accessToken(c);
    const data=await this.post('/api/2/menu',{organizationId:remoteOrganizationId},token);
    if(!Array.isArray(data.externalMenus))throw new ProviderError('BAD_RESPONSE',false);
    return data.externalMenus.map(raw=>{const r=asRecord(raw);
      const id=r.id??r.externalMenuId;
      if(typeof id!=='string'||typeof r.name!=='string')throw new ProviderError('BAD_RESPONSE',false);
      return {id,name:r.name};
    });
  }
  async catalog(c:Credentials,remoteOrganizationId:string,externalMenuId:string):Promise<CatalogProduct[]>{
    const token=await this.accessToken(c);
    const data=await this.post('/api/menu/v3/by_id',{externalMenuId,organizationIds:[remoteOrganizationId]},token);
    return normalizeIikoMenu(data,remoteOrganizationId);
  }
}
