import {assert,integerField,textField} from './rules.ts';
import {basisPoints,centsSum,financePeriod,type FinanceReport} from './finance.ts';

export type Confidence='LOW'|'MEDIUM'; // Observational evidence never proves causation.
export type DecisionStatus='PROPOSED'|'IN_PROGRESS'|'IMPLEMENTED'|'REVIEWED'|'CANCELLED';
export interface Signal {
  id:string;title:string;severity:'INFO'|'WARNING';period:string;comparisonPeriod:string;
  evidence:{metric:string;before:number|null;after:number|null;unit:'cents'|'bps'|'orders'}[];
  candidateCauses:string[];alternatives:string[];missingData:string[];
  confidence:Confidence;recommendation:string;expectedBenefit:string;provenCause:false;
}
export interface Diagnosis {period:string;comparisonPeriod:string;signals:Signal[];limitations:string[];}
export interface Decision {
  id:string;branchId:string;signalId:string;title:string;hypothesis:string;action:string;
  baselinePeriod:string;reviewPeriod:string|null;implementationCostCents:number|null;
  status:DecisionStatus;revision:number;createdAt:string;updatedAt:string;
  baselineRevenueCents:number;baselineProfitCents:number|null;
  observedRevenueCents:number|null;observedProfitCents:number|null;
  observedProfitDeltaCents:number|null;observation:string|null;
}
export function previousPeriod(period:string){
  financePeriod(period);
  const [y,m]=period.split('-').map(Number);
  return `${m===1?y-1:y}-${String(m===1?12:m-1).padStart(2,'0')}`;
}
export function evaluate(current:FinanceReport,previous:FinanceReport):Diagnosis{
  assert(previous.period===previousPeriod(current.period),400,'PERIOD_SEQUENCE','Периоды должны быть последовательными');
  const signals:Signal[]=[];
  const common={period:current.period,comparisonPeriod:previous.period,provenCause:false as const};
  if(current.uncostedOrders>0){signals.push({...common,id:'MISSING_FOOD_COST',title:'Себестоимость рассчитана не для всех заказов',severity:'WARNING',
    evidence:[{metric:'Заказы без полной себестоимости',before:previous.uncostedOrders,after:current.uncostedOrders,unit:'orders'}],confidence:'MEDIUM',
    candidateCauses:['Отсутствуют рецептуры или исторические данные'],alternatives:['Импортированные заказы без движения склада'],
    missingData:['Рецептуры и нормы расхода для завершённых заказов'],recommendation:'Проверить рецептуры и связи заказов с расходом ингредиентов',
    expectedBenefit:'Повышение достоверности отчётов; финансовая выгода не оценена'});}
  const comparable=previous.completedOrders>=10&&current.completedOrders>=10&&previous.revenueCents>0;
  if(comparable){
    const change=basisPoints(current.revenueCents-previous.revenueCents,previous.revenueCents)!;
    if(change<=-1000){
      const countChange=basisPoints(current.completedOrders-previous.completedOrders,previous.completedOrders)!;
      const similarOrders=Math.abs(countChange)<=500;
      signals.push({...common,id:similarOrders?'REVENUE_TICKET_DROP':'REVENUE_DROP',title:similarOrders?'Выручка снизилась при близком числе заказов':'Выручка снизилась относительно прошлого месяца',severity:'WARNING',confidence:'MEDIUM',
        evidence:[{metric:'Выручка',before:previous.revenueCents,after:current.revenueCents,unit:'cents'},
          {metric:'Завершённые заказы',before:previous.completedOrders,after:current.completedOrders,unit:'orders'}],
        candidateCauses:similarOrders?['Снижение среднего чека','Изменение структуры заказов или скидок']:['Снижение числа заказов','Падение среднего чека'],
        alternatives:['Сезонность','Разная длительность месяца','Неполный импорт данных','Перемещение заказов между филиалами'],
        missingData:['Трафик гостей, а не только заказы','Скидки и возвраты','Сопоставимые дни и часы'],
        recommendation:'Сравнить средний чек, количество заказов, скидки и ассортимент по сопоставимым дням',
        expectedBenefit:'Не рассчитана: требуется проверка гипотезы и оценка стоимости мер'});
    }
  }
  if(previous.foodCostRateBps!==null&&current.foodCostRateBps!==null&&previous.completedOrders>=10&&current.completedOrders>=10&&current.foodCostRateBps-previous.foodCostRateBps>=300){
    signals.push({...common,id:'FOOD_COST_RATE_RISE',title:'Доля себестоимости выросла минимум на 3 процентных пункта',severity:'WARNING',confidence:'MEDIUM',
      evidence:[{metric:'Доля себестоимости',before:previous.foodCostRateBps,after:current.foodCostRateBps,unit:'bps'}],
      candidateCauses:['Рост закупочной стоимости','Смена товарной корзины','Отклонения расхода'],
      alternatives:['Неполные или несопоставимые данные','Сезонность поставок'],missingData:['Цены закупок по ингредиентам','Порции и списания'],
      recommendation:'Проверить ингредиенты с наибольшим приростом удельных затрат',expectedBenefit:'Не рассчитана без оценки закупок и мер'});
  }
  if(previous.operatingResultCents!==null&&current.operatingResultCents!==null&&current.operatingResultCents<previous.operatingResultCents&&current.revenueCents>=previous.revenueCents){
    signals.push({...common,id:'PROFIT_DOWN_REVENUE_UP',title:'Операционный результат снижается при неуменьшающейся выручке',severity:'WARNING',confidence:'LOW',
      evidence:[{metric:'Операционный результат',before:previous.operatingResultCents,after:current.operatingResultCents,unit:'cents'},
        {metric:'Выручка',before:previous.revenueCents,after:current.revenueCents,unit:'cents'}],
      candidateCauses:['Изменение себестоимости','Рост фонда оплаты труда','Рост расходов'],alternatives:['Неполнота затрат','Разовое начисление','Разное число рабочих дней'],
      missingData:['Подтверждение полноты расходных документов','Разделение постоянных и переменных затрат'],
      recommendation:'Сравнить расходы по категориям и структуру себестоимости',expectedBenefit:'Не рассчитана до подтверждения расходов'});
  }
  return {period:current.period,comparisonPeriod:previous.period,signals,limitations:[
    'Сравнение последовательных месяцев; сезонность и количество дней не нормализованы.',
    'Количество завершённых заказов не равно количеству уникальных гостей.',
    'Полнота операционных расходов не проверена: результат не является бухгалтерской чистой прибылью.',
    'Причины — гипотезы, корреляция не доказывает причинность.',
    ...(!comparable?['Для анализа выручки требуется минимум по 10 заказов в каждом месяце и ненулевая база.']:[])
  ]};
}
export function decisionInput(input:{title:unknown;hypothesis:unknown;action:unknown;implementationCostCents:unknown}){
  return {title:textField(input.title,'title',160,5),hypothesis:textField(input.hypothesis,'hypothesis',1200,8),
    action:textField(input.action,'action',1200,8),implementationCostCents:input.implementationCostCents===null?null:integerField(input.implementationCostCents,'implementationCostCents',0,9_999_999_999_999)};
}
export function reviewPeriodAllowed(baseline:string,review:string,now=new Date()):boolean{
  financePeriod(baseline);financePeriod(review);
  return review>baseline && review<=now.toISOString().slice(0,7);
}
export function transition(from:DecisionStatus,to:DecisionStatus){
  const edges:Record<DecisionStatus,DecisionStatus[]>={PROPOSED:['IN_PROGRESS','CANCELLED'],IN_PROGRESS:['IMPLEMENTED','CANCELLED'],IMPLEMENTED:['REVIEWED'],REVIEWED:[],CANCELLED:[]};
  assert(edges[from].includes(to),409,'DECISION_TRANSITION','Недопустимый переход решения');
}
export function observation(baseline:FinanceReport,review:FinanceReport,implementationCostCents:number|null){
  // Comparisons are descriptive and not causal ROI.
  const delta=baseline.operatingResultCents!==null&&review.operatingResultCents!==null?
    centsSum([review.operatingResultCents,-baseline.operatingResultCents],'Разница результатов'):null;
  return {observedRevenueCents:review.revenueCents,observedProfitCents:review.operatingResultCents,observedProfitDeltaCents:delta,
    interpretation:delta===null?'Результат нельзя оценить из-за неполной себестоимости':
      implementationCostCents===null?'Разница рассчитана, стоимость внедрения неизвестна':
      'Разница рассчитана; стоимость внедрения известна, но причинная окупаемость не доказана'};
}
