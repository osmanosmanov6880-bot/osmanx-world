import {randomUUID,createHash} from 'node:crypto';
import {AppError,assert} from '../domain/rules.ts';
import type {Ctx} from '../store.ts';
import type {CatalogItem,CatalogProduct,ClaimedSync,IntegrationConnection,StoredIntegration,SyncJob,IntegrationState} from '../domain/integrations.ts';
import type {IntegrationRepository} from './repository.ts';
type Row=Record<string,any>;
type DB={query:(sql:string,params?:unknown[])=>Promise<{rows:Row[];rowCount:number|null}>};
type Pool=DB & {connect:()=>Promise<DB & {release:()=>void}>};
const date=(x:unknown):string|null=>x===null||x===undefined?null:new Date(x as string).toISOString();
const publicConnection=(r:Row):IntegrationConnection=>({id:r.id,branchId:r.branch_id,provider:'IIKO',alias:r.alias,
  remoteOrganizationId:r.remote_organization_id,state:r.state,revision:r.revision,
  remoteOrganizationName:r.remote_organization_name,verifiedAt:date(r.verified_at),lastErrorCode:r.last_error_code,
  lastSyncAt:date(r.last_sync_at),createdAt:date(r.created_at)!,updatedAt:date(r.updated_at)!});
const jobRow=(r:Row):SyncJob=>({id:r.id,connectionId:r.connection_id,menuId:r.menu_id,status:r.status,
  attemptCount:r.attempt_count,nextAttemptAt:date(r.next_attempt_at)!,lastErrorCode:r.last_error_code,
  createdAt:date(r.created_at)!,completedAt:date(r.completed_at),itemsCount:r.items_count});
export class PgIntegrationRepository implements IntegrationRepository {
  private pool:Pool;
  constructor(pool:Pool){this.pool=pool;}
  private async tx<T>(work:(db:DB)=>Promise<T>):Promise<T>{
    const client=await this.pool.connect();
    try{await client.query('BEGIN');const result=await work(client);await client.query('COMMIT');return result;}
    catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
  }
  private async command<T>(ctx:Ctx,key:string,operation:unknown,work:(db:DB)=>Promise<T>):Promise<T>{
    const fingerprint=createHash('sha256').update(JSON.stringify(operation)).digest('hex');
    return this.tx(async db=>{
      await db.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',[`${ctx.organizationId}:integration:${ctx.userId}:${key}`]);
      const existing=(await db.query('SELECT fingerprint,response FROM integration_commands WHERE organization_id=$1 AND actor_id=$2 AND idempotency_key=$3',
        [ctx.organizationId,ctx.userId,key])).rows[0];
      if(existing){assert(existing.fingerprint===fingerprint,409,'IDEMPOTENCY_CONFLICT','Повторный ключ использован для другого действия');return existing.response as T;}
      const result=await work(db);
      await db.query('INSERT INTO integration_commands(organization_id,actor_id,idempotency_key,fingerprint,response) VALUES($1,$2,$3,$4,$5)',
        [ctx.organizationId,ctx.userId,key,fingerprint,JSON.stringify(result)]);
      return result;
    });
  }
  private async locked(db:DB,ctx:Ctx,id:string){
    const r=(await db.query('SELECT * FROM integration_connections WHERE organization_id=$1 AND branch_id=$2 AND id=$3 FOR UPDATE',
      [ctx.organizationId,ctx.branchId,id])).rows[0];
    assert(r,404,'NOT_FOUND','Подключение не найдено');return r;
  }
  async list(ctx:Ctx):Promise<IntegrationConnection[]>{
    const q=await this.pool.query('SELECT * FROM integration_connections WHERE organization_id=$1 AND branch_id=$2 ORDER BY created_at DESC LIMIT 100',
      [ctx.organizationId,ctx.branchId]);return q.rows.map(publicConnection);
  }
  async read(ctx:Ctx,id:string):Promise<StoredIntegration>{
    const r=(await this.pool.query('SELECT * FROM integration_connections WHERE organization_id=$1 AND branch_id=$2 AND id=$3',
      [ctx.organizationId,ctx.branchId,id])).rows[0];
    assert(r,404,'NOT_FOUND','Подключение не найдено');return {...publicConnection(r),sealedCredentials:r.sealed_credentials};
  }
  async create(ctx:Ctx,input:{id:string;alias:string;remoteOrganizationId:string;sealedCredentials:string;fingerprint:string},key:string){
    return this.command(ctx,key,{type:'connection-create',alias:input.alias,remoteOrganizationId:input.remoteOrganizationId,fingerprint:input.fingerprint},async db=>{
      const q=await db.query(`INSERT INTO integration_connections(id,organization_id,branch_id,provider,alias,remote_organization_id,sealed_credentials)
        VALUES($1,$2,$3,'IIKO',$4,$5,$6) RETURNING *`,
        [input.id,ctx.organizationId,ctx.branchId,input.alias,input.remoteOrganizationId,input.sealedCredentials]);
      return publicConnection(q.rows[0]);
    });
  }
  async transition(ctx:Ctx,id:string,revision:number,action:'VERIFY'|'ERROR'|'DISABLE'|'ROTATE',
    value:{remoteOrganizationName?:string;errorCode?:string;sealedCredentials?:string;fingerprint?:string},key:string){
    return this.command(ctx,key,{type:'transition',id,revision,action,remoteOrganizationName:value.remoteOrganizationName,
      errorCode:value.errorCode,fingerprint:value.fingerprint},async db=>{
      const r=await this.locked(db,ctx,id);
      assert(r.revision===revision,409,'VERSION_CONFLICT','Подключение изменилось в другом окне');
      if(action==='VERIFY')assert(r.state!=='DISABLED',409,'DISABLED','Подключение отключено');
      if(action==='ROTATE')assert(value.sealedCredentials,400,'VALIDATION','Требуются новые ключи');
      const state:IntegrationState=action==='VERIFY'?'VERIFIED':action==='ERROR'?'ERROR':action==='ROTATE'?'UNVERIFIED':'DISABLED';
      const q=await db.query(`UPDATE integration_connections SET state=$4,revision=revision+1,
        sealed_credentials=COALESCE($5,sealed_credentials),remote_organization_name=CASE WHEN $6='VERIFY' THEN $7 WHEN $6='ROTATE' THEN NULL ELSE remote_organization_name END,
        verified_at=CASE WHEN $6='VERIFY' THEN now() WHEN $6='ROTATE' THEN NULL ELSE verified_at END,
        last_sync_at=CASE WHEN $6='ROTATE' THEN NULL ELSE last_sync_at END,
        last_error_code=$8,updated_at=now() WHERE organization_id=$1 AND branch_id=$2 AND id=$3 RETURNING *`,
        [ctx.organizationId,ctx.branchId,id,state,value.sealedCredentials??null,action,value.remoteOrganizationName??null,value.errorCode??null]);
      if(action==='ROTATE'||action==='DISABLE'){
        await db.query(`UPDATE integration_sync_jobs SET status='CANCELLED',lease_token=NULL,lease_until=NULL,completed_at=now()
          WHERE connection_id=$1 AND status IN('QUEUED','RUNNING','RETRY')`,[id]);
      }
      if(action==='ROTATE')await db.query('DELETE FROM integration_catalog WHERE connection_id=$1',[id]);
      return publicConnection(q.rows[0]);
    });
  }
  async enqueue(ctx:Ctx,id:string,menuId:string,key:string):Promise<SyncJob>{
    return this.command(ctx,key,{type:'sync',id,menuId},async db=>{
      const r=await this.locked(db,ctx,id);
      assert(r.state==='VERIFIED',409,'NOT_VERIFIED','Сначала проверьте подключение');
      const busy=(await db.query(`SELECT id FROM integration_sync_jobs WHERE connection_id=$1 AND status IN('QUEUED','RUNNING','RETRY')`,[id])).rows[0];
      assert(!busy,409,'SYNC_BUSY','Синхронизация уже выполняется');
      const q=await db.query(`INSERT INTO integration_sync_jobs(organization_id,branch_id,connection_id,menu_id)
        VALUES($1,$2,$3,$4) RETURNING *`,[ctx.organizationId,ctx.branchId,id,menuId]);
      return jobRow(q.rows[0]);
    });
  }
  async jobs(ctx:Ctx,id:string){
    // Verify scoped ownership before returning any rows.
    await this.read(ctx,id);
    const q=await this.pool.query(`SELECT * FROM integration_sync_jobs WHERE organization_id=$1 AND branch_id=$2 AND connection_id=$3
      ORDER BY created_at DESC,id DESC LIMIT 40`,[ctx.organizationId,ctx.branchId,id]);return q.rows.map(jobRow);
  }
  async catalog(ctx:Ctx,id:string):Promise<CatalogItem[]>{
    await this.read(ctx,id);
    const q=await this.pool.query(`SELECT c.external_id,c.name,c.category,c.price_cents,c.source_job_id,l.menu_item_id
      FROM integration_catalog c LEFT JOIN integration_menu_links l ON l.connection_id=c.connection_id AND l.external_id=c.external_id
      WHERE c.organization_id=$1 AND c.branch_id=$2 AND c.connection_id=$3 ORDER BY c.category,c.name LIMIT 5000`,
      [ctx.organizationId,ctx.branchId,id]);
    return q.rows.map(r=>({externalId:r.external_id,name:r.name,category:r.category,
      priceCents:r.price_cents===null?null:Number(r.price_cents),sourceRunId:r.source_job_id,
      importedMenuItemId:r.menu_item_id??null}));
  }
  async importCatalog(ctx:Ctx,id:string,jobId:string,ids:string[],key:string){
    return this.command(ctx,key,{type:'import',id,jobId,ids},async db=>{
      const c=await this.locked(db,ctx,id);assert(c.state==='VERIFIED',409,'NOT_VERIFIED','Подключение не проверено');
      const currency=(await db.query('SELECT currency FROM organizations WHERE id=$1',[ctx.organizationId])).rows[0]?.currency;
      assert(currency==='RUB',409,'CURRENCY_MISMATCH','Импорт iiko доступен только для ресторанов с валютой RUB');
      const job=(await db.query(`SELECT status FROM integration_sync_jobs WHERE organization_id=$1 AND branch_id=$2 AND connection_id=$3 AND id=$4`,
        [ctx.organizationId,ctx.branchId,id,jobId])).rows[0];
      assert(job?.status==='SUCCEEDED',409,'STALE_CATALOG','Нет завершённой синхронизации');
      const {rows}=await db.query(`SELECT external_id,name,price_cents,source_job_id FROM integration_catalog WHERE organization_id=$1 AND branch_id=$2 AND connection_id=$3 AND external_id=ANY($4::text[]) ORDER BY external_id`,
        [ctx.organizationId,ctx.branchId,id,ids]);
      assert(rows.length===ids.length&&rows.every(r=>r.source_job_id===jobId),409,'STALE_CATALOG','Каталог обновился; повторите просмотр');
      assert(rows.every(r=>r.price_cents!==null),409,'MISSING_PRICE','Цена неизвестна: импорт блюда запрещён');
      let created=0,updated=0;
      for(const r of rows){
        const linked=(await db.query('SELECT menu_item_id FROM integration_menu_links WHERE connection_id=$1 AND external_id=$2 FOR UPDATE',[id,r.external_id])).rows[0];
        if(linked){
          await db.query(`UPDATE menu_items SET name=$4,price_cents=$5,revision=revision+1
            WHERE organization_id=$1 AND branch_id=$2 AND id=$3`,[ctx.organizationId,ctx.branchId,linked.menu_item_id,r.name,r.price_cents]);
          updated++;
        }else{
          const item=(await db.query('INSERT INTO menu_items(organization_id,branch_id,name,price_cents) VALUES($1,$2,$3,$4) RETURNING id',
            [ctx.organizationId,ctx.branchId,r.name,r.price_cents])).rows[0];
          await db.query(`INSERT INTO integration_menu_links(organization_id,branch_id,connection_id,external_id,menu_item_id)
            VALUES($1,$2,$3,$4,$5)`,[ctx.organizationId,ctx.branchId,id,r.external_id,item.id]);created++;
        }
      }
      await db.query(`INSERT INTO audit_events(organization_id,branch_id,actor_id,action,entity_type,entity_id,metadata)
        VALUES($1,$2,$3,'integration.menu.import','integration_connection',$4,$5)`,
        [ctx.organizationId,ctx.branchId,ctx.userId,id,JSON.stringify({jobId,count:rows.length,created,updated})]);
      return {imported:created+updated,created,updated};
    });
  }
  async claim():Promise<ClaimedSync|null>{
    return this.tx(async db=>{
      const {rows}=await db.query(`SELECT j.*,c.sealed_credentials,c.remote_organization_id FROM integration_sync_jobs j
        JOIN integration_connections c ON c.id=j.connection_id AND c.organization_id=j.organization_id AND c.branch_id=j.branch_id
        WHERE c.state='VERIFIED' AND ((j.status IN('QUEUED','RETRY') AND j.next_attempt_at<=now()) OR (j.status='RUNNING' AND j.lease_until<now()))
        ORDER BY j.next_attempt_at,j.created_at FOR UPDATE OF j SKIP LOCKED LIMIT 1`);
      if(!rows.length)return null;const r=rows[0],token=randomUUID();
      const q=await db.query(`UPDATE integration_sync_jobs SET status='RUNNING',attempt_count=attempt_count+1,
        lease_token=$2,lease_until=now()+interval '90 seconds',last_error_code=NULL WHERE id=$1 RETURNING attempt_count`,[r.id,token]);
      return {id:r.id,connectionId:r.connection_id,organizationId:r.organization_id,branchId:r.branch_id,
        menuId:r.menu_id,leaseToken:token,attemptCount:q.rows[0].attempt_count,
        sealedCredentials:r.sealed_credentials,remoteOrganizationId:r.remote_organization_id};
    });
  }
  async succeed(job:ClaimedSync,items:CatalogProduct[]):Promise<boolean>{
    assert(items.length<=5000,400,'INVALID_MENU','Превышен размер каталога');
    return this.tx(async db=>{
      // Lock connection before job, matching rotate/disable lock ordering.
      await db.query('SELECT id FROM integration_connections WHERE id=$1 FOR UPDATE',[job.connectionId]);
      const {rows}=await db.query(`SELECT id FROM integration_sync_jobs WHERE id=$1 AND lease_token=$2 AND status='RUNNING' AND lease_until>now() FOR UPDATE`,
        [job.id,job.leaseToken]);
      if(!rows.length)return false;
      // Snapshot replacement is atomic; previous catalog survives provider or worker failures.
      await db.query('DELETE FROM integration_catalog WHERE connection_id=$1',[job.connectionId]);
      if(items.length){
        await db.query(`INSERT INTO integration_catalog(organization_id,branch_id,connection_id,external_id,name,category,price_cents,source_job_id)
          SELECT $1,$2,$3,x."externalId",x.name,x.category,x."priceCents",$4
          FROM jsonb_to_recordset($5::jsonb) AS x("externalId" text,name text,category text,"priceCents" bigint)`,
          [job.organizationId,job.branchId,job.connectionId,job.id,JSON.stringify(items)]);
      }
      await db.query(`UPDATE integration_sync_jobs SET status='SUCCEEDED',lease_until=NULL,lease_token=NULL,
        items_count=$3,completed_at=now() WHERE id=$1 AND lease_token=$2`,[job.id,job.leaseToken,items.length]);
      await db.query('UPDATE integration_connections SET last_sync_at=now(),last_error_code=NULL,updated_at=now() WHERE id=$1',[job.connectionId]);
      return true;
    });
  }
  async fail(job:ClaimedSync,code:string):Promise<boolean>{
    const retry=job.attemptCount<4 && ['RATE_LIMIT','UNAVAILABLE','TIMEOUT'].includes(code);
    const delay=Math.min(600,30*2**Math.max(0,job.attemptCount-1));
    return this.tx(async db=>{
      await db.query('SELECT id FROM integration_connections WHERE id=$1 FOR UPDATE',[job.connectionId]);
      const q=await db.query(`UPDATE integration_sync_jobs SET status=$3,last_error_code=$4,lease_token=NULL,lease_until=NULL,
        next_attempt_at=now()+$5 * interval '1 second',completed_at=CASE WHEN $3='FAILED' THEN now() ELSE NULL END
        WHERE id=$1 AND lease_token=$2 AND status='RUNNING' AND lease_until>now()`,
        [job.id,job.leaseToken,retry?'RETRY':'FAILED',code,delay]);
      if(q.rowCount)await db.query('UPDATE integration_connections SET last_error_code=$2,updated_at=now() WHERE id=$1',[job.connectionId,code]);
      return !!q.rowCount;
    });
  }
}
