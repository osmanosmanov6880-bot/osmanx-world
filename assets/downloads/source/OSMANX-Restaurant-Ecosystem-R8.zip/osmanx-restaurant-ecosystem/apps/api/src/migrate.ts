import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {postgresConnectionString} from './infra/postgres.ts';

export async function runMigrations(connectionString=process.env.DATABASE_URL):Promise<number> {
  if (!connectionString) throw new Error('DATABASE_URL is required');
  const {default:pg} = await import('pg');
  const client=new pg.Client({connectionString:postgresConnectionString(connectionString)});
  await client.connect();
  let count=0;
  try {
    const migrations=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../../db/migrations');
    await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())`);
    const files=(await readdir(migrations)).filter(n=>/^\d+_[a-z0-9_]+\.sql$/.test(n)).sort();
    for (const file of files) {
      await client.query('BEGIN');
      try {
        await client.query('SELECT pg_advisory_xact_lock(92170431)');
        const present=await client.query('SELECT 1 FROM schema_migrations WHERE name=$1',[file]);
        if (present.rowCount===0) {
          const sql=await readFile(path.join(migrations,file),'utf8');
          await client.query(sql);
          await client.query('INSERT INTO schema_migrations(name) VALUES($1)',[file]);
          count++;
        }
        await client.query('COMMIT');
      } catch(e) {await client.query('ROLLBACK'); throw e;}
    }
    return count;
  } finally {await client.end();}
}
if (process.argv[1] && fileURLToPath(import.meta.url)===path.resolve(process.argv[1])) {
  runMigrations().then(n=>{console.info(`Applied ${n} migration(s)`);}).catch(e=>{console.error(e);process.exitCode=1;});
}
