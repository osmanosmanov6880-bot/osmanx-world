import {createHash,randomUUID} from 'node:crypto';
import type {Ctx} from '../store.ts';
import {AppError,assert} from '../domain/rules.ts';
import {checkRevision,credentialsInput,integrationInput,menuId,selectedExternalIds,safeProviderError,type Credentials} from '../domain/integrations.ts';
import {encryptionKey,openCredentials,requireKey,sealCredentials} from '../infra/integration-crypto.ts';
import type {IikoClient} from '../infra/iiko.ts';
import type {IntegrationRepository} from './repository.ts';
export type IikoApi=Pick<IikoClient,'verify'|'menus'|'catalog'>;
const fingerprint=(x:unknown)=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
export class IntegrationRuntime {
  private key:Buffer|null;
  readonly repo:IntegrationRepository;private iiko:IikoApi;
  constructor(repo:IntegrationRepository,iiko:IikoApi,encodedKey?:string){this.repo=repo;this.iiko=iiko;this.key=encryptionKey(encodedKey);}
  async create(ctx:Ctx,raw:Record<string,unknown>,key:string){
    const input=integrationInput(raw);const id=randomUUID();
    return this.repo.create(ctx,{id,alias:input.alias,remoteOrganizationId:input.remoteOrganizationId,
      fingerprint:fingerprint(input.credentials),sealedCredentials:sealCredentials(requireKey(this.key),ctx,id,input.credentials)},key);
  }
  async verify(ctx:Ctx,id:string,expectedRevision:number,key:string){
    const connection=await this.repo.read(ctx,id);
    assert(connection.state!=='DISABLED',409,'DISABLED','Подключение отключено');
    const secret=openCredentials(requireKey(this.key),ctx,id,connection.sealedCredentials);
    let remote;
    try{remote=await this.iiko.verify(secret,connection.remoteOrganizationId);}
    catch(error){
      const safe=safeProviderError(error);
      // Never confuse provider failure with a local optimistic-revision conflict.
      await this.repo.transition(ctx,id,expectedRevision,'ERROR',{errorCode:safe.code},`${key.slice(0,75)}-failure`).catch(()=>{});
      throw new AppError(safe.retryable?503:502,safe.code,
        safe.code==='ORG_NOT_FOUND'?'Организация не найдена в выданных iiko правах':
        safe.code==='AUTH_FAILED'?'iiko отклонил учётные данные':'Не удалось проверить подключение iiko');
    }
    return this.repo.transition(ctx,id,expectedRevision,'VERIFY',{remoteOrganizationName:remote.name},key);
  }
  async menus(ctx:Ctx,id:string){
    const conn=await this.repo.read(ctx,id);
    assert(conn.state==='VERIFIED',409,'NOT_VERIFIED','Сначала проверьте подключение');
    const secret=openCredentials(requireKey(this.key),ctx,id,conn.sealedCredentials);
    try{return await this.iiko.menus(secret,conn.remoteOrganizationId);}
    catch(error){const safe=safeProviderError(error);throw new AppError(safe.retryable?503:502,safe.code,'Не удалось загрузить список меню iiko');}
  }
  async rotate(ctx:Ctx,id:string,revision:number,raw:Record<string,unknown>,key:string){
    const credentials=credentialsInput(raw);
    return this.repo.transition(ctx,id,revision,'ROTATE',{sealedCredentials:sealCredentials(requireKey(this.key),ctx,id,credentials),fingerprint:fingerprint(credentials)},key);
  }
  async runOnce():Promise<'IDLE'|'SUCCEEDED'|'RETRY'|'FAILED'>{
    if(!this.key)return 'IDLE';
    const job=await this.repo.claim();if(!job)return 'IDLE';
    try{
      const credentials=openCredentials(this.key,{organizationId:job.organizationId,branchId:job.branchId},job.connectionId,job.sealedCredentials);
      const result=await this.iiko.catalog(credentials,job.remoteOrganizationId,job.menuId);
      const accepted=await this.repo.succeed(job,result);
      return accepted?'SUCCEEDED':'IDLE';
    }catch(error){
      const safe=safeProviderError(error);
      await this.repo.fail(job,safe.code);
      return safe.retryable&&job.attemptCount<4?'RETRY':'FAILED';
    }
  }
}
