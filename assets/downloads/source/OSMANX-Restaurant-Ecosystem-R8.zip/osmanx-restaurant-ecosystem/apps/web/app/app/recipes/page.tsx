'use client';
import {useCallback,useEffect,useState,type FormEvent} from 'react';
import Link from 'next/link';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {formatQty,parseQty,UNIT_LABELS,type Ingredient,type MenuItem,type Recipe} from '../../../lib/types';

type Line={ingredientId:string;quantity:string};
export default function Recipes(){
  const {base,organization,api}=useScope();
  const [items,setItems]=useState<MenuItem[]>([]),[ingredients,setIngredients]=useState<Ingredient[]>([]),[selected,setSelected]=useState('');
  const [recipe,setRecipe]=useState<Recipe|null>(null),[lines,setLines]=useState<Line[]>([{ingredientId:'',quantity:'1'}]);
  const [loading,setLoading]=useState(true),[busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const editable=['owner','operations_director','manager','chef'].includes(organization?.role||'');
  const load=useCallback(async()=>{if(!base)return;const [m,i]=await Promise.all([api<{items:MenuItem[]}>(`${base}/menu`),api<{ingredients:Ingredient[]}>(`${base}/ingredients`)]);
    setItems(m.items);setIngredients(i.ingredients);setSelected(old=>old||m.items[0]?.id||'');},[base,api]);
  useEffect(()=>{setLoading(true);setError('');void load().catch(e=>setError(e.message)).finally(()=>setLoading(false));},[load]);
  useEffect(()=>{if(!base||!selected){setRecipe(null);setLines([{ingredientId:'',quantity:'1'}]);return;}
    let active=true;setError('');void api<{recipe:Recipe|null}>(`${base}/recipes/${selected}`).then(r=>{if(!active)return;setRecipe(r.recipe);
      setLines(r.recipe?.components.length?r.recipe.components.map(c=>({ingredientId:c.ingredientId,quantity:String(c.quantityMilli/1000)})):[{ingredientId:'',quantity:'1'}]);
    }).catch(e=>{if(active)setError(e.message);});return()=>{active=false;};
  },[base,selected,api]);
  async function save(e:FormEvent){e.preventDefault();if(!base||!selected)return;setBusy(true);setError('');setNotice('');
    try{const components=lines.map(l=>({ingredientId:l.ingredientId,quantityMilli:parseQty(l.quantity)}));
      const r=await api<{recipe:Recipe}>(`${base}/recipes/${selected}`,{method:'PUT',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({expectedRevision:recipe?.revision||0,components})});
      setRecipe(r.recipe);setNotice('Рецептура сохранена. Для уже отправленных на кухню заказов остаются прежние нормы расхода.');
    }catch(e){setError(e instanceof Error?e.message:'Ошибка сохранения');}finally{setBusy(false);}}
  const choice=items.find(i=>i.id===selected);
  return <><PageHeading eyebrow="TECHNOLOGY / FOOD COST" title="Рецептуры блюд" subtitle="Точные нормы ингредиентов на одну порцию. В момент отправки заказа на кухню фиксируется снимок рецепта."/>
    {error&&<Alert text={error}/>} {notice&&<div className="notice" role="status">{notice}</div>}
    <Panel title="Выберите блюдо" subtitle="Меню и склад относятся к выбранному ресторану">
      {loading?<div className="loading-panel">Загрузка…</div>:!items.length?<Empty title="Нет блюд" description="Сначала создайте позицию в меню."/>:<div className="r3-form"><label>Блюдо<select value={selected} onChange={e=>setSelected(e.target.value)}>{items.map(x=><option value={x.id} key={x.id}>{x.name}{x.active?'':' · скрыто'}</option>)}</select></label>
        <div className="r3-form-caption">{choice?.name} · {recipe?`Версия рецепта ${recipe.revision}`:'Рецептура пока не создана'}</div></div>}
    </Panel>
    {selected&&<Panel title="Состав одной порции" subtitle="Количество на одну порцию в единицах выбранного ингредиента (точность 0,001)">
      {!ingredients.length?<Empty title="Нет ингредиентов" description="Создайте складские позиции, прежде чем сохранять рецептуру."/>:<form onSubmit={save}>
        <div className="r3-line-editor">{lines.map((line,index)=><div className="r3-recipe-line" key={index}>
          <label>Ингредиент<select required disabled={!editable} value={line.ingredientId} onChange={e=>setLines(p=>p.map((l,i)=>i===index?{...l,ingredientId:e.target.value}:l))}><option value="">Выберите ингредиент</option>{ingredients.map(x=><option value={x.id} key={x.id}>{x.name} ({UNIT_LABELS[x.unit]})</option>)}</select></label>
          <label>Количество<input required inputMode="decimal" disabled={!editable} value={line.quantity} onChange={e=>setLines(p=>p.map((l,i)=>i===index?{...l,quantity:e.target.value}:l))}/></label>
          {editable&&<button type="button" className="text-button" aria-label={`Удалить ингредиент ${index+1}`} disabled={lines.length===1||busy} onClick={()=>setLines(p=>p.filter((_,i)=>i!==index))}>Удалить</button>}
        </div>)}</div>
        {editable&&<div className="r3-toolbar"><button type="button" className="gold-outline-button" disabled={lines.length>=60||busy} onClick={()=>setLines(p=>[...p,{ingredientId:'',quantity:'1'}])}>Добавить ингредиент</button>
        <button className="gold-button" disabled={busy}>Сохранить рецептуру</button></div>}
      </form>}
    </Panel>}
    {recipe&&<Panel title="Установленные нормы" subtitle="Это текущий рецепт; уже отправленные заказы используют собственные снимки">
      <div className="table-scroll"><table className="data-table"><thead><tr><th>Ингредиент</th><th>Расход на порцию</th><th>Остаток на складе</th></tr></thead><tbody>{recipe.components.map(c=>{
        const current=ingredients.find(i=>i.id===c.ingredientId);return <tr key={c.ingredientId}><td><strong>{c.name}</strong></td><td>{formatQty(c.quantityMilli)} {UNIT_LABELS[c.unit]}</td>
          <td className={current&&current.quantityMilli<c.quantityMilli?'r3-negative':'gold-text'}>{current?`${formatQty(current.quantityMilli)} ${UNIT_LABELS[current.unit]}`:'Не найден'}</td></tr>;
      })}</tbody></table></div>
    </Panel>}
    <div className="info-footnote">Блюдо без рецепта можно продать, но его себестоимость будет помечена как неполная. При дефиците ингредиента завершение заказа с известной рецептурой блокируется. <Link href="/app/inventory">Перейти на склад</Link>.</div>
  </>;
}
