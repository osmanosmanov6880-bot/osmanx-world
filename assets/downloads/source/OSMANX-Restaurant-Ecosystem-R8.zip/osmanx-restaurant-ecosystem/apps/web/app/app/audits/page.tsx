'use client';
import {useCallback,useEffect,useState,type FormEvent} from 'react';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {prettyDate,score,type Standard,type Audit,type NetworkAction,type ActionStatus} from '../../../lib/network';

type AnswerDraft={passed:boolean|null;note:string};
export default function AuditsPage(){
  const {base,organization,api}=useScope();const orgId=organization?.organizationId;
  const [standards,setStandards]=useState<Standard[]>([]),[selectedId,setSelectedId]=useState('');
  const [audits,setAudits]=useState<Audit[]>([]),[actions,setActions]=useState<NetworkAction[]>([]);
  const [answers,setAnswers]=useState<Record<string,AnswerDraft>>({});const [resolution,setResolution]=useState<Record<string,string>>({});
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const selected=standards.find(s=>s.id===selectedId)||null;
  const canAudit=['owner','operations_director','manager'].includes(organization?.role||'');
  const read=useCallback(async()=>{if(!base||!orgId)return;
    const [s,a,c]=await Promise.all([api<{standards:Standard[]}>(`/api/v1/organizations/${orgId}/standards`),
      api<{audits:Audit[]}>(`${base}/audits`),api<{actions:NetworkAction[]}>(`${base}/corrective-actions`)]);
    setStandards(s.standards);setAudits(a.audits);setActions(c.actions);
    setSelectedId(id=>s.standards.some(v=>v.id===id&&v.active)?id:(s.standards.find(v=>v.active)?.id||''));
  },[base,orgId,api]);
  useEffect(()=>{setError('');void read().catch(e=>setError(e.message));},[read]);
  useEffect(()=>{setAnswers({});},[selectedId]);
  const update=(id:string,patch:Partial<AnswerDraft>)=>setAnswers(prev=>({...prev,[id]:{passed:null,note:'',...prev[id],...patch}}));
  async function submit(e:FormEvent){e.preventDefault();if(!base||!selected||!canAudit)return;
    const items=selected.criteria.map(c=>({criterionId:c.id,passed:answers[c.id]?.passed,note:answers[c.id]?.note||''}));
    if(items.some(x=>x.passed===null||x.passed===undefined)){setError('Укажите результат для каждого критерия');return;}
    setBusy(true);setError('');setNotice('');try{
      await api(`${base}/audits`,{method:'POST',idempotencyKey:crypto.randomUUID(),
        body:JSON.stringify({standardId:selected.id,expectedStandardRevision:selected.revision,answers:items})});
      setAnswers({});await read();setNotice('Аудит зафиксирован; нарушения добавлены в корректирующие действия.');
    }catch(e){setError(e instanceof Error?e.message:'Ошибка аудита');}finally{setBusy(false);}
  }
  async function move(a:NetworkAction,status:ActionStatus){if(!base||!canAudit)return;setBusy(true);setError('');setNotice('');try{
    await api(`${base}/corrective-actions/${a.id}/status`,{method:'POST',idempotencyKey:crypto.randomUUID(),
      body:JSON.stringify({status,expectedRevision:a.revision,resolution:status==='RESOLVED'?resolution[a.id]||'':null})});
    await read();setResolution(prev=>({...prev,[a.id]:''}));setNotice('Состояние корректирующего действия обновлено.');
  }catch(e){setError(e instanceof Error?e.message:'Ошибка изменения');}finally{setBusy(false);}}
  return <><PageHeading eyebrow="SCALE / QUALITY ASSURANCE" title="Аудиты и нарушения" subtitle="Проверка выбранного ресторана по действующей редакции стандарта. Без подстановки ответов и баллов."/>
    {error&&<Alert text={error}/>} {notice&&<p className="notice" role="status">{notice}</p>}
    {canAudit&&<Panel title="Провести проверку" subtitle="Все пункты требуют явного ответа. Для нарушения укажите наблюдаемый факт.">
      {!standards.some(s=>s.active)?<Empty title="Нет действующих стандартов" description="Владелец сети сначала создаёт стандарт."/>:
      <form className="form-grid" onSubmit={e=>void submit(e)}>
        <label>Стандарт<select value={selectedId} onChange={e=>setSelectedId(e.target.value)}>{standards.filter(s=>s.active).map(s=><option key={s.id} value={s.id}>{s.title} · редакция {s.revision}</option>)}</select></label>
        {selected?.criteria.map(c=><fieldset key={c.id} className="r7-audit-field">
          <legend>{c.title} <span className="small-muted">Вес {c.weight}{c.critical?' · критический':''}</span></legend>
          <div className="r7-radio-row"><label><input type="radio" name={c.id} checked={answers[c.id]?.passed===true} onChange={()=>update(c.id,{passed:true})}/> Соответствует</label>
            <label><input type="radio" name={c.id} checked={answers[c.id]?.passed===false} onChange={()=>update(c.id,{passed:false})}/> Есть нарушение</label></div>
          {answers[c.id]?.passed===false&&<label>Описание нарушения<textarea required minLength={8} maxLength={1000} value={answers[c.id]?.note||''}
            onChange={e=>update(c.id,{note:e.target.value})} placeholder="Что именно обнаружено и где"/></label>}
        </fieldset>)}
        <button className="gold-button" type="submit" disabled={busy||!selected}>Зафиксировать аудит</button>
      </form>}
    </Panel>}
    <Panel title="Корректирующие действия" subtitle="Каждое несоответствие создаёт отдельное действие с обязательным подтверждением устранения">
      {actions.length===0?<Empty title="Корректирующих действий нет" description="Они появятся после аудита с нарушениями."/>:
      <div className="r7-audit-list">{actions.map(a=><article key={a.id} className="r7-audit-field">
        <div className="r7-row"><h3>{a.title}</h3><span className={`r7-state ${a.status==='RESOLVED'?'r7-state-active':''}`}>{a.status==='OPEN'?'Открыто':a.status==='IN_PROGRESS'?'Исправляется':'Закрыто'}</span></div>
        <p className="small-muted">Создано: {prettyDate(a.createdAt)} · версия {a.revision}</p>
        {a.resolution&&<p>Факт устранения: {a.resolution}</p>}
        {canAudit&&<div className="r7-actions-row">
          {a.status==='OPEN'&&<button type="button" className="gold-outline-button" disabled={busy} onClick={()=>void move(a,'IN_PROGRESS')}>Взять в работу</button>}
          {a.status!=='RESOLVED'&&<><input aria-label={`Подтверждение устранения: ${a.title}`} maxLength={1000} placeholder="Что исправлено и как проверили (минимум 8 символов)"
            value={resolution[a.id]||''} onChange={e=>setResolution(p=>({...p,[a.id]:e.target.value}))}/>
            <button type="button" className="gold-button" disabled={busy||(resolution[a.id]||'').trim().length<8} onClick={()=>void move(a,'RESOLVED')}>Подтвердить устранение</button></>}
          {a.status==='RESOLVED'&&<button type="button" className="gold-outline-button" disabled={busy} onClick={()=>void move(a,'OPEN')}>Открыть повторно</button>}
        </div>}
      </article>)}</div>}
    </Panel>
    <Panel title="История проверок" subtitle="Оценки не изменяются при редактировании стандартов">
      {audits.length===0?<Empty title="Проверок пока нет"/>:<div className="table-scroll"><table className="data-table"><thead><tr><th>Стандарт</th><th>Дата</th><th>Баллы</th><th>Нарушения</th></tr></thead><tbody>
        {audits.map(a=><tr key={a.id}><td>{a.standardTitle}<div className="small-muted">Редакция {a.standardRevision}</div></td><td>{prettyDate(a.performedAt)}</td>
          <td>{score(a.scoreBps)}</td><td>{a.failedCount} · критичных {a.criticalFailures}</td></tr>)}
      </tbody></table></div>}
    </Panel>
  </>;
}
