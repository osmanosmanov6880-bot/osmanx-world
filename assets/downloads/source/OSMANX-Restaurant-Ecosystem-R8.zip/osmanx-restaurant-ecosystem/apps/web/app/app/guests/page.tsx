'use client';
import {useCallback,useEffect,useState,type FormEvent} from 'react';
import Link from 'next/link';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {dateTime,money,type Consent,type Guest,type GuestVisit} from '../../../lib/types';
const editable=['owner','operations_director','manager','marketer','waiter','cashier'];
const consentRoles=['owner','operations_director','manager','marketer'];
const empty={displayName:'',email:'',phone:''};
export default function Guests(){
  const {base,organization,api}=useScope();const role=organization?.role||'';
  const [guests,setGuests]=useState<Guest[]>([]),[next,setNext]=useState<string|null>(null),[selected,setSelected]=useState<string|null>(null);
  const [visits,setVisits]=useState<GuestVisit[]>([]),[consents,setConsents]=useState<Consent[]>([]);
  const [draft,setDraft]=useState(empty),[editing,setEditing]=useState(false),[newGuest,setNewGuest]=useState(empty);
  const [channel,setChannel]=useState<'EMAIL'|'SMS'>('EMAIL'),[state,setState]=useState<'GRANTED'|'REVOKED'>('GRANTED'),[evidence,setEvidence]=useState('');
  const [loading,setLoading]=useState(true),[busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const guest=guests.find(g=>g.id===selected)||null;
  const refresh=useCallback(async(after:string|null=null)=>{if(!base)return;
    const result=await api<{guests:Guest[];nextCursor:string|null}>(`${base}/guests${after?`?after=${encodeURIComponent(after)}`:''}`);
    setGuests(prev=>after?[...prev.filter(p=>!result.guests.some(x=>x.id===p.id)),...result.guests]:result.guests);
    setNext(result.nextCursor);
  },[base,api]);
  const details=useCallback(async(id:string)=>{if(!base)return;
    const [v,c]=await Promise.all([api<{visits:GuestVisit[]}>(`${base}/guests/${id}/visits`),api<{consents:Consent[]}>(`${base}/guests/${id}/consents`)]);
    setVisits(v.visits);setConsents(c.consents);
  },[base,api]);
  useEffect(()=>{setLoading(true);setSelected(null);setConsents([]);setVisits([]);setError('');
    void refresh().catch(e=>setError(e.message)).finally(()=>setLoading(false));},[refresh]);
  useEffect(()=>{if(!selected)return;void details(selected).catch(e=>setError(e.message));},[selected,details]);
  const work=async(fn:()=>Promise<void>)=>{setBusy(true);setError('');setNotice('');try{await fn();}catch(e){setError(e instanceof Error?e.message:'Ошибка операции');}finally{setBusy(false);}};
  const create=(e:FormEvent)=>{e.preventDefault();if(!base)return;void work(async()=>{
    const r=await api<{guest:Guest}>(`${base}/guests`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify(newGuest)});
    setNewGuest(empty);await refresh();setSelected(r.guest.id);setNotice('Карточка создана без автоматических согласий на рассылку.');});};
  const save=(e:FormEvent)=>{e.preventDefault();if(!base||!guest)return;void work(async()=>{
    await api(`${base}/guests/${guest.id}`,{method:'PATCH',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({...draft,expectedRevision:guest.revision})});
    await refresh();setEditing(false);setNotice('Данные обновлены.');});};
  const saveConsent=(e:FormEvent)=>{e.preventDefault();if(!base||!guest)return;void work(async()=>{
    const current=consents.find(c=>c.channel===channel);
    await api(`${base}/guests/${guest.id}/consents/${channel}`,{method:'PUT',idempotencyKey:crypto.randomUUID(),
      body:JSON.stringify({state,evidence:state==='GRANTED'?evidence:null,expectedRevision:current?.revision||0})});
    await details(guest.id);setEvidence('');setNotice(state==='GRANTED'?'Основание согласия записано. Это не проверка его юридической действительности.':'Отзыв согласия записан.');});};
  const erase=()=>{if(!base||!guest||!['owner','operations_director'].includes(role))return;
    if(!window.confirm('Удалить персональную карточку, все согласия и связанные отзывы? Финансовые заказы останутся без связи с гостем. Действие необратимо.'))return;
    void work(async()=>{await api(`${base}/guests/${guest.id}`,{method:'DELETE',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({expectedRevision:guest.revision})});
      setSelected(null);setVisits([]);setConsents([]);await refresh();setNotice('Основные данные гостя и его связи удалены. Резервные копии обрабатываются отдельно.');});};
  return <><PageHeading eyebrow="GROWTH / GUEST PROFILES" title="Гости и CRM" subtitle="Контакты, связанные завершённые заказы и согласия. Ни одно согласие не устанавливается автоматически." action={<Link className="gold-outline-button" href="/app/guest-insights">Аналитика гостей</Link>}/>
    {error&&<Alert text={error}/>}{notice&&<p className="info-footnote" role="status">{notice}</p>}
    {editable.includes(role)&&<Panel title="Новая карточка" subtitle="Указывайте только необходимые данные. Идентичность гостя не определяется автоматически по имени.">
      <form className="r5-guest-form" onSubmit={create}><label>Имя гостя<input required minLength={2} maxLength={120} value={newGuest.displayName} onChange={e=>setNewGuest(p=>({...p,displayName:e.target.value}))}/></label>
      <label>Email (необязательно)<input type="email" value={newGuest.email} onChange={e=>setNewGuest(p=>({...p,email:e.target.value}))}/></label>
      <label>Телефон (необязательно)<input type="tel" value={newGuest.phone} onChange={e=>setNewGuest(p=>({...p,phone:e.target.value}))}/></label>
      <button className="gold-button" disabled={busy}>Создать карточку</button></form></Panel>}
    <div className="r5-two-columns"><Panel title="Реестр гостей" subtitle="Список филиала · 100 записей на страницу">
      {loading?<p>Загрузка…</p>:!guests.length?<Empty title="Нет гостей" description="Создайте первую карточку и свяжите её с новым заказом."/>:<div className="r5-guest-list">{guests.map(g=><button type="button" className={`r5-guest-row ${selected===g.id?'r5-selected':''}`} key={g.id} onClick={()=>{setSelected(g.id);setEditing(false);setDraft({displayName:g.displayName,email:g.email||'',phone:g.phone||''});setError('');}}>
        <strong>{g.displayName}</strong><small>{g.phone||g.email||'Контакт не указан'}</small></button>)}</div>}
      {next&&<button className="gold-outline-button" type="button" disabled={busy} onClick={()=>void work(()=>refresh(next))}>Показать следующие 100</button>}
    </Panel><Panel title="Карточка и посещения" subtitle={guest?`Запись ${guest.id.slice(0,8)} · версия ${guest.revision}`:'Выберите гостя из реестра'}>
      {!guest?<Empty title="Выберите карточку" description="Здесь появятся визиты, контакты и согласия."/>:<div className="r5-profile">
        <h3>{guest.displayName}</h3><p className="small-muted">{guest.email||'Email не указан'} · {guest.phone||'Телефон не указан'}</p>
        {editing?<form className="r5-stack" onSubmit={save}>
          <label>Имя<input required value={draft.displayName} onChange={e=>setDraft(p=>({...p,displayName:e.target.value}))}/></label>
          <label>Email<input type="email" value={draft.email} onChange={e=>setDraft(p=>({...p,email:e.target.value}))}/></label>
          <label>Телефон<input type="tel" value={draft.phone} onChange={e=>setDraft(p=>({...p,phone:e.target.value}))}/></label>
          <button className="gold-button" disabled={busy}>Сохранить</button><button className="text-button" type="button" onClick={()=>setEditing(false)}>Отмена</button></form>:
          <div className="r5-button-line">{editable.includes(role)&&<button type="button" className="gold-outline-button" onClick={()=>{setDraft({displayName:guest.displayName,email:guest.email||'',phone:guest.phone||''});setEditing(true);}}>Изменить</button>}
            {['owner','operations_director'].includes(role)&&<button type="button" className="text-button r5-danger" disabled={busy} onClick={erase}>Удалить данные</button>}</div>}
        <h4>Завершённые заказы</h4><p className="small-muted">Показаны только заказы, к которым гостя привязали явно. История ограничена 200 строками.</p>
        {!visits.length?<p>Связанных завершённых заказов нет.</p>:<div className="r5-compact-list">{visits.map(v=><div key={v.orderId}><span>{dateTime(v.completedAt)} · заказ {v.orderId.slice(0,8)}</span><strong>{money(v.totalCents,organization?.currency)}</strong></div>)}</div>}
        <h4>Маркетинговые согласия</h4><p className="small-muted">Отсутствие записи означает отсутствие подтверждённого согласия. Автоматических рассылок в R5 нет.</p>
        <div className="r5-compact-list">{(['EMAIL','SMS'] as const).map(ch=>{const c=consents.find(x=>x.channel===ch);return <div key={ch}><span>{ch}</span><strong>{c?.state==='GRANTED'?'Записано согласие':c?.state==='REVOKED'?'Отозвано':'Не получено'}</strong></div>;})}</div>
        {consentRoles.includes(role)&&<form className="r5-stack" onSubmit={saveConsent}><label>Канал<select value={channel} onChange={e=>setChannel(e.target.value as 'EMAIL'|'SMS')}><option>EMAIL</option><option>SMS</option></select></label>
          <label>Действие<select value={state} onChange={e=>setState(e.target.value as 'GRANTED'|'REVOKED')}><option value="GRANTED">Зафиксировать согласие</option><option value="REVOKED">Зафиксировать отзыв</option></select></label>
          {state==='GRANTED'&&<label>Основание (обязательно)<input required minLength={8} maxLength={240} placeholder="Источник, дата и идентификатор согласия" value={evidence} onChange={e=>setEvidence(e.target.value)}/></label>}
          <button className="gold-outline-button" disabled={busy}>Сохранить статус согласия</button></form>}
      </div>}
    </Panel></div>
    <div className="info-footnote">Управление контактами и согласиями — учёт записей, не юридическое подтверждение согласия. Выгрузка, сроки хранения резервных копий и региональные правовые процедуры требуют отдельной настройки перед commercial release.</div>
  </>;
}
