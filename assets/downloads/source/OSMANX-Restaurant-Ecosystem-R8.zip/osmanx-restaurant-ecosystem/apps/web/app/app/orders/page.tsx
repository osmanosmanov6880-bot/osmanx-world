'use client';
import {useCallback,useEffect,useState,type FormEvent} from 'react';
import {Alert,Empty,PageHeading,Panel,Status} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {money,type MenuItem,type DiningTable,type Order,type OrderStatus,type Guest} from '../../../lib/types';

const nextStatuses:Record<OrderStatus,OrderStatus[]>={OPEN:['SENT','CANCELLED'],SENT:['PREPARING','CANCELLED'],PREPARING:['READY','CANCELLED'],READY:['COMPLETED','CANCELLED'],COMPLETED:[],CANCELLED:[]};
const nextLabel:Partial<Record<OrderStatus,string>>={SENT:'На кухню',PREPARING:'Начать готовить',READY:'Готово',COMPLETED:'Закрыть заказ',CANCELLED:'Отменить'};
const canChange=(role:string,from:OrderStatus,to:OrderStatus)=>{
  if(['owner','manager','operations_director'].includes(role))return true;
  if(['chef','kitchen'].includes(role))return (from==='SENT'&&to==='PREPARING')||(from==='PREPARING'&&to==='READY');
  if(['waiter','cashier'].includes(role))return (from==='OPEN'&&to==='SENT')||(from==='READY'&&to==='COMPLETED');
  return false;
};
export default function Orders(){
  const {base,organization,api}=useScope();
  const [guests,setGuests]=useState<Guest[]>([]);const [guestSelection,setGuestSelection]=useState<Record<string,string>>({});const [orders,setOrders]=useState<Order[]>([]);const [menu,setMenu]=useState<MenuItem[]>([]);const [tables,setTables]=useState<DiningTable[]>([]);const [error,setError]=useState('');const [loading,setLoading]=useState(true);const [busy,setBusy]=useState('');
  const [newTable,setNewTable]=useState('');const [selection,setSelection]=useState<Record<string,{itemId:string;quantity:number}>>({});
  const role=organization?.role||'';const canLink=['owner','operations_director','manager','waiter','cashier'].includes(role);const canCreate=['owner','operations_director','manager','waiter','cashier'].includes(role);
  const read=useCallback(async()=>{if(!base)return;
    const [ordersData,menuData,tablesData]=await Promise.all([api<{orders:Order[]}>(`${base}/orders`),api<{items:MenuItem[]}>(`${base}/menu`),api<{tables:DiningTable[]}>(`${base}/tables`)]);
    setOrders(ordersData.orders);setMenu(menuData.items.filter(m=>m.active));setTables(tablesData.tables);
    if(canLink){const profiles=await api<{guests:Guest[]}>(`${base}/guests`);setGuests(profiles.guests);}else setGuests([]);
  },[base,api,canLink]);
  useEffect(()=>{setLoading(true);setError('');void read().catch(e=>setError(e.message)).finally(()=>setLoading(false));},[read]);
  const perform=async(key:string,cb:()=>Promise<unknown>)=>{setBusy(key);setError('');try{await cb();await read();}catch(e){setError(e instanceof Error?e.message:'Ошибка операции');}finally{setBusy('');}};
  async function create(e:FormEvent){e.preventDefault();if(!base)return;await perform('new',()=>api(`${base}/orders`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({tableId:newTable||null})}));}
  async function linkGuest(o:Order){if(!base)return;const guestId=guestSelection[o.id]??o.guestId??'';
    await perform(o.id,()=>api(`${base}/orders/${o.id}/guest`,{method:'POST',idempotencyKey:crypto.randomUUID(),
      body:JSON.stringify({guestId:guestId||null,expectedRevision:o.revision})}));}
  async function addLine(o:Order){if(!base)return;const sel=selection[o.id];if(!sel?.itemId)return setError('Сначала выберите блюдо');
    await perform(o.id,()=>api(`${base}/orders/${o.id}/items`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({menuItemId:sel.itemId,quantity:sel.quantity||1,expectedRevision:o.revision})}));}
  async function status(o:Order,to:OrderStatus){if(!base)return;await perform(o.id,()=>api(`${base}/orders/${o.id}/status`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({status:to,expectedRevision:o.revision})}));}
  return <><PageHeading eyebrow="OPERATIONS / ORDER FLOW" title="Заказы и кухня" subtitle="Создание заказа, фиксация состава и контроль статуса приготовления."/>{error&&<Alert text={error}/>}
    {canCreate&&<Panel title="Новый заказ" subtitle="Выберите стол или оформите заказ навынос"><form onSubmit={create} className="inline-form"><label>Место обслуживания<select value={newTable} onChange={e=>setNewTable(e.target.value)}><option value="">Навынос / без стола</option>{tables.map(t=><option value={t.id} key={t.id}>{t.label} · {t.capacity} мест</option>)}</select></label><button className="gold-button" disabled={busy!==''}>Создать заказ</button></form></Panel>}
    <Panel title="Операции ресторана" subtitle="Изменения статусов защищены от одновременного редактирования"><div className="order-stack">{loading?<div className="loading-panel">Загрузка…</div>:!orders.length?<Empty title="Заказов пока нет" description="Создайте заказ, добавьте блюдо, отправьте на кухню и завершите обслуживание."/>:orders.map(o=><article className="order-card" id={`order-${o.id}`} key={o.id}>
      <div className="order-top"><div><div className="eyebrow">ЗАКАЗ #{o.id.slice(0,8).toUpperCase()}</div><h3>{o.tableId?tables.find(t=>t.id===o.tableId)?.label||'Стол':'Навынос'} <Status value={o.status}/></h3><span className="small-muted">{o.guestId?`Гость: ${guests.find(g=>g.id===o.guestId)?.displayName||'Связанная карточка'} · `:''}{new Date(o.createdAt).toLocaleString('ru-RU')} · версия {o.revision}</span></div><strong className="order-total">{money(o.totalCents,organization?.currency)}</strong></div>
      <div className="order-content">{o.items.length?<ul className="line-items">{o.items.map(i=><li key={i.id}><span>{i.name} <small>× {i.quantity}</small></span><span>{money(i.lineTotalCents,organization?.currency)}</span></li>)}</ul>:<p className="small-muted">В заказ ещё не добавлены блюда.</p>}</div>
      {o.status==='COMPLETED'&&['owner','finance_director','operations_director','manager','chef','analyst','auditor'].includes(role)&&<div className="r3-order-cost">
        {o.actualFoodCostCents===null?'Себестоимость не установлена (исторический заказ до R3).':<>
          <strong>Учтённая стоимость ингредиентов: {money(o.actualFoodCostCents,organization?.currency)}</strong>
          {!o.foodCostComplete&&<span className="r3-negative">Расчёт неполный: {o.missingRecipeLines??'—'} строк(и) без рецептуры. Не используйте это значение как полную себестоимость заказа.</span>}
        </>}
      </div>}
      {o.status==='OPEN'&&canLink&&<div className="r5-order-link"><label>Гость (необязательно)<select value={guestSelection[o.id]??o.guestId??''}
        onChange={e=>setGuestSelection(prev=>({...prev,[o.id]:e.target.value}))}>
        <option value="">Без привязки</option>{guests.map(g=><option key={g.id} value={g.id}>{g.displayName}</option>)}
      </select></label><button type="button" className="gold-outline-button" disabled={busy!==''}
        onClick={()=>void linkGuest(o)}>Сохранить гостя</button></div>}
      {o.status==='OPEN'&&canCreate&&<div className="order-add"><label>Блюдо<select value={selection[o.id]?.itemId||''} onChange={e=>setSelection(p=>({...p,[o.id]:{itemId:e.target.value,quantity:p[o.id]?.quantity||1}}))}><option value="">Выберите позицию</option>{menu.map(m=><option key={m.id} value={m.id}>{m.name} · {money(m.priceCents,organization?.currency)}</option>)}</select></label><label>Шт.<input aria-label="Количество порций" type="number" min={1} max={30} value={selection[o.id]?.quantity||1} onChange={e=>setSelection(p=>({...p,[o.id]:{itemId:p[o.id]?.itemId||'',quantity:Number(e.target.value)}}))}/></label><button className="small-button" disabled={busy!==''||!menu.length} onClick={()=>void addLine(o)}>Добавить блюдо</button></div>}
      {!!nextStatuses[o.status].filter(to=>canChange(role,o.status,to)).length&&<div className="order-actions">{nextStatuses[o.status].filter(to=>canChange(role,o.status,to)).map(to=><button key={to} className={to==='CANCELLED'?'text-button':'gold-outline-button'} disabled={busy!==''} onClick={()=>void status(o,to)}>{busy===o.id?'Сохраняем…':nextLabel[to]}</button>)}</div>}
    </article>)}</div></Panel>
    <div className="info-footnote">Завершённые заказы участвуют в выручке. Открытые и отменённые — нет. Бронирования и кухонный экран доступны в отдельных разделах. Для посадки по брони откройте «Бронирования»; система создаст связанный заказ.</div>
  </>;
}
