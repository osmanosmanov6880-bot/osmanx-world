'use client';
import Link from 'next/link';
import {useCallback,useEffect,useState} from 'react';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {prettyDate,score,type Quality,type NetworkAction,type Standard} from '../../../lib/network';

export default function NetworkQualityPage(){
  const {organization,api,pickBranch}=useScope();const orgId=organization?.organizationId;
  const [selectedId,setSelectedId]=useState('');const [standards,setStandards]=useState<Standard[]>([]),[quality,setQuality]=useState<Quality|null>(null);
  const [actions,setActions]=useState<NetworkAction[]>([]),[error,setError]=useState(''),[loading,setLoading]=useState(true);
  const refresh=useCallback(async()=>{if(!orgId)return;setLoading(true);setError('');try{
    const [q,a]=await Promise.all([api<{quality:Quality;standards:Standard[]}>(`/api/v1/organizations/${orgId}/network/quality${selectedId?`?standardId=${selectedId}`:''}`),
      api<{actions:NetworkAction[]}>(`/api/v1/organizations/${orgId}/network/actions`)]);
    setStandards(q.standards);setQuality(q.quality);setActions(a.actions);
  }catch(e){setError(e instanceof Error?e.message:'Не удалось загрузить сеть');}finally{setLoading(false);}},[orgId,selectedId,api]);
  useEffect(()=>{void refresh();},[refresh]);
  const open=actions.filter(a=>a.status!=='RESOLVED');
  return <><PageHeading eyebrow="SCALE / QUALITY CONTROL" title="Качество ресторанной сети"
    subtitle="Сопоставимость оценок проверяется по одному стандарту и редакции. Отсутствие аудита не считается нулевым результатом."
    action={<button type="button" className="gold-outline-button" disabled={loading} onClick={()=>void refresh()}>{loading?'Загружаем…':'Обновить'}</button>}/>
    {error&&<Alert text={error}/>}
    <Panel title="Стандарт для сравнения" subtitle="Только доступные вам рестораны">
      <label className="r7-picker">Критерий сравнения <select value={selectedId} onChange={e=>setSelectedId(e.target.value)}>
        <option value="">Первый активный стандарт</option>{standards.map(s=><option key={s.id} value={s.id}>{s.title} · редакция {s.revision}{s.active?'':' · отключён'}</option>)}
      </select></label>
      <div className="r7-quality-metrics"><div><span>Доступно филиалов</span><strong>{quality?.branches.length??'—'}</strong></div>
        <div><span>Открытых нарушений</span><strong>{open.length}</strong></div>
        <div><span>Сопоставимость</span><strong className="r7-metric-word">{quality?.comparable?'Подтверждена':'Не подтверждена'}</strong></div></div>
      {quality?.limitations.map((x,i)=><p className="small-muted" key={i}>• {x}</p>)}
    </Panel>
    <Panel title={quality?.standardTitle?`Сравнение · ${quality.standardTitle}`:'Филиалы'} subtitle={quality?.standardRevision?`Редакция стандарта ${quality.standardRevision}`:'В организации пока нет действующих стандартов'}>
      {loading?<div className="loading-panel">Обновляем данные…</div>:quality&&!quality.branches.length?<Empty title="Нет доступных филиалов"/>:
        <div className="table-scroll"><table className="data-table"><thead><tr><th>Ресторан</th><th>Аудит</th><th>Оценка</th><th>Критические нарушения</th><th>Открытые действия</th><th>Проверить</th></tr></thead>
          <tbody>{quality?.branches.map(b=><tr key={b.branchId}><td><strong>{b.branchName}</strong></td>
            <td>{prettyDate(b.auditAt)}{b.outdated&&<div className="r3-negative">Устаревшая редакция</div>}</td>
            <td><span className="r7-quality-score">{score(b.scoreBps)}</span>{b.scoreBps!==null&&<div className="r7-score-track"><div style={{width:`${b.scoreBps/100}%`}}/></div>}</td>
            <td>{b.criticalFailures===null?'Нет актуальной оценки':b.criticalFailures}</td><td>{b.openActions}</td>
            <td><Link href="/app/audits" className="subtle-link" onClick={()=>pickBranch(b.branchId)}>Открыть аудит</Link></td></tr>)}</tbody></table></div>}
      {quality?.comparable&&<p className="small-muted">Все показанные баллы рассчитаны по одной редакции. Сравнение не доказывает причину различий между ресторанами.</p>}
    </Panel>
    <Panel title="Контроль нарушений по сети" subtitle="Только филиалы в пределах ваших прав">
      {open.length===0?<Empty title="Открытых действий нет" description="При выявлении несоответствий система добавит их сюда."/>:
      <div className="table-scroll"><table className="data-table"><thead><tr><th>Филиал</th><th>Нарушение</th><th>Статус</th><th>Создано</th></tr></thead><tbody>
        {open.map(a=><tr key={a.id}><td>{a.branchName}</td><td>{a.title}</td><td>{a.status==='OPEN'?'Ожидает работы':'В работе'}</td><td>{prettyDate(a.createdAt)}</td></tr>)}
      </tbody></table></div>}
    </Panel>
  </>;
}
