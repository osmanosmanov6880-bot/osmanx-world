'use client';
import {useCallback,useEffect,useState,type FormEvent} from 'react';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {money} from '../../../lib/types';
type Evidence={metric:string;before:number|null;after:number|null;unit:'cents'|'bps'|'orders'};
type Signal={id:string;title:string;severity:'INFO'|'WARNING';period:string;comparisonPeriod:string;evidence:Evidence[];
  candidateCauses:string[];alternatives:string[];missingData:string[];confidence:'LOW'|'MEDIUM';recommendation:string;expectedBenefit:string;provenCause:false};
type Diagnosis={period:string;comparisonPeriod:string;signals:Signal[];limitations:string[]};
type Status='PROPOSED'|'IN_PROGRESS'|'IMPLEMENTED'|'REVIEWED'|'CANCELLED';
type Decision={id:string;title:string;hypothesis:string;action:string;signalId:string;baselinePeriod:string;status:Status;revision:number;
  reviewPeriod:string|null;implementationCostCents:number|null;baselineRevenueCents:number;observedRevenueCents:number|null;observedProfitDeltaCents:number|null;observation:string|null};
const statusNames:Record<Status,string>={PROPOSED:'Предложено',IN_PROGRESS:'В работе',IMPLEMENTED:'Внедрено',REVIEWED:'Результат проверен',CANCELLED:'Отменено'};
const reviewNext=(v:string)=>{const [y,m]=v.split('-').map(Number);return `${m===12?y+1:y}-${String(m===12?1:m+1).padStart(2,'0')}`;};
export default function IntelligencePage(){
  const {base,organization,api}=useScope();
  const [period,setPeriod]=useState(()=>new Date().toISOString().slice(0,7));
  const [diagnosis,setDiagnosis]=useState<Diagnosis|null>(null);
  const [decisions,setDecisions]=useState<Decision[]>([]);
  const [error,setError]=useState(''),[message,setMessage]=useState(''),[loading,setLoading]=useState(false);
  const [selected,setSelected]=useState<Signal|null>(null);
  const [hypothesis,setHypothesis]=useState(''),[action,setAction]=useState(''),[cost,setCost]=useState('');
  const [reviewPeriod,setReviewPeriod]=useState(''),[observationText,setObservationText]=useState('');
  const canWrite=['owner','finance_director','operations_director','manager'].includes(organization?.role||'');
  const refresh=useCallback(async()=>{if(!base)return;setLoading(true);setError('');try{
    const [a,b]=await Promise.all([api<{diagnosis:Diagnosis}>(`${base}/intelligence/diagnosis?period=${period}`),api<{decisions:Decision[]}>(`${base}/intelligence/decisions`)]);
    setDiagnosis(a.diagnosis);setDecisions(b.decisions);
  }catch(e){setError(e instanceof Error?e.message:'Не удалось получить диагностику');}finally{setLoading(false);}},[api,base,period]);
  useEffect(()=>{void refresh();},[refresh]);
  const showEvidence=(e:Evidence,v:number|null)=>v===null?'Недостаточно данных':e.unit==='cents'?money(v,organization?.currency):e.unit==='bps'?`${(v/100).toLocaleString('ru-RU')}%`:String(v);
  async function createDecision(event:FormEvent){event.preventDefault();if(!base||!selected||!canWrite)return;
    try{setLoading(true);setError('');const cents=cost.trim()===''?null:Math.round(Number(cost.replace(',','.'))*100);
      if(cents!==null&&(!Number.isSafeInteger(cents)||cents<0))throw Error('Укажите неотрицательную стоимость');
      await api(`${base}/intelligence/decisions`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({period,signalId:selected.id,title:selected.title,hypothesis,action,implementationCostCents:cents})});
      setSelected(null);setHypothesis('');setAction('');setCost('');setMessage('Гипотеза сохранена');await refresh();
    }catch(e){setError(e instanceof Error?e.message:'Ошибка создания');}finally{setLoading(false);}
  }
  async function advance(d:Decision,status:Status){if(!base||!canWrite)return;
    try{setLoading(true);setError('');await api(`${base}/intelligence/decisions/${d.id}/status`,{method:'POST',idempotencyKey:crypto.randomUUID(),
      body:JSON.stringify({expectedRevision:d.revision,status,reviewPeriod:status==='REVIEWED'?reviewPeriod:null,observation:status==='REVIEWED'?observationText:null})});
      setReviewPeriod('');setObservationText('');setMessage('Состояние обновлено');await refresh();
    }catch(e){setError(e instanceof Error?e.message:'Не удалось сохранить');}finally{setLoading(false);}
  }
  return <><PageHeading eyebrow="INTELLIGENCE / DECISION SYSTEM" title="OSMANX Intelligence" subtitle="Наблюдаемые сигналы → гипотезы → действия → проверка. Система не выдаёт совпадения за доказанные причины." action={<button type="button" disabled={loading} className="gold-outline-button" onClick={()=>void refresh()}>{loading?'Обновляем…':'Обновить данные'}</button>}/>
    {error&&<Alert text={error}/>}{message&&<p role="status" className="small-muted">{message}</p>}
    <Panel title="Диагностика филиала" subtitle="Сравнение соседних календарных месяцев; данные только выбранного филиала">
      <label className="select-label">Месяц анализа <input aria-label="Период диагностики" type="month" min="2000-02" max="2100-12" value={period} onChange={e=>setPeriod(e.target.value)}/></label>
      <p className="small-muted">{diagnosis?`Сравниваем ${diagnosis.comparisonPeriod} и ${diagnosis.period}`:'Загрузка…'}</p>
      {diagnosis?.signals.length===0&&<Empty title="Подтверждённых отклонений нет" description="Это не означает, что проблем в бизнесе нет: проверьте покрытие данных и ограничения методики."/>}
      {diagnosis?.signals.map(signal=><article className="panel" key={signal.id} style={{marginTop:16}}>
        <div className="section-row"><h3>{signal.title}</h3><span className="small-muted">Уверенность: {signal.confidence==='MEDIUM'?'средняя':'низкая'}</span></div>
        <div className="table-scroll"><table className="data-table"><thead><tr><th>Показатель</th><th>{signal.comparisonPeriod}</th><th>{signal.period}</th></tr></thead><tbody>{signal.evidence.map(e=><tr key={e.metric}><td>{e.metric}</td><td>{showEvidence(e,e.before)}</td><td>{showEvidence(e,e.after)}</td></tr>)}</tbody></table></div>
        <p><strong>Гипотезы:</strong> {signal.candidateCauses.join('; ')}</p><p><strong>Альтернативы:</strong> {signal.alternatives.join('; ')}</p>
        <p><strong>Необходимые данные:</strong> {signal.missingData.join('; ')}</p><p><strong>Действие:</strong> {signal.recommendation}</p>
        <p className="small-muted">Ожидаемая польза: {signal.expectedBenefit}. Причинность не доказана.</p>
        {canWrite&&<button className="gold-outline-button" type="button" onClick={()=>{setSelected(signal);setHypothesis(signal.candidateCauses[0]||'');setAction(signal.recommendation);}}>Создать управленческую гипотезу</button>}
      </article>)}
    </Panel>
    {selected&&<Panel title="Новая гипотеза" subtitle={`Сигнал: ${selected.title}`}><form onSubmit={e=>void createDecision(e)} className="form-grid">
      <label>Что проверяем<textarea required minLength={8} maxLength={1200} value={hypothesis} onChange={e=>setHypothesis(e.target.value)}/></label>
      <label>Что делаем<textarea required minLength={8} maxLength={1200} value={action} onChange={e=>setAction(e.target.value)}/></label>
      <label>Оценка стоимости внедрения (необязательно)<input type="text" inputMode="decimal" value={cost} onChange={e=>setCost(e.target.value)} placeholder="Например, 1500.00"/></label>
      <div><button disabled={loading} className="gold-button" type="submit">Сохранить</button> <button type="button" className="gold-outline-button" onClick={()=>setSelected(null)}>Отмена</button></div>
    </form></Panel>}
    <Panel title="Реестр управленческих решений" subtitle="Фиксируйте внедрение и измеряйте результат после выбранного месяца">
      {decisions.length===0?<Empty title="Решений пока нет" description="Выберите диагностический сигнал и оформите действие."/>:<div className="table-scroll"><table className="data-table"><thead><tr><th>Гипотеза / действие</th><th>Статус</th><th>База</th><th>После</th><th>Управление</th></tr></thead><tbody>{decisions.map(d=><tr key={d.id}>
        <td><strong>{d.title}</strong><p className="small-muted">{d.hypothesis}</p><p>{d.action}</p>{d.observation&&<p>Наблюдение: {d.observation}</p>}</td>
        <td>{statusNames[d.status]}</td><td>{d.baselinePeriod}<p>{money(d.baselineRevenueCents,organization?.currency)}</p></td>
        <td>{d.reviewPeriod||'—'}<p>{d.observedProfitDeltaCents===null?'Разница не рассчитана':money(d.observedProfitDeltaCents,organization?.currency)}</p></td>
        <td>{canWrite&&<div style={{display:'grid',gap:8}}>
          {d.status==='PROPOSED'&&<><button disabled={loading} className="gold-outline-button" onClick={()=>void advance(d,'IN_PROGRESS')}>Начать</button><button disabled={loading} className="text-button" onClick={()=>void advance(d,'CANCELLED')}>Отменить</button></>}
          {d.status==='IN_PROGRESS'&&<button disabled={loading} className="gold-outline-button" onClick={()=>void advance(d,'IMPLEMENTED')}>Внедрено</button>}
          {d.status==='IMPLEMENTED'&&<><label>Месяц проверки<input type="month" min={reviewNext(d.baselinePeriod)} value={reviewPeriod} onChange={e=>setReviewPeriod(e.target.value)}/></label><label>Что произошло<textarea value={observationText} minLength={5} maxLength={1200} onChange={e=>setObservationText(e.target.value)}/></label><button disabled={loading||!reviewPeriod||observationText.length<5} className="gold-outline-button" onClick={()=>void advance(d,'REVIEWED')}>Сравнить факт</button></>}
        </div>}</td></tr>)}</tbody></table></div>}
    </Panel>
    <Panel title="Методика и ограничения"><ul>{(diagnosis?.limitations||[]).map(x=><li key={x}>{x}</li>)}</ul><p className="small-muted">Даже рост операционного результата после изменения не означает, что он вызван именно этим решением. Для оценки причинности применяйте контрольные группы или сопоставимые периоды.</p></Panel>
  </>;
}
