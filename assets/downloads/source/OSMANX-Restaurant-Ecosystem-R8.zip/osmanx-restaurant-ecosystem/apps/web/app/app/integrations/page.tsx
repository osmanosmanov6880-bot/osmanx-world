'use client';
import {useCallback,useEffect,useState,type FormEvent} from 'react';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';

type State='UNVERIFIED'|'VERIFIED'|'ERROR'|'DISABLED';
type Connection={id:string;alias:string;provider:'IIKO';remoteOrganizationId:string;remoteOrganizationName:string|null;
  state:State;revision:number;lastErrorCode:string|null;lastSyncAt:string|null;verifiedAt:string|null};
type Menu={id:string;name:string};
type Job={id:string;menuId:string;status:string;attemptCount:number;nextAttemptAt:string;lastErrorCode:string|null;itemsCount:number|null;createdAt:string};
type Item={externalId:string;name:string;category:string;priceCents:number|null;sourceRunId:string;importedMenuItemId:string|null};
const names:Record<State,string>={UNVERIFIED:'Ожидает проверки',VERIFIED:'Подтверждено через API',ERROR:'Ошибка проверки',DISABLED:'Отключено'};
const jobs:Record<string,string>={QUEUED:'В очереди',RUNNING:'Загружается',RETRY:'Повторная попытка',SUCCEEDED:'Завершено',FAILED:'Ошибка',CANCELLED:'Отменено'};
const money=(c:number|null)=>c===null?'Цена требует уточнения':`${(c/100).toLocaleString('ru-RU',{minimumFractionDigits:2,maximumFractionDigits:2})} ₽`;
const stamp=(s:string|null)=>s?new Date(s).toLocaleString('ru-RU'):'—';
export default function IntegrationsPage(){
  const {base,organization,api}=useScope();
  const [connections,setConnections]=useState<Connection[]>([]),[selected,setSelected]=useState('');
  const [menus,setMenus]=useState<Menu[]>([]),[menuId,setMenuId]=useState('');
  const [catalog,setCatalog]=useState<Item[]>([]),[runs,setRuns]=useState<Job[]>([]),[chosen,setChosen]=useState<string[]>([]);
  const [alias,setAlias]=useState(''),[remote,setRemote]=useState(''),[appId,setAppId]=useState(''),[clientSecret,setClientSecret]=useState(''),[apiKey,setApiKey]=useState('');
  const [rotation,setRotation]=useState(false),[working,setWorking]=useState(false),[loading,setLoading]=useState(true);
  const [error,setError]=useState(''),[notice,setNotice]=useState('');
  const canManage=['owner','operations_director'].includes(organization?.role||'');
  const canImport=['owner','operations_director','manager'].includes(organization?.role||'');
  const current=connections.find(c=>c.id===selected);
  const root=base?`${base}/integrations`:null;
  const refresh=useCallback(async()=>{if(!root)return;
    const data=await api<{connections:Connection[]}>(root);setConnections(data.connections);
    setSelected(prev=>data.connections.some(c=>c.id===prev)?prev:(data.connections[0]?.id||''));
  },[root,api]);
  const details=useCallback(async()=>{if(!root||!selected)return;
    const prefix=`${root}/${selected}`;
    const [j,c]=await Promise.all([api<{jobs:Job[]}>(`${prefix}/jobs`),api<{items:Item[]}>(`${prefix}/catalog`)]);
    setRuns(j.jobs);setCatalog(c.items);
  },[root,selected,api]);
  useEffect(()=>{setSelected('');setConnections([]);setLoading(true);setError('');void refresh().catch(e=>setError(e.message)).finally(()=>setLoading(false));},[refresh]);
  useEffect(()=>{setMenus([]);setMenuId('');setChosen([]);setCatalog([]);setRuns([]);
    void details().catch(e=>setError(e.message));},[details]);
  useEffect(()=>{if(!root||!selected)return;const id=window.setInterval(()=>{
    void details().catch(()=>{}); // Status remains visible without disclosing or masking a provider failure.
  },12000);return()=>window.clearInterval(id);},[root,selected,details]);
  async function action(fn:()=>Promise<void>){setWorking(true);setError('');setNotice('');try{await fn();await refresh();await details();}
    catch(e){setError(e instanceof Error?e.message:'Ошибка запроса');}finally{setWorking(false);}}
  const clearSecrets=()=>{setAppId('');setClientSecret('');setApiKey('');};
  async function save(e:FormEvent){e.preventDefault();if(!root||!canManage)return;
    await action(async()=>{
      const target=rotation?`${root}/${selected}/rotate`:root;
      const payload=rotation?{appId,clientSecret,apiKey,expectedRevision:current!.revision}:
        {alias,remoteOrganizationId:remote,appId,clientSecret,apiKey};
      const res=await api<{connection:Connection}>(target,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify(payload)});
      setSelected(res.connection.id);clearSecrets();setRotation(false);setAlias('');setRemote('');
      setNotice('Ключи сохранены в зашифрованном виде. Теперь проверьте соединение.');
    });
  }
  async function verify(){if(!current||!root)return;await action(async()=>{
    await api(`${root}/${current.id}/verify`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({expectedRevision:current.revision})});
    setNotice('iiko подтвердила доступ к выбранной организации.');
  });}
  async function fetchMenus(){if(!current||!root)return;await action(async()=>{
    const data=await api<{menus:Menu[]}>(`${root}/${current.id}/menus`);setMenus(data.menus);setMenuId(data.menus[0]?.id||'');
    setNotice(data.menus.length?'Выберите внешнее меню для чтения.':'В iiko нет опубликованных внешних меню.');
  });}
  async function enqueue(){if(!current||!root||!menuId)return;await action(async()=>{
    await api(`${root}/${current.id}/sync`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({menuId})});
    setNotice('Задача поставлена в очередь. Каталог обновится после успешной синхронизации.');
  });}
  async function importItems(){if(!current||!root||!chosen.length)return;
    const sourceRunId=catalog.find(i=>chosen.includes(i.externalId))?.sourceRunId;
    if(!sourceRunId)return;
    await action(async()=>{
      const r=await api<{result:{created:number;updated:number}}>(`${root}/${current.id}/import`,
        {method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({sourceRunId,externalIds:chosen})});
      setChosen([]);setNotice(`Меню обновлено: новых блюд ${r.result.created}, обновлено ${r.result.updated}.`);
    });}
  async function disable(){if(!current||!root||!confirm(`Отключить интеграцию «${current.alias}»?`))return;
    await action(async()=>{await api(`${root}/${current.id}/disable`,{method:'POST',idempotencyKey:crypto.randomUUID(),
      body:JSON.stringify({expectedRevision:current.revision})});setNotice('Подключение отключено. Активные задачи отменены.');});}
  const newestSuccess=runs.find(j=>j.status==='SUCCEEDED');
  const available=catalog.filter(i=>i.priceCents!==null&&i.sourceRunId===newestSuccess?.id);
  const allSelected=available.length>0&&available.every(i=>chosen.includes(i.externalId));
  return <><PageHeading eyebrow="TECHNOLOGY / OFFICIAL POS API" title="Интеграции с POS"
    subtitle="Официальный iikoCloud API. Доступ проверяется у провайдера; никакие демонстрационные подключения не выдаются за рабочие."
    action={<button className="gold-outline-button" disabled={working||loading} onClick={()=>void action(refresh)}>Обновить</button>}/>
    {error&&<Alert text={error}/>} {notice&&<p className="notice" role="status">{notice}</p>}
    <div className="r8-grid">
      <Panel title="Подключённые рестораны" subtitle="Каждый коннектор принадлежит одному филиалу">
        {!connections.length?<Empty title="POS ещё не подключена" description="Добавьте учётные данные и подтвердите доступ через API iiko."/>:
          <div className="r8-list">{connections.map(c=><button type="button" className={`r8-connection ${c.id===selected?'r8-selected':''}`}
            onClick={()=>setSelected(c.id)} key={c.id} aria-pressed={c.id===selected}>
            <strong>{c.alias}</strong><small>{c.remoteOrganizationName||c.remoteOrganizationId}</small>
            <span className={`r8-status r8-${c.state.toLowerCase()}`}>{names[c.state]}</span>
          </button>)}</div>}
      </Panel>
      {canManage&&<Panel title={rotation?'Смена ключей подключения':'Новое подключение iiko'} subtitle="Ключи не будут возвращаться браузеру. В базе они зашифрованы AES-256-GCM.">
        <form className="form-grid" onSubmit={e=>void save(e)} autoComplete="off">
          {!rotation&&<><label>Название подключения<input value={alias} onChange={e=>setAlias(e.target.value)} required maxLength={100} placeholder="Основной ресторан"/></label>
            <label>UUID организации iiko<input value={remote} onChange={e=>setRemote(e.target.value)} required placeholder="Идентификатор из iikoWeb"/></label></>}
          <label>App ID<input value={appId} onChange={e=>setAppId(e.target.value)} required maxLength={180}/></label>
          <label>Client Secret<input type="password" value={clientSecret} onChange={e=>setClientSecret(e.target.value)} required maxLength={250} autoComplete="new-password"/></label>
          <label>API key<input type="password" value={apiKey} onChange={e=>setApiKey(e.target.value)} required maxLength={250} autoComplete="new-password"/></label>
          <div className="r8-inline"><button className="gold-button" disabled={working} type="submit">{working?'Сохраняем…':rotation?'Заменить ключи':'Сохранить подключение'}</button>
            {rotation&&<button type="button" className="text-button" onClick={()=>{setRotation(false);clearSecrets();}}>Отмена</button>}</div>
        </form><p className="info-footnote">Нужны App ID, Client Secret и API Key, выданные через официальный портал iiko. Не вставляйте ключи в переписку или GitHub.</p>
      </Panel>}
    </div>
    {current&&<Panel title={`Управление · ${current.alias}`} subtitle="Проверка реальных прав доступа и безопасная синхронизация только на чтение">
      <div className="r8-meta"><span>Состояние <b>{names[current.state]}</b></span>
        <span>Проверено <b>{stamp(current.verifiedAt)}</b></span>
        <span>Последняя синхронизация <b>{stamp(current.lastSyncAt)}</b></span>
        {current.lastErrorCode&&<span>Код ошибки <b>{current.lastErrorCode}</b></span>}</div>
      <div className="r8-inline">{canManage&&current.state!=='DISABLED'&&<button disabled={working} className="gold-outline-button" onClick={()=>void verify()}>Проверить доступ iiko</button>}
        {current.state==='VERIFIED'&&<button disabled={working} className="gold-outline-button" onClick={()=>void fetchMenus()}>Получить меню iiko</button>}
        {canManage&&current.state!=='DISABLED'&&<button disabled={working} className="text-button" onClick={()=>{setRotation(true);clearSecrets();}}>Сменить ключи</button>}
        {canManage&&current.state!=='DISABLED'&&<button disabled={working} className="text-button" onClick={()=>void disable()}>Отключить</button>}</div>
      {menus.length>0&&current.state==='VERIFIED'&&<div className="r8-inline r8-sync-form">
        <label>Внешнее меню<select value={menuId} onChange={e=>setMenuId(e.target.value)}>{menus.map(m=><option value={m.id} key={m.id}>{m.name}</option>)}</select></label>
        {canManage&&<button className="gold-button" disabled={!menuId||working} onClick={()=>void enqueue()}>Синхронизировать каталог</button>}
      </div>}
    </Panel>}
    {current&&<Panel title="Очередь и журнал синхронизации" subtitle="Задачи выполняются сервером; ошибки и повторы видны в журнале">
      {!runs.length?<Empty title="Операций пока нет" description="После проверки подключения выберите меню и запустите чтение каталога."/>:
      <div className="table-scroll"><table className="data-table"><thead><tr><th>Запрошено</th><th>Внешнее меню</th><th>Статус</th><th>Попытки</th><th>Блюд</th><th>Ошибка</th></tr></thead>
        <tbody>{runs.map(j=><tr key={j.id}><td>{stamp(j.createdAt)}</td><td>{j.menuId}</td><td>{jobs[j.status]||j.status}</td>
        <td>{j.attemptCount}</td><td>{j.itemsCount??'—'}</td><td>{j.lastErrorCode||'—'}</td></tr>)}</tbody></table></div>}
    </Panel>}
    {current&&<Panel title="Каталог на проверке" subtitle="Импорт только по явному выбору. Неоднозначные цены не допускаются в рабочее меню.">
      {!catalog.length?<Empty title="Нет загруженных позиций" description="Каталог появится после успешного чтения POS."/>:<>
        <div className="r8-inline"><label className="r8-check"><input type="checkbox" disabled={!canImport} checked={allSelected}
          onChange={e=>setChosen(e.target.checked?available.map(i=>i.externalId):[])}/> Выбрать все с подтверждённой ценой ({available.length})</label>
          {canImport&&<button className="gold-button" disabled={working||!chosen.length||!newestSuccess} onClick={()=>void importItems()}>Импортировать выбранные ({chosen.length})</button>}</div>
        <div className="table-scroll"><table className="data-table"><thead><tr><th>Выбор</th><th>Категория</th><th>Блюдо</th><th>Цена из POS</th><th>Состояние</th></tr></thead><tbody>
          {catalog.map(i=><tr key={i.externalId}><td><input aria-label={`Импортировать ${i.name}`} type="checkbox"
            disabled={!canImport||i.priceCents===null||i.sourceRunId!==newestSuccess?.id}
            checked={chosen.includes(i.externalId)} onChange={e=>setChosen(p=>e.target.checked?[...p,i.externalId]:p.filter(x=>x!==i.externalId))}/></td>
            <td>{i.category}</td><td>{i.name}</td><td>{money(i.priceCents)}</td><td>{i.importedMenuItemId?'Ранее импортировано':'Не импортировано'}</td></tr>)}</tbody></table></div>
      </>}
    </Panel>}
    <p className="info-footnote">R8 использует только чтение внешнего меню iiko. Автоматическое создание заказов в POS, платежи и двусторонние остатки не подключены. Доступность интеграции зависит от действующих ключей и прав iiko.</p>
  </>;
}
