import type {MetadataRoute} from 'next';
export default function manifest():MetadataRoute.Manifest{return {name:'OSMANX Restaurant Ecosystem',short_name:'OSMANX',description:'Управление ресторанным бизнесом',start_url:'/app',display:'standalone',background_color:'#07090D',theme_color:'#07090D',lang:'ru',icons:[{src:'/icon.svg',sizes:'any',type:'image/svg+xml'}]};}
