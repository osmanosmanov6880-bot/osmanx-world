'use client';
import {useState,type FormEvent} from 'react';
import {PageHeading,Panel,Alert} from '../../../components/ui';
import {useScope} from '../../../lib/session';
export default function Branches(){
  const {organization,branch,api,reload}=useScope();const [name,setName]=useState('');const [timezone,setTimezone]=useState('Europe/Moscow');const [error,setError]=useState('');const [busy,setBusy]=useState(false);
  const allowed=['owner','operations_director'].includes(organization?.role||'');
  async function add(e:FormEvent){e.preventDefault();if(!organization)return;setBusy(true);setError('');try{
    await api(`/api/v1/organizations/${organization.organizationId}/branches`,{method:'POST',body:JSON.stringify({name,timezone})});setName('');await reload();
  }catch(e){setError(e instanceof Error?e.message:'Ошибка');}finally{setBusy(false);}}
  return <><PageHeading eyebrow="SCALE / NETWORK" title="Моя сеть" subtitle="Организации, филиалы и доступные вам рестораны."/>{error&&<Alert text={error}/>}
    <div className="network-summary panel"><span className="eyebrow">ТЕКУЩАЯ ОРГАНИЗАЦИЯ</span><h2>{organization?.organizationName||'—'}</h2><p>Валюта: {organization?.currency} · Ваша роль: {organization?.role}</p></div>
    {allowed&&<Panel title="Открыть новый филиал"><form className="inline-form" onSubmit={add}><label>Название ресторана<input required maxLength={160} value={name} onChange={e=>setName(e.target.value)} placeholder="OSMANX Central"/></label><label>Часовой пояс<input required value={timezone} maxLength={60} onChange={e=>setTimezone(e.target.value)} placeholder="Europe/Moscow"/></label><button disabled={busy} className="gold-button">Добавить филиал</button></form></Panel>}
    <Panel title="Доступные рестораны" subtitle="Доступ к филиалам проверяется на сервере"><div className="branch-cards">{organization?.branches.map(b=><div key={b.id} className={`branch-card ${branch?.id===b.id?'branch-current':''}`}><span className="branch-symbol">∞</span><h3>{b.name}</h3><p>{b.timezone}</p><small>{b.id===branch?.id?'Текущий филиал':'Доступ разрешён'}</small></div>)}</div></Panel>
  </>;
}
