'use client';
import {useCallback,useEffect,useRef,useState,type FormEvent} from 'react';
import Link from 'next/link';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {FINANCE_CATEGORY_NAMES,money,parseMoney,rateText,type FinanceBudget,type FinanceReport,type FinanceExpense,
  type FinanceLedgerEntry,type FinanceCategory,type ExpenseCategory} from '../../../lib/types';

const expenseCategories:ExpenseCategory[]=['PAYROLL','RENT','UTILITIES','MARKETING','SERVICES','OTHER'];
const budgetCategories:FinanceCategory[]=['REVENUE','FOOD_COST',...expenseCategories];
const canCreate=(role:string)=>['owner','finance_director','operations_director','manager'].includes(role);
const canBudget=(role:string)=>['owner','finance_director','operations_director'].includes(role);
const canVoid=(role:string)=>canBudget(role);
const ledgerLabels:Record<FinanceLedgerEntry['source'],string>={ORDER:'Продажа',FOOD_COST:'Себестоимость',EXPENSE:'Расход',STOCK_LOSS:'Потеря склада'};
const today=()=>new Date().toISOString().slice(0,10);

export default function Finance(){
  const {base,organization,branch,api}=useScope();
  const [period,setPeriod]=useState(today().slice(0,7));
  const [report,setReport]=useState<FinanceReport|null>(null);
  const [expenses,setExpenses]=useState<FinanceExpense[]>([]);
  const [budgets,setBudgets]=useState<FinanceBudget[]>([]);
  const [entries,setEntries]=useState<FinanceLedgerEntry[]>([]);
  const [expenseCategory,setExpenseCategory]=useState<ExpenseCategory>('RENT');
  const [description,setDescription]=useState('');const [amount,setAmount]=useState('');
  const [expenseDate,setExpenseDate]=useState(today());
  const [drafts,setDrafts]=useState<Record<string,string>>({});
  const [voidTarget,setVoidTarget]=useState('');const [voidReason,setVoidReason]=useState('');
  const [busy,setBusy]=useState('');const [loading,setLoading]=useState(true);
  const [error,setError]=useState('');const [notice,setNotice]=useState('');
  // Retain a key across a failed network response. A retry cannot double-post an expense.
  const expenseKey=useRef('');const budgetKeys=useRef<Record<string,string>>({});const voidKeys=useRef<Record<string,string>>({});
  const currency=organization?.currency||'RUB';const role=organization?.role||'';
  const refresh=useCallback(async()=>{
    if(!base)return;
    const query=`?period=${encodeURIComponent(period)}`;
    const [a,b,c,d]=await Promise.all([
      api<{report:FinanceReport}>(`${base}/finance/report${query}`),
      api<{expenses:FinanceExpense[]}>(`${base}/finance/expenses${query}`),
      api<{budgets:FinanceBudget[]}>(`${base}/finance/budgets${query}`),
      api<{entries:FinanceLedgerEntry[]}>(`${base}/finance/ledger${query}`)
    ]);
    setReport(a.report);setExpenses(b.expenses);setBudgets(c.budgets);setEntries(d.entries);
    setDrafts(Object.fromEntries(c.budgets.map(x=>[x.category,(x.amountCents/100).toFixed(2)])));
  },[base,api,period]);
  useEffect(()=>{
    let mounted=true;setReport(null);setLoading(true);setError('');setNotice('');
    if(!base){setLoading(false);return;}
    // Do not overwrite another branch's data when the scope changes during a request.
    const query=`?period=${encodeURIComponent(period)}`;
    Promise.all([
      api<{report:FinanceReport}>(`${base}/finance/report${query}`),
      api<{expenses:FinanceExpense[]}>(`${base}/finance/expenses${query}`),
      api<{budgets:FinanceBudget[]}>(`${base}/finance/budgets${query}`),
      api<{entries:FinanceLedgerEntry[]}>(`${base}/finance/ledger${query}`)
    ]).then(([a,b,c,d])=>{if(!mounted)return;setReport(a.report);setExpenses(b.expenses);setBudgets(c.budgets);setEntries(d.entries);
      setDrafts(Object.fromEntries(c.budgets.map(x=>[x.category,(x.amountCents/100).toFixed(2)])));
    }).catch(e=>{if(mounted)setError(e.message);}).finally(()=>{if(mounted)setLoading(false);});
    return()=>{mounted=false;};
  },[base,api,period]);
  const execute=async(key:string,work:()=>Promise<unknown>,success:string)=>{
    setBusy(key);setError('');setNotice('');
    try{await work();await refresh();setNotice(success);return true;}
    catch(e){setError(e instanceof Error?e.message:'Ошибка сохранения');return false;}
    finally{setBusy('');}
  };
  const inputChanged=()=>{expenseKey.current='';};
  async function addExpense(e:FormEvent){e.preventDefault();if(!base)return;
    if(!expenseDate.startsWith(period)){setError('Дата расхода должна относиться к выбранному месяцу');return;}
    let cents:number;try{cents=parseMoney(amount);if(cents<=0)throw new Error('Сумма должна быть больше нуля');}
    catch(e){setError(e instanceof Error?e.message:'Неверная сумма');return;}
    const key=expenseKey.current||crypto.randomUUID();expenseKey.current=key;
    const ok=await execute('expense',()=>api(`${base}/finance/expenses`,{method:'POST',idempotencyKey:key,
      body:JSON.stringify({category:expenseCategory,description,amountCents:cents,occurredOn:expenseDate})}),
      'Расход проведён. Он включён в фактические данные выбранного месяца.');
    if(ok){setDescription('');setAmount('');expenseKey.current='';}
  }
  async function saveBudget(category:FinanceCategory){if(!base)return;
    let cents:number;try{cents=parseMoney(drafts[category]||'0');}catch(e){setError(e instanceof Error?e.message:'Неверная сумма');return;}
    const existing=budgets.find(b=>b.category===category);
    const key=budgetKeys.current[category]||crypto.randomUUID();budgetKeys.current[category]=key;
    const ok=await execute(`budget:${category}`,
      ()=>api(`${base}/finance/budgets/${category}`,{method:'PUT',idempotencyKey:key,
        body:JSON.stringify({period,amountCents:cents,expectedRevision:existing?.revision||0})}),
      `План «${FINANCE_CATEGORY_NAMES[category]}» сохранён`);
    if(ok)delete budgetKeys.current[category];
  }
  async function voidExpense(expense:FinanceExpense){if(!base)return;
    if(voidReason.trim().length<3){setError('Укажите причину аннулирования (минимум 3 символа)');return;}
    const key=voidKeys.current[expense.id]||crypto.randomUUID();voidKeys.current[expense.id]=key;
    const ok=await execute(`void:${expense.id}`,
      ()=>api(`${base}/finance/expenses/${expense.id}/void`,{method:'POST',idempotencyKey:key,
        body:JSON.stringify({expectedRevision:expense.revision,reason:voidReason})}),
      'Расход аннулирован. Исходная запись и причина сохранены в истории.');
    if(ok){setVoidTarget('');setVoidReason('');delete voidKeys.current[expense.id];}
  }
  function changePeriod(v:string){setPeriod(v);setExpenseDate(v===today().slice(0,7)?today():`${v}-01`);budgetKeys.current={};}
  const margin=report?.operatingResultCents;
  return <>
    <PageHeading eyebrow="MANAGEMENT / FINANCIAL CONTROL / R4" title="Финансы и прибыль" subtitle={`Филиал: ${branch?.name||'—'}. Проверяемый результат по учтённым операциям; это не налоговая отчётность.`}
      action={<label className="r4-period">Отчётный месяц <input aria-label="Отчётный месяц" type="month" min="2020-01" max="2100-12" value={period} onChange={e=>changePeriod(e.target.value)}/></label>}/>
    {error&&<Alert text={error}/>} {notice&&<div role="status" className="notice">{notice}</div>}
    {loading?<div className="panel loading-panel">Загружаем финансовые операции…</div>:report&&<>
      {report.uncostedOrders>0&&<div className="r3-warning" role="status"><strong>Неполная себестоимость.</strong> В {report.uncostedOrders} завершённых заказах данных недостаточно; валовая прибыль, операционный результат и маржа не рассчитываются. <Link href="/app/recipes">Проверить рецептуры</Link></div>}
      <div className="r4-metrics">
        <div className="metric"><span className="metric-label">Выручка за месяц</span><strong>{money(report.revenueCents,currency)}</strong><span>{report.completedOrders} завершённых заказов</span></div>
        <div className="metric"><span className="metric-label">Food Cost</span><strong>{report.foodCostCents===null?'Не определён':money(report.foodCostCents,currency)}</strong><span>{rateText(report.foodCostRateBps)} от выручки · известных затрат {money(report.knownFoodCostCents,currency)}</span></div>
        <div className="metric"><span className="metric-label">Labor Cost</span><strong>{money(report.laborCostCents,currency)}</strong><span>{rateText(report.laborCostRateBps)} · по введённым выплатам</span></div>
        <div className="metric"><span className="metric-label">Операционный результат</span><strong className={margin!==null&&margin!==undefined&&margin<0?'r3-negative':''}>{margin===null||margin===undefined?'Не определён':money(margin,currency)}</strong><span>По зарегистрированным расходам, до налогов</span></div>
      </div>
      <Panel title="Расчётный P&L" subtitle="Суммы берутся из завершённых заказов, списаний и проведённых расходов">
        <div className="r4-waterfall" role="table" aria-label="Расчёт результата">
          {[
            ['Выручка',report.revenueCents,false],['Себестоимость блюд',report.foodCostCents,true],
            ['Валовая прибыль',report.grossProfitCents,false],['Списания по недостачам',report.stockLossCents,true],
            ['Операционные расходы',report.expensesCents,true],['Расчётный операционный результат',report.operatingResultCents,false]
          ].map(([label,value,cost],i)=><div role="row" className={`r4-pnl-row ${i===5?'r4-total':''}`} key={String(label)}>
            <span role="cell">{label}</span><strong role="cell">{value===null?'Недостаточно данных':`${cost?'− ':''}${money(value as number,currency)}`}</strong>
          </div>)}
        </div>
        <p className="info-footnote">Приобретение товара увеличивает остатки, но не списывается вторично в расходах. Положительные складские излишки не считаются доходом. Полнота внесённых расходов не подтверждена; налоги, амортизация и платёжные комиссии могут отсутствовать.</p>
      </Panel>
      <Panel title="План / факт" subtitle="План задаётся вручную и не подменяется историческими значениями">
        <div className="table-scroll"><table className="data-table r4-plan-table"><thead><tr><th>Показатель</th><th>План</th><th>Факт</th><th>Отклонение, факт − план</th><th>Управление</th></tr></thead><tbody>
          {budgetCategories.map(category=>{const r=report.planFact.find(x=>x.category===category);const b=budgets.find(x=>x.category===category);return <tr key={category}>
            <td><strong>{FINANCE_CATEGORY_NAMES[category]}</strong></td><td>{canBudget(role)?<input aria-label={`План: ${FINANCE_CATEGORY_NAMES[category]}`} inputMode="decimal" placeholder="0.00" value={drafts[category]??''} onChange={e=>{setDrafts(p=>({...p,[category]:e.target.value}));delete budgetKeys.current[category];}}/>:r?.plannedCents===null?'Не задан':money(r?.plannedCents??0,currency)}</td>
            <td>{r?.actualCents===null?'Не определён':money(r?.actualCents??0,currency)}</td><td>{r?.varianceCents===null?'—':money(r?.varianceCents??0,currency)}</td>
            <td>{canBudget(role)?<button type="button" className="gold-outline-button" disabled={!!busy} onClick={()=>void saveBudget(category)}>{b?'Изменить':'Задать план'}</button>:<span className="small-muted">Чтение</span>}</td>
          </tr>;})}
        </tbody></table></div>
      </Panel>
      {canCreate(role)&&<Panel title="Провести операционный расход" subtitle="Укажите реально понесённый расход и дату его отнесения; документы закупки ингредиентов сюда повторно не заносятся">
        <form className="r4-expense-form" onSubmit={addExpense}>
          <label>Категория<select value={expenseCategory} onChange={e=>{setExpenseCategory(e.target.value as ExpenseCategory);inputChanged();}}>{expenseCategories.map(c=><option key={c} value={c}>{FINANCE_CATEGORY_NAMES[c]}</option>)}</select></label>
          <label>Дата<input aria-label="Дата расхода" required type="date" min={`${period}-01`} max={`${period}-${new Date(Number(period.slice(0,4)),Number(period.slice(5,7)),0).getDate()}`} value={expenseDate} onChange={e=>{setExpenseDate(e.target.value);inputChanged();}}/></label>
          <label>Сумма ({currency})<input aria-label="Сумма расхода" required placeholder="15000.00" inputMode="decimal" value={amount} onChange={e=>{setAmount(e.target.value);inputChanged();}}/></label>
          <label className="r4-description">Описание<input aria-label="Описание расхода" maxLength={500} required value={description} onChange={e=>{setDescription(e.target.value);inputChanged();}} placeholder="Например, аренда помещения за ноябрь"/></label>
          <button className="gold-button" disabled={!!busy}>Провести расход</button>
        </form>
      </Panel>}
      <Panel title="Зарегистрированные расходы" subtitle="Все записи сохраняются в истории, включая аннулированные">
        {!expenses.length?<Empty title="Расходов за период нет" description="Выберите другой месяц либо зарегистрируйте первый расход."/>:<div className="table-scroll"><table className="data-table"><thead><tr><th>Дата</th><th>Категория и описание</th><th>Сумма</th><th>Статус</th><th>Действие</th></tr></thead><tbody>
          {expenses.map(e=><tr key={e.id}><td>{e.occurredOn}</td><td><strong>{FINANCE_CATEGORY_NAMES[e.category]}</strong><div className="small-muted">{e.description}</div>{e.voidReason&&<div className="r3-negative small-muted">Аннулирование: {e.voidReason}</div>}</td>
            <td>{money(e.amountCents,currency)}</td><td><span className={`r4-state ${e.status==='POSTED'?'r4-state-on':''}`}>{e.status==='POSTED'?'Учтён':'Аннулирован'}</span></td>
            <td>{canVoid(role)&&e.status==='POSTED'&&<>{voidTarget!==e.id?<button className="text-button" onClick={()=>{setVoidTarget(e.id);setVoidReason('');}} type="button">Аннулировать</button>:
              <div className="r4-void"><input aria-label="Причина аннулирования" autoFocus placeholder="Причина исправления" maxLength={500} value={voidReason} onChange={event=>{setVoidReason(event.target.value);delete voidKeys.current[e.id];}}/>
                <button type="button" className="gold-outline-button" disabled={!!busy} onClick={()=>void voidExpense(e)}>Подтвердить</button><button type="button" className="text-button" onClick={()=>setVoidTarget('')}>Отмена</button></div>}</>}</td>
          </tr>)}
        </tbody></table></div>}
      </Panel>
      <Panel title="Проверка исходных операций" subtitle="Проверка источников · до 400 заказов, 400 недостач и расходы за период">
        {!entries.length?<Empty title="Операций нет" description="Журнал сформируется по реальным продажам и расходам."/>:<div className="table-scroll"><table className="data-table"><thead><tr><th>Дата и время</th><th>Источник</th><th>Описание</th><th>Влияние на результат</th><th>Документ</th></tr></thead><tbody>{entries.map(e=><tr key={e.id}>
          <td>{new Date(e.occurredAt).toLocaleString('ru-RU')}</td><td>{ledgerLabels[e.source]}</td><td>{e.description}{!e.complete&&<div className="r3-negative small-muted">Неполный расчёт / аннулировано</div>}</td>
          <td className={e.signedAmountCents<0?'r3-negative':'gold-text'}>{e.signedAmountCents>0?'+ ':''}{money(e.signedAmountCents,currency)}</td>
          <td>{e.source==='ORDER'||e.source==='FOOD_COST'?<Link className="subtle-link" href={`/app/orders#order-${e.sourceId}`}>Заказ #{e.sourceId.slice(0,8)}</Link>:
            <span className="mono small-muted">#{e.sourceId.slice(0,8)}</span>}</td></tr>)}</tbody></table></div>}
      </Panel>
    </>}
    <div className="info-footnote">R4 не подключён к бухгалтерии и POS. Если смены, продажи или затраты ведутся вне платформы, отчёт отражает только введённые сюда данные. <Link href="/app/network">Сравнить филиалы сети</Link>.</div>
  </>;
}
