'use client';
import {useCallback,useEffect,useState,type FormEvent} from 'react';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import type {Standard} from '../../../lib/network';

type InputCriterion={title:string;weight:number;critical:boolean};
const blank=():InputCriterion=>({title:'',weight:1,critical:false});
export default function StandardsPage(){
  const {organization,api}=useScope();const orgId=organization?.organizationId;
  const [standards,setStandards]=useState<Standard[]>([]);const [editing,setEditing]=useState<Standard|null>(null);
  const [title,setTitle]=useState('');const [description,setDescription]=useState('');const [active,setActive]=useState(true);
  const [criteria,setCriteria]=useState<InputCriterion[]>([blank()]);const [loading,setLoading]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const canWrite=['owner','operations_director'].includes(organization?.role||'');
  const refresh=useCallback(async()=>{if(!orgId)return;const r=await api<{standards:Standard[]}>(`/api/v1/organizations/${orgId}/standards`);setStandards(r.standards);},[orgId,api]);
  useEffect(()=>{setError('');void refresh().catch(e=>setError(e.message));},[refresh]);
  const reset=()=>{setEditing(null);setTitle('');setDescription('');setCriteria([blank()]);setActive(true);};
  const begin=(s:Standard)=>{setEditing(s);setTitle(s.title);setDescription(s.description);setCriteria(s.criteria.map(x=>({title:x.title,weight:x.weight,critical:x.critical})));setActive(s.active);setNotice('');};
  const change=(index:number,patch:Partial<InputCriterion>)=>setCriteria(prev=>prev.map((c,i)=>i===index?{...c,...patch}:c));
  async function save(e:FormEvent){e.preventDefault();if(!orgId||!canWrite)return;
    setLoading(true);setError('');setNotice('');try{
      const body=JSON.stringify({title,description,criteria,...(editing?{expectedRevision:editing.revision,active}:{})});
      await api(`/api/v1/organizations/${orgId}/standards${editing?`/${editing.id}`:''}`,{method:editing?'PATCH':'POST',
        idempotencyKey:crypto.randomUUID(),body});
      reset();await refresh();setNotice('Стандарт сохранён. Проверки старых редакций останутся в истории.');
    }catch(e){setError(e instanceof Error?e.message:'Не удалось сохранить стандарт');}finally{setLoading(false);}
  }
  return <><PageHeading eyebrow="SCALE / NETWORK STANDARDS" title="Стандарты ресторанной сети"
    subtitle="Единые критерии и разные редакции. Изменение стандарта не переписывает историю проверок."/>
    {error&&<Alert text={error}/>} {notice&&<p className="notice" role="status">{notice}</p>}
    <Panel title="Каталог стандартов" subtitle="Сеть использует только созданные вами нормы качества">
      {standards.length===0?<Empty title="Стандартов ещё нет" description="Начните с нескольких измеримых требований, по которым реально проверить ресторан."/>:
      <div className="r7-standard-grid">{standards.map(s=><article className="r7-standard-card" key={s.id}>
        <div className="r7-row"><h3>{s.title}</h3><span className={`r7-state ${s.active?'r7-state-active':''}`}>{s.active?'Действует':'Отключён'}</span></div>
        <p>{s.description||'Описание отсутствует'}</p><div className="small-muted">Редакция {s.revision} · {s.criteria.length} пунктов</div>
        <ul>{s.criteria.map(c=><li key={c.id}>{c.title} · вес {c.weight}{c.critical?' · критический':''}</li>)}</ul>
        {canWrite&&<button className="gold-outline-button" type="button" onClick={()=>begin(s)}>Редактировать стандарт</button>}
      </article>)}</div>}
    </Panel>
    {canWrite&&<Panel title={editing?`Изменить стандарт · редакция ${editing.revision}`:'Новый стандарт'}
      subtitle={editing?'Будет создана новая редакция. Старые аудиты сохранят исходные критерии и оценки.':'Каждый пункт должен быть измеримым; вес 1–10 задаёт его влияние на оценку.'}>
      <form className="form-grid" onSubmit={e=>void save(e)}>
        <label>Название стандарта<input required minLength={1} maxLength={160} value={title} onChange={e=>setTitle(e.target.value)} placeholder="Например, качество обслуживания"/></label>
        <label>Описание<input maxLength={500} value={description} onChange={e=>setDescription(e.target.value)} placeholder="Какую область мы контролируем"/></label>
        <h3>Критерии проверки</h3>
        {criteria.map((c,i)=><div className="r7-criterion-editor" key={i}>
          <label>Требование {i+1}<input required maxLength={160} value={c.title} onChange={e=>change(i,{title:e.target.value})} placeholder="Например, температура хранения"/></label>
          <label>Вес (1–10)<input type="number" min={1} max={10} value={c.weight} onChange={e=>change(i,{weight:Number(e.target.value)})}/></label>
          <label className="r7-inline-check"><input type="checkbox" checked={c.critical} onChange={e=>change(i,{critical:e.target.checked})}/> Критический пункт</label>
          <button type="button" className="text-button" disabled={criteria.length===1} onClick={()=>setCriteria(prev=>prev.filter((_,index)=>index!==i))}>Удалить пункт</button>
        </div>)}
        <div className="r7-row"><button className="gold-outline-button" type="button" disabled={criteria.length>=20} onClick={()=>setCriteria(prev=>[...prev,blank()])}>Добавить критерий</button>
        {editing&&<label className="r7-inline-check"><input type="checkbox" checked={active} onChange={e=>setActive(e.target.checked)}/> Стандарт действует</label>}</div>
        <div className="r7-row"><button disabled={loading} className="gold-button" type="submit">{loading?'Сохраняем…':editing?'Сохранить новую редакцию':'Создать стандарт'}</button>
          {editing&&<button type="button" className="text-button" onClick={reset}>Отмена редактирования</button>}</div>
      </form>
    </Panel>}
    <p className="info-footnote">Право редактирования стандарта принадлежит владельцу сети и операционному директору. Аудитор имеет доступ только на чтение.</p>
  </>;
}
