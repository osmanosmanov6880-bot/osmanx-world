'use client';
import {Suspense,useState,type FormEvent} from 'react';
import {useSearchParams,useRouter} from 'next/navigation';
import {InfinityLogo,Alert} from '../../components/ui';
function InviteForm(){
  const token=useSearchParams().get('token')||'';const router=useRouter();const [email,setEmail]=useState('');const [displayName,setName]=useState('');const [password,setPassword]=useState('');const [error,setError]=useState('');const [busy,setBusy]=useState(false);
  async function submit(e:FormEvent){e.preventDefault();setError('');setBusy(true);try{
    const res=await fetch('/api/v1/auth/accept-invite',{method:'POST',headers:{'content-type':'application/json'},credentials:'same-origin',body:JSON.stringify({token,email,displayName,password})});
    const data=await res.json();if(!res.ok)throw new Error(data.error?.message||'Не удалось принять приглашение');
    router.replace('/app');router.refresh();
  }catch(e){setError(e instanceof Error?e.message:'Ошибка');}finally{setBusy(false);}}
  return <div className="auth-page centered"><div className="auth-card"><div className="auth-brand"><InfinityLogo/><span>OSMANX.WORLD</span></div><div className="eyebrow">ПРИГЛАШЕНИЕ</div><h1>Присоединиться к команде</h1><p className="auth-subtitle">Укажите email, на который было выдано приглашение, и создайте пароль.</p>
    {!token?<Alert text="В ссылке отсутствует токен приглашения"/>:<form onSubmit={submit} className="stack-form"><label>Имя<input required maxLength={120} value={displayName} onChange={e=>setName(e.target.value)}/></label><label>Email<input required type="email" value={email} onChange={e=>setEmail(e.target.value)}/></label><label>Пароль (от 12 символов)<input required type="password" minLength={12} maxLength={128} value={password} onChange={e=>setPassword(e.target.value)}/></label>{error&&<Alert text={error}/>}<button className="gold-button" disabled={busy}>{busy?'Сохранение…':'Принять приглашение'}</button></form>}</div></div>;
}
export default function Invite(){return <Suspense fallback={<div className="boot-screen">Загрузка…</div>}><InviteForm/></Suspense>;}
