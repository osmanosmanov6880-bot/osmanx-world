'use client';
import {useCallback,useEffect,useState,type FormEvent} from 'react';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {dateTime,type Employee,type Shift} from '../../../lib/types';

const managers=['owner','operations_director','manager'];
const canWork=['owner','finance_director','operations_director','manager','chef','kitchen','waiter','cashier','marketer','analyst'];
export default function Shifts(){
  const {base,organization,session,api}=useScope();
  const [workers,setWorkers]=useState<Employee[]>([]),[shifts,setShifts]=useState<Shift[]>([]),[workerId,setWorkerId]=useState('');
  const [openingNote,setOpeningNote]=useState(''),[notes,setNotes]=useState<Record<string,string>>({});
  const [busy,setBusy]=useState(''),[error,setError]=useState(''),[notice,setNotice]=useState(''),[loading,setLoading]=useState(true);
  const isManager=managers.includes(organization?.role||''), canOpen=canWork.includes(organization?.role||'');
  const refresh=useCallback(async()=>{if(!base)return;
    const [a,b]=await Promise.all([api<{staff:Employee[]}>(`${base}/staff`),api<{shifts:Shift[]}>(`${base}/shifts`)]);
    setWorkers(a.staff);setShifts(b.shifts);
  },[base,api]);
  useEffect(()=>{setLoading(true);setError('');void refresh().catch(e=>setError(e.message)).finally(()=>setLoading(false));},[refresh]);
  const open=async(e:FormEvent)=>{e.preventDefault();if(!base||!session)return;
    setBusy('new');setError('');setNotice('');
    try{await api(`${base}/shifts`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({userId:isManager?workerId||session.user.id:session.user.id,openingNote})});
      setOpeningNote('');setNotice('Смена открыта');await refresh();
    }catch(e){setError(e instanceof Error?e.message:'Не удалось открыть смену');}finally{setBusy('');}
  };
  const close=async(s:Shift)=>{if(!base)return;setBusy(s.id);setError('');setNotice('');
    try{await api(`${base}/shifts/${s.id}/close`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({expectedRevision:s.revision,closingNote:notes[s.id]||''})});
      setNotice('Смена закрыта');await refresh();
    }catch(e){setError(e instanceof Error?e.message:'Не удалось закрыть смену');await refresh().catch(()=>{});}finally{setBusy('');}
  };
  return <><PageHeading eyebrow="MANAGEMENT / TEAM OPERATIONS" title="Рабочие смены" subtitle="Открытие и закрытие смен, исполнители, время и комментарии передачи."/>
    {error&&<Alert text={error}/>}{notice&&<div role="status" className="notice">{notice}</div>}
    {canOpen&&<Panel title="Открыть смену" subtitle="У одного сотрудника может быть только одна открытая смена в организации.">
      <form className="shift-form" onSubmit={open}>
        {isManager&&<label>Сотрудник<select value={workerId} onChange={e=>setWorkerId(e.target.value)}><option value="">Я сам(а)</option>{workers.filter(w=>w.id!==session?.user.id).map(w=><option value={w.id} key={w.id}>{w.displayName} · {w.role}</option>)}</select></label>}
        <label>Примечание открытия<input maxLength={500} value={openingNote} placeholder="Например, проверен зал" onChange={e=>setOpeningNote(e.target.value)}/></label>
        <button className="gold-button" disabled={busy!==''}>{busy==='new'?'Открываем…':'Начать смену'}</button>
      </form>
    </Panel>}
    <Panel title="Учёт смен" subtitle={isManager?'Все доступные сотрудники филиала':'Только ваши смены'} action={<button className="text-button" type="button" onClick={()=>void refresh().catch(e=>setError(e.message))}>Обновить</button>}>
      {loading?<div className="loading-panel">Загрузка…</div>:!shifts.length?<Empty title="Смены пока не открывались" description="Откройте первую рабочую смену, чтобы запустить учёт времени."/>:<div className="shift-list">
        {shifts.map(s=><article className="shift-card" key={s.id}><div className="shift-main"><span className="eyebrow">{s.status==='OPEN'?'АКТИВНАЯ СМЕНА':'ЗАКРЫТАЯ СМЕНА'}</span><h3>{s.employeeName}</h3>
          <p className="small-muted">Открыта {dateTime(s.openedAt)}{s.closedAt?` · закрыта ${dateTime(s.closedAt)}`:''}</p>
          {s.openingNote&&<p className="small-muted">Открытие: {s.openingNote}</p>}{s.closingNote&&<p className="small-muted">Завершение: {s.closingNote}</p>}
        </div>{s.status==='OPEN'&&canOpen&&(isManager||s.userId===session?.user.id)&&<div className="shift-close">
          <label>Итог смены<input maxLength={500} value={notes[s.id]||''} placeholder="Передача дежурства" onChange={e=>setNotes(prev=>({...prev,[s.id]:e.target.value}))}/></label>
          <button className="gold-outline-button" disabled={busy!==''} onClick={()=>void close(s)}>{busy===s.id?'Закрываем…':'Закрыть смену'}</button>
        </div>}
        </article>)}
      </div>}
    </Panel>
  </>;
}
