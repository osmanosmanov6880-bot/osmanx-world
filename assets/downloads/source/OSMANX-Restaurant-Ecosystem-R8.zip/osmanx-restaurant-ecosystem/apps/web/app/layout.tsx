import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'OSMANX Restaurant Ecosystem',description:'Премиальная операционная система для ресторанного бизнеса',applicationName:'OSMANX RESTAURANT ECOSYSTEM'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ru"><body>{children}</body></html>;}
