'use client';
import {useCallback,useEffect,useState,type FormEvent} from 'react';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import Link from 'next/link';
import type {FloorTable} from '../../../lib/types';
export default function Tables(){
  const {base,organization,api}=useScope();const [tables,setTables]=useState<FloorTable[]>([]);const [error,setError]=useState('');const [loading,setLoading]=useState(true);const [label,setLabel]=useState('');const [capacity,setCapacity]=useState('2');const [busy,setBusy]=useState(false);
  const read=useCallback(async()=>{if(base){const r=await api<{tables:FloorTable[]}>(`${base}/floor`);setTables(r.tables);}},[base,api]);
  useEffect(()=>{setLoading(true);void read().catch(e=>setError(e.message)).finally(()=>setLoading(false));},[read]);
  const editable=['owner','operations_director','manager'].includes(organization?.role||'');
  async function add(e:FormEvent){e.preventDefault();if(!base)return;setBusy(true);setError('');try{await api(`${base}/tables`,{method:'POST',body:JSON.stringify({label,capacity:Number(capacity)})});setLabel('');await read();}catch(e){setError(e instanceof Error?e.message:'Ошибка');}finally{setBusy(false);}}
  return <><PageHeading eyebrow="TECHNOLOGY / FLOOR" title="Зал и столы" subtitle="Настройка посадочных мест, доступных для создания заказов."/>{error&&<Alert text={error}/>}
    {editable&&<Panel title="Новый стол"><form onSubmit={add} className="inline-form"><label>Номер или название<input required value={label} maxLength={30} onChange={e=>setLabel(e.target.value)} placeholder="Стол 01"/></label><label>Количество мест<input required type="number" min={1} max={40} value={capacity} onChange={e=>setCapacity(e.target.value)}/></label><button className="gold-button" disabled={busy}>Добавить стол</button></form></Panel>}
    <Panel title="План зала" subtitle="Текущая посадка и ближайшие бронирования" action={<button className="text-button" type="button" onClick={()=>void read().catch(e=>setError(e.message))}>Обновить</button>}>{loading?<div className="loading-panel">Загрузка…</div>:!tables.length?<Empty title="План зала пуст" description="Добавьте столы, чтобы принимать заказы в зале."/>:<div className="tables-grid">{tables.map(t=><div className={`table-tile floor-${t.state.toLowerCase()}`} key={t.id}>
      <div className="table-symbol"><span>{t.label}</span></div>
      <strong>{t.label}</strong><small>{t.capacity} мест</small>
      <span className={`floor-state floor-state-${t.state.toLowerCase()}`}>
        {t.state==='OCCUPIED'?'Занят':t.state==='RESERVED'?'Скоро бронь':'Свободен'}
      </span>
      {t.nextReservationAt&&<small>Бронь: {new Date(t.nextReservationAt).toLocaleString('ru-RU',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}</small>}
      {t.state==='OCCUPIED'&&<Link className="subtle-link" href="/app/orders">К заказу</Link>}
    </div>)}</div>}</Panel>
    <div className="info-footnote">Статус «Свободен» не гарантирует доступность стола на весь день: проверьте время следующей брони. Перемещение и объединение столов запланированы отдельно.</div>
  </>;
}
