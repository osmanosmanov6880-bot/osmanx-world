'use client';
import {useEffect,useState} from 'react';
import Link from 'next/link';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {money,rateText,type FinanceNetwork} from '../../../lib/types';

export default function NetworkFinance(){
  const {organization,pickBranch,api}=useScope();
  const [period,setPeriod]=useState(new Date().toISOString().slice(0,7));
  const [data,setData]=useState<FinanceNetwork|null>(null);const [error,setError]=useState('');
  const [loading,setLoading]=useState(true);
  const orgId=organization?.organizationId;
  useEffect(()=>{
    if(!orgId)return;
    let mounted=true;setLoading(true);setData(null);setError('');
    api<{overview:FinanceNetwork}>(`/api/v1/organizations/${orgId}/finance/overview?period=${encodeURIComponent(period)}`)
      .then(r=>{if(mounted)setData(r.overview);}).catch(e=>{if(mounted)setError(e.message);})
      .finally(()=>{if(mounted)setLoading(false);});
    return()=>{mounted=false;};
  },[orgId,period,api]);
  const totals=data?.totals;
  return <>
    <PageHeading eyebrow="SCALE / FINANCIAL NETWORK" title="Финансы ресторанной сети" subtitle="Сравнение только тех филиалов, к которым вам разрешён доступ. Неполная себестоимость не скрывается при суммировании."
      action={<label className="r4-period">Отчётный месяц <input aria-label="Отчётный месяц сети" type="month" min="2020-01" max="2100-12" value={period} onChange={e=>setPeriod(e.target.value)}/></label>}/>
    {error&&<Alert text={error}/>}{loading?<div className="panel loading-panel">Загружаем доступные филиалы…</div>:data&&<>
      <div className="r4-metrics">
        <div className="metric"><span className="metric-label">Выручка сети</span><strong>{money(totals?.revenueCents??0,data.currency)}</strong><span>По завершённым заказам</span></div>
        <div className="metric"><span className="metric-label">Известная себестоимость</span><strong>{money(totals?.knownFoodCostCents??0,data.currency)}</strong><span>{totals?.uncostedOrders||0} заказов с неполной оценкой</span></div>
        <div className="metric"><span className="metric-label">Учтённые расходы</span><strong>{money(totals?.expensesCents??0,data.currency)}</strong><span>Без двойного учёта закупок</span></div>
        <div className="metric"><span className="metric-label">Операционный результат сети</span><strong>{totals?.operatingResultCents===null?'Не определён':money(totals?.operatingResultCents??0,data.currency)}</strong><span>По зарегистрированным затратам</span></div>
      </div>
      {totals&&totals.uncostedOrders>0&&<div className="r3-warning" role="status">{totals.uncostedOrders} заказов без полной себестоимости в доступных филиалах. До уточнения этих данных итоговая прибыль сети не рассчитывается.</div>}
      <Panel title="Сравнение филиалов" subtitle={`${data.branches.length} доступных ресторанов · период ${period}`}>
        {!data.branches.length?<Empty title="Нет доступных филиалов"/>:<div className="table-scroll"><table className="data-table"><thead><tr><th>Филиал</th><th>Выручка</th><th>Food Cost</th><th>Labor Cost</th><th>Результат</th><th>Данные</th></tr></thead>
          <tbody>{data.branches.map(b=><tr key={b.id}><td><strong>{b.name}</strong><div><Link href="/app/finance" onClick={()=>pickBranch(b.id)} className="subtle-link">Открыть финансовый отчёт</Link></div></td>
            <td>{money(b.report.revenueCents,data.currency)}</td><td>{rateText(b.report.foodCostRateBps)}</td><td>{rateText(b.report.laborCostRateBps)}</td>
            <td>{b.report.operatingResultCents===null?'Не определён':money(b.report.operatingResultCents,data.currency)}</td>
            <td>{b.report.uncostedOrders>0?<span className="r3-negative">{b.report.uncostedOrders} без оценки</span>:<span className="small-muted">Food Cost учтён</span>}</td>
          </tr>)}</tbody></table></div>}
      </Panel>
    </>}
    <div className="info-footnote">Расчёты каждого филиала ведутся в его локальном календарном месяце и консолидируются в валюте организации. Пересчёт валют и трансферные операции между филиалами не реализованы; отчёт не является подтверждённой финансовой отчётностью.</div>
  </>;
}
