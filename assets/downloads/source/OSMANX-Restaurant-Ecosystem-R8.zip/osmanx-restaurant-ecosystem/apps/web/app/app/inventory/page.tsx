'use client';
import {useCallback,useEffect,useState,type FormEvent} from 'react';
import Link from 'next/link';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {formatQty,parseQty,parseMoney,money,dateTime,UNIT_LABELS,type Ingredient,type StockMovement,type StockUnit} from '../../../lib/types';

export default function Inventory(){
  const {base,organization,api}=useScope();
  const [items,setItems]=useState<Ingredient[]>([]),[movements,setMovements]=useState<StockMovement[]>([]);
  const [name,setName]=useState(''),[unit,setUnit]=useState<StockUnit>('g'),[minimum,setMinimum]=useState('0');
  const [countId,setCountId]=useState(''),[counted,setCounted]=useState(''),[foundValue,setFoundValue]=useState('');
  const [minimumId,setMinimumId]=useState(''),[newMinimum,setNewMinimum]=useState('');
  const [busy,setBusy]=useState(false),[loading,setLoading]=useState(true),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const writable=['owner','operations_director','manager','chef'].includes(organization?.role||'');
  const read=useCallback(async()=>{if(!base)return;const [a,m]=await Promise.all([api<{ingredients:Ingredient[]}>(`${base}/ingredients`),api<{movements:StockMovement[]}>(`${base}/stock-movements`)]);
    setItems(a.ingredients);setMovements(m.movements);},[base,api]);
  useEffect(()=>{setLoading(true);setError('');void read().catch(e=>setError(e.message)).finally(()=>setLoading(false));},[read]);
  async function perform(action:()=>Promise<unknown>,success:string){setBusy(true);setError('');setNotice('');
    try{await action();setNotice(success);await read();setCountId('');setMinimumId('');}catch(e){setError(e instanceof Error?e.message:'Ошибка склада');}finally{setBusy(false);}}
  async function create(e:FormEvent){e.preventDefault();if(!base)return;
    await perform(async()=>{await api(`${base}/ingredients`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({name,unit,minQuantityMilli:parseQty(minimum,true)})});
      setName('');setMinimum('0');},'Ингредиент добавлен');}
  async function stocktake(item:Ingredient){if(!base)return;
    await perform(()=>api(`${base}/ingredients/${item.id}/count`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({countedQuantityMilli:parseQty(counted,true),expectedRevision:item.revision,
      foundValueCents:foundValue.trim()?parseMoney(foundValue):null})}), 'Инвентаризация сохранена с записью движения');}
  async function changeMinimum(item:Ingredient){if(!base)return;await perform(()=>api(`${base}/ingredients/${item.id}/minimum`,{method:'POST',idempotencyKey:crypto.randomUUID(),
    body:JSON.stringify({minQuantityMilli:parseQty(newMinimum,true),expectedRevision:item.revision})}),'Минимальный остаток обновлён');}
  const low=items.filter(x=>x.lowStock);const valuation=items.reduce((sum,i)=>sum+i.valueCents,0);
  return <><PageHeading eyebrow="MANAGEMENT / INVENTORY" title="Склад и остатки" subtitle="Движение ингредиентов, стоимость запасов, контроль дефицита и инвентаризация. Данные хранятся в PostgreSQL."/>
    {error&&<Alert text={error}/>} {notice&&<div className="notice" role="status">{notice}</div>}
    <div className="r3-metrics"><div><span>Ингредиентов</span><strong>{items.length}</strong></div><div><span>Ниже минимума</span><strong className={low.length?'r3-danger':''}>{low.length}</strong></div><div><span>Учётная стоимость запасов</span><strong>{money(valuation,organization?.currency)}</strong></div></div>
    {low.length>0&&<div className="r3-warning" role="status"><strong>Нужно пополнить склад:</strong> {low.map(x=>x.name).join(', ')}. <Link href="/app/purchasing">Создать поступление</Link></div>}
    {writable&&<Panel title="Новый ингредиент" subtitle="Количество ведётся с точностью 0,001 выбранной единицы"><form className="r3-form" onSubmit={create}>
      <label>Название<input required maxLength={160} placeholder="Например, кофе арабика" value={name} onChange={e=>setName(e.target.value)}/></label>
      <label>Единица<select value={unit} onChange={e=>setUnit(e.target.value as StockUnit)}><option value="g">Граммы</option><option value="ml">Миллилитры</option><option value="pcs">Штуки</option></select></label>
      <label>Мин. запас<input required inputMode="decimal" value={minimum} onChange={e=>setMinimum(e.target.value)}/></label>
      <button className="gold-button" disabled={busy}>Добавить</button>
    </form></Panel>}
    <Panel title="Текущие остатки" subtitle="Обновление после каждой операции, блокировка отрицательных запасов">
      {loading?<div className="loading-panel">Загрузка…</div>:!items.length?<Empty title="Склад пуст" description="Добавьте ингредиент и зарегистрируйте первое поступление."/>:<div className="table-scroll"><table className="data-table"><thead><tr><th>Ингредиент</th><th>На складе</th><th>Минимум</th><th>Стоимость</th>{writable&&<th>Действие</th>}</tr></thead><tbody>{items.map(i=><tr key={i.id}>
        <td><strong>{i.name}</strong><div className="small-muted">Версия {i.revision}</div></td>
        <td className="gold-text">{formatQty(i.quantityMilli)} {UNIT_LABELS[i.unit]}{i.lowStock&&<span className="r3-low">Мало</span>}</td>
        <td>{formatQty(i.minQuantityMilli)} {UNIT_LABELS[i.unit]}</td><td>{money(i.valueCents,organization?.currency)}</td>
        {writable&&<td className="r3-actions"><button className="small-button" disabled={busy} onClick={()=>{setCountId(i.id);setCounted(String(i.quantityMilli/1000));setFoundValue('');setMinimumId('');}}>Пересчитать</button><button className="text-button" disabled={busy} onClick={()=>{setMinimumId(i.id);setNewMinimum(String(i.minQuantityMilli/1000));setCountId('');}}>Порог</button></td>}
      </tr>)}</tbody></table></div>}
    </Panel>
    {writable&&countId&&<Panel title="Инвентаризация" subtitle="Записывается фактическое количество. Излишек требует явной оценки стоимости."><form className="r3-form" onSubmit={e=>{e.preventDefault();const item=items.find(i=>i.id===countId);if(item)void stocktake(item);}}>
      <label>Ингредиент<input value={items.find(i=>i.id===countId)?.name||''} readOnly/></label>
      <label>Посчитано фактически<input required inputMode="decimal" value={counted} onChange={e=>setCounted(e.target.value)}/></label>
      <label>Стоимость излишка, если есть<input inputMode="decimal" placeholder="Только если нашли больше" value={foundValue} onChange={e=>setFoundValue(e.target.value)}/></label>
      <button className="gold-button" disabled={busy}>Зафиксировать</button><button className="text-button" type="button" onClick={()=>setCountId('')}>Отмена</button>
    </form></Panel>}
    {writable&&minimumId&&<Panel title="Изменить порог" subtitle="Предупреждение включается, когда остаток меньше порога"><form className="r3-form" onSubmit={e=>{e.preventDefault();const item=items.find(i=>i.id===minimumId);if(item)void changeMinimum(item);}}>
      <label>Минимальный остаток<input required inputMode="decimal" value={newMinimum} onChange={e=>setNewMinimum(e.target.value)}/></label><button className="gold-button" disabled={busy}>Сохранить порог</button><button className="text-button" type="button" onClick={()=>setMinimumId('')}>Отмена</button>
    </form></Panel>}
    <Panel title="Журнал движений" subtitle="Поступления, расход по заказам и расхождения инвентаризации">
      {!movements.length?<Empty title="Движений нет" description="История появится после закупки, продажи или инвентаризации."/>:<div className="table-scroll"><table className="data-table"><thead><tr><th>Время</th><th>Ингредиент</th><th>Операция</th><th>Количество</th><th>Стоимость</th></tr></thead><tbody>{movements.slice(0,35).map(m=><tr key={m.id}>
        <td>{dateTime(m.createdAt)}</td><td>{m.ingredientName}</td><td>{m.reason==='RECEIPT'?'Поступление':m.reason==='ORDER'?'Расход по заказу':'Инвентаризация'}</td>
        <td className={m.deltaQuantityMilli<0?'r3-negative':'gold-text'}>{m.deltaQuantityMilli>0?'+':''}{formatQty(m.deltaQuantityMilli)}</td><td>{m.deltaValueCents>0?'+':''}{money(m.deltaValueCents,organization?.currency)}</td>
      </tr>)}</tbody></table></div>}
    </Panel><div className="info-footnote">Учётная стоимость рассчитывается из поступлений и списаний по средневзвешенной стоимости. Это не рыночная стоимость, не P&amp;L и не налогооблагаемая прибыль.</div>
  </>;
}
