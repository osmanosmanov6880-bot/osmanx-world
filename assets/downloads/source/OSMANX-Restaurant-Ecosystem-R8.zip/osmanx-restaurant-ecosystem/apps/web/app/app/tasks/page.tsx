'use client';
import {useCallback,useEffect,useState,type FormEvent} from 'react';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {dateTime,type Employee,type RestaurantTask,type TaskStatus} from '../../../lib/types';

const labels:Record<TaskStatus,string>={OPEN:'Новая',IN_PROGRESS:'В работе',DONE:'Выполнена',CANCELLED:'Отменена'};
export default function Tasks(){
  const {base,organization,session,api}=useScope();
  const [tasks,setTasks]=useState<RestaurantTask[]>([]),[staff,setStaff]=useState<Employee[]>([]);
  const [title,setTitle]=useState(''),[description,setDescription]=useState(''),[assignedTo,setAssignedTo]=useState(''),[due,setDue]=useState('');
  const [busy,setBusy]=useState(false),[loading,setLoading]=useState(true),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const manager=['owner','operations_director','manager'].includes(organization?.role||'');
  const read=useCallback(async()=>{if(!base)return;const t=await api<{tasks:RestaurantTask[]}>(`${base}/tasks`);setTasks(t.tasks);
    if(manager){const s=await api<{staff:Employee[]}>(`${base}/staff`);setStaff(s.staff);}
  },[base,api,manager]);
  useEffect(()=>{setLoading(true);setError('');void read().catch(e=>setError(e.message)).finally(()=>setLoading(false));},[read]);
  async function perform(action:()=>Promise<unknown>,noticeText:string){setBusy(true);setError('');setNotice('');
    try{await action();await read();setNotice(noticeText);}catch(e){setError(e instanceof Error?e.message:'Ошибка задачи');await read().catch(()=>{});}finally{setBusy(false);}}
  async function create(e:FormEvent){e.preventDefault();if(!base)return;await perform(async()=>{
    const dueAt=due?new Date(due).toISOString():null;
    await api(`${base}/tasks`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({title,description,assignedTo:assignedTo||null,dueAt})});
    setTitle('');setDescription('');setDue('');
  },'Задача создана');}
  async function change(t:RestaurantTask,status:TaskStatus){if(!base)return;await perform(()=>api(`${base}/tasks/${t.id}/status`,{
    method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({status,expectedRevision:t.revision})
  }),'Статус задачи обновлён');}
  const active=tasks.filter(t=>t.status==='OPEN'||t.status==='IN_PROGRESS');
  return <><PageHeading eyebrow="MANAGEMENT / TASK CONTROL" title="Задачи команде" subtitle="Назначение, срок и подтверждённое исполнение. Сотрудник видит только свои задачи."/>
    {error&&<Alert text={error}/>} {notice&&<div className="notice" role="status">{notice}</div>}
    <div className="r3-metrics"><div><span>Всего задач</span><strong>{tasks.length}</strong></div><div><span>Активные</span><strong>{active.length}</strong></div><div><span>Просрочены</span><strong className={active.some(t=>t.dueAt&&Date.parse(t.dueAt)<Date.now())?'r3-danger':''}>{active.filter(t=>t.dueAt&&Date.parse(t.dueAt)<Date.now()).length}</strong></div></div>
    {manager&&<Panel title="Поставить задачу" subtitle="Назначайте только сотрудникам с доступом к данному филиалу"><form className="r3-form" onSubmit={create}>
      <label>Название<input required maxLength={160} placeholder="Проверить остатки на складе" value={title} onChange={e=>setTitle(e.target.value)}/></label>
      <label>Исполнитель<select value={assignedTo} onChange={e=>setAssignedTo(e.target.value)}><option value="">Не назначен</option>{staff.map(s=><option value={s.id} key={s.id}>{s.displayName}</option>)}</select></label>
      <label>Срок (время вашего устройства)<input type="datetime-local" value={due} onChange={e=>setDue(e.target.value)}/></label>
      <label className="r3-wide">Описание<input maxLength={1000} placeholder="Что считается выполнением" value={description} onChange={e=>setDescription(e.target.value)}/></label>
      <button className="gold-button" disabled={busy}>Назначить</button>
    </form></Panel>}
    <Panel title="Контроль исполнения" subtitle={manager?'Задачи всего филиала':'Ваши назначенные задачи'} action={<button className="text-button" onClick={()=>void read().catch(e=>setError(e.message))}>Обновить</button>}>
      {loading?<div className="loading-panel">Загрузка…</div>:!tasks.length?<Empty title="Нет задач" description="После назначения задачи она появится здесь."/>:<div className="r3-task-list">
        {tasks.map(t=><article className="r3-task" key={t.id}><div className="r3-task-main"><span className={`booking-badge ${t.status==='DONE'?'booking-seated':''}`}>{labels[t.status]}</span>
          <h3>{t.title}</h3>{t.description&&<p>{t.description}</p>}
          <div className="small-muted">{t.employeeName||'Не назначен'}{t.dueAt?` · до ${dateTime(t.dueAt)}`:''} · версия {t.revision}</div>
          {t.status==='DONE'&&t.completedAt&&<div className="small-muted">Выполнено: {dateTime(t.completedAt)}</div>}</div>
          {t.status!=='DONE'&&t.status!=='CANCELLED'&&(manager||t.assignedTo===session?.user.id)&&<div className="r3-task-actions">
            {t.status==='OPEN'&&<button disabled={busy} className="gold-outline-button" onClick={()=>void change(t,'IN_PROGRESS')}>Взять в работу</button>}
            <button disabled={busy} className="gold-button" onClick={()=>void change(t,'DONE')}>Завершить</button>
            {manager&&<button disabled={busy} className="text-button" onClick={()=>void change(t,'CANCELLED')}>Отменить</button>}
          </div>}
        </article>)}
      </div>}
    </Panel>
    <div className="info-footnote">Исполнение фиксируется в журнале аудита, изменения используют версии, чтобы не потерять параллельные правки. Просрочка — сигнал, но не автоматическое доказательство невыполнения работы.</div>
  </>;
}
