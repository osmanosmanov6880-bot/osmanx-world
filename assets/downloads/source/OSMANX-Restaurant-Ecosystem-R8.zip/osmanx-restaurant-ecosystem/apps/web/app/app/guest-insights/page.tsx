'use client';
import {useCallback,useEffect,useState} from 'react';
import Link from 'next/link';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {dateTime,money,GUEST_SEGMENT_LABELS,type GuestInsights,type Guest} from '../../../lib/types';
export default function GuestIntelligence(){
  const {base,organization,api}=useScope();
  const [insights,setInsights]=useState<GuestInsights|null>(null),[names,setNames]=useState<Record<string,string>>({}),[error,setError]=useState(''),[busy,setBusy]=useState(false);
  const canSeeNames=['owner','operations_director','manager','marketer','waiter','cashier'].includes(organization?.role||'');
  const load=useCallback(async()=>{if(!base)return;setBusy(true);setError('');try{
    const response=await api<{insights:GuestInsights}>(`${base}/guest-insights`);setInsights(response.insights);
    if(canSeeNames){const first=await api<{guests:Guest[]}>(`${base}/guests`);setNames(Object.fromEntries(first.guests.map(g=>[g.id,g.displayName])));}else setNames({});
  }catch(e){setError(e instanceof Error?e.message:'Не удалось загрузить данные');}finally{setBusy(false);}
  },[base,api,canSeeNames]);
  useEffect(()=>{void load();},[load]);
  const pct=(n:number|null)=>n===null?'Нет базы':`${n.toLocaleString('ru-RU',{maximumFractionDigits:2})}%`;
  return <><PageHeading eyebrow="GROWTH / OBSERVED BEHAVIOUR" title="Возвращаемость гостей" subtitle="Наблюдаемая история заказов, RFM и группы для проверки гипотез. Прогнозов оттока и выдуманных данных нет." action={<button className="gold-outline-button" disabled={busy} onClick={()=>void load()}>{busy?'Обновление…':'Обновить расчёт'}</button>}/>
    {error&&<Alert text={error}/>}{!insights?<Panel><p>Загрузка аналитики…</p></Panel>:<>
      <div className="r5-metrics"><div className="panel"><small>Связано с гостями</small><strong>{pct(insights.identificationCoveragePercent)}</strong><p>{insights.identifiedCompletedOrders} из {insights.totalCompletedOrders} завершённых заказов</p></div>
      <div className="panel"><small>Повторные среди идентифицированных</small><strong>{pct(insights.repeatShareOfIdentifiedPercent)}</strong><p>{insights.repeatGuests} из {insights.identifiedGuestsWithVisits} гостей с заказами</p></div>
      <div className="panel"><small>Период наблюдения</small><strong>{insights.windowDays} дней</strong><p>По состоянию на {dateTime(insights.asOf)}</p></div></div>
      <Panel title="Сигналы по гостям" subtitle="Сегменты описывают только наблюдаемое поведение, а не причины изменений.">
        {!insights.guests.length?<Empty title="Нет карточек гостей" description={canSeeNames?"Создайте карточки и связывайте их с заказами, чтобы получить историю.":"По вашей роли доступны только сводные показатели без персональных профилей."}/>:
          <div className="table-scroll"><table className="data-table"><thead><tr><th>Гость</th><th>Сегмент</th><th>Заказов / 365 дней</th><th>Выручка по заказам</th><th>Последний заказ</th><th>R / F / M</th></tr></thead><tbody>{insights.guests.map(g=><tr key={g.guestId}><td>{names[g.guestId]||`Гость ${g.guestId.slice(0,8)}`}</td><td>{GUEST_SEGMENT_LABELS[g.segment]}</td><td>{g.visits365}</td><td>{money(g.spend365Cents,organization?.currency)}</td><td>{g.lastVisitAt?dateTime(g.lastVisitAt):'—'}</td><td>{[g.recencyScore,g.frequencyScore,g.monetaryScore].map(x=>x??'—').join(' / ')}</td></tr>)}</tbody></table></div>}
      </Panel>
      <Panel title="Методика и ограничения"><ul className="r5-limitations">{insights.limitations.map(x=><li key={x}>{x}</li>)}</ul>
        <p className="small-muted">Порог риска: нет завершённого заказа более 90 дней при минимум двух прошлых заказах. Для проверки причин нужны данные о качестве, сезонности и контексте. Монетарный квинтиль доступен только при пяти и более идентифицированных гостях с заказами.</p>
        {canSeeNames&&<Link className="gold-outline-button" href="/app/guests">Перейти к карточкам</Link>}
      </Panel></>}
  </>;
}
