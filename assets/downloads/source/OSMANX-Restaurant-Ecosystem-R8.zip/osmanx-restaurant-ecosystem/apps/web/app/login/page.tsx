'use client';
import {useState,type FormEvent} from 'react';
import {useRouter} from 'next/navigation';
import {InfinityLogo,Alert} from '../../components/ui';
export default function Login(){
  const router=useRouter();const [create,setCreate]=useState(false);const [busy,setBusy]=useState(false);const [error,setError]=useState('');
  const [email,setEmail]=useState('');const [password,setPassword]=useState('');const [displayName,setDisplayName]=useState('');
  const [organizationName,setOrganizationName]=useState('');const [branchName,setBranchName]=useState('');
  async function submit(event:FormEvent){
    event.preventDefault();setBusy(true);setError('');
    const path=create?'register':'login';const body=create?{email,password,displayName,organizationName,branchName}:{email,password};
    try{
      const res=await fetch(`/api/v1/auth/${path}`,{method:'POST',headers:{'content-type':'application/json'},credentials:'same-origin',body:JSON.stringify(body)});
      const data=await res.json();if(!res.ok)throw new Error(data.error?.message||'Ошибка входа');
      router.replace('/app');router.refresh();
    }catch(e){setError(e instanceof Error?e.message:'Не удалось войти');}finally{setBusy(false);}
  }
  return <div className="auth-page"><div className="auth-glow"/><div className="auth-card"><div className="auth-brand"><InfinityLogo/><span>OSMANX.WORLD</span><small>RESTAURANT ECOSYSTEM</small></div>
    <div className="eyebrow">СИСТЕМА УПРАВЛЕНИЯ</div><h1>{create?'Создайте свою сеть':'Ваш бизнес. Под контролем.'}</h1><p className="auth-subtitle">Решения, основанные на фактах. Без выдуманных цифр.</p>
    <div className="auth-switch"><button onClick={()=>{setCreate(false);setError('');}} className={!create?'chosen':''} type="button">Вход</button><button onClick={()=>{setCreate(true);setError('');}} className={create?'chosen':''} type="button">Создать аккаунт</button></div>
    <form onSubmit={submit} className="stack-form">{create&&<><label>Ваше имя<input required maxLength={120} value={displayName} onChange={e=>setDisplayName(e.target.value)} autoComplete="name"/></label><label>Название компании<input required maxLength={160} value={organizationName} onChange={e=>setOrganizationName(e.target.value)}/></label><label>Название первого ресторана<input required maxLength={160} value={branchName} onChange={e=>setBranchName(e.target.value)}/></label></>}
      <label>Рабочий email<input type="email" required autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)}/></label>
      <label>Пароль<input type="password" minLength={12} maxLength={128} required autoComplete={create?'new-password':'current-password'} value={password} onChange={e=>setPassword(e.target.value)}/></label>
      {error&&<Alert text={error}/>}<button type="submit" disabled={busy} className="gold-button">{busy?'Проверяем…':create?'Создать организацию':'Войти в систему'}</button>
    </form><p className="auth-note">R3 · Данные защищены сессиями и правами доступа. Для production необходимы дополнительная приёмка и настройка инфраструктуры.</p>
  </div><div className="auth-side"><div className="global-orbit"><div className="orbit-one"/><div className="orbit-two"/><span>∞</span></div><div className="side-statement"><small>OSMANX INTELLIGENCE / FOUNDATION</small><h2>Технологии.<br/>Команда.<br/><em>Рост.</em></h2><p>Каждое решение должно приводить к измеримому результату.</p></div></div></div>;
}
