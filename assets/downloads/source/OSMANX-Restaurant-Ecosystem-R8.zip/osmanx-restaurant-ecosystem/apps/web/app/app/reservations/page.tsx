'use client';
import {useCallback,useEffect,useState,type FormEvent} from 'react';
import Link from 'next/link';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {dateTime,RESERVATION_LABELS,type FloorTable,type Reservation,type ReservationStatus} from '../../../lib/types';

function nextSlot(){
  const d=new Date(Date.now()+30*60_000);d.setMinutes(Math.ceil(d.getMinutes()/15)*15,0,0);
  const p=(x:number)=>String(x).padStart(2,'0');return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}
const editRoles=['owner','operations_director','manager','waiter','cashier'];
export default function Reservations(){
  const {base,organization,branch,api}=useScope();
  const [tables,setTables]=useState<FloorTable[]>([]),[bookings,setBookings]=useState<Reservation[]>([]);
  const [guestName,setGuestName]=useState(''),[tableId,setTableId]=useState(''),[partySize,setPartySize]=useState('2');
  const [startsAt,setStartsAt]=useState(nextSlot),[duration,setDuration]=useState('90');
  const [busy,setBusy]=useState(''),[error,setError]=useState(''),[notice,setNotice]=useState(''),[loading,setLoading]=useState(true),[now,setNow]=useState(Date.now());
  const editable=editRoles.includes(organization?.role||'');
  const load=useCallback(async()=>{if(!base)return;
    const [a,b]=await Promise.all([api<{reservations:Reservation[]}>(`${base}/reservations`),api<{tables:FloorTable[]}>(`${base}/floor`)]);
    setBookings(a.reservations);setTables(b.tables);setNow(Date.now());
  },[base,api]);
  useEffect(()=>{setError('');setLoading(true);void load().catch(e=>setError(e.message)).finally(()=>setLoading(false));
    const timer=setInterval(()=>{void load().catch(()=>{});},20_000);return ()=>clearInterval(timer);
  },[load]);
  const submit=async(e:FormEvent)=>{e.preventDefault();if(!base)return;
    setBusy('create');setError('');setNotice('');
    try{
      const date=new Date(startsAt);if(!Number.isFinite(date.getTime()))throw new Error('Укажите корректное время');
      await api(`${base}/reservations`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({
        tableId,guestName,partySize:Number(partySize),startsAt:date.toISOString(),durationMinutes:Number(duration)
      })});
      setGuestName('');setStartsAt(nextSlot());setNotice('Бронирование сохранено');await load();
    }catch(e){setError(e instanceof Error?e.message:'Не удалось создать бронь');}finally{setBusy('');}
  };
  const act=async(r:Reservation,action:'seat'|'CANCELLED'|'NO_SHOW')=>{if(!base)return;
    setBusy(r.id);setError('');setNotice('');
    try{
      if(action==='seat'){
        await api(`${base}/reservations/${r.id}/seat`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({expectedRevision:r.revision})});
        setNotice('Гости посажены, заказ создан. Можно добавлять блюда в разделе «Заказы».');
      }else{
        await api(`${base}/reservations/${r.id}/status`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({status:action,expectedRevision:r.revision})});
        setNotice(action==='CANCELLED'?'Бронь отменена':'Неявка зафиксирована');
      }
      await load();
    }catch(e){setError(e instanceof Error?e.message:'Не удалось обновить бронь');await load().catch(()=>{});}finally{setBusy('');}
  };
  const label=(status:ReservationStatus)=>RESERVATION_LABELS[status];
  return <>
    <PageHeading eyebrow="TECHNOLOGY / GUEST ARRIVAL" title="Бронирования" subtitle="Принимайте брони, управляйте посадкой гостей и связывайте бронирования с заказами."/>
    {error&&<Alert text={error}/>}{notice&&<div role="status" className="notice">{notice}</div>}
    {editable&&<Panel title="Новое бронирование" subtitle="Пересечения по столу и времени блокируются на сервере, даже при одновременных запросах.">
      <form className="booking-form" onSubmit={submit}>
        <label>Имя гостя<input required maxLength={120} value={guestName} onChange={e=>setGuestName(e.target.value)} placeholder="Имя для бронирования"/></label>
        <label>Стол<select required value={tableId} onChange={e=>setTableId(e.target.value)}><option value="">Выберите стол</option>{tables.map(t=><option key={t.id} value={t.id}>{t.label} · {t.capacity} мест</option>)}</select></label>
        <label>Количество гостей<input required type="number" min="1" max="40" value={partySize} onChange={e=>setPartySize(e.target.value)}/></label>
        <label>Начало (время вашего устройства)<input required type="datetime-local" value={startsAt} onChange={e=>setStartsAt(e.target.value)}/></label>
        <label>Продолжительность<select value={duration} onChange={e=>setDuration(e.target.value)}><option value="30">30 минут</option><option value="60">1 час</option><option value="90">1,5 часа</option><option value="120">2 часа</option><option value="180">3 часа</option><option value="240">4 часа</option></select></label>
        <button className="gold-button" disabled={busy!==''||!tableId}>{busy==='create'?'Сохраняем…':'Подтвердить бронь'}</button>
      </form>
      <p className="small-muted">Часовой пояс ресторана: {branch?.timezone}. Введите местное время на вашем устройстве; система хранит момент в UTC. Посадка разрешена за 30 минут до брони.</p>
    </Panel>}
    <Panel title="Журнал бронирований" subtitle="Данные выбранного филиала. Обновление каждые 20 секунд." action={<button className="text-button" type="button" disabled={busy!==''} onClick={()=>void load().catch(e=>setError(e.message))}>Обновить</button>}>
      {loading?<div className="loading-panel">Загрузка…</div>:!bookings.length?<Empty title="Бронирований ещё нет" description="После создания брони она появится здесь и в схеме зала."/>:<div className="reservation-list">
        {bookings.map(r=><article className="reservation-card" key={r.id}>
          <div className="reservation-primary"><div className="eyebrow">{dateTime(r.startsAt)} — {new Date(r.endsAt).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})}</div>
            <h3>{r.guestName}</h3><p className="small-muted">{tables.find(t=>t.id===r.tableId)?.label||'Стол'} · гостей: {r.partySize}</p></div>
          <div className="reservation-actions"><span className={`booking-badge booking-${r.status.toLowerCase()}`}>{label(r.status)}</span>
            {r.status==='CONFIRMED'&&editable&&<>
              <button className="gold-outline-button" disabled={busy!==''||now<Date.parse(r.startsAt)-30*60000||now>=Date.parse(r.endsAt)+30*60000}
                title="Посадка доступна за 30 минут до начала брони и до 30 минут после её окончания" onClick={()=>void act(r,'seat')}>Посадить гостей</button>
              <button className="text-button" disabled={busy!==''||now<Date.parse(r.startsAt)+15*60000} onClick={()=>void act(r,'NO_SHOW')}>Неявка</button>
              <button className="text-button" disabled={busy!==''} onClick={()=>void act(r,'CANCELLED')}>Отменить</button>
            </>}
            {r.orderId&&<Link href="/app/orders" className="gold-outline-button">Открыть заказ</Link>}
          </div>
        </article>)}
      </div>}
    </Panel>
  </>;
}
