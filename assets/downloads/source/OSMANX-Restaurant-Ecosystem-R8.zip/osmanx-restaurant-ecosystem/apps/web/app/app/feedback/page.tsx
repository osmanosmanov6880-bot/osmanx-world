'use client';
import {useCallback,useEffect,useState,type FormEvent} from 'react';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {FEEDBACK_KIND_LABELS,dateTime,type Guest,type GuestFeedback} from '../../../lib/types';
const canWrite=['owner','operations_director','manager','marketer','waiter','cashier'];
const canResolve=['owner','operations_director','manager','marketer'];
export default function Feedback(){
  const {base,organization,api}=useScope();const role=organization?.role||'';
  const [items,setItems]=useState<GuestFeedback[]>([]),[guests,setGuests]=useState<Guest[]>([]);
  const [guestId,setGuestId]=useState(''),[kind,setKind]=useState<GuestFeedback['kind']>('COMPLAINT'),[rating,setRating]=useState(''),[comment,setComment]=useState('');
  const [resolutions,setResolutions]=useState<Record<string,string>>({});const [busy,setBusy]=useState(false),[error,setError]=useState(''),[loading,setLoading]=useState(true);
  const read=useCallback(async()=>{if(!base)return;
    const data=await api<{feedback:GuestFeedback[]}>(`${base}/feedback`);setItems(data.feedback);
    if(canWrite.includes(role)){const list=await api<{guests:Guest[]}>(`${base}/guests`);setGuests(list.guests);}else setGuests([]);
  },[base,api,role]);
  useEffect(()=>{setError('');setLoading(true);void read().catch(e=>setError(e.message)).finally(()=>setLoading(false));},[read]);
  const work=async(fn:()=>Promise<unknown>)=>{setBusy(true);setError('');try{await fn();await read();}catch(e){setError(e instanceof Error?e.message:'Ошибка');}finally{setBusy(false);}};
  function create(e:FormEvent){e.preventDefault();if(!base)return;void work(async()=>{
    await api(`${base}/feedback`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({guestId:guestId||null,orderId:null,kind,rating:rating?Number(rating):null,comment:comment.trim()||null})});
    setRating('');setComment('');setGuestId('');});}
  function resolve(item:GuestFeedback){if(!base)return;void work(()=>api(`${base}/feedback/${item.id}/resolve`,{method:'POST',idempotencyKey:crypto.randomUUID(),
    body:JSON.stringify({expectedRevision:item.revision,resolution:resolutions[item.id]||''})}));}
  return <><PageHeading eyebrow="GROWTH / GUEST VOICE" title="Отзывы и обращения" subtitle="Фиксация обратной связи, ответственных действий и статусов. Записи вводятся сотрудниками и не считаются проверенными отзывами из внешних сервисов."/>
    {error&&<Alert text={error}/>}
    {canWrite.includes(role)&&<Panel title="Зафиксировать обращение" subtitle="Источник: ручной ввод сотрудника. Без автоматической отправки сообщений.">
      <form className="r5-guest-form" onSubmit={create}><label>Тип<select value={kind} onChange={e=>setKind(e.target.value as GuestFeedback['kind'])}><option value="COMPLAINT">Жалоба</option><option value="COMPLIMENT">Благодарность</option><option value="SUGGESTION">Предложение</option></select></label>
      <label>Гость (необязательно)<select value={guestId} onChange={e=>setGuestId(e.target.value)}><option value="">Без идентификации</option>{guests.map(g=><option key={g.id} value={g.id}>{g.displayName}</option>)}</select></label>
      <label>Оценка (1–5)<select value={rating} onChange={e=>setRating(e.target.value)}><option value="">Нет оценки</option>{[1,2,3,4,5].map(i=><option key={i} value={i}>{i}</option>)}</select></label>
      <label className="r5-full">Комментарий<textarea rows={3} maxLength={1000} value={comment} onChange={e=>setComment(e.target.value)} placeholder="Что сообщил гость? Указывайте минимум необходимого."/></label>
      <button className="gold-button" disabled={busy||(!rating&&!comment.trim())}>Сохранить</button></form></Panel>}
    <Panel title="Журнал обратной связи" subtitle="До 200 последних обращений по выбранному ресторану">
      {loading?<p>Загрузка…</p>:!items.length?<Empty title="Обращений пока нет" description="Обратная связь появится после первой записанной оценки или жалобы."/>:<div className="r5-feedback-grid">{items.map(f=><article key={f.id} className="r5-feedback-card"><div className="r5-feedback-top"><strong>{FEEDBACK_KIND_LABELS[f.kind]}</strong><span className={f.status==='OPEN'?'r5-badge-warn':'r5-badge-ok'}>{f.status==='OPEN'?'В работе':'Закрыто'}</span></div>
        <p className="small-muted">{dateTime(f.createdAt)} · {f.rating===null?'Без оценки':`Оценка ${f.rating}/5`} · версия {f.revision}</p>
        {f.comment&&<p>{f.comment}</p>}{f.resolution&&<div className="r5-resolution"><strong>Решение:</strong> {f.resolution}</div>}
        {f.status==='OPEN'&&canResolve.includes(role)&&<div className="r5-stack"><label>Результат разбора<textarea rows={2} minLength={5} maxLength={1000} value={resolutions[f.id]||''} onChange={e=>setResolutions(p=>({...p,[f.id]:e.target.value}))} placeholder="Что конкретно сделано"/></label>
          <button type="button" className="gold-outline-button" disabled={busy||(resolutions[f.id]||'').trim().length<5} onClick={()=>resolve(f)}>Закрыть обращение</button></div>}
      </article>)}</div>}
    </Panel>
  </>;
}
