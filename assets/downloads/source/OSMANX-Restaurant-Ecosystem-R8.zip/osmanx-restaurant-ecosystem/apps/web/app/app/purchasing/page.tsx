'use client';
import {useCallback,useEffect,useState,type FormEvent} from 'react';
import Link from 'next/link';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {formatQty,parseQty,parseMoney,money,dateTime,UNIT_LABELS,type Ingredient,type Supplier,type Receipt} from '../../../lib/types';

type PurchaseLine={ingredientId:string;quantity:string;value:string};
export default function Purchasing(){
  const {base,organization,api}=useScope();
  const [items,setItems]=useState<Ingredient[]>([]),[suppliers,setSuppliers]=useState<Supplier[]>([]),[receipts,setReceipts]=useState<Receipt[]>([]);
  const [supplierName,setSupplierName]=useState(''),[supplierId,setSupplierId]=useState(''),[reference,setReference]=useState('');
  const [lines,setLines]=useState<PurchaseLine[]>([{ingredientId:'',quantity:'1',value:'0'}]);
  const [busy,setBusy]=useState(false),[loading,setLoading]=useState(true),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const writable=['owner','operations_director','manager'].includes(organization?.role||'');
  const refresh=useCallback(async()=>{if(!base)return;const [i,s,r]=await Promise.all([api<{ingredients:Ingredient[]}>(`${base}/ingredients`),
    api<{suppliers:Supplier[]}>(`${base}/suppliers`),api<{receipts:Receipt[]}>(`${base}/receipts`)]);
    setItems(i.ingredients);setSuppliers(s.suppliers);setReceipts(r.receipts);
  },[base,api]);
  useEffect(()=>{setLoading(true);setError('');void refresh().catch(e=>setError(e.message)).finally(()=>setLoading(false));},[refresh]);
  async function execute(action:()=>Promise<unknown>,message:string){setBusy(true);setError('');setNotice('');
    try{await action();await refresh();setNotice(message);}catch(e){setError(e instanceof Error?e.message:'Не удалось сохранить поступление');}finally{setBusy(false);}}
  async function addSupplier(e:FormEvent){e.preventDefault();if(!base)return;await execute(async()=>{
    await api(`${base}/suppliers`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({name:supplierName})});setSupplierName('');
  },'Поставщик добавлен');}
  async function receive(e:FormEvent){e.preventDefault();if(!base)return;await execute(async()=>{
    const rows=lines.map(l=>({ingredientId:l.ingredientId,quantityMilli:parseQty(l.quantity),totalCostCents:parseMoney(l.value)}));
    await api(`${base}/receipts`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({supplierId:supplierId||null,reference,lines:rows})});
    setReference('');setLines([{ingredientId:'',quantity:'1',value:'0'}]);
  },'Поступление проведено, складские остатки и стоимость обновлены');}
  return <><PageHeading eyebrow="MANAGEMENT / PURCHASING" title="Закупки и поступления" subtitle="Фиксируйте закупленное количество и фактическую стоимость по накладной. Запись нельзя провести дважды одним ключом."/>
    {error&&<Alert text={error}/>} {notice&&<div className="notice" role="status">{notice}</div>}
    {writable&&<Panel title="Поставщики" subtitle="Каталог поставщиков каждого ресторана"><form className="r3-form" onSubmit={addSupplier}>
      <label>Название организации<input required value={supplierName} maxLength={160} onChange={e=>setSupplierName(e.target.value)} placeholder="Название поставщика"/></label><button className="gold-button" disabled={busy}>Добавить поставщика</button>
    </form></Panel>}
    {writable&&<Panel title="Провести поступление" subtitle="Вводите общую стоимость каждой позиции из документа. Суммы не рассчитываются из цен «на глаз».">
      {!items.length?<Empty title="Нет ингредиентов" description="Сначала добавьте позиции на складе."/>:<form onSubmit={receive}>
        <div className="r3-form"><label>Поставщик<select value={supplierId} onChange={e=>setSupplierId(e.target.value)}><option value="">Без поставщика</option>{suppliers.map(s=><option value={s.id} key={s.id}>{s.name}</option>)}</select></label>
          <label>Номер накладной<input maxLength={100} value={reference} onChange={e=>setReference(e.target.value)} placeholder="Например, INV-0067"/></label></div>
        <div className="r3-line-editor">{lines.map((line,index)=><div className="r3-recipe-line" key={index}>
          <label>Ингредиент<select required value={line.ingredientId} onChange={e=>setLines(p=>p.map((l,i)=>i===index?{...l,ingredientId:e.target.value}:l))}><option value="">Выберите</option>{items.map(x=><option value={x.id} key={x.id}>{x.name} · {UNIT_LABELS[x.unit]}</option>)}</select></label>
          <label>Количество<input inputMode="decimal" required value={line.quantity} onChange={e=>setLines(p=>p.map((l,i)=>i===index?{...l,quantity:e.target.value}:l))}/></label>
          <label>Общая стоимость ({organization?.currency||'RUB'})<input required inputMode="decimal" value={line.value} onChange={e=>setLines(p=>p.map((l,i)=>i===index?{...l,value:e.target.value}:l))}/></label>
          <button type="button" className="text-button" disabled={lines.length===1||busy} onClick={()=>setLines(p=>p.filter((_,i)=>i!==index))}>Удалить</button>
        </div>)}</div>
        <div className="r3-toolbar"><button className="gold-outline-button" type="button" disabled={busy||lines.length>=50} onClick={()=>setLines(p=>[...p,{ingredientId:'',quantity:'1',value:'0'}])}>Добавить строку</button>
          <button className="gold-button" disabled={busy}>Провести поступление</button></div>
      </form>}
    </Panel>}
    <Panel title="История приходов" subtitle={`${receipts.length} последних зарегистрированных поступлений`}>
      {loading?<div className="loading-panel">Загрузка…</div>:!receipts.length?<Empty title="Поставок ещё не было" description="После первой закупки здесь появятся первичные данные и сумма."/>:<div className="table-scroll"><table className="data-table"><thead><tr><th>Дата</th><th>Накладная</th><th>Поставщик</th><th>Позиции</th><th>Сумма</th></tr></thead><tbody>{receipts.map(r=><tr key={r.id}>
        <td>{dateTime(r.receivedAt)}</td><td>{r.reference||r.id.slice(0,8)}</td><td>{suppliers.find(s=>s.id===r.supplierId)?.name||'Не указан'}</td>
        <td><div className="r3-receipt-lines">{r.lines.map(l=><div key={l.ingredientId}>{l.name}: {formatQty(l.quantityMilli)} · {money(l.totalCostCents,organization?.currency)}</div>)}</div></td>
        <td className="gold-text">{money(r.totalCostCents,organization?.currency)}</td></tr>)}</tbody></table></div>}
    </Panel>
    <div className="info-footnote">Проведённые поступления не редактируются: коррекции производятся документированной инвентаризацией. <Link href="/app/inventory">Смотреть остатки и журнал движений</Link>.</div>
  </>;
}
