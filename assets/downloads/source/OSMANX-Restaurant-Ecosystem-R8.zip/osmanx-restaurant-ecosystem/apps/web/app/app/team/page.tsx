'use client';
import {useState,type FormEvent} from 'react';
import {Alert,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
const roles=[['manager','Управляющий'],['finance_director','Финансовый директор'],['operations_director','Операционный директор'],['chef','Шеф-повар'],['kitchen','Сотрудник кухни'],['waiter','Официант'],['cashier','Кассир'],['marketer','Маркетолог'],['analyst','Аналитик'],['auditor','Аудитор (только чтение)']];
export default function Team(){
  const {organization,api}=useScope();const [email,setEmail]=useState('');const [role,setRole]=useState('manager');const [branches,setBranches]=useState<string[]>([]);const [link,setLink]=useState('');const [error,setError]=useState('');const [busy,setBusy]=useState(false);const allowed=organization?.role==='owner';
  async function invite(e:FormEvent){e.preventDefault();if(!organization)return;setBusy(true);setError('');setLink('');try{
    const data=await api<{invitation:{url:string}}>(`/api/v1/organizations/${organization.organizationId}/invitations`,{method:'POST',body:JSON.stringify({email,role,branchIds:branches})});setLink(data.invitation.url);setEmail('');
  }catch(e){setError(e instanceof Error?e.message:'Ошибка');}finally{setBusy(false);}}
  return <><PageHeading eyebrow="MANAGEMENT / ACCESS" title="Сотрудники и роли" subtitle="Приглашение сотрудников с ограничением доступа к конкретным филиалам."/>
    {!allowed?<Panel title="Управление доступом"><p>Выпуск приглашений разрешён владельцу организации. Вы можете работать только с назначенными вам филиалами.</p></Panel>:<Panel title="Пригласить сотрудника" subtitle="Ссылка действует 48 часов и используется один раз"><form onSubmit={invite} className="stack-form wide-form"><label>Рабочий email<input required type="email" value={email} onChange={e=>setEmail(e.target.value)}/></label><label>Роль<select value={role} onChange={e=>{setRole(e.target.value);setBranches([]);}}>{roles.map(([v,label])=><option value={v} key={v}>{label}</option>)}</select></label><fieldset className="checklist"><legend>Доступные филиалы</legend>{organization?.branches.map(b=><label key={b.id}><input type="checkbox" checked={branches.includes(b.id)} onChange={e=>setBranches(prev=>e.target.checked?[...prev,b.id]:prev.filter(v=>v!==b.id))}/>{b.name}</label>)}<small>Финансовый и операционный директор имеют доступ ко всем филиалам. Остальным ролям нужно выбрать минимум один.</small></fieldset>
      {error&&<Alert text={error}/>}<button className="gold-button" disabled={busy}>Создать приглашение</button></form>
      {link&&<div className="invite-result"><strong>Приглашение создано</strong><p>Передайте ссылку сотруднику по защищённому каналу:</p><div className="inline-form"><input readOnly aria-label="Ссылка приглашения" value={link}/><button className="small-button" onClick={()=>void navigator.clipboard.writeText(link)}>Скопировать</button></div></div>}</Panel>}
    <div className="info-footnote">В R1 новые сотрудники принимают одноразовое приглашение через отдельную страницу. Отправка email и MFA входят в следующие этапы готовности.</div>
  </>;
}
