'use client';
import {useEffect,useState} from 'react';
import Link from 'next/link';
import {PageHeading,Panel,Empty,Alert,Status} from '../../components/ui';
import {useScope} from '../../lib/session';
import {money,type Dashboard} from '../../lib/types';

export default function CommandCenter(){
  const {base,branch,organization,api}=useScope();const [data,setData]=useState<Dashboard|null>(null);const [error,setError]=useState('');const [selected,setSelected]=useState(6);
  useEffect(()=>{if(!base)return;let active=true;setData(null);setError('');api<{dashboard:Dashboard}>(`${base}/dashboard`).then(r=>{if(active)setData(r.dashboard);}).catch(e=>{if(active)setError(e.message);});return()=>{active=false;};},[base,api]);
  const currency=organization?.currency||'RUB';const max=Math.max(1,...(data?.series.map(d=>d.revenueCents)||[]));
  return <><PageHeading eyebrow="EXECUTIVE COMMAND CENTER / R4" title="Обзор бизнеса" subtitle={`Филиал: ${branch?.name||'—'}. Только реальные операции, зарегистрированные в системе.`} action={<span className="live-indicator"><span/> Данные из API</span>}/>
    {error&&<Alert text={error}/>}{!data&&!error?<div className="panel loading-panel">Загружаем показатели…</div>:data&&<>
      <div className="metric-grid">
        <div className="metric"><span className="metric-label">Выручка завершённых заказов</span><strong>{money(data.revenueCents,currency)}</strong><span>Без вычета расходов и налогов</span></div>
        <div className="metric"><span className="metric-label">Завершено заказов</span><strong>{data.completedOrders.toLocaleString('ru-RU')}</strong><span>За всё время работы филиала</span></div>
        <div className="metric"><span className="metric-label">Средний чек</span><strong>{money(data.averageCheckCents,currency)}</strong><span>По завершённым заказам</span></div>
        <div className="metric"><span className="metric-label">Заказы в работе</span><strong>{data.activeOrders}</strong><span>Новые, на кухне и готовые</span></div>
      </div>
      {data.lowStockCount>0&&<div className="r3-warning" role="status"><strong>Склад требует внимания.</strong> {data.lowStockCount} позиций ниже минимального остатка. <Link href="/app/inventory">Проверить запасы</Link></div>}
      <div className="dashboard-grid">
        <Panel title="Динамика выручки" subtitle="Последние 7 календарных дней · по времени филиала" className="chart-panel">
          {data.series.every(point=>point.revenueCents===0)&&<div className="chart-empty-note">За последние 7 дней завершённых заказов нет</div>}
          <div className="bar-chart" role="group" aria-label="Выберите день для просмотра выручки">{data.series.map((point,index)=><button type="button" key={point.day} className={`chart-col ${selected===index?'chart-selected':''}`} title={`${point.day}: ${money(point.revenueCents,currency)}`} aria-label={`${point.day}: ${money(point.revenueCents,currency)}`} aria-pressed={selected===index} onClick={()=>setSelected(index)}><div className="chart-track"><span style={{height:`${point.revenueCents?Math.max(3,point.revenueCents/max*100):1}%`}}/></div><small>{new Date(point.day+'T12:00:00').toLocaleDateString('ru-RU',{weekday:'short'})}</small></button>)}</div>
          <div className="chart-summary"><span>{data.series[selected]?.day||'—'}</span><strong>{money(data.series[selected]?.revenueCents||0,currency)}</strong></div>
        </Panel>
        <Panel title="Операционное состояние" subtitle="Фактическая конфигурация ресторана">
          <div className="operations-overview"><Link href="/app/menu"><span>Активных блюд</span><strong>{data.menuItems}</strong></Link><Link href="/app/tables"><span>Столов в зале</span><strong>{data.tables}</strong></Link><Link href="/app/orders"><span>Заказов в работе</span><strong>{data.activeOrders}</strong></Link><Link href="/app/inventory"><span>Низкие остатки</span><strong>{data.lowStockCount}</strong></Link></div>
          <div className="guide-note"><strong>Правило платформы</strong><p>Рост продаж нельзя приравнивать к росту прибыли. В R4 доступен расчётный P&L на основе завершённых заказов, списаний склада и введённых расходов. Неполная себестоимость не превращается в фиктивную прибыль.</p></div>
        </Panel>
      </div>
      {['owner','finance_director','operations_director','manager','analyst','auditor'].includes(organization?.role||'')&&<div className="r4-main-cta">
        <div><span className="eyebrow">FINANCIAL CONTROL / R4</span><strong>От выручки — к проверяемому результату</strong><p>Расходы, Food Cost, Labor Cost, план-факт и сводка сети.</p></div>
        <Link className="gold-button" href="/app/finance">Открыть финансовый центр</Link>
      </div>}
      <div className="command-links" aria-label="Быстрые операции">
        <Link href="/app/reservations"><span className="eyebrow">ОПЕРАЦИИ</span><strong>Бронирования</strong><span>Приём гостей и посадка по столам</span></Link>
        <Link href="/app/kitchen"><span className="eyebrow">КУХНЯ</span><strong>Монитор KDS</strong><span>Текущие заказы и их статус</span></Link>
        <Link href="/app/shifts"><span className="eyebrow">ПЕРСОНАЛ</span><strong>Рабочие смены</strong><span>Открытие, завершение и журнал</span></Link>
        <Link href="/app/inventory"><span className="eyebrow">СКЛАД</span><strong>Контроль запасов</strong><span>Низкие остатки, инвентаризация и расход</span></Link>
        <Link href="/app/recipes"><span className="eyebrow">СЕБЕСТОИМОСТЬ</span><strong>Рецептуры</strong><span>Нормы расхода ингредиентов по блюдам</span></Link>
        <Link href="/app/tasks"><span className="eyebrow">УПРАВЛЕНИЕ</span><strong>Задачи</strong><span>Исполнители, сроки и контроль</span></Link>
      </div>
      <Panel title="Последние заказы" subtitle="Нажмите «Управление заказами», чтобы изменить этап приготовления" action={<Link className="subtle-link" href="/app/orders">Управление заказами</Link>}>
        {!data.recentOrders.length?<Empty title="Заказов ещё нет" description="Добавьте блюдо и создайте первый заказ — здесь появятся фактические операции."/>:<div className="table-scroll"><table className="data-table"><thead><tr><th>Заказ</th><th>Создан</th><th>Сумма</th><th>Этап</th></tr></thead><tbody>{data.recentOrders.map(o=><tr key={o.id}><td className="mono">#{o.id.slice(0,8)}</td><td>{new Date(o.createdAt).toLocaleString('ru-RU')}</td><td className="gold-text">{money(o.totalCents,currency)}</td><td><Status value={o.status}/></td></tr>)}</tbody></table></div>}
      </Panel>
      <div className="info-footnote">* Отображаемая выручка — сумма завершённых заказов в этой платформе. Если реальный ресторан ведёт продажи в другой POS-системе, её показатели появятся здесь только после отдельной проверенной интеграции.</div>
    </>}
  </>;
}
