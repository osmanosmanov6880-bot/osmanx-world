'use client';
import {SessionProvider} from '../../lib/session';
import {AppShell} from '../../components/shell';
export default function WorkspaceLayout({children}:{children:React.ReactNode}){return <SessionProvider><AppShell>{children}</AppShell></SessionProvider>;}
