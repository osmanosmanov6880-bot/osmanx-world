'use client';
import {useCallback,useEffect,useState} from 'react';
import {Alert,Empty,PageHeading,Panel} from '../../../components/ui';
import {useScope} from '../../../lib/session';
import {type KitchenTicket,type FloorTable} from '../../../lib/types';

const columns=[{key:'SENT' as const,label:'Ожидают',hint:'Новые заказы'},
  {key:'PREPARING' as const,label:'Готовятся',hint:'На станции кухни'},
  {key:'READY' as const,label:'К выдаче',hint:'Ожидают официанта'}];
const canAdvance=(role:string,status:KitchenTicket['status'])=>{
  if(['owner','manager','operations_director'].includes(role))return true;
  return (role==='chef'||role==='kitchen')&&status!=='READY';
};
export default function Kitchen(){
  const {base,organization,api}=useScope();
  const [tickets,setTickets]=useState<KitchenTicket[]>([]),[tables,setTables]=useState<FloorTable[]>([]),[error,setError]=useState(''),[busy,setBusy]=useState(''),[updated,setUpdated]=useState('');
  const [clock,setClock]=useState(Date.now());
  const refresh=useCallback(async()=>{if(!base)return;
    const [data,floor]=await Promise.all([api<{tickets:KitchenTicket[]}>(`${base}/kitchen`),api<{tables:FloorTable[]}>(`${base}/floor`)]);
    setTickets(data.tickets);setTables(floor.tables);setUpdated(new Date().toLocaleTimeString('ru-RU'));setClock(Date.now());
  },[base,api]);
  useEffect(()=>{setError('');void refresh().catch(e=>setError(e.message));
    const polling=setInterval(()=>{void refresh().catch(()=>{});},10_000);
    const ticking=setInterval(()=>setClock(Date.now()),30_000);
    return ()=>{clearInterval(polling);clearInterval(ticking);};
  },[refresh]);
  async function advance(t:KitchenTicket){if(!base)return;
    const status=t.status==='SENT'?'PREPARING':t.status==='PREPARING'?'READY':'COMPLETED';
    setBusy(t.id);setError('');
    try{await api(`${base}/orders/${t.id}/status`,{method:'POST',idempotencyKey:crypto.randomUUID(),body:JSON.stringify({status,expectedRevision:t.revision})});await refresh();}
    catch(e){setError(e instanceof Error?e.message:'Не удалось обновить заказ');await refresh().catch(()=>{});}finally{setBusy('');}
  }
  const elapsed=(time:string|null)=>time?`${Math.max(0,Math.floor((clock-Date.parse(time))/60000))} мин`:'Время отправки неизвестно';
  return <><PageHeading eyebrow="OPERATIONS / LIVE KITCHEN" title="Кухонный экран" subtitle="Очередь приготовления по реальным заказам. Обновление каждые 10 секунд." action={<button className="gold-outline-button" onClick={()=>void refresh().catch(e=>setError(e.message))}>Обновить очередь</button>}/>
    {error&&<Alert text={error}/>}
    <div className="kitchen-summary"><span className="live-indicator"><span/>Синхронизация опросом</span><span className="small-muted">Последнее обновление: {updated||'ожидание ответа'}</span><span className="small-muted">В очереди: {tickets.length}</span></div>
    <div className="kds-grid">{columns.map(c=><Panel key={c.key} title={`${c.label} · ${tickets.filter(t=>t.status===c.key).length}`} subtitle={c.hint} className="kds-column">
      {tickets.filter(t=>t.status===c.key).length===0?<Empty title="Здесь пока пусто" description="Новые операции появятся после отправки заказа."/>:
        <div className="kds-stack">{tickets.filter(t=>t.status===c.key).map(t=><article key={t.id} className="kds-ticket">
          <div className="kds-ticket-head"><span className="eyebrow">#{t.id.slice(0,8).toUpperCase()}</span><span className="small-muted">{elapsed(t.sentAt)}</span></div>
          <h3>{t.tableId?tables.find(x=>x.id===t.tableId)?.label||'Стол':'Навынос'}</h3>
          <ul className="kds-lines">{t.items.map(i=><li key={i.id}><strong>{i.quantity}×</strong><span>{i.name}</span></li>)}</ul>
          {canAdvance(organization?.role||'',t.status)&&<button className="gold-button kds-action" disabled={busy!==''} onClick={()=>void advance(t)}>
            {busy===t.id?'Обновляем…':t.status==='SENT'?'Начать готовить':t.status==='PREPARING'?'Готово к выдаче':'Завершить обслуживание'}
          </button>}
        </article>)}</div>}
    </Panel>)}</div>
    <p className="info-footnote">Кухня меняет заказ только с учётом разрешений и версии записи. Для статуса «К выдаче» официант закрывает заказ через раздел заказов. Если соединение прервалось, время последнего обновления остаётся видимым.</p>
  </>;
}
