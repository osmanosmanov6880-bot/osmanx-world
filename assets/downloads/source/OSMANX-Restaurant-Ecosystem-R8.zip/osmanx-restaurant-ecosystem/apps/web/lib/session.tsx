'use client';
import {createContext,useContext,useEffect,useState,useCallback,useMemo,type ReactNode} from 'react';
import type {Branch,Me,Membership} from './types';

type ApiInit=RequestInit & {idempotencyKey?:string};
interface SessionContextType {
  session:Me|null; loading:boolean; loadError:string; organization:Membership|null; branch:Branch|null;
  pickOrganization:(id:string)=>void; pickBranch:(id:string)=>void;
  api:<T>(path:string,init?:ApiInit)=>Promise<T>; reload:()=>Promise<void>;
}
const Context=createContext<SessionContextType|null>(null);
export function SessionProvider({children}:{children:ReactNode}){
  const [session,setSession]=useState<Me|null>(null);
  const [loading,setLoading]=useState(true);
  const [loadError,setLoadError]=useState('');
  const [orgId,setOrgId]=useState('');
  const [branchId,setBranchId]=useState('');
  const reload=useCallback(async()=>{
    setLoadError('');
    try{
      const res=await fetch('/api/v1/me',{cache:'no-store',credentials:'same-origin'});
      if(res.status===401){window.location.assign('/login');return;}
      if(!res.ok)throw new Error('Не удалось получить данные аккаунта');
      const payload=await res.json() as Me;
      setSession(payload);
      setOrgId(prev=>payload.memberships.some(m=>m.organizationId===prev)?prev:(payload.memberships[0]?.organizationId||''));
    }catch(e){setLoadError(e instanceof Error?e.message:'Ошибка соединения');throw e;}finally{setLoading(false);}
  },[]);
  useEffect(()=>{void reload().catch(()=>setLoading(false));},[reload]);
  const organization=useMemo(()=>session?.memberships.find(m=>m.organizationId===orgId)||session?.memberships[0]||null,[session,orgId]);
  const branch=useMemo(()=>organization?.branches.find(b=>b.id===branchId)||organization?.branches[0]||null,[organization,branchId]);
  const api=useCallback(async<T,>(path:string,init:ApiInit={}):Promise<T>=>{
    const {idempotencyKey,...settings}=init;
    const headers=new Headers(settings.headers);
    if(settings.body && !headers.has('content-type'))headers.set('content-type','application/json');
    if(settings.method && settings.method.toUpperCase()!=='GET' && session?.csrfToken)headers.set('x-osmanx-csrf',session.csrfToken);
    if(idempotencyKey)headers.set('idempotency-key',idempotencyKey);
    const response=await fetch(path,{...settings,headers,credentials:'same-origin',cache:'no-store'});
    const payload=await response.json().catch(()=>({}));
    if(!response.ok)throw new Error(payload?.error?.message||`Ошибка сервера ${response.status}`);
    return payload as T;
  },[session?.csrfToken]);
  return <Context.Provider value={{session,loading,loadError,organization,branch,pickOrganization:setOrgId,pickBranch:setBranchId,api,reload}}>{children}</Context.Provider>;
}
export function useSession(){const value=useContext(Context);if(!value)throw new Error('SessionProvider отсутствует');return value;}
export function useScope(){
  const s=useSession();
  return {...s,base:s.organization&&s.branch?`/api/v1/organizations/${s.organization.organizationId}/branches/${s.branch.id}`:null};
}
