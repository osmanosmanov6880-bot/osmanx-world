export interface Branch {id:string;name:string;timezone:string;}
export interface Membership {organizationId:string;organizationName:string;currency:string;role:string;branches:Branch[];}
export interface Me {user:{id:string;email:string;displayName:string};memberships:Membership[];csrfToken:string;}
export interface MenuItem {id:string;name:string;priceCents:number;active:boolean;revision:number;}
export interface DiningTable {id:string;label:string;capacity:number;}
export type OrderStatus='OPEN'|'SENT'|'PREPARING'|'READY'|'COMPLETED'|'CANCELLED';
export interface OrderLine {id:string;menuItemId:string;name:string;unitPriceCents:number;quantity:number;lineTotalCents:number;}
export interface Order {id:string;guestId:string|null;tableId:string|null;status:OrderStatus;totalCents:number;revision:number;createdAt:string;items:OrderLine[];actualFoodCostCents:number|null;missingRecipeLines:number|null;foodCostComplete:boolean;}
export type ReservationStatus='CONFIRMED'|'SEATED'|'COMPLETED'|'CANCELLED'|'NO_SHOW';
export interface Reservation {id:string;tableId:string;guestName:string;partySize:number;startsAt:string;endsAt:string;status:ReservationStatus;revision:number;orderId:string|null;createdAt:string;}
export interface FloorTable extends DiningTable {state:'AVAILABLE'|'OCCUPIED'|'RESERVED';activeOrderId:string|null;reservationId:string|null;nextReservationAt:string|null;}
export interface KitchenTicket {id:string;tableId:string|null;status:'SENT'|'PREPARING'|'READY';sentAt:string|null;preparingAt:string|null;readyAt:string|null;revision:number;items:OrderLine[];}
export interface Shift {id:string;userId:string;employeeName:string;status:'OPEN'|'CLOSED';openedAt:string;closedAt:string|null;openingNote:string;closingNote:string;revision:number;}
export interface Employee {id:string;displayName:string;role:string;}
export const RESERVATION_LABELS:Record<ReservationStatus,string>={CONFIRMED:'Подтверждена',SEATED:'Гости за столом',COMPLETED:'Посещение завершено',CANCELLED:'Отменена',NO_SHOW:'Неявка'};
export function dateTime(value:string){return new Date(value).toLocaleString('ru-RU',{dateStyle:'short',timeStyle:'short'});}
export interface Dashboard {lowStockCount:number;revenueCents:number;completedOrders:number;averageCheckCents:number;activeOrders:number;menuItems:number;tables:number;series:{day:string;revenueCents:number}[];recentOrders:Order[];}
export function money(cents:number,currency='RUB') {
  return new Intl.NumberFormat('ru-RU',{style:'currency',currency,maximumFractionDigits:2,minimumFractionDigits:0}).format(cents/100);
}
export function parseMoney(value:string):number {
  const trimmed=value.trim().replace(',','.');
  if(!/^\d{1,10}(\.\d{1,2})?$/.test(trimmed))throw new Error('Цена должна быть положительным числом с максимум 2 знаками после запятой');
  const [whole,fraction='']=trimmed.split('.');
  const cents=Number(whole)*100+Number(fraction.padEnd(2,'0'));
  if(!Number.isSafeInteger(cents)||cents>999_999_999_999)throw new Error('Превышен предел стоимости');
  return cents;
}
export const STATUS_LABELS:Record<OrderStatus,string>={OPEN:'Новый',SENT:'На кухне',PREPARING:'Готовится',READY:'Готов',COMPLETED:'Завершён',CANCELLED:'Отменён'};

export type StockUnit='g'|'ml'|'pcs';
export interface Ingredient {id:string;name:string;unit:StockUnit;minQuantityMilli:number;quantityMilli:number;valueCents:number;revision:number;lowStock:boolean;}
export interface RecipeComponent {ingredientId:string;name:string;unit:StockUnit;quantityMilli:number;}
export interface Recipe {menuItemId:string;revision:number;components:RecipeComponent[];}
export interface Supplier {id:string;name:string;}
export interface ReceiptLine {ingredientId:string;name:string;quantityMilli:number;totalCostCents:number;}
export interface Receipt {id:string;supplierId:string|null;reference:string;totalCostCents:number;receivedAt:string;lines:ReceiptLine[];}
export interface StockMovement {id:string;ingredientId:string;ingredientName:string;deltaQuantityMilli:number;deltaValueCents:number;reason:'RECEIPT'|'ORDER'|'COUNT';createdAt:string;sourceId:string;}
export interface StockCount {id:string;ingredientId:string;beforeQuantityMilli:number;countedQuantityMilli:number;deltaQuantityMilli:number;deltaValueCents:number;}
export type TaskStatus='OPEN'|'IN_PROGRESS'|'DONE'|'CANCELLED';
export interface RestaurantTask {id:string;title:string;description:string;assignedTo:string|null;employeeName:string|null;createdBy:string;status:TaskStatus;dueAt:string|null;completedAt:string|null;revision:number;createdAt:string;}
export const UNIT_LABELS:Record<StockUnit,string>={g:'г',ml:'мл',pcs:'шт.'};
export function formatQty(milli:number){return (milli/1000).toLocaleString('ru-RU',{maximumFractionDigits:3});}
export function parseQty(value:string,zero=false){
  const raw=value.trim().replace(',','.');
  if(!/^\d{1,9}(?:\.\d{1,3})?$/.test(raw))throw new Error('Количество: до 9 цифр и 3 знаков после запятой');
  const [whole,fraction='']=raw.split('.');
  const n=Number(whole)*1000+Number(fraction.padEnd(3,'0'));
  if(!Number.isSafeInteger(n)||n>999_999_999_999||(!zero&&n<=0))throw new Error('Количество вне допустимых пределов');
  return n;
}

// R4: Accounting amounts are always integer minor units; missing costs are nullable.
export const FINANCE_CATEGORY_NAMES={
  REVENUE:'Выручка',FOOD_COST:'Себестоимость блюд',PAYROLL:'Фонд оплаты труда',RENT:'Аренда',
  UTILITIES:'Коммунальные расходы',MARKETING:'Маркетинг',SERVICES:'Услуги и сервисы',OTHER:'Прочие расходы'
} as const;
export type FinanceCategory=keyof typeof FINANCE_CATEGORY_NAMES;
export type ExpenseCategory=Exclude<FinanceCategory,'REVENUE'|'FOOD_COST'>;
export interface FinanceExpense {id:string;category:ExpenseCategory;description:string;occurredOn:string;amountCents:number;status:'POSTED'|'VOIDED';revision:number;createdAt:string;voidedAt:string|null;voidReason:string|null;}
export interface FinanceBudget {period:string;category:FinanceCategory;amountCents:number;revision:number;}
export interface FinancePlanFact {category:FinanceCategory;plannedCents:number|null;actualCents:number|null;varianceCents:number|null;}
export interface FinanceReport {
  period:string;revenueCents:number;completedOrders:number;uncostedOrders:number;
  knownFoodCostCents:number;foodCostCents:number|null;stockLossCents:number;
  expensesCents:number;laborCostCents:number;expensesByCategory:Record<ExpenseCategory,number>;
  grossProfitCents:number|null;operatingResultCents:number|null;
  foodCostRateBps:number|null;laborCostRateBps:number|null;operatingMarginBps:number|null;
  planFact:FinancePlanFact[];expenseCoverage:'UNVERIFIED';
}
export interface FinanceLedgerEntry {id:string;source:'ORDER'|'FOOD_COST'|'EXPENSE'|'STOCK_LOSS';sourceId:string;description:string;occurredAt:string;signedAmountCents:number;complete:boolean;}
export interface FinanceNetwork {period:string;currency:string;branches:{id:string;name:string;report:FinanceReport}[];totals:FinanceReport;}
export function rateText(bps:number|null){return bps===null?'Нет базы':`${(bps/100).toLocaleString('ru-RU',{maximumFractionDigits:2})}%`;}

// R5: guest identity is explicit, branch-scoped, and never inferred from name alone.
export interface Guest {id:string;displayName:string;email:string|null;phone:string|null;revision:number;createdAt:string;}
export interface Consent {guestId:string;channel:'EMAIL'|'SMS';state:'GRANTED'|'REVOKED';evidence:string|null;revision:number;recordedAt:string;}
export interface GuestVisit {orderId:string;completedAt:string;totalCents:number;}
export interface GuestScore {guestId:string;visits365:number;spend365Cents:number;lastVisitAt:string|null;recencyDays:number|null;recencyScore:number|null;frequencyScore:number|null;monetaryScore:number|null;segment:'NEW'|'LOYAL'|'AT_RISK'|'OTHER'|'NO_VISITS';}
export interface GuestInsights {asOf:string;windowDays:number;totalCompletedOrders:number;identifiedCompletedOrders:number;identificationCoveragePercent:number|null;identifiedGuestsWithVisits:number;repeatGuests:number;repeatShareOfIdentifiedPercent:number|null;monetaryScoringAvailable:boolean;guests:GuestScore[];limitations:string[];}
export interface GuestFeedback {id:string;guestId:string|null;orderId:string|null;kind:'COMPLAINT'|'COMPLIMENT'|'SUGGESTION';rating:number|null;comment:string|null;status:'OPEN'|'RESOLVED';resolution:string|null;revision:number;createdAt:string;resolvedAt:string|null;}
export const GUEST_SEGMENT_LABELS:Record<GuestScore['segment'],string>={NEW:'Первый заказ',LOYAL:'Частые визиты',AT_RISK:'Нет визитов более 90 дней',OTHER:'Другой профиль',NO_VISITS:'Нет завершённых заказов'};
export const FEEDBACK_KIND_LABELS:Record<GuestFeedback['kind'],string>={COMPLAINT:'Жалоба',COMPLIMENT:'Благодарность',SUGGESTION:'Предложение'};
