export interface Criterion {id:string;title:string;weight:number;critical:boolean;}
export interface Standard {id:string;title:string;description:string;revision:number;active:boolean;criteria:Criterion[];createdAt:string;updatedAt:string;}
export interface AuditAnswer {criterionId:string;title:string;weight:number;critical:boolean;passed:boolean;note:string;}
export interface Audit {id:string;branchId:string;standardId:string;standardTitle:string;standardRevision:number;scoreBps:number;criticalFailures:number;failedCount:number;performedAt:string;answers:AuditAnswer[];}
export type ActionStatus='OPEN'|'IN_PROGRESS'|'RESOLVED';
export interface NetworkAction {id:string;branchId:string;auditId:string;standardId:string;standardRevision:number;criterionId:string;title:string;status:ActionStatus;revision:number;createdAt:string;updatedAt:string;resolution:string|null;branchName?:string;}
export interface BranchQuality {branchId:string;branchName:string;scoreBps:number|null;auditAt:string|null;criticalFailures:number|null;openActions:number;outdated:boolean;}
export interface Quality {standardId:string|null;standardTitle:string|null;standardRevision:number|null;branches:BranchQuality[];comparable:boolean;limitations:string[];}
export const score=(bps:number|null)=>bps===null?'Нет актуальной оценки':`${(bps/100).toLocaleString('ru-RU',{maximumFractionDigits:2})}%`;
export const prettyDate=(v:string|null)=>v?new Date(v).toLocaleString('ru-RU'):'—';
