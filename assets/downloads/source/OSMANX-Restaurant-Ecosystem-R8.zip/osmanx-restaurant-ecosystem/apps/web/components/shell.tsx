'use client';
import {useState} from 'react';
import Link from 'next/link';
import {usePathname} from 'next/navigation';
import {useSession} from '../lib/session';
import {InfinityLogo} from './ui';
const routes=[
  {path:'/app',label:'Обзор бизнеса',num:'01'},
  {path:'/app/orders',label:'Заказы',num:'02'},
  {path:'/app/kitchen',label:'Кухонный экран',num:'03'},
  {path:'/app/reservations',label:'Бронирования',num:'04'},
  {path:'/app/menu',label:'Меню и цены',num:'05'},
  {path:'/app/tables',label:'Зал и столы',num:'06'},
  {path:'/app/shifts',label:'Рабочие смены',num:'07'},
  {path:'/app/inventory',label:'Склад и остатки',num:'08'},
  {path:'/app/recipes',label:'Рецептуры блюд',num:'09'},
  {path:'/app/purchasing',label:'Закупки',num:'10'},
  {path:'/app/tasks',label:'Задачи',num:'11'},
  {path:'/app/branches',label:'Моя сеть',num:'12'},
  {path:'/app/team',label:'Сотрудники',num:'13'},
  {path:'/app/finance',label:'Финансы и P&L',num:'14'},
  {path:'/app/network',label:'Финансы сети',num:'15'},
  {path:'/app/guests',label:'Гости и CRM',num:'16'},
  {path:'/app/guest-insights',label:'Возвращаемость гостей',num:'17'},
  {path:'/app/feedback',label:'Отзывы и обращения',num:'18'},
  {path:'/app/intelligence',label:'OSMANX Intelligence',num:'19'},
  {path:'/app/standards',label:'Стандарты сети',num:'20'},
  {path:'/app/audits',label:'Аудиты и нарушения',num:'21'},
  {path:'/app/network-quality',label:'Качество сети',num:'22'},
  {path:'/app/integrations',label:'Интеграции с POS',num:'23'},
];
export function AppShell({children}:{children:React.ReactNode}){
  const {session,loading,loadError,reload,organization,branch,pickOrganization,pickBranch,api}=useSession();
  const [menuOpen,setMenuOpen]=useState(false);
  const path=usePathname();
  const visibleRoutes=routes.filter(r=>{
    const role=organization?.role||'';
    if(r.path==='/app')return ['owner','finance_director','operations_director','manager','analyst','auditor'].includes(role);
    if(r.path==='/app/kitchen')return ['owner','operations_director','manager','chef','kitchen','waiter','cashier','auditor'].includes(role);
    if(r.path==='/app/reservations')return ['owner','operations_director','manager','waiter','cashier','analyst','auditor'].includes(role);
    if(r.path==='/app/team')return role==='owner';
    if(r.path==='/app/guests')return ['owner','operations_director','manager','marketer','waiter','cashier'].includes(role);
    if(r.path==='/app/guest-insights')return ['owner','operations_director','manager','marketer','analyst','auditor'].includes(role);
    if(r.path==='/app/feedback')return ['owner','operations_director','manager','marketer','analyst','auditor','waiter','cashier'].includes(role);
    if(r.path==='/app/integrations')return ['owner','finance_director','operations_director','manager','analyst','auditor'].includes(role);
    if(r.path==='/app/standards'||r.path==='/app/audits'||r.path==='/app/network-quality')return ['owner','finance_director','operations_director','manager','chef','analyst','auditor'].includes(role);
    if(r.path==='/app/intelligence')return ['owner','finance_director','operations_director','manager','analyst','auditor'].includes(role);
    if(r.path==='/app/finance'||r.path==='/app/network')return ['owner','finance_director','operations_director','manager','analyst','auditor'].includes(role);
    if(r.path==='/app/inventory')return ['owner','finance_director','operations_director','manager','chef','analyst','auditor'].includes(role);
    if(r.path==='/app/recipes')return ['owner','finance_director','operations_director','manager','chef','analyst','auditor'].includes(role);
    if(r.path==='/app/purchasing')return ['owner','finance_director','operations_director','manager','chef','analyst','auditor'].includes(role);
    return true;
  });
  const [signingOut,setSigningOut]=useState(false);const [logoutError,setLogoutError]=useState('');
  async function logout(){try{setLogoutError('');setSigningOut(true);await api('/api/v1/auth/logout',{method:'POST'});window.location.assign('/login');}catch(e){setLogoutError(e instanceof Error?e.message:'Не удалось завершить сессию');setSigningOut(false);}}
  if(loading)return <div className="boot-screen"><InfinityLogo/><span>Подключаем рабочее пространство…</span></div>;
  if(!session)return <div className="boot-screen">{loadError||"Нет активной сессии."} <button type="button" className="small-button" onClick={()=>void reload().catch(()=>{})}>Повторить</button> <Link href="/login">Войти</Link></div>;
  return <div className="app-layout">
    {menuOpen&&<button type="button" aria-label="Закрыть меню" className="nav-scrim" onClick={()=>setMenuOpen(false)}/>}
    <aside className={`sidebar ${menuOpen?'sidebar-open':''}`} aria-label="Главная навигация">
      <div className="brand"><InfinityLogo/><div><strong>OSMANX.WORLD</strong><small>RESTAURANT ECOSYSTEM</small></div></div>
      <div className="nav-caption">РАБОЧЕЕ ПРОСТРАНСТВО</div>
      <nav className="side-nav">{visibleRoutes.map(r=><Link key={r.path} href={r.path} onClick={()=>setMenuOpen(false)} aria-current={path===r.path?'page':undefined} className={`nav-link ${path===r.path?'nav-active':''}`}><span className="nav-number">{r.num}</span><span>{r.label}</span></Link>)}</nav>
      <div className="sidebar-foot"><span className="online-dot"/> R8 · POS Integrations<div className="foot-divider"/><span className="small-muted">{session.user.email}</span></div>
    </aside>
    <div className="workspace">
      <header className="topbar"><div className="topbar-left"><button className="menu-toggle" type="button" aria-label={menuOpen?'Закрыть навигацию':'Открыть навигацию'} aria-expanded={menuOpen} onClick={()=>setMenuOpen(!menuOpen)}><span/><span/><span/></button><span className="topbar-title">Операционная система ресторана</span></div>
        <div className="topbar-actions">{session.memberships.length>1&&<label className="select-label">Организация<select value={organization?.organizationId||''} onChange={e=>pickOrganization(e.target.value)}>{session.memberships.map(o=><option key={o.organizationId} value={o.organizationId}>{o.organizationName}</option>)}</select></label>}
        {organization&&<label className="select-label">Филиал<select value={branch?.id||''} onChange={e=>pickBranch(e.target.value)}>{organization.branches.map(b=><option key={b.id} value={b.id}>{b.name}</option>)}</select></label>}
        <button className="text-button logout" onClick={logout} disabled={signingOut}>{signingOut?'Выход…':'Выйти'}</button></div>
      </header>
      <main className="page-content">{logoutError&&<p role="alert" className="alert">{logoutError}</p>}{branch?children:<div className="panel"><h2>Нет доступных филиалов</h2><p>Попросите владельца сети предоставить доступ к ресторану.</p></div>}</main>
      <footer className="workspace-footer">OSMANX.WORLD <span>© 2026 · Данные без демонстрационных значений</span></footer>
    </div>
  </div>;
}
