import type {ReactNode} from 'react';
import type {OrderStatus} from '../lib/types';
import {STATUS_LABELS} from '../lib/types';
export function InfinityLogo({small=false}:{small?:boolean}){
  return <div className={`brand-mark${small?' brand-mark-small':''}`} aria-hidden="true"><svg viewBox="0 0 100 56" fill="none" role="presentation"><path d="M49.8 27.8C40.4 13.8 31.5 11.2 22.4 11.2 10.2 11.2 5.8 19.5 5.8 28.4S11.2 45 22.3 45c11.1 0 18.1-9.2 27.5-17.2C59.3 13.4 69.8 11 78.7 11 90.5 11 95 19.2 95 28.2c0 9.3-5.4 16.8-16.5 16.8-10.7 0-18.8-8.9-28.7-17.2Z" stroke="url(#gold)" strokeWidth="5" strokeLinecap="round"/><defs><linearGradient id="gold" x1="0" x2="100" y1="0" y2="56"><stop stopColor="#8C642E"/><stop offset=".45" stopColor="#F6DAA0"/><stop offset="1" stopColor="#B98A48"/></linearGradient></defs></svg></div>;
}
export function Panel({title,subtitle,action,children,className=''}:{title?:string;subtitle?:string;action?:ReactNode;children:ReactNode;className?:string}){
  return <section className={`panel ${className}`}>{title&&<div className="panel-head"><div><h2>{title}</h2>{subtitle&&<p>{subtitle}</p>}</div>{action}</div>}{children}</section>;
}
export function PageHeading({eyebrow,title,subtitle,action}:{eyebrow:string;title:string;subtitle:string;action?:ReactNode}){
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>{action}</div>;
}
export function Empty({title='Пока нет данных',description='Записи появятся после первой операции.'}:{title?:string;description?:string}){
  return <div className="empty"><div className="empty-orbit" aria-hidden="true">∞</div><strong>{title}</strong><p>{description}</p></div>;
}
export function Alert({text}:{text:string}){return <div className="alert" role="alert">{text}</div>;}
export function Status({value}:{value:OrderStatus}){return <span className={`status status-${value.toLowerCase()}`}>{STATUS_LABELS[value]}</span>;}
