import {test,expect} from '@playwright/test';

for (const scenario of ['food-cost','tasks'] as const) test(`R3 ${scenario}: real restaurant operations`,async({page},info)=>{
  const mobile=info.project.name.includes('mobile');
  async function navigate(link:RegExp){
    if(mobile)await page.getByRole('button',{name:'Открыть навигацию'}).click();
    await page.locator('nav.side-nav').getByRole('link',{name:link}).click();
  }
  const id=`${Date.now()}-${info.project.name.replace(/\W/g,'')}-r3-${scenario}`;
  await page.goto('/login');
  await page.getByRole('button',{name:'Создать аккаунт'}).click();
  await page.getByLabel('Ваше имя').fill('R3 Владелец');
  await page.getByLabel('Название компании').fill(`OSMANX R3 ${id}`);
  await page.getByLabel('Название первого ресторана').fill('Контрольный ресторан');
  await page.getByLabel('Рабочий email').fill(`e2e-${id}@example.test`);
  await page.getByLabel('Пароль').fill('TestSecurePassword-1234');
  await page.getByRole('button',{name:'Создать организацию'}).click();
  await expect(page.getByRole('heading',{name:'Обзор бизнеса'})).toBeVisible();
  if(scenario==='tasks'){
    await navigate(/Задачи/);
    await page.getByPlaceholder('Проверить остатки на складе').fill('Проверить холодильник');
    await page.getByRole('button',{name:'Назначить'}).click();
    await expect(page.locator('.r3-task').first()).toContainText('Проверить холодильник');
    await page.getByRole('button',{name:'Взять в работу'}).click();
    await expect(page.locator('.r3-task').first()).toContainText('В работе');
    await page.getByRole('button',{name:'Завершить'}).click();
    await expect(page.locator('.r3-task').first()).toContainText('Выполнена');
    return;
  }
  await navigate(/Склад и остатки/);
  await page.getByPlaceholder('Например, кофе арабика').fill('Арабика R3');
  await page.getByRole('button',{name:'Добавить',exact:true}).click();
  await expect(page.getByRole('cell',{name:'Арабика R3'})).toBeVisible();
  await navigate(/Закупки/);
  await page.getByPlaceholder('Название поставщика').fill('Поставщик R3');
  await page.getByRole('button',{name:'Добавить поставщика'}).click();
  await page.getByRole('combobox',{name:'Поставщик'}).selectOption({index:1});
  await page.getByRole('combobox',{name:'Ингредиент'}).selectOption({index:1});
  await page.getByRole('textbox',{name:'Количество'}).fill('100');
  await page.getByRole('textbox',{name:/Общая стоимость/}).fill('100');
  await page.getByRole('button',{name:'Провести поступление'}).click();
  await expect(page.getByRole('table').first()).toContainText('Арабика R3');
  await navigate(/Меню и цены/);
  await page.getByPlaceholder('Например, капучино').fill('Эспрессо R3');
  await page.getByPlaceholder('390.00').fill('350');
  await page.getByRole('button',{name:'Добавить в меню'}).click();
  await navigate(/Рецептуры блюд/);
  await expect(page.getByRole('heading',{name:'Рецептуры блюд'})).toBeVisible();
  await expect(page.getByRole('combobox',{name:'Блюдо'})).toHaveValue(/.+/);
  await page.getByRole('combobox',{name:'Ингредиент'}).selectOption({index:1});
  await page.getByRole('textbox',{name:'Количество'}).fill('18');
  await page.getByRole('button',{name:'Сохранить рецептуру'}).click();
  await expect(page.getByRole('status').filter({hasText:'Рецептура сохранена'})).toBeVisible();
  await navigate(/Заказы/);
  await page.getByRole('button',{name:'Создать заказ'}).click();
  await page.getByRole('combobox',{name:'Блюдо'}).selectOption({index:1});
  await page.getByRole('button',{name:'Добавить блюдо'}).click();
  for(const action of ['На кухню','Начать готовить','Готово','Закрыть заказ'])await page.getByRole('button',{name:action,exact:true}).click();
  await expect(page.locator('.r3-order-cost')).toContainText('18');
  await navigate(/Склад и остатки/);
  await expect(page.getByRole('row',{name:/Арабика R3/})).toContainText('82');
  const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth+1);
  expect(overflow).toBe(false);
});
