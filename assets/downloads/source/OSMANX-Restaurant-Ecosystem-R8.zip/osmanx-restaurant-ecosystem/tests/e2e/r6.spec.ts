import {test,expect} from '@playwright/test';

test('R6: observable missing-cost signal -> decision, status and responsive page',async({page},info)=>{
  const mobile=info.project.name.includes('mobile');
  const id=`${Date.now()}-${info.project.name.replace(/\W/g,'')}-r6`;
  async function navigate(label:RegExp){if(mobile)await page.getByRole('button',{name:'Открыть навигацию'}).click();
    await page.locator('nav.side-nav').getByRole('link',{name:label}).click();}
  await page.goto('/login');
  await page.getByRole('button',{name:'Создать аккаунт'}).click();
  await page.getByLabel('Ваше имя').fill('Интеллектуальная диагностика');
  await page.getByLabel('Название компании').fill(`OSMANX R6 ${id}`);
  await page.getByLabel('Название первого ресторана').fill('Ресторан R6');
  await page.getByLabel('Рабочий email').fill(`r6-${id}@example.test`);
  await page.getByLabel('Пароль').fill('SecureR6Password-12345');
  await page.getByRole('button',{name:'Создать организацию'}).click();
  await navigate(/Меню и цены/);
  await page.getByPlaceholder('Например, капучино').fill('Блюдо R6 без рецепта');
  await page.getByPlaceholder('390.00').fill('250');
  await page.getByRole('button',{name:'Добавить в меню'}).click();
  await navigate(/Заказы/);
  await page.getByRole('button',{name:'Создать заказ'}).click();
  await page.getByRole('combobox',{name:'Блюдо'}).selectOption({index:1});
  await page.getByRole('button',{name:'Добавить блюдо'}).click();
  for(const status of ['На кухню','Начать готовить','Готово','Закрыть заказ'])
    await page.getByRole('button',{name:status,exact:true}).click();
  await navigate(/OSMANX Intelligence/);
  await expect(page.getByRole('heading',{name:'OSMANX Intelligence'})).toBeVisible();
  await expect(page.getByText('Себестоимость рассчитана не для всех заказов')).toBeVisible();
  await page.getByRole('button',{name:'Создать управленческую гипотезу'}).click();
  await page.getByRole('button',{name:'Сохранить',exact:true}).click();
  await expect(page.getByText('Гипотеза сохранена')).toBeVisible();
  await page.getByRole('button',{name:'Начать'}).click();
  await expect(page.getByText('В работе')).toBeVisible();
  expect(await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth+1)).toBe(false);
});
