import {test,expect} from '@playwright/test';

for(const screen of ['financials','network'] as const){
  test(`R4 ${screen}: manual expense, budget and branch financial view`,async({page},info)=>{
    const mobile=info.project.name.includes('mobile');
    const uid=`${Date.now()}-${info.project.name.replace(/\W/g,'')}-${screen}`;
    await page.goto('/login');
    await page.getByRole('button',{name:'Создать аккаунт'}).click();
    await page.getByLabel('Ваше имя').fill('R4 Владелец');
    await page.getByLabel('Название компании').fill(`R4 Test ${uid}`);
    await page.getByLabel('Название первого ресторана').fill('Restaurant Central');
    await page.getByLabel('Рабочий email').fill(`r4-${uid}@example.test`);
    await page.getByLabel('Пароль').fill('R4StrongPassword-012345');
    await page.getByRole('button',{name:'Создать организацию'}).click();
    await expect(page.getByRole('heading',{name:'Обзор бизнеса'})).toBeVisible();
    const navigate=async(name:RegExp)=>{
      if(mobile)await page.getByRole('button',{name:'Открыть навигацию'}).click();
      await page.locator('nav.side-nav').getByRole('link',{name}).click();
    };
    await navigate(/Финансы и P&L/);
    await expect(page.getByRole('heading',{name:'Финансы и прибыль'})).toBeVisible();
    await expect(page.locator('.r4-pnl-row').last()).toContainText('0');
    await page.getByRole('textbox',{name:'Описание расхода'}).fill('Аренда за период');
    await page.getByRole('textbox',{name:'Сумма расхода'}).fill('150');
    await page.getByRole('button',{name:'Провести расход'}).click();
    await expect(page.getByRole('status').filter({hasText:'Расход проведён'})).toBeVisible();
    await expect(page.locator('.r4-pnl-row').filter({hasText:'Операционные расходы'})).toContainText('150');
    const plan=page.getByRole('textbox',{name:'План: Выручка'});
    await plan.fill('1000');
    await page.locator('.r4-plan-table tbody tr').first().getByRole('button',{name:'Задать план'}).click();
    await expect(page.getByRole('status').filter({hasText:'План «Выручка» сохранён'})).toBeVisible();
    await expect(page.locator('.r4-plan-table tbody tr').first()).toContainText('1 000');
    if(screen==='network'){
      await navigate(/Финансы сети/);
      await expect(page.getByRole('heading',{name:'Финансы ресторанной сети'})).toBeVisible();
      await expect(page.getByRole('table').first()).toContainText('Restaurant Central');
      await expect(page.getByRole('table').first()).toContainText('150');
      await page.getByRole('link',{name:'Открыть финансовый отчёт'}).click();
      await expect(page.getByRole('heading',{name:'Финансы и прибыль'})).toBeVisible();
    }else{
      await page.getByRole('button',{name:'Аннулировать'}).click();
      await page.getByRole('textbox',{name:'Причина аннулирования'}).fill('Дубль документа');
      await page.getByRole('button',{name:'Подтвердить'}).click();
      await expect(page.getByRole('status').filter({hasText:'Расход аннулирован'})).toBeVisible();
      await expect(page.getByRole('table').last()).toContainText('Аннулирован');
      await expect(page.locator('.r4-pnl-row').filter({hasText:'Операционные расходы'})).toContainText('0');
    }
    expect(await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth+1)).toBe(false);
  });
}
