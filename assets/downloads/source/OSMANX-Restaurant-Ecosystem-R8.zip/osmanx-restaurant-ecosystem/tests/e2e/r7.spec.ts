import {test,expect} from '@playwright/test';

test('R7: owner defines standard, audits branch, resolves violation and views network quality',async({page},info)=>{
  const mobile=info.project.name.includes('mobile');
  const suffix=`${Date.now()}-${info.project.name.replace(/\W/g,'')}-r7`;
  async function navigate(label:RegExp){if(mobile)await page.getByRole('button',{name:'Открыть навигацию'}).click();
    await page.locator('nav.side-nav').getByRole('link',{name:label}).click();}
  await page.goto('/login');
  await page.getByRole('button',{name:'Создать аккаунт'}).click();
  await page.getByLabel('Ваше имя').fill('Проверяющий сети');
  await page.getByLabel('Название компании').fill(`OSMANX R7 ${suffix}`);
  await page.getByLabel('Название первого ресторана').fill('Ресторан R7');
  await page.getByLabel('Рабочий email').fill(`r7-${suffix}@example.test`);
  await page.getByLabel('Пароль').fill('SecureR7Password-12345');
  await page.getByRole('button',{name:'Создать организацию'}).click();
  await navigate(/Стандарты сети/);
  await page.getByRole('heading',{name:'Стандарты ресторанной сети'}).waitFor();
  await page.getByLabel('Название стандарта').fill('Стандарт кухни');
  await page.getByLabel('Описание').fill('Проверка качества ресторана');
  await page.getByLabel('Требование 1').fill('Температура хранения');
  await page.getByLabel('Вес (1–10)').fill('5');
  await page.getByLabel('Критический пункт').check();
  await page.getByRole('button',{name:'Создать стандарт'}).click();
  await expect(page.getByText('Стандарт сохранён. Проверки старых редакций останутся в истории.')).toBeVisible();
  await navigate(/Аудиты и нарушения/);
  await expect(page.getByRole('heading',{name:'Аудиты и нарушения'})).toBeVisible();
  await page.getByLabel('Есть нарушение').check();
  await page.getByLabel('Описание нарушения').fill('Зафиксировано нарушение температуры холодильника');
  await page.getByRole('button',{name:'Зафиксировать аудит'}).click();
  await expect(page.getByText('Аудит зафиксирован; нарушения добавлены в корректирующие действия.')).toBeVisible();
  await expect(page.getByText('Критических нарушений: 1')).toHaveCount(0); // No invented global KPI.
  await page.getByRole('button',{name:'Взять в работу'}).click();
  await page.getByLabel(/Подтверждение устранения/).fill('Исправлена температура и проведена повторная проверка');
  await page.getByRole('button',{name:'Подтвердить устранение'}).click();
  await expect(page.getByText('Закрыто')).toBeVisible();
  await navigate(/Качество сети/);
  await expect(page.getByRole('heading',{name:'Качество ресторанной сети'})).toBeVisible();
  await expect(page.getByText('Ресторан R7')).toBeVisible();
  await expect(page.getByText('Не подтверждена')).toBeVisible(); // One branch is not a ranked network.
  expect(await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth+1)).toBe(false);
});
