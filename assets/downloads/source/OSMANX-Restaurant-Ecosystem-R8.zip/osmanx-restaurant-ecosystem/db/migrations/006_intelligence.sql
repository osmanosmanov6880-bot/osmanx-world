-- R6: hypotheses and observed outcomes, strictly branch-scoped.
CREATE TABLE IF NOT EXISTS intelligence_decisions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 organization_id uuid NOT NULL,
 branch_id uuid NOT NULL,
 actor_id uuid NOT NULL REFERENCES users(id),
 signal_id varchar(80) NOT NULL,
 title varchar(160) NOT NULL,
 hypothesis text NOT NULL,
 action text NOT NULL,
 baseline_period char(7) NOT NULL CHECK (baseline_period ~ '^(20[0-9]{2}|2100)-(0[1-9]|1[0-2])$'),
 review_period char(7),
 implementation_cost_cents bigint CHECK (implementation_cost_cents BETWEEN 0 AND 9999999999999),
 status varchar(24) NOT NULL DEFAULT 'PROPOSED' CHECK (status IN ('PROPOSED','IN_PROGRESS','IMPLEMENTED','REVIEWED','CANCELLED')),
 revision integer NOT NULL DEFAULT 1 CHECK (revision > 0),
 baseline_revenue_cents bigint NOT NULL,
 baseline_profit_cents bigint,
 observed_revenue_cents bigint,
 observed_profit_cents bigint,
 observed_profit_delta_cents bigint,
 observation text,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id)
);
CREATE INDEX IF NOT EXISTS intelligence_decisions_scope_idx ON intelligence_decisions(organization_id,branch_id,created_at DESC);
CREATE TABLE IF NOT EXISTS intelligence_commands (
 organization_id uuid NOT NULL,
 branch_id uuid NOT NULL,
 actor_id uuid NOT NULL,
 idempotency_key varchar(120) NOT NULL,
 fingerprint text NOT NULL,
 result jsonb NOT NULL,
 PRIMARY KEY (organization_id,branch_id,actor_id,idempotency_key),
 FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id)
);
