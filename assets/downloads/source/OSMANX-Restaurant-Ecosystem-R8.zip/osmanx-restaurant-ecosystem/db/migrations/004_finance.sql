-- R4: immutable financial amounts; voiding retains a full audit trail.
-- Purchase receipts increase inventory assets and MUST NOT also become operating expenses.
CREATE TABLE finance_expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,
  branch_id uuid NOT NULL,
  category varchar(20) NOT NULL CHECK (category IN ('PAYROLL','RENT','UTILITIES','MARKETING','SERVICES','OTHER')),
  occurred_on date NOT NULL,
  description varchar(500) NOT NULL,
  amount_cents bigint NOT NULL CHECK (amount_cents BETWEEN 1 AND 9999999999999),
  status varchar(12) NOT NULL DEFAULT 'POSTED' CHECK(status IN ('POSTED','VOIDED')),
  revision integer NOT NULL DEFAULT 1 CHECK (revision > 0),
  created_by uuid NOT NULL REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  voided_by uuid REFERENCES users(id),
  voided_at timestamptz,
  void_reason varchar(500),
  UNIQUE(organization_id,branch_id,id),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id) ON DELETE CASCADE,
  CONSTRAINT finance_expenses_void_guard CHECK (
    (status='POSTED' AND voided_by IS NULL AND voided_at IS NULL AND void_reason IS NULL)
    OR (status='VOIDED' AND voided_by IS NOT NULL AND voided_at IS NOT NULL AND void_reason IS NOT NULL AND length(trim(void_reason))>0)
  )
);
CREATE INDEX finance_expenses_period_idx ON finance_expenses(organization_id,branch_id,occurred_on DESC);
CREATE TABLE finance_budgets (
  organization_id uuid NOT NULL,
  branch_id uuid NOT NULL,
  period varchar(7) NOT NULL CHECK (period ~ '^(20[0-9]{2}|2100)-(0[1-9]|1[0-2])$'),
  category varchar(20) NOT NULL CHECK (category IN ('REVENUE','FOOD_COST','PAYROLL','RENT','UTILITIES','MARKETING','SERVICES','OTHER')),
  amount_cents bigint NOT NULL CHECK (amount_cents BETWEEN 0 AND 9999999999999),
  revision integer NOT NULL DEFAULT 1 CHECK(revision>0),
  updated_by uuid NOT NULL REFERENCES users(id),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (organization_id,branch_id,period,category),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id) ON DELETE CASCADE
);
