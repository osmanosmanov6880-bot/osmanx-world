-- R8 official POS integrations. No credentials in logs or audit metadata.
CREATE TABLE IF NOT EXISTS integration_connections (
  id uuid PRIMARY KEY,organization_id uuid NOT NULL,branch_id uuid NOT NULL,
  provider varchar(16) NOT NULL CHECK(provider='IIKO'),
  alias varchar(100) NOT NULL,remote_organization_id uuid NOT NULL,
  sealed_credentials text NOT NULL,
  state varchar(20) NOT NULL DEFAULT 'UNVERIFIED' CHECK(state IN('UNVERIFIED','VERIFIED','ERROR','DISABLED')),
  revision integer NOT NULL DEFAULT 1 CHECK(revision>=1),
  remote_organization_name varchar(160),verified_at timestamptz,last_error_code varchar(40),last_sync_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY(organization_id,branch_id) REFERENCES branches(organization_id,id) ON DELETE CASCADE,
  UNIQUE(organization_id,branch_id,id)
);
CREATE INDEX IF NOT EXISTS integrations_branch_idx ON integration_connections(organization_id,branch_id,created_at DESC);
CREATE TABLE IF NOT EXISTS integration_commands (
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  actor_id uuid NOT NULL REFERENCES users(id),
  idempotency_key varchar(100) NOT NULL,fingerprint char(64) NOT NULL,response jsonb NOT NULL,
  PRIMARY KEY(organization_id,actor_id,idempotency_key)
);
CREATE TABLE IF NOT EXISTS integration_sync_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),organization_id uuid NOT NULL,branch_id uuid NOT NULL,
  connection_id uuid NOT NULL,menu_id varchar(120) NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'QUEUED' CHECK(status IN('QUEUED','RUNNING','RETRY','SUCCEEDED','FAILED','CANCELLED')),
  attempt_count integer NOT NULL DEFAULT 0 CHECK(attempt_count BETWEEN 0 AND 5),
  next_attempt_at timestamptz NOT NULL DEFAULT now(),
  lease_token uuid,lease_until timestamptz,last_error_code varchar(40),items_count integer,
  created_at timestamptz NOT NULL DEFAULT now(),completed_at timestamptz,
  FOREIGN KEY(organization_id,branch_id,connection_id) REFERENCES integration_connections(organization_id,branch_id,id) ON DELETE CASCADE,
  UNIQUE(organization_id,branch_id,connection_id,id)
);
-- One pending/running job at a time per connector, to prevent duplicate provider calls.
CREATE UNIQUE INDEX IF NOT EXISTS integration_one_active_job_idx ON integration_sync_jobs(connection_id)
 WHERE status IN('QUEUED','RUNNING','RETRY');
CREATE INDEX IF NOT EXISTS integration_due_idx ON integration_sync_jobs(next_attempt_at,created_at)
 WHERE status IN('QUEUED','RUNNING','RETRY');
CREATE TABLE IF NOT EXISTS integration_catalog (
  organization_id uuid NOT NULL,branch_id uuid NOT NULL,connection_id uuid NOT NULL,
  external_id varchar(180) NOT NULL,name varchar(160) NOT NULL,category varchar(160) NOT NULL,
  price_cents bigint CHECK(price_cents BETWEEN 0 AND 999999999999),
  source_job_id uuid NOT NULL,synced_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(connection_id,external_id),
  FOREIGN KEY(organization_id,branch_id,connection_id) REFERENCES integration_connections(organization_id,branch_id,id) ON DELETE CASCADE,
  FOREIGN KEY(organization_id,branch_id,connection_id,source_job_id) REFERENCES integration_sync_jobs(organization_id,branch_id,connection_id,id)
);
CREATE INDEX IF NOT EXISTS integration_catalog_recent_idx ON integration_catalog(organization_id,branch_id,connection_id,source_job_id);
CREATE TABLE IF NOT EXISTS integration_menu_links (
  organization_id uuid NOT NULL,branch_id uuid NOT NULL,connection_id uuid NOT NULL,
  external_id varchar(180) NOT NULL,menu_item_id uuid NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(connection_id,external_id),
  UNIQUE(connection_id,menu_item_id),
  FOREIGN KEY(organization_id,branch_id,connection_id) REFERENCES integration_connections(organization_id,branch_id,id) ON DELETE CASCADE,
  FOREIGN KEY(organization_id,branch_id,menu_item_id) REFERENCES menu_items(organization_id,branch_id,id)
);
