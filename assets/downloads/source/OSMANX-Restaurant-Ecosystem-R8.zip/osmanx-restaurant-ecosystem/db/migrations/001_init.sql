-- OSMANX R1. Every branch-owned record carries organization and branch IDs.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE CHECK (email = lower(email)),
  display_name varchar(120) NOT NULL,
  password_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name varchar(160) NOT NULL,
  currency char(3) NOT NULL DEFAULT 'RUB' CHECK (currency ~ '^[A-Z]{3}$'),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE memberships (
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role varchar(40) NOT NULL CHECK (role IN ('owner','finance_director','operations_director','manager','chef','kitchen','waiter','cashier','marketer','analyst','auditor')),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (organization_id,user_id)
);
CREATE TABLE branches (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name varchar(160) NOT NULL,
  timezone varchar(60) NOT NULL DEFAULT 'Europe/Moscow',
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id), UNIQUE (organization_id,id)
);
CREATE INDEX branches_org_idx ON branches(organization_id);
CREATE TABLE branch_grants (
  organization_id uuid NOT NULL,
  branch_id uuid NOT NULL,
  user_id uuid NOT NULL,
  PRIMARY KEY (organization_id,branch_id,user_id),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id) ON DELETE CASCADE,
  FOREIGN KEY (organization_id,user_id) REFERENCES memberships(organization_id,user_id) ON DELETE CASCADE
);
CREATE TABLE sessions (
  token_hash char(64) PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX sessions_user_idx ON sessions(user_id);
CREATE TABLE invitations (
  token_hash char(64) PRIMARY KEY,
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  email text NOT NULL,
  role varchar(40) NOT NULL CHECK (role IN ('finance_director','operations_director','manager','chef','kitchen','waiter','cashier','marketer','analyst','auditor')),
  branch_ids uuid[] NOT NULL DEFAULT '{}'::uuid[],
  issued_by uuid NOT NULL REFERENCES users(id),
  expires_at timestamptz NOT NULL,
  redeemed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE menu_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,
  branch_id uuid NOT NULL,
  name varchar(160) NOT NULL,
  price_cents bigint NOT NULL CHECK (price_cents BETWEEN 0 AND 999999999999),
  active boolean NOT NULL DEFAULT true,
  revision integer NOT NULL DEFAULT 1 CHECK (revision > 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id,branch_id,id),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id) ON DELETE CASCADE
);
CREATE INDEX menu_branch_idx ON menu_items(organization_id,branch_id,active);
CREATE TABLE dining_tables (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,
  branch_id uuid NOT NULL,
  label varchar(30) NOT NULL,
  capacity integer NOT NULL CHECK (capacity BETWEEN 1 AND 40),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id,branch_id,id),
  UNIQUE (organization_id,branch_id,label),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id) ON DELETE CASCADE
);
CREATE TABLE orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,
  branch_id uuid NOT NULL,
  table_id uuid,
  status varchar(20) NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','SENT','PREPARING','READY','COMPLETED','CANCELLED')),
  total_cents bigint NOT NULL DEFAULT 0 CHECK (total_cents BETWEEN 0 AND 9999999999999),
  revision integer NOT NULL DEFAULT 1,
  created_by uuid NOT NULL REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  UNIQUE (organization_id,branch_id,id),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id),
  FOREIGN KEY (organization_id,branch_id,table_id) REFERENCES dining_tables(organization_id,branch_id,id),
  CHECK ((status = 'COMPLETED') = (completed_at IS NOT NULL))
);
CREATE UNIQUE INDEX one_active_order_per_table_idx ON orders(branch_id,table_id)
  WHERE table_id IS NOT NULL AND status NOT IN ('COMPLETED','CANCELLED');
CREATE INDEX orders_branch_created_idx ON orders(organization_id,branch_id,created_at DESC);
CREATE INDEX orders_completed_idx ON orders(organization_id,branch_id,completed_at) WHERE status='COMPLETED';
CREATE TABLE order_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,
  branch_id uuid NOT NULL,
  order_id uuid NOT NULL,
  menu_item_id uuid NOT NULL,
  name_snapshot varchar(160) NOT NULL,
  unit_price_cents bigint NOT NULL CHECK (unit_price_cents >= 0),
  quantity integer NOT NULL CHECK (quantity BETWEEN 1 AND 30),
  line_total_cents bigint GENERATED ALWAYS AS (unit_price_cents * quantity) STORED,
  FOREIGN KEY (organization_id,branch_id,order_id) REFERENCES orders(organization_id,branch_id,id) ON DELETE CASCADE,
  FOREIGN KEY (organization_id,branch_id,menu_item_id) REFERENCES menu_items(organization_id,branch_id,id)
);
CREATE INDEX lines_order_idx ON order_lines(order_id);
CREATE TABLE idempotency_records (
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  actor_id uuid NOT NULL REFERENCES users(id),
  operation_key varchar(100) NOT NULL,
  fingerprint char(64) NOT NULL,
  status_code integer,
  response jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (organization_id,actor_id,operation_key)
);
CREATE TABLE audit_events (
  id bigserial PRIMARY KEY,
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_id uuid,
  actor_id uuid NOT NULL REFERENCES users(id),
  action varchar(80) NOT NULL,
  entity_type varchar(60) NOT NULL,
  entity_id uuid NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id)
);
CREATE INDEX audit_events_org_idx ON audit_events(organization_id,created_at DESC);
