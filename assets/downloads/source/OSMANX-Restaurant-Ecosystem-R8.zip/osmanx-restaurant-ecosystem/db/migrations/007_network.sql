-- R7: network standards, immutable audit snapshots and corrective actions.
-- All organization/branch foreign keys enforce tenant isolation independently of API routing.
CREATE TABLE IF NOT EXISTS network_standards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id),
  title varchar(160) NOT NULL,
  description varchar(500) NOT NULL DEFAULT '',
  revision integer NOT NULL DEFAULT 1 CHECK(revision>=1),
  active boolean NOT NULL DEFAULT true,
  criteria jsonb NOT NULL CHECK(jsonb_typeof(criteria)='array'),
  created_by uuid NOT NULL REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id,id)
);
CREATE INDEX IF NOT EXISTS network_standards_org_idx ON network_standards(organization_id,active,title);
CREATE TABLE IF NOT EXISTS network_audits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,branch_id uuid NOT NULL,
  standard_id uuid NOT NULL,standard_title varchar(160) NOT NULL,
  standard_revision integer NOT NULL CHECK(standard_revision>0),
  answers jsonb NOT NULL CHECK(jsonb_typeof(answers)='array'),
  score_bps integer NOT NULL CHECK(score_bps BETWEEN 0 AND 10000),
  failed_count integer NOT NULL CHECK(failed_count>=0),
  critical_failures integer NOT NULL CHECK(critical_failures>=0),
  performed_by uuid NOT NULL REFERENCES users(id),
  performed_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id),
  FOREIGN KEY (organization_id,standard_id) REFERENCES network_standards(organization_id,id),
  UNIQUE (organization_id,branch_id,id)
);
CREATE INDEX IF NOT EXISTS network_audits_latest_idx ON network_audits(organization_id,branch_id,standard_id,performed_at DESC,id DESC);
CREATE TABLE IF NOT EXISTS network_corrective_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,branch_id uuid NOT NULL,
  audit_id uuid NOT NULL,
  standard_id uuid NOT NULL,
  standard_revision integer NOT NULL CHECK(standard_revision>0),
  criterion_id varchar(40) NOT NULL,
  title varchar(160) NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','IN_PROGRESS','RESOLVED')),
  resolution text,
  revision integer NOT NULL DEFAULT 1 CHECK(revision>0),
  created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (organization_id,branch_id,audit_id) REFERENCES network_audits(organization_id,branch_id,id),
  FOREIGN KEY (organization_id,standard_id) REFERENCES network_standards(organization_id,id),
  UNIQUE(organization_id,branch_id,id),
  UNIQUE(audit_id,criterion_id)
);
CREATE INDEX IF NOT EXISTS network_actions_open_idx ON network_corrective_actions(organization_id,branch_id,status,created_at DESC);
CREATE TABLE IF NOT EXISTS network_commands (
  organization_id uuid NOT NULL REFERENCES organizations(id),
  actor_id uuid NOT NULL REFERENCES users(id),
  idempotency_key varchar(100) NOT NULL,
  fingerprint text NOT NULL,
  result jsonb NOT NULL,
  PRIMARY KEY(organization_id,actor_id,idempotency_key)
);
