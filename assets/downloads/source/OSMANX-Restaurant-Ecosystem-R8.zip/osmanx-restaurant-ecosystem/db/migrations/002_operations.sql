-- R2: operational flow. Database constraints are authoritative under concurrent requests.
CREATE EXTENSION IF NOT EXISTS btree_gist;

CREATE TABLE reservations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,
  branch_id uuid NOT NULL,
  table_id uuid NOT NULL,
  guest_name varchar(120) NOT NULL,
  party_size integer NOT NULL CHECK (party_size BETWEEN 1 AND 40),
  starts_at timestamptz NOT NULL,
  ends_at timestamptz NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'CONFIRMED'
    CHECK (status IN ('CONFIRMED','SEATED','COMPLETED','CANCELLED','NO_SHOW')),
  revision integer NOT NULL DEFAULT 1 CHECK (revision > 0),
  created_by uuid NOT NULL REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (ends_at > starts_at),
  CHECK (ends_at <= starts_at + interval '4 hours'),
  UNIQUE (organization_id,branch_id,id),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id),
  FOREIGN KEY (organization_id,branch_id,table_id) REFERENCES dining_tables(organization_id,branch_id,id),
  -- The exclusion constraint prevents two concurrent bookings for the same table/time.
  CONSTRAINT reservations_no_overlap EXCLUDE USING gist (
    organization_id WITH =, branch_id WITH =, table_id WITH =,
    tstzrange(starts_at, ends_at, '[)') WITH &&
  ) WHERE (status = 'CONFIRMED')
);
CREATE INDEX reservations_branch_schedule_idx
  ON reservations(organization_id,branch_id,starts_at DESC);
CREATE INDEX reservations_guest_status_idx ON reservations(organization_id,branch_id,status);

ALTER TABLE orders ADD COLUMN reservation_id uuid;
ALTER TABLE orders ADD COLUMN sent_at timestamptz;
ALTER TABLE orders ADD COLUMN preparing_at timestamptz;
ALTER TABLE orders ADD COLUMN ready_at timestamptz;
ALTER TABLE orders ADD CONSTRAINT orders_reservation_fkey
  FOREIGN KEY (organization_id,branch_id,reservation_id)
  REFERENCES reservations(organization_id,branch_id,id);
CREATE UNIQUE INDEX orders_one_per_reservation_idx ON orders(organization_id,branch_id,reservation_id)
  WHERE reservation_id IS NOT NULL;
CREATE INDEX orders_kitchen_queue_idx ON orders(organization_id,branch_id,sent_at)
  WHERE status IN ('SENT','PREPARING','READY');

CREATE TABLE staff_shifts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,
  branch_id uuid NOT NULL,
  user_id uuid NOT NULL,
  opened_by uuid NOT NULL REFERENCES users(id),
  closed_by uuid REFERENCES users(id),
  opened_at timestamptz NOT NULL DEFAULT now(),
  closed_at timestamptz,
  opening_note varchar(500) NOT NULL DEFAULT '',
  closing_note varchar(500) NOT NULL DEFAULT '',
  status varchar(12) NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','CLOSED')),
  revision integer NOT NULL DEFAULT 1 CHECK (revision > 0),
  UNIQUE (organization_id,branch_id,id),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id),
  FOREIGN KEY (organization_id,user_id) REFERENCES memberships(organization_id,user_id),
  CHECK ((status = 'CLOSED') = (closed_at IS NOT NULL)),
  CHECK (closed_at IS NULL OR closed_at >= opened_at)
);
CREATE UNIQUE INDEX one_open_shift_per_worker_idx ON staff_shifts(organization_id,user_id) WHERE status='OPEN';
CREATE INDEX staff_shifts_branch_time_idx ON staff_shifts(organization_id,branch_id,opened_at DESC);
