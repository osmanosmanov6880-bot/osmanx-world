-- R3: stock quantities are integers measured in 1/1000 of g, ml or piece.
-- All balances and cost entries are stored as signed integer minor currency units.
CREATE TABLE ingredients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL, branch_id uuid NOT NULL,
  name varchar(160) NOT NULL,
  unit varchar(4) NOT NULL CHECK (unit IN ('g','ml','pcs')),
  min_quantity_milli bigint NOT NULL DEFAULT 0 CHECK (min_quantity_milli BETWEEN 0 AND 999999999999),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id,branch_id,id),
  UNIQUE (organization_id,branch_id,name),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id)
);
CREATE INDEX ingredients_branch_idx ON ingredients(organization_id,branch_id,name);
CREATE TABLE stock_balances (
  organization_id uuid NOT NULL, branch_id uuid NOT NULL, ingredient_id uuid NOT NULL,
  quantity_milli bigint NOT NULL DEFAULT 0 CHECK (quantity_milli BETWEEN 0 AND 999999999999),
  value_cents bigint NOT NULL DEFAULT 0 CHECK (value_cents BETWEEN 0 AND 9999999999999),
  revision integer NOT NULL DEFAULT 1 CHECK (revision>0),
  PRIMARY KEY (organization_id,branch_id,ingredient_id),
  FOREIGN KEY (organization_id,branch_id,ingredient_id) REFERENCES ingredients(organization_id,branch_id,id)
);
CREATE TABLE menu_recipes (
  organization_id uuid NOT NULL,branch_id uuid NOT NULL,menu_item_id uuid NOT NULL,
  revision integer NOT NULL DEFAULT 1 CHECK (revision>0),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (organization_id,branch_id,menu_item_id),
  FOREIGN KEY (organization_id,branch_id,menu_item_id) REFERENCES menu_items(organization_id,branch_id,id)
);
CREATE TABLE recipe_components (
  organization_id uuid NOT NULL,branch_id uuid NOT NULL,menu_item_id uuid NOT NULL,ingredient_id uuid NOT NULL,
  quantity_milli bigint NOT NULL CHECK (quantity_milli BETWEEN 1 AND 999999999999),
  PRIMARY KEY (organization_id,branch_id,menu_item_id,ingredient_id),
  FOREIGN KEY (organization_id,branch_id,menu_item_id) REFERENCES menu_recipes(organization_id,branch_id,menu_item_id) ON DELETE CASCADE,
  FOREIGN KEY (organization_id,branch_id,ingredient_id) REFERENCES ingredients(organization_id,branch_id,id)
);
CREATE TABLE suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,branch_id uuid NOT NULL,
  name varchar(160) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id,branch_id,id),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id)
);
CREATE TABLE purchase_receipts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,branch_id uuid NOT NULL,
  supplier_id uuid,
  reference varchar(100) NOT NULL DEFAULT '',
  total_cost_cents bigint NOT NULL CHECK(total_cost_cents BETWEEN 0 AND 9999999999999),
  received_by uuid NOT NULL REFERENCES users(id),
  received_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id,branch_id,id),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id),
  FOREIGN KEY (organization_id,branch_id,supplier_id) REFERENCES suppliers(organization_id,branch_id,id)
);
-- A manual retry with a NEW Idempotency-Key must not repeat a documented invoice.
-- Empty references are allowed for informal deliveries and are not deduplicated.
CREATE UNIQUE INDEX receipt_supplier_reference_unique ON purchase_receipts(organization_id,branch_id,supplier_id,reference)
  WHERE reference <> '' AND supplier_id IS NOT NULL;
CREATE UNIQUE INDEX receipt_no_supplier_reference_unique ON purchase_receipts(organization_id,branch_id,reference)
  WHERE reference <> '' AND supplier_id IS NULL;
CREATE TABLE purchase_receipt_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,branch_id uuid NOT NULL,receipt_id uuid NOT NULL,ingredient_id uuid NOT NULL,
  quantity_milli bigint NOT NULL CHECK(quantity_milli BETWEEN 1 AND 999999999999),
  total_cost_cents bigint NOT NULL CHECK(total_cost_cents BETWEEN 0 AND 9999999999999),
  FOREIGN KEY (organization_id,branch_id,receipt_id) REFERENCES purchase_receipts(organization_id,branch_id,id),
  FOREIGN KEY (organization_id,branch_id,ingredient_id) REFERENCES ingredients(organization_id,branch_id,id)
);
CREATE TABLE stock_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,branch_id uuid NOT NULL,ingredient_id uuid NOT NULL,
  delta_quantity_milli bigint NOT NULL CHECK (delta_quantity_milli <> 0),
  delta_value_cents bigint NOT NULL,
  reason varchar(20) NOT NULL CHECK (reason IN ('RECEIPT','ORDER','COUNT')),
  source_id uuid NOT NULL,
  actor_id uuid NOT NULL REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (organization_id,branch_id,ingredient_id) REFERENCES ingredients(organization_id,branch_id,id)
);
CREATE INDEX stock_movements_branch_idx ON stock_movements(organization_id,branch_id,created_at DESC);
CREATE UNIQUE INDEX stock_order_once_idx ON stock_movements(organization_id,branch_id,source_id,ingredient_id) WHERE reason='ORDER';
CREATE TABLE stock_counts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,branch_id uuid NOT NULL,ingredient_id uuid NOT NULL,
  before_quantity_milli bigint NOT NULL, counted_quantity_milli bigint NOT NULL,
  delta_quantity_milli bigint NOT NULL, delta_value_cents bigint NOT NULL,
  actor_id uuid NOT NULL REFERENCES users(id),
  counted_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (organization_id,branch_id,ingredient_id) REFERENCES ingredients(organization_id,branch_id,id)
);
CREATE INDEX stock_counts_branch_idx ON stock_counts(organization_id,branch_id,counted_at DESC);
-- R1/R2 completed orders have UNKNOWN historical cost (NULL); they are NOT silently revalued.
ALTER TABLE orders ADD COLUMN recipe_missing_lines integer;
ALTER TABLE orders ADD COLUMN actual_food_cost_cents bigint CHECK (actual_food_cost_cents BETWEEN 0 AND 9999999999999);
ALTER TABLE orders ADD COLUMN costed_at timestamptz;
-- Required for cross-branch-safe composite FK into existing R1 order lines.
ALTER TABLE order_lines ADD CONSTRAINT order_lines_scoped_id_unique UNIQUE (organization_id,branch_id,id);
CREATE TABLE order_recipe_snapshots (
  organization_id uuid NOT NULL,branch_id uuid NOT NULL,order_line_id uuid NOT NULL,
  ingredient_id uuid NOT NULL,quantity_milli bigint NOT NULL CHECK(quantity_milli BETWEEN 1 AND 999999999999),
  PRIMARY KEY (organization_id,branch_id,order_line_id,ingredient_id),
  FOREIGN KEY (organization_id,branch_id,order_line_id) REFERENCES order_lines(organization_id,branch_id,id),
  FOREIGN KEY (organization_id,branch_id,ingredient_id) REFERENCES ingredients(organization_id,branch_id,id)
);
CREATE TABLE restaurant_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,branch_id uuid NOT NULL,
  title varchar(160) NOT NULL,description varchar(1000) NOT NULL DEFAULT '',
  assigned_to uuid,created_by uuid NOT NULL REFERENCES users(id),
  status varchar(20) NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','IN_PROGRESS','DONE','CANCELLED')),
  due_at timestamptz, completed_at timestamptz,
  revision integer NOT NULL DEFAULT 1 CHECK(revision>0),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(organization_id,branch_id,id),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id),
  FOREIGN KEY (organization_id,assigned_to) REFERENCES memberships(organization_id,user_id),
  CHECK ((status='DONE')=(completed_at IS NOT NULL))
);
CREATE INDEX restaurant_tasks_due_idx ON restaurant_tasks(organization_id,branch_id,due_at) WHERE status IN ('OPEN','IN_PROGRESS');
