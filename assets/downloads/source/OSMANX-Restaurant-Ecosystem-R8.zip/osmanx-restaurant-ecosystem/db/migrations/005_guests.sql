-- R5 / Guest Intelligence. All guest data remains branch-scoped: no implicit cross-branch identity joins.
-- PII is never stored in order snapshots, and marketing consent is not inferred from purchases.
CREATE TABLE crm_guests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,
  branch_id uuid NOT NULL,
  display_name varchar(120) NOT NULL,
  email varchar(254),
  phone varchar(32),
  revision integer NOT NULL DEFAULT 1 CHECK (revision > 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id,branch_id,id),
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id) ON DELETE CASCADE
);
CREATE INDEX crm_guests_branch_page_idx ON crm_guests(organization_id,branch_id,id);
-- No UNIQUE email/phone: identity matching and cross-person merging require explicit verification.
CREATE TABLE guest_consents (
  organization_id uuid NOT NULL,
  branch_id uuid NOT NULL,
  guest_id uuid NOT NULL,
  channel varchar(10) NOT NULL CHECK(channel IN ('EMAIL','SMS')),
  state varchar(10) NOT NULL CHECK(state IN ('GRANTED','REVOKED')),
  evidence varchar(240),
  revision integer NOT NULL DEFAULT 1 CHECK(revision>0),
  recorded_by uuid NOT NULL REFERENCES users(id),
  recorded_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(organization_id,branch_id,guest_id,channel),
  FOREIGN KEY(organization_id,branch_id,guest_id) REFERENCES crm_guests(organization_id,branch_id,id) ON DELETE CASCADE,
  CONSTRAINT guest_consent_proof CHECK (state='REVOKED' OR (evidence IS NOT NULL AND length(trim(evidence))>=8))
);
ALTER TABLE orders ADD COLUMN guest_id uuid;
ALTER TABLE orders ADD CONSTRAINT orders_guest_scope_fk
  FOREIGN KEY (organization_id,branch_id,guest_id) REFERENCES crm_guests(organization_id,branch_id,id) ON DELETE SET NULL (guest_id);
CREATE INDEX orders_guest_visits_idx ON orders(organization_id,branch_id,guest_id,completed_at)
  WHERE status='COMPLETED' AND guest_id IS NOT NULL;
CREATE TABLE guest_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,
  branch_id uuid NOT NULL,
  guest_id uuid,
  order_id uuid,
  kind varchar(12) NOT NULL CHECK(kind IN ('COMPLAINT','COMPLIMENT','SUGGESTION')),
  rating smallint CHECK(rating BETWEEN 1 AND 5),
  comment varchar(1000),
  status varchar(12) NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','RESOLVED')),
  resolution varchar(1000),
  revision integer NOT NULL DEFAULT 1 CHECK(revision>0),
  created_by uuid NOT NULL REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_by uuid REFERENCES users(id),
  resolved_at timestamptz,
  FOREIGN KEY(organization_id,branch_id) REFERENCES branches(organization_id,id) ON DELETE CASCADE,
  FOREIGN KEY(organization_id,branch_id,guest_id) REFERENCES crm_guests(organization_id,branch_id,id),
  FOREIGN KEY(organization_id,branch_id,order_id) REFERENCES orders(organization_id,branch_id,id),
  CONSTRAINT feedback_content CHECK(rating IS NOT NULL OR comment IS NOT NULL),
  CONSTRAINT feedback_resolution CHECK(
    (status='OPEN' AND resolved_by IS NULL AND resolved_at IS NULL AND resolution IS NULL)
    OR (status='RESOLVED' AND resolved_by IS NOT NULL AND resolved_at IS NOT NULL AND resolution IS NOT NULL)
  )
);
CREATE INDEX guest_feedback_branch_idx ON guest_feedback(organization_id,branch_id,created_at DESC);
