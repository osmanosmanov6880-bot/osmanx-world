import {defineConfig,devices} from '@playwright/test';
export default defineConfig({
  testDir:'./tests/e2e',timeout:30000,retries:process.env.CI?1:0,workers:1,
  reporter:process.env.CI?'github':'list',
  use:{baseURL:'http://localhost:3000',trace:'retain-on-failure'},
  projects:[{name:'chromium-desktop',use:{...devices['Desktop Chrome']}},{name:'chromium-mobile',use:{...devices['Pixel 7']}}],
  webServer:[
    {command:'npm run dev:api',url:'http://localhost:4000/health/ready',timeout:120000,reuseExistingServer:!process.env.CI},
    {command:'npm run dev:web',url:'http://localhost:3000/login',timeout:120000,reuseExistingServer:!process.env.CI}
  ]
});
